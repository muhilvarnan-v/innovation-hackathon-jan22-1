from requests.api import post
from utils import dbutils, constants
from pprint import pprint
from utils import gupshuphelper as helper, util
from utils.gupshupconnector import post_to_gupshup
import sys
from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, Request, BackgroundTasks, Response
from pathlib import Path
import traceback
from utils.constants import OPTIONS
cur_dir = str(Path(Path(__file__).parent.parent).resolve())
print(cur_dir)
sys.path.append(cur_dir)


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

tracker = {}
greetings = ['hi', 'hello']


def find_user(contact, flow='seller'):
    try:
        if flow == "buyer":
            query = f"FOR prod in consumers SEARCH prod.contact_number == '{str(contact)}' RETURN prod.name"
        else:
            query = f"FOR prod in ecomm_en_view SEARCH prod.contact_number == '{str(contact)}' RETURN prod.contact_name"
        db = dbutils.get_db("hackathon_db")
        data = dbutils.run_query(query, db)
        print("data received from database")
        print(data)
        try:
            name = data['data'][0]
            is_registered = True
        except IndexError as e:
            name = ""
            is_registered = False
        return is_registered

    except Exception as e:
        print("Inside find user in")
        print(traceback.exc())


def initiate_buyer_flow(contact, dial_code, bgtask, context, lang):
    is_registered = find_user(dial_code, "buyer")
    if is_registered:
        sender_msg = helper.create_text_reply(
            util.get_lang_option("BUYER_TEXT_2", lang), contact)
        tracker[contact].update({'state': 'add_items', 'registered': True})
        bgtask.add_task(post_to_gupshup, sender_msg)
    else:
        sender_msg = helper.create_text_reply(
            util.get_lang_option("BUYER_TEXT_1", lang), contact)
        tracker[contact].update(
            {'state': "registration", 'substate': 'detail_1', 'registered': False})
        bgtask.add_task(post_to_gupshup, sender_msg)
    return


def initiate_seller_flow(contact, dial_code, bgtask, context, lang):
    try:
        is_registered = find_user(dial_code)
        if is_registered:
            sender_msg = helper.create_quick_reply(
                "SLR_PROCESS_BTN", util.get_lang_option("SLR_TEXT_13", lang), contact, lang)
            tracker[contact].update(
                {'state': 'processing', 'registered': is_registered})
            bgtask.add_task(post_to_gupshup, sender_msg)
        else:
            sender_msg = helper.create_quick_reply(
                'SLR_NEW_OPTION', util.get_lang_option("SLR_TEXT_3", lang), contact, lang)
            tracker[contact].update(
                {'state': "registration", 'registered': False})
            bgtask.add_task(post_to_gupshup, sender_msg)
        return
    except Exception as e:
        print("Inside find initiate seller flow")
        print(traceback.print_exc())


def add_items(contact, dial_code, bgtask, context, lang):
    if tracker[contact]['registered'] == True:
        sender_msg = helper.create_text_reply(
            'Enter the items, after completion enter done', contact)
        tracker[contact].update({'state': 'build_catalog'})
        bgtask.add_task(post_to_gupshup, sender_msg)
    return


def view_shop(contact, dial_code, bgtask, context, lang):
    if tracker[contact]['registered'] == True:
        sender_msg = helper.create_text_reply('your shop items', contact)
        tracker[contact].update({'state': 'view_shop'})
        bgtask.add_task(post_to_gupshup, sender_msg)
    else:
        sender_msg = helper.create_text_reply(
            'You are not registered, please register', contact)
        tracker[contact].update({'state': 22})
        bgtask.add_task(post_to_gupshup, sender_msg)
        


def get_store_address():
    pass


def select_user_type(contact, dial_code, bgtask, context, lang):
    if tracker[contact]['flow_owner'] == '':
        sender_msg = helper.create_quick_reply(
            "MAIN_OPTION", util.get_lang_option("SLR_TEXT_2", lang), contact, lang)
    else:
        sender_msg = helper.create_quick_reply(
            "SLR_PROCESS_BTN", util.get_lang_option("SLR_TEXT_13", lang), contact, lang)
    bgtask.add_task(post_to_gupshup, sender_msg)
    return


def registration_flow(msg_data, contact, dial_code, bgtask, lang):
    try:
        if tracker[contact]['registered'] is False and tracker[contact]['flow'] == constants.flow_dict["1"] and tracker[contact]['substate'] == '':
            sender_msg = helper.create_text_reply(
                util.get_lang_option("SLR_TEXT_4", lang), contact)
            tracker[contact]['substate'] = "detail_1"
            bgtask.add_task(post_to_gupshup, sender_msg)
            return
        if tracker[contact]['substate'] == 'detail_1':
            if tracker[contact]['flow'] == constants.flow_dict["1"]:
                tracker[contact]['shop_details']['merchant_name'] = msg_data['text']
                sender_msg = helper.create_text_reply(
                    util.get_lang_option("SLR_TEXT_5", lang), contact)
                tracker[contact]['substate'] = "detail_2"
            elif tracker[contact]['flow'] == constants.flow_dict["2"]:
                tracker[contact]['buyer_details']['name'] = msg_data['text']
                sender_msg = helper.create_text_reply(
                    util.get_lang_option("BUYER_TEXT_2", lang), contact)
                tracker[contact]['substate'] = 'share_loc'
            bgtask.add_task(post_to_gupshup, sender_msg)
            return Response()
        if tracker[contact]['substate'] == 'detail_2':
            tracker[contact]['shop_details']['store_name'] = msg_data['text']
            sender_msg = helper.create_quick_reply("SLR_PAYMENT_BTNS", util.get_lang_option(
                "SLR_TEXT_7", lang), contact, lang)  # ('Please Shop Name', contact)
            tracker[contact]['substate'] = "detail_3"
            bgtask.add_task(post_to_gupshup, sender_msg)
            return Response()
        if tracker[contact]['substate'] == 'detail_3':
            option = msg_data['reply'].split(" ")[-1]
            if option == "1":
                sender_msg = helper.create_quick_reply("SLR_FULFILLMENT_BTNS", util.get_lang_option(
                    "SLR_TEXT_8", lang), contact, lang)  # ('Please Shop Name', contact)
                tracker[contact]['substate'] = 'detail_5'
                tracker[contact]['shop_details']['payment_type'] = ["COD"]
                bgtask.add_task(post_to_gupshup, sender_msg)
                return Response()
            elif option == "2":
                tracker[contact]['substate'] = 'detail_4'
                tracker[contact]['shop_details']['payment_type'] = ["UPI"]
                sender_msg = helper.create_text_reply(
                    util.get_lang_option("SLR_TEXT_16", lang), contact)
                bgtask.add_task(post_to_gupshup, sender_msg)
                return Response()
        if tracker[contact]['substate'] == 'detail_4':
            tracker[contact]['shop_details']['payment_url'] = msg_data['text']
            sender_msg = helper.create_quick_reply("SLR_FULFILLMENT_BTNS", util.get_lang_option(
                "SLR_TEXT_8", lang), contact, lang)  # ('Please Shop Name', contact)
            tracker[contact]['substate'] = "detail_5"
            bgtask.add_task(post_to_gupshup, sender_msg)
            return Response()
        if tracker[contact]['substate'] == 'detail_5':
            option = msg_data['reply'].split(" ")[-1]
            if option == "1":
                tracker[contact]['shop_details']['fulfillment_type'] = [
                    "Self Delivery"]
            if option == "2":
                tracker[contact]['shop_details']['fulfillment_type'] = [
                    "Delivery Partner"]
            if option == "3":
                tracker[contact]['shop_details']['fulfillment_type'] = [
                    "In-Store Pickup"]
            sender_msg = helper.create_quick_reply(
                "SLR_DISTANCE_BTNS", util.get_lang_option("SLR_TEXT_9", lang), contact, lang)
            tracker[contact]['substate'] = "detail_6"
            bgtask.add_task(post_to_gupshup, sender_msg)
            return Response()
        if tracker[contact]['substate'] == 'detail_6':
            option = msg_data['reply'].split(" ")[-1]
            if option == "1":
                tracker[contact]['shop_details']['serving_radius'] = "5km"
            if option == "2":
                tracker[contact]['shop_details']['serving_radius'] = "10km"
            if option == "3":
                tracker[contact]['shop_details']['serving_radius'] = "15km"
            tracker[contact]['substate'] = "share_loc"
            sender_msg = helper.create_text_reply(util.get_lang_option("SLR_TEXT_6", lang).format(
                store_name=tracker[contact]['shop_details']['store_name']), contact)
            bgtask.add_task(post_to_gupshup, sender_msg)
            return Response()
        if tracker[contact]['substate'] == 'share_loc':
            if tracker[contact]['flow'] == constants.flow_dict["1"]:
                print("Tracing the location shared")
                if list(msg_data.keys()) == ['longitude', 'latitude']:
                    tracker[contact]['shop_details'].update(msg_data)
                else:
                    tracker[contact]['shop_details']['address'] = msg_data['text']
                    tracker[contact]['shop_details']['address_received'] = "manually"
                tracker[contact]['substate'] = "detail_7"
                sender_msg = helper.create_quick_reply(
                    "SLR_ACCEPT_BUTNS", util.get_lang_option("SLR_TEXT_10", lang), contact, lang)
                bgtask.add_task(post_to_gupshup, sender_msg)
                return Response()
            elif tracker[contact]['flow'] == constants.flow_dict["2"]:
                if list(msg_data.keys()) == ['longitude', 'latitude']:
                    sender_msg = helper.create_text_reply(
                        util.get_lang_option("BUYER_TEXT_3", lang), contact)
                    tracker[contact]['buyer_details'].update(msg_data)
                    tracker[contact]['substate'] = ""
                    tracker[contact]['state'] = "search"
                    bgtask.add_task(post_to_gupshup, sender_msg)
                    return Response()
        if tracker[contact]['substate'] == 'detail_7':
            option = msg_data['reply'].split(" ")[-1]
            if option == "1":
                sender_msg = helper.create_text_reply(
                    util.get_lang_option("SLR_TEXT_11", lang), contact)
                bgtask.add_task(post_to_gupshup, sender_msg)
                tracker[contact]['substate'] = ""
                tracker[contact]['state'] = "build_catalog"
                store = dbutils.build_store_from_gps(
                    **tracker[contact]['shop_details'], merchant_number=dial_code)
                return Response()
    except Exception as e:
        import traceback
        print(traceback.print_exc())


def buyer_flow(msg_data, contact, dial_code, bgtask, lang):
    if tracker[contact]['state'] == 'catalog':
        if list(msg_data.keys()) == ['longitude', 'latitude']:
            if False:
                tracker[contact]['registered'] = True
                tracker[contact]['shop_details'] = {}
                tracker[contact]['state'] = "catalog"
                sender_msg = he
    print("inside buyer flow")
    sender_msg = helper.create_text_reply(
        util.get_lang_option("BUYER_TEXT_1", lang), contact)
    bgtask.add_task(post_to_gupshup, sender_msg)


def user_operations(msg_data, contact, dial_code, bgtask, lang):
    option = msg_data['reply'].split(" ")[-1]
    if option == '1':
        sender_msg = helper.create_text_reply(
            util.get_lang_option("SLR_TEXT_17", lang), contact)
        tracker[contact]['state'] = 'update_catalog'
        bgtask.add_task(post_to_gupshup, sender_msg)
        return Response()


switcher = {
    "LNG_BTNS_1": select_user_type,
    "LNG_BTNS_2": select_user_type,
    "LNG_BTNS_3": select_user_type,
    "SLR_PROCESS_BTN_1": user_operations,
    "MAIN_OPTION_1": initiate_seller_flow,
    "MAIN_OPTION_2": initiate_buyer_flow,
    "SLR_NEW_OPTION_1": registration_flow,
    "SLR_NEW_OPTION_2": add_items,
    "SLR_NEW_OPTION_3": view_shop,
    "SLR_OPTION_1": add_items,
    "SLR_OPTION_2": view_shop,
    "SLR_LOCATION_1": registration_flow,
    "SLR_LOCATION_2": registration_flow
}


@app.post("/webhook")
async def response_from_gupshup(request: Request, bgtask: BackgroundTasks):
    try:
        rdata = await request.json()
        if rdata['type'] == 'message-event':
            return Response(status_code=200)
        else:
            print('***********TRACKER**************')
            pprint(tracker)
            msg_data = rdata['payload']['payload']
            msg_type = rdata['payload']['type']
            contact = rdata['payload']['sender']['phone']
            dial_code = rdata['payload']['sender']['dial_code']
            del rdata
            print(msg_data)
            context = ""
            if contact not in tracker:
                tracker[contact] = {'state': ""}
                tracker[contact] = {'flow_lng': ""}
            if msg_type.lower() == 'text':
                print("Text message received")
                text = msg_data['text']
                if text.lower() in greetings:
                    user = ""
                    sender_msg = helper.create_quick_reply(
                        "LNG_BTNS", util.get_lang_option("SLR_TEXT_1").format(user), contact)
                    bgtask.add_task(post_to_gupshup, sender_msg)
                    tracker[contact] = constants.tracker_obj
                    tracker[contact]['flow_owner'] = user
                    tracker[contact]['state'] = 'find_lng'
                    return Response()
                # if tracker[contact]['flow_lng'] != 'en' and tracker[contact]['flow_lng'] != "":
                #     text = util.translate(text, tracker[contact]['flow_lng'], "en")
                if tracker[contact]['state'] == 'registration':
                    print("calling registration flow")
                    registration_flow(msg_data, contact, dial_code,
                                      bgtask, tracker[contact]['flow_lng'])
                    return Response()
                else:
                    if tracker[contact]['state'] in ['build_catalog', 'update_catalog', 'search']:
                        print("updating or adding item")
                        if text.lower().replace(" ", "") not in ['done', 'completed', 'nomoreitemstoadd']:
                            tracker[contact]['items']['entered'].append(text)
                            print(
                                f"Items entered:  {tracker[contact]['items']['entered']}")
                            return Response()
                        print("*******Items Entered********")
                        bgtask.add_task(dbutils.parse_items, tracker[contact]['items']['entered'], tracker[contact]['shop_details'].get(
                            'store_name', ""), contact, dial_code, bgtask, tracker[contact]['flow'], tracker[contact]['flow_lng'], tracker)
                        if tracker[contact]['flow'] == constants.flow_dict['1']:
                            return Response()
                        elif tracker[contact]['flow'] == constants.flow_dict['2']:
                            tracker[contact]['state'] = 'search'
                            sender_msg = helper.create_text_reply(util.get_lang_option(
                                "BUYER_TEXT_4", tracker[contact]['flow_lng']), contact)
                            bgtask.add_task(post_to_gupshup, sender_msg)
                            return Response()
                    if tracker[contact]['state'] == 'view shop':
                        store_id = dbutils.get_store_id(dial_code)
                        shop_items = util.send_request(
                            "POST", f"{constants.base_url}/store/{store_id}/products", params=constants.url_params)
                        # bgtask.add_task(convert_data_as_per _whatsapp, shop_items, contact) ## todo write the code to convert as per requirement
                        return Response(content="Fetching the store data wait .....")
            elif msg_type.lower() == 'button_reply':
                if tracker[contact]['state'] == 'registration':
                    registration_flow(msg_data, contact, dial_code,
                                      bgtask, tracker[contact]['flow_lng'])
                    return Response()
                print("user replied with button")
                context = msg_data['id']
                option = msg_data['reply'].split(" ")[-1]
                key = f"{context}_{option}"
                if context == "SLR_PROCESS_BTN":
                    user_operations(msg_data, contact, dial_code,
                                    bgtask, tracker[contact]['flow_lng'])
                if context == "MAIN_OPTION":
                    tracker[contact]['flow'] = constants.flow_dict[option]
                if tracker[contact]['state'] == 'find_lng':
                    tracker[contact]['flow_lng'] = constants.lang_dict[option]
                    tracker[contact]['state'] = 'start'
                if tracker[contact]['state'] == 'select':
                    if option == '2':
                        bgtask.add_task(dbutils.parse_items, tracker[contact]['items']['entered'], tracker[contact]['shop_details'].get(
                            'store_name', ""), contact, dial_code, bgtask, tracker[contact]['flow'], tracker[contact]['flow_lng'], tracker)
                        return Response()
                    else:
                        sender_msg = helper.create_text_reply(util.get_lang_option("BUYER_TEXT_8", tracker[contact]['flow_lng']).format(
                            tracker[contact]['bill_amount']), tracker[contact]['flow_'])
                        tracker[contact] = constants.tracker_obj
                        tracker[contact]['state'] = 'confirmed'
                        return Response()
                print(f"user selected: {key}")
                print("switch_to: {}". format(f"{switcher[key]}"))
                bgtask.add_task(switcher[f"{context}_{option}"], contact,
                                dial_code, bgtask, context, tracker[contact]['flow_lng'])
            if msg_type.lower() == 'location':
                if tracker[contact]['state'] == 'registration':
                    registration_flow(msg_data, contact, dial_code,
                                      bgtask, tracker[contact]['flow_lng'])
                    return Response()
            if msg_type.lower() == 'list_reply':
                list1 = {
                    'providers': [
                        {
                            "provider_name": "मारुति स्टोर",
                            "items": [
                                {
                                    "item_name": "संतरा",
                                    "selling_price": 70,
                                    "currency_type": "Rs",
                                    "weight": 1,
                                    "weight_unit": "kg"
                                },
                                {
                                    "item_name": "केला",
                                    "selling_price": 60,
                                    "currency_type": "Rs",
                                    "weight": 500,
                                    "weight_unit": "g"
                                }
                            ]
                        }
                    ]
                }
            list2 = {
                'providers': [
                    {
                        "provider_name": "संसार मॉल",
                        "items": [
                            {
                                "item_name": "संतरा",
                                "selling_price": "Rs",
                                "currency_type": "INR",
                                "weight": 1,
                                "weight_unit": "kg"
                            },
                            {
                                "item_name": "केला",
                                "selling_price": 40,
                                "currency_type": "Rs",
                                "weight": 1,
                                "weight_unit": "kg"
                            }
                        ]
                    }
                ]
            }
            if tracker[contact]['state'] == 'select':
                amount = msg_data['title'].split(":")[-1]
                tracker[contact]['bill_amount'] = amount
                msg1 = msg_data['description'] + '\nTotal:' + amount
                msg2 = util.get_lang_option(
                    "BUYER_TEXT_6", tracker[contact]['flow_lng'])
                final_msg = msg1 + msg2
                sender_msg = helper.create_quick_reply(
                    "BUYER_CONFIRM_BTNS", final_msg, contact, tracker[contact]['flow_lng'])
                bgtask.add_task(post_to_gupshup, sender_msg)
                return Response()
            return Response()

    except Exception as e:
        print("Exception in webhook", e)
        traceback.print_exc()
        return Response()
