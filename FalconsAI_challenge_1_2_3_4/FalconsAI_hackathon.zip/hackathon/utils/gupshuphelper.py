from utils import util
import json


def create_quick_reply(context, msg, receiver, lang='en', sender='918217350525'):
    
    button_names = util.get_lang_option(context, lang.upper())
    print("button_names are ",button_names)
    #prefix = "option:["
    #suffix = "]"
    button_name_pattern = ""
    for each in button_names:
       button_name_pattern = button_name_pattern + '{"type":"text","title":' + '"' + each +'"},'

    button_name_pattern = button_name_pattern[:-1]
    print("button_name_pattern is ",button_name_pattern) 

    payload  = {
     'channel': 'whatsapp',
     'source': sender,
     'destination': receiver,
     'message': '{"msgid": "'+context+'","type":"quick_reply","content":{"type":"text","text":"'+msg+'","caption":" "},"options":[' + button_name_pattern+ ']}',
     'src.name': 'FalconsBot'
    }    

    return payload


def create_text_reply(message, receiver, sender='918217350525'):

    payload  = {
           'channel': 'whatsapp',
           'source': sender,
           'destination': receiver,
           'message': '{"type":"text","text": "' + message + '"}',
           'src.name': 'FalconsBot'
       }
    return payload

def create_image_reply(text, image_url, receiver, sender='918217350525'):

     payload = {
           'channel': 'whatsapp',
           'source': sender,
           'destination': receiver,
           'message': '{"type":"image","previewUrl":"' + image_url + '" , "originalUrl":"' + image_url + '","caption":"' + text + '"}',
           'src.name': 'FalconsBot'
       }

     return payload



def create_items_payload(items, provider_name):
    item_template = {
      "title": "",
      "subtitle": "dummy",
      "options": [
        {
          "type": "text",
          "title": "",
          "description": "",
          "postbackText": "Test Postback"
        }
      ]
    }
    item_template["title"] = provider_name
    description_str = ""
    count = 1
    order_total = 0
    for each in items:
        item_str = str(count) +  each['item_name'] + " " + str(each['weight']) + each['weight_unit'] + " - " + str(each['selling_price']) + each['currency_type']
        count = count + 1
        order_total = str(order_total) + str(each['selling_price'])
        description_str = description_str + item_str + '\n'

    description_str = description_str[:-1]
    print("Description str is",description_str )
    item_template["options"][0]['description'] = description_str
    item_template['options'][0]['title'] = 'Order Total :' + str(order_total) 
    print("Returning item_temlplate:", item_template)

    return item_template


def create_list_reply(data, receiver, sender='918217350525'):

   provider_name_string = ""
   json_template = {
      "type": "list",
      "title": "We were able to find following options",
      "body" : provider_name_string,
      "msgid": "list1",
      "globalButtons": [
        {
            "type": "text",
            "title": "Select one of them"
        }
      ],
      "items": [
      ]
   }

   item_list = []
   #json_template["body"] = 
   for each in data["providers"]:
       item_json = {}
       provider_name_string = each["provider_name"] + "\n" + provider_name_string
       items = each["items"]
       item_json = create_items_payload(items, each["provider_name"])
       print("item_list is ", item_list)
       item_list.append(item_json)       
      
   print("Itme list is : ", item_list)
   json_template["body"] = provider_name_string
   json_template["items"] = item_list
  
   print("json_template is ", json_template)
   string_template = json.dumps(json_template)
   #string_template = string_template.replace("'",'"')
   #string_template = '{"channel": "whatsapp", "source": "918217350525", "destination": "919972822344", "src.name": "FalconsBot", "message": "{"type": "list", "title": "We were able to find following options", "body": "Sansaar mall\nMaruthi stores", "msgid": "list1", "globalButtons": [{"type": "text", "title": "Please click and select one of them"}], "items": [{"title": "Maruthi stores", "subtitle": "dummy", "options": [{"type": "text", "title": "Order Total 100", "description": "1Apple 1kg - INR\n2Orange 1kg - INR", "postbackText": "Test Postback"}]}, {"title": "Sansaar mall", "subtitle": "dummy", "options": [{"type": "text", "title": "Order Total 100", "description": "1Apple 1kg - INR\n2Orange 1kg - INR", "postbackText": "Test Postback"}]}]}"}' 
   
   #string_template = json.dumps(json_payload)  
   print("Type of template is ", type(string_template))
   payload = {
    "channel" : "whatsapp",
    "source" : sender,
    "destination" : receiver,
    "src.name":"FalconsBot",
    #"message" : '{"type": "list", "title": "We were able to find following options", "body": "Maruthi Traders\\nNanjundeshwara traders", "msgid": "list1", "globalButtons": [{"type": "text", "title": "Select one of them"}], "items": [{"title": "Maruthi stores", "subtitle": "dummy", "options": [{"type": "text", "title": "Order Total :100", "description": "1Apple 1kg - INR2Orange 1kg - INR", "postbackText": "Test Postback"}]}, {"title": "Sansaar mall", "subtitle": "dummy", "options": [{"type": "text", "title": "Order Total :100", "description": "1Apple 1kg - INR2Orange 1kg - INR", "postbackText": "Test Postback"}]}]}'
    "message"  : string_template
}

   return payload






