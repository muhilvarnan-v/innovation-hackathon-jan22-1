# import gupshuphelper as gpshp
import requests

def count_words_at_url(url):
    """Just an example function that's called async."""
    resp = requests.get(url)
    return len(resp.text.split())

quick_data = {
     'channel': 'whatsapp',
     'source': '918217350525',
     'destination': '919972822344',
     'message': '{"type":"quick_reply","content":{"type":"text","text":"1 chai , 1 Veg Biryani","caption":"Order details"},"options":[{"type":"text","title":"Accept"},{"type":"text","title":"Reject"}]}',
     'src.name': 'FalconsBot'
   }


def post_to_gupshup(payload):

   print(" payload to send is", payload)

   headers = {
    'Cache-Control': 'no-cache',
    'Content-Type': 'application/x-www-form-urlencoded',
    'apikey': 'bdqqfg7haw7moriwla57bghkyypthrzn',
    'cache-control': 'no-cache',
   }

   response = requests.post('https://api.gupshup.io/sm/api/v1/msg', headers=headers, data=payload)
   print(response.status_code)
   print(response.text)
   if response.status_code == 200:
       resp_data = response.json()
   #print("response is ", resp_data)



#payload = gpshp.create_quick_reply("SLR_NEW_OPTION", "Please chose an option", "","")
#post_to_gupshup(payload)

