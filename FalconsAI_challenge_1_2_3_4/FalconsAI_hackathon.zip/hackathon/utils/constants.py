base_url = "https://sandbox.hitbyseo.com:8081/account/hackathon"
url = "http://65.2.62.107:8081/"

translation_url = "https://meity-auth.ulcacontrib.org/ulca/apis/v0/model/compute"
translation_model_ids = {
    "english_kannada": "6125c1940cebec3d5c2251ef",  # "6110f814014fa35d5e767c41"
    "english_hindi": "6110f7f7014fa35d5e767c3f",
    "hindi_english": "61c9ac1c8aa82374f4e6cbae",
    "kannada_english": "6125bffe0cebec3d5c2251e4"  # "6110f8c9014fa35d5e767c49"
}


url_params = {
    "accessToken": "falcons"
}
headers = {
    'Content-Type': 'Application/json'
}

lang_dict = {
    '1': 'en',
    '2': 'hi',
    '3': 'kn'
}

flow_dict = {
    '1': 'seller',
    '2': 'buyer'
}

OPTIONS = {
    "SLR_TEXT_1": "Welcome to ONDC {}, I am Aanya the ONDC Whatsapp bot.\nPlease select your preferred language",
    "LNG_BTNS": ['English', 'हिन्दी', 'ಕನ್ನಡ'],
    "SLR_TEXT_2": "Thank you for selecting English as your preferred language.\nPlease identify yourself",
    "MAIN_OPTION": ["I am a Seller", "I am a Buyer"],
    "SLR_TEXT_3": "Dear Seller, Thank you for showing interest in ONDC.  Please register yourself.",
    "SLR_NEW_OPTION": ["Register As A Seller"],
    "SLR_TEXT_4": "Please mention the name of the Shop Owner",
    "SLR_TEXT_5": "Please Enter the Shop Name",
    "SLR_TEXT_6": "Please set the address of  {store_name}.\nShare current GPS location or add manually. ",
    "SLR_LOCATION": ["Share Current Location", "Add Location Manually"],
    "SLR_TEXT_7": "Please Enter The Preferred Payment Method",
    "SLR_PAYMENT_BTNS": ["Cash On Delivery", "UPI"], 
    "SLR_TEXT_8": "Please Select The Mode Of Delivery",
    "SLR_FULFILLMENT_BTNS":["Self Delivery", "Delivery Partner", "In-Store Pickup"],
    "SLR_TEXT_9": "Preferred Delivery Area by Distance From Shop",
    "SLR_DISTANCE_BTNS": ["5km", "10km",  "15km"],
    "SLR_TEXT_10": "Please accept the T&C  to finish the onboarding \n https://ondc.com/T&C ",
    "SLR_ACCEPT_BUTNS": ["Accept", "Reject"],
    "SLR_TEXT_11": "Congratulations!\n You are now registered. \n Let us start adding products. Type Done when completed.",
    "SLR_TEXT_12": "Thank You! Your Shop is Now Ready.\n View your shop online at  https://ondc.com/mamatha-grocery",
    "SLR_TEXT_13": "What can i help you with ?",
    "SLR_PROCESS_BTN": ["Update Items","View Shop", "I am Done"],
    "SLR_TEXT_14": "Please add the items that you wish to add / update. Are type \"Done\" when completed.",
    "SLR_TEXT_15": "Your Items are updated successfully !",
    "SLR_TEXT_16": "Share UPI",
    "SLR_TEXT_17": "Please add the items that you wish to add / update. Are type Done when completed.",
    
    
    
    # "LNG_BTN_TEXT": "Select the Language",
    # "BTN_TEXT": "Select your option",
    
    # "SLR_OPTION": ["Add items", "View Shop"],
    
    "BYR_LOCATION": ["Add google map loc", "Add manually"],
    "BYR_ITEM_SEARCH": "Thank you. What would you like to buy",
    "BYR_LOCATION_AVLBL": "Following options are available",
    "BUYER_TEXT_1": "Enter your name",
    "BUYER_TEXT_2": "Please share the location to proceed",
    "BUYER_TEXT_3": "Great!, We are all set. What are you looking for ?",
    "BUYER_TEXT_4": "Searching products ...",
    "BUYER_TEXT_5": "Following merchants available near you. Click on any merchant to get price per product.",
    "BUYER_TEXT_6": "Thank You! Please confirm your order",
    "BUYER_CONFIRM_BTNS": ['Confirm Order', 'Edit Order'],
    "BUYER_TEXT_8": "Thank you. Your order is confirmed.\n You will need to pay Rs.{} to the delivery agent.\n Please find your tracking information :https://m.track.in/order/122345"
}

OPTIONS_HI = {
    "SLR_TEXT_1": "ONDC में आपका स्वागत है, मैं ONDC व्हाट्सएप बॉट अनन्या हूं।\nकृपया अपनी पसंदीदा भाषा चुनें",
    "LNG_BTNS": ['English', 'हिन्दी', 'ಕನ್ನಡ'],
    "SLR_TEXT_2": "हिंदी को अपनी पसंदीदा भाषा के रूप में चुनने के लिए धन्यवाद।\nकृपया अपनी पहचान बनाएं",
    "MAIN_OPTION": ["विक्रेता", "खरीदार"],
    "SLR_TEXT_3": "प्रिय विक्रेता, ONDC में रुचि दिखाने के लिए धन्यवाद। कृपया स्वयं को पंजीकृत करें।",
    "SLR_NEW_OPTION": ["रजिस्टर करें"],
    "SLR_TEXT_4": "कृपया दुकान के मालिक का नाम बताएं",
    "SLR_TEXT_5": "कृपया दुकान का नाम दर्ज करें",
    "SLR_TEXT_6": "कृपया {store_name} का पता सेट करें।\nवर्तमान GPS स्थान साझा करें या मैन्युअल रूप से जोड़ें।",
    "SLR_TEXT_7": "कृपया पसंदीदा भुगतान विधि दर्ज करें",
    "SLR_PAYMENT_BTNS": ["कैश", "UPI"],
    "SLR_LOCATION": ["गूगल मैप", "पता जोड़ें"],
    "SLR_TEXT_8": "कृपया डिलीवरी का तरीका चुनें",
    "SLR_FULFILLMENT_BTNS":["सेल्फ़ डिलीवरी", "डिलीवरी पार्टनर", "पिकअप"],
    "SLR_TEXT_9": "दुकान से दूरी के अनुसार पसंदीदा वितरण क्षेत्र",
    "SLR_DISTANCE_BTNS": ["5किमी", "10किमी", "15किमी"],
    "SLR_TEXT_10": "कृपया ऑनबोर्डिंग समाप्त करने के लिए नियम एवं शर्तें स्वीकार करें \n https://ondc.com/T&C ",
    "SLR_ACCEPT_BUTNS": ["स्वीकार", "अस्वीकार"],
    "SLR_TEXT_11": "बधाई हो!\n अब आप पंजीकृत हैं। \n चलिए उत्पादों को जोड़ना शुरू करते हैं। पूरा होने पर Done टाइप करें।",
    "SLR_TEXT_12": "धन्यवाद! आपकी दुकान अब तैयार है।\n https://ondc.com/parvati-grocery पर अपनी दुकान ऑनलाइन देखें",
    "SLR_TEXT_13": "आप और क्या करना चाहते हैं?",
    "SLR_PROCESS_BTN": ["सामान जोड़े", "शॉप देखें", "समाप्त"],
    "SLR_TEXT_14": "कृपया वे आइटम जोड़ें जिन्हें आप जोड़ना/अपडेट करना चाहते हैं। पूर्ण होने पर Done टाइप करें।",
    "SLR_TEXT_15": "आपके आइटम सफलतापूर्वक अपडेट हो गए हैं!",
    "SLR_TEXT_16": "UPI साझा करें",
    "BTN_TEXT": "एक चुनो",
    "SLR_OPTION": ["आइटम जोड़ें", "स्टोर देखे"],
    "BYR_LOCATION": ["गूगल मैप ", "पता जोड़ें"],
    "BYR_ITEM_SEARCH": "Thank you. What would you like to buy",
    "BYR_LOCATION_AVLBL": "Following options are available",
    "BYR_PAYMENT_BTNS": ["कैश", "UPI"],
    "BUYER_TEXT_1": "अपना नाम दर्ज करें",
    "BUYER_TEXT_2": "कृपया आगे बढ़ने के लिए स्थान साझा करें",
    "BUYER_TEXT_3": "अभी आप क्या ढूंढ रहे हैं",
    "BUYER_TEXT_4": "उत्पाद खोज रहे हैं ...",
    "BUYER_TEXT_5": "{} विकल्प आपके आस-पास उपलब्ध हैं",
    "BUYER_TEXT_6": "भुगतान विधि चुनें",
    "BUYER_CONFIRM_BTNS" : ["स्विकार", "परिवर्तन"],
    "BUYER_TEXT_8": "शुक्रिया। आपके आदेश की पुष्टि हो गई है।\n आपको डिलीवरी एजेंट को रु.{} का भुगतान करना होगा।\n कृपया अपनी ट्रैकिंग जानकारी प्राप्त करें:https://m.track.in/order/122345"
}

OPTIONS_KN = {
    "SLR_TEXT_1": "ONDC ಗೆ ಸುಸ್ವಾಗತ, ನಾನು Aanya ONDC Whatsapp ಬಾಟ್.\nದಯವಿಟ್ಟು ನಿಮ್ಮ ಆದ್ಯತೆಯ ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ",
    "LNG_BTNS": ['ಇಂಗ್ಲಿಷ್', 'ಹಿಂದಿ', 'ಕನ್ನಡ'],
    "SLR_TEXT_2": "ನಿಮ್ಮ ಆದ್ಯತೆಯ ಭಾಷೆಯಾಗಿ ಕನ್ನಡ ಆಯ್ಕೆ ಮಾಡಿದ್ದಕ್ಕಾಗಿ ಧನ್ಯವಾದಗಳು.\nದಯವಿಟ್ಟು ನಿಮ್ಮನ್ನು ಗುರುತಿಸಿಕೊಳ್ಳಿ",
    "MAIN_OPTION": ["ಮಾರಾಟಗಾರ", "ಖರೀದಿದಾರ"],
    "SLR_TEXT_3": "ಆತ್ಮೀಯ ಮಾರಾಟಗಾರರೇ, ONDC ನಲ್ಲಿ ಆಸಕ್ತಿ ತೋರಿಸಿದ್ದಕ್ಕಾಗಿ ಧನ್ಯವಾದಗಳು. ದಯವಿಟ್ಟು ನೀವೇ ನೋಂದಾಯಿಸಿ.",
    "SLR_NEW_OPTION": ["ನೋಂದಾಯಿಸಿ"],
    "SLR_TEXT_4": "ದಯವಿಟ್ಟು ಅಂಗಡಿ ಮಾಲೀಕರ ಹೆಸರನ್ನು ನಮೂದಿಸಿ",
    "SLR_TEXT_5": "ದಯವಿಟ್ಟು ಅಂಗಡಿಯ ಹೆಸರನ್ನು ನಮೂದಿಸಿ",
    "SLR_TEXT_6": "ದಯವಿಟ್ಟು {store_name} ನ ವಿಳಾಸವನ್ನು ಹೊಂದಿಸಿ.\nಪ್ರಸ್ತುತ GPS ಸ್ಥಳವನ್ನು ಹಂಚಿಕೊಳ್ಳಿ ಅಥವಾ ಹಸ್ತಚಾಲಿತವಾಗಿ ಸೇರಿಸಿ. ",
    "SLR_LOCATION": ["google live location", "ಸ್ಥಳವನ್ನು ಸೇರಿಸಿ"],
    "SLR_TEXT_7": "ದಯವಿಟ್ಟು ಆದ್ಯತೆಯ ಪಾವತಿ ವಿಧಾನವನ್ನು ನಮೂದಿಸಿ",
    "SLR_PAYMENT_BTNS": ["COD", "UPI"],
    "SLR_TEXT_8": "ದಯವಿಟ್ಟು ಡೆಲಿವರಿ ಮೋಡ್ ಅನ್ನು ಆಯ್ಕೆ ಮಾಡಿ",
    "SLR_FULFILLMENT_BTNS":["ಸ್ವಯಂ", "ವಿತರಣಾ", "ಇನ್-ಸ್ಟೋರ್"],
    "SLR_TEXT_9": "ಅಂಗಡಿಯಿಂದ ದೂರದ ಮೂಲಕ ಆದ್ಯತೆಯ ವಿತರಣಾ ಪ್ರದೇಶ",
    "SLR_DISTANCE_BTNS": ["5km", "10km", "15km"],
    "SLR_TEXT_10": "ಆನ್‌ಬೋರ್ಡಿಂಗ್ ಅನ್ನು ಪೂರ್ಣಗೊಳಿಸಲು ದಯವಿಟ್ಟು T&C ಅನ್ನು ಒಪ್ಪಿಕೊಳ್ಳಿ \n https://ondc.com/T&C ",
    "SLR_ACCEPT_BUTNS": ["ಸ್ವೀಕರಿಸಿ", "ತಿರಸ್ಕರಿಸಿ"],
    "SLR_TEXT_11": "ಅಭಿನಂದನೆಗಳು!\n ನೀವು ಈಗ ನೋಂದಾಯಿಸಿರುವಿರಿ. \n ಉತ್ಪನ್ನಗಳನ್ನು ಸೇರಿಸಲು ಪ್ರಾರಂಭಿಸೋಣ. ಪೂರ್ಣಗೊಂಡಾಗ ಮುಗಿದಿದೆ ಎಂದು ಟೈಪ್ ಮಾಡಿ.",
    "SLR_TEXT_12": "ಧನ್ಯವಾದಗಳು! ನಿಮ್ಮ ಅಂಗಡಿ ಈಗ ಸಿದ್ಧವಾಗಿದೆ.\n ನಿಮ್ಮ ಅಂಗಡಿಯನ್ನು ಆನ್‌ಲೈನ್‌ನಲ್ಲಿ https://ondc.com/maruthi-grocery ನಲ್ಲಿ ವೀಕ್ಷಿಸಿ",
    "SLR_TEXT_13": "ನೀವು ಇನ್ನೇನು ಮಾಡಲು ಬಯಸುತ್ತೀರಿ?",
    "SLR_PROCESS_BTN": ["ಐಟಂ ನವೀಕರಿಸಿ", "ವೀಕ್ಷಣೆ ಮಳಿಗೆ", "ನಾನು ಮುಗಿಸಿದ್ದೇನೆ"],
    "SLR_TEXT_14": "ನೀವು ಸೇರಿಸಲು / ನವೀಕರಿಸಲು ಬಯಸುವ ಐಟಂಗಳನ್ನು ದಯವಿಟ್ಟು ಸೇರಿಸಿ. ಪೂರ್ಣಗೊಂಡಾಗ \"ಮುಗಿದಿದೆ\" ಎಂದು ಟೈಪ್ ಮಾಡಿ.",
    "SLR_TEXT_15": "ನಿಮ್ಮ ಐಟಂಗಳನ್ನು ಯಶಸ್ವಿಯಾಗಿ ನವೀಕರಿಸಲಾಗಿದೆ!",
    "SLR_TEXT_16": "UPI ಹಂಚಿಕೊಳ್ಳಿ",
    "BYR_LOCATION": ["google map loc ಸೇರಿಸಿ", "ಹಸ್ತಚಾಲಿತವಾಗಿ ಸೇರಿಸಿ"],
    "BYR_ITEM_SEARCH": "ಧನ್ಯವಾದಗಳು. ನೀವು ಏನನ್ನು ಖರೀದಿಸಲು ಬಯಸುತ್ತೀರಿ",
    "BYR_LOCATION_AVLBL": "ಕೆಳಗಿನ ಆಯ್ಕೆಗಳು ಲಭ್ಯವಿದೆ",
    "BUYER_TEXT_1": "ನಿಮ್ಮ ಹೆಸರನ್ನು ನಮೂದಿಸಿ",
    "BUYER_TEXT_2": "ಮುಂದುವರಿಯಲು ದಯವಿಟ್ಟು ಸ್ಥಳವನ್ನು ಹಂಚಿಕೊಳ್ಳಿ",
    "BUYER_TEXT_3": "ಅದ್ಭುತ!, ನಾವು ಸಿದ್ಧರಾಗಿದ್ದೇವೆ. ನೀವು ಏನನ್ನು ಹುಡುಕುತ್ತಿದ್ದೀರಿ ?",
    "BUYER_TEXT_4": "ಉತ್ಪನ್ನಗಳನ್ನು ಹುಡುಕಲಾಗುತ್ತಿದೆ ...",
    "BUYER_TEXT_5": "ನಿಮ್ಮ ಸಮೀಪದಲ್ಲಿ ಲಭ್ಯವಿರುವ ವ್ಯಾಪಾರಿಗಳನ್ನು ಅನುಸರಿಸುತ್ತಿದ್ದಾರೆ. ಪ್ರತಿ ಉತ್ಪನ್ನದ ಬೆಲೆಯನ್ನು ಪಡೆಯಲು ಯಾವುದೇ ವ್ಯಾಪಾರಿಯ ಮೇಲೆ ಕ್ಲಿಕ್ ಮಾಡಿ.",
    "BUYER_TEXT_6": "ಧನ್ಯವಾದಗಳು! ದಯವಿಟ್ಟು ನಿಮ್ಮ ಆದೇಶವನ್ನು ದೃಢೀಕರಿಸಿ",
    "BUYER_CONFIRM_BTNS": ['ದೃಢೀಕರಿಸಿ', 'ಸಂಪಾದಿಸಿ'],
    "BUYER_TEXT_8": "ಧನ್ಯವಾದಗಳು. ನಿಮ್ಮ ಆದೇಶವನ್ನು ದೃಢೀಕರಿಸಲಾಗಿದೆ.\n ನೀವು ಡೆಲಿವರಿ ಏಜೆಂಟ್‌ಗೆ ರೂ.{} ಪಾವತಿಸಬೇಕಾಗುತ್ತದೆ.\n ದಯವಿಟ್ಟು ನಿಮ್ಮ ಟ್ರ್ಯಾಕಿಂಗ್ ಮಾಹಿತಿಯನ್ನು ಹುಡುಕಿ :https://m.track.in/order/122345 "
}

tracker_obj = {
    'flow_lng': '',
    'flow': '',
    'flow_owner': '',
    'state': 'start',
    'substate': '',
    'registered': None,
    'items': {
        'entered': [],
        'processed': []
    },
    'shop_details': {},
    'buyer_details': {}
}

db_name = 'hackathon_db'
user_name = "root"
password = "Admin123"

NAME = "name"
PRICE_RANG = "price_range"
ENTITIS = "entities"

# Arango view name
ECOMM_EN_VIEW = "ecomm_en_view"
catalog = "ecomm_it_view"

# AQL lang constants used in queries
EN_AQL_LANG_CONST = "text_en"
IT_AQL_LANG_CONST = "text_it"


ARANGO_SEARCH = "arangosearch"
NAME = "name"
PRICE_RANGE = 'price_range'
ENTITIES = "entities"

DB = "db"
UNDERSCORE = "_"

ARANGO_HOST = "arango_host"
ARANGO_CLOUD = "arangodb.cloud"