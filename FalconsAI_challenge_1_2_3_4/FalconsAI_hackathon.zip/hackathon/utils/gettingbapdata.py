from aiohttp import ClientSession
import json
from pprint import pprint
headers = {
  'Content-Type': 'application/json'
}

url = 'https://qa.api.box.beckn.org/bap/client/v1/{}'


async def trigger_request(method, url, request_data=None, headers=None):
    async with ClientSession() as session:
        pprint(request_data)
        async with session.request(method, url, data=request_data, headers=headers) as resp:
            response=await resp.json()
            return response
        



async def search_inventory(search_item, latitude, longitude):
    payload = json.dumps({
    'context': {
        'bpp_id': 'sandbox.hitbyseo.com/v1/beckn/ns_a2zshop'
    },
    'message': {
        'criteria': {
        'search_string': search_item,  # 'apple+orange',
        'delivery_location': f'{latitude},{longitude}', # '12.903561,77.5939631'
        }
    }
    })
    search_url = url.format('search')
    response = await trigger_request('POST', search_url, payload, headers)
    if response['message']['ack']['status'] == 'ACK':
        items_found = await get_bpp_response(response['context']['message_id'])
        pprint(items_found)


async def get_bpp_response(message_id):
    url = f'https://qa.api.box.beckn.org/bap/client/v1/on_search?messageId={message_id}'
    response = await trigger_request('GET', url)
    catalog = response.get('message', {}).get('catalogs')
    whatsapp_resp = []
    for each in catalog:
        provider_data = {}
        providers = each.get('bpp_providers')
        for provider in providers:
            items = []
            provider_data['provider_name'] = provider['descriptor']['name']
            provider_data['provider_id'] = provider['id']
            provider_items = provider.get('items')
            for i in provider_items:
                temp={}
                temp['item_name'] = i['descriptor']['name']
                temp['item_image'] = i['descriptor']['images'][0]
                temp['item_price'] = f"{i['price']['currency']} {i['price']['value']}"
                items.append(temp)
            provider_data['items'] = items
        whatsapp_resp.append(provider_data)
    return whatsapp_resp




import asyncio

asyncio.run(search_inventory('apple+orrange', 12.903561, 77.5939631))

