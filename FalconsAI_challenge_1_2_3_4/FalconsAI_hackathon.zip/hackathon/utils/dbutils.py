from arango import ArangoClient
import traceback
import json
from pprint import pprint
from uuid import uuid4
from utils import constants
from pathlib import Path
from utils import util
from utils.gupshupconnector import post_to_gupshup
from utils import gupshuphelper as helper
import requests


def get_db(name='hackathon_db', hosts='http://sandbox.hitbyseo.com:8529'):
    client = ArangoClient(hosts)
    return client.db(name=name, username='root', password='admin123')


def run_query(query, db):
    print('Executing the query')
    try:
        return_data = {'data': []}
        aql = db.aql
        result = aql.execute(query, True)
        if result.__len__() > 0:
            for res in result:
                return_data['data'].append(res)
        return return_data
    except ConnectionError as e:
        print(traceback.print_exc())
    except Exception as e:
        print(traceback.print_exc())


def get_store_id(contact):
    db = get_db()
    query = f"FOR store in ecomm_en_view SEARCH store.contact_number=='{str(contact)}' RETURN store.nearshop_store_id"
    store_id = run_query(query, db)['data'][0]
    return store_id


def build_store_from_gps(store_name, merchant_name, latitude, longitude, merchant_number, **kwargs):
    store = {}
    store['name'] = store_name
    store['description'] = "retail shop"
    store['location'] = {'lat': latitude, 'lng': longitude}
    store['contact_name'] = merchant_name
    store['contact_number'] = merchant_number
    store['contact_email'] = ""
    store['business_number'] = merchant_number
    store['category'] = ""
    store['sub_category'] = ""
    store['rating'] = 3.0
    store['serving_radius'] = kwargs.get('serving_radius', 0)
    fulfillment_type = kwargs.get('fulfillment_type')
    store['delivery_type'] = fulfillment_type
    if 'Home Delivery' in fulfillment_type:
        store['delivery_support_required'] = True
    else:
        store['delivery_support_required'] = False
    store['minimum_order_size'] = 0
    store['helpline_number'] = merchant_number
    store['license_number'] = ""
    store['tax_number'] = ""
    store['website'] = ""
    store['store_type'] = 'retail shop'
    store['payment'] = {'payment_type': kwargs.get(
        'payment_type', []), 'payment_uri': kwargs.get('payment_uri', "")}
    store['terms'] = {}
    store['support_timings'] = {}
    if kwargs.get('address_received', None) == "manually":
        store['address'] = kwargs.get('address', '')
        store['country'] = ""
        store['state'] = ""
        store['pin_code'] = ""
        store['district'] = ""
        store['city'] = ""
    else:
        address, location_details = util.get_details_from_gps(
            latitude, longitude)
        store['address'] = address
        store['country'] = location_details['address'].get('country', '')
        store['state'] = location_details['address'].get('state', '')
        store['pin_code'] = location_details['address'].get('postcode', '')
        store['district'] = location_details['address'].get(
            'state_district', '')
        store['city'] = location_details['address'].get('city', '')
    store['image'] = []
    store['nearshop_store_id'] = str(uuid4())
    pprint(store)
    resp = util.send_request(
        'POST', f"{constants.base_url}/store", store, constants.headers, constants.url_params)
    pprint(resp)
    if 'storeId' in resp:
        return store
    return {}

    # Todo keep store_id and phone_number mapping


# build_store_from_gps("shenoy_mobiles", "Sandeep Shenoy", 14.170429647261772, 75.0236178106726, 9036110969)
# store_id = 78556efb-ad3d-4487-863c-1c3e5d41df50
def get_product_image(item_name):
    inventory_file_path = Path("utils/imageinventory.json")
    product = {}
    print(inventory_file_path)
    with open(inventory_file_path, "r") as fp:
        inventory_data = json.load(fp)
    for each in inventory_data.get("fields", [{}]):
        s1 = set(item_name.lower().split(" "))
        product_name = each.get('product_name').lower()
        s2 = set(product_name.split(" "))
        if s1.issubset(s2) or s1.issuperset(s2):
            product['images'] = [each.get('product_image')]
            product['category_name'] = each.get('category')
            product['sub_category_name'] = each.get('subcategory')
            break
        else:
            product['images'] = [
                'https://www.freeiconspng.com/thumbs/no-image-icon/no-image-icon-15.png']
            product['category_name'] = ''
            product['sub_category_name'] = ''
    return product


def build_product(item_name, price, weight=1, weight_unit="kg", **kwargs):
    try:
        product = {}
        product['name'] = item_name
        product['selling_price'] = price
        product['price'] = price
        product['description'] = ""
        product['in_stock'] = True
        product['stock_in_hand'] = 10
        product['weight'] = weight
        product['weight_unit'] = weight_unit
        product['on_sale_flag'] = True
        product['discount_percent'] = 0
        product['rating'] = 4.5
        product['reviews'] = ""
        product['tags'] = []
        product['delivery_timeline'] = "30 minutes"
        product['id'] = str(uuid4())
        product.update(get_product_image(item_name))
        product['currency'] = kwargs.get('currency', "INR")
        return product
    except ValueError as e:
        return {}


def parse_items(items, provider_name, contact, dial_code, bgtask, flow, lang, tracker):
    print(f'Parsing items')
    data = []
    for each in items:
        if 'and' in each:
            data.extend(each.split("and"))
        else:
            data.append(each)
    print(data)
    data = ['banana 1 kg 50', 'orange 1 kg 70', 'apple 1 kg 100']
    response = requests.post("http://65.2.62.107:8081/parse_text",
                                json=data, headers={'content-type': 'Application/Json'})
    print(response.text)
    if response.status_code == 200:
        processed_items = []
        for each in response.json():
            name = each.pop('name', [])
            try:
                price = each.pop('price')[0]
            except Exception as ie:
                price = ""
            try:
                currency = each.pop('currency')[0]
            except Exception as ie:
                currency = "INR"
            try:
                weight = each.pop('weight')[0]
            except Exception as ie:
                weight = ""
            try:
                weight_unit = each.pop('weight_unit')[0]
            except Exception as ie:
                weight_unit = ""
            for i in name:
                items = {}
                items['item_name'] = i
                items['price'] = price
                items['currency'] = currency
                items['weight'] = weight
                items['weight_unit'] = weight_unit
                processed_items.append(items)
    if provider_name == "":
        search_product(processed_items, dial_code, bgtask, contact, tracker)
    else:
        insert_product(processed_items, provider_name,
                       dial_code, bgtask, contact, lang)
    return


def insert_product(products, provider_name, merchant_number, bgtask, receiver, lang):
    # take an input as [{item_name: "", price: "", weight: float, weight_unit:""}]
    product_list = []
    error_list = []
    # for index, each in enumerate(products):
    for index, each in enumerate(products):
        each['provider_name'] = provider_name
        product = build_product(**each)
        if product:
            product_list.append(product)
        else:
            error_list.append(index)
    payload = {
        'data': product_list
    }
    store_id = get_store_id(merchant_number)
    print(store_id,    merchant_number)
    pprint(payload)
    resp = util.send_request(
        'POST', f"{constants.base_url}/store/{store_id}/products", payload, constants.headers, constants.url_params)
    print(resp)
    if resp['code'] == 200:
        sender_msg = helper.create_text_reply(
            util.get_lang_option("SLR_TEXT_12", lang), receiver)
        bgtask.add_task(post_to_gupshup, sender_msg)
    return


def store_buyer(data):
    resp = util.send_request(
        'POST', f"{constants.base_url}/buyer", data, constants.headers, constants.url_params)
    if resp['code'] == 200:
        print('buyer added successfully')
    else:
        print('buyer not uploaded')


def search_product(products, dial_code, bgtask, contact, tracker):
    lang = tracker[contact]['flow_lng']
    data = {
        'providers': [
            {
                "provider_name": "मारुति स्टोर",
                "items": [
                    {
                        "item_name": "संतरा",
                        "selling_price": 70,
                        "currency_type": "Rs",
                        "weight": 1,
                        "weight_unit": "kg"
                    },
                    {
                        "item_name": "केला",
                        "selling_price": 60,
                        "currency_type": "Rs",
                        "weight": 500,
                        "weight_unit": "g"
                    }
                ]
            },
            {
                "provider_name": "संसार मॉल",
                "items": [
                    {
                        "item_name": "संतरा",
                        "selling_price": "Rs",
                        "currency_type": "INR",
                        "weight": 1,
                        "weight_unit": "kg"
                    },
                    {
                        "item_name": "केला",
                        "selling_price": 40,
                        "currency_type": "Rs",
                        "weight": 1,
                        "weight_unit": "kg"
                    }
                ]
            }
        ]
    }

    # build search either add end point to kg search or use postman and collect response
    # Todo process the
    sender_msg = helper.create_list_reply(data, contact)
    tracker[contact]['state'] = 'select'
    bgtask.add_task(post_to_gupshup, sender_msg)
    pass

# insert_product([{'item_name': 'banana', 'price': 60,
#                'weight': 1, 'weight_unit': 'kg'}], 9036110969)


# query = f"FOR prod in ecomm_en_view SEARCH prod.contact_number == '9036110969' RETURN true"

# get_store_id(9036110969)
