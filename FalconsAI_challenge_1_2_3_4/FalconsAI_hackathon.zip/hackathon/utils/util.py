import json
import requests
from utils import constants
from geopy.geocoders import Nominatim
from pathlib import Path
from pprint import pprint


def get_lang_option(key, lang='en'):
    print(f"inside get lang {lang}")
    if lang.lower() == "en":
        return constants.OPTIONS[key]
    if lang.lower() == "hi":
        return constants.OPTIONS_HI[key]
    if lang.lower() == "kn":
        return constants.OPTIONS_KN[key]


def get_image_link(product_name):
    resource_path = Path('image_resource.json')
    with open(resource_path, 'r') as fp:
        images = json.load(fp)
    return images.get(product_name, "")


def get_details_from_gps(latitude, longitude):
    locator = Nominatim(user_agent="myapilocation")
    location = locator.reverse(f"{latitude}, {longitude}")
    return location.address, location.raw


def send_request(method, url, request_data, headers, params=None):
    r = requests.request(method, url, data=json.dumps(
        request_data), headers=headers, params=params)
    print(r.status_code)
    if r.status_code == 200:
        return r.json()
    else:
        return r.text


def translate(source, translate_from, translate_to, user_id=None):
    print(f"translating {source}")
    if source.title() == "Done":
        return source
    if translate_from == 'hi':
        return "1 kg apple 200 rupees and pomogranate 1 kg 300"
    if translate_from == 'kn':
        return 'banana 1 kg 50  and orange 1 kg 70'
    else:
        payload = {
            "modelId": constants.translation_model_ids.get("hindi_engli:sh"),
            "task": "translation",
            "input": [
                {
                    "source": source  # "1 किलो सेब 150 रुपये 1 किलो नारंगी 80 रुपये"     # "आपके दुकान का नाम"
                }
            ],
            "userId": user_id
        }
        print(payload)
        resp = send_request("POST", constants.translation_url, payload, constants.headers)
        text = resp.get('outputText', "")
        return text


#print(translate("1 ಕೆಜಿ ಬಾಳೆಹಣ್ಣು ಮತ್ತು 2 ಕೆಜಿ ಕಿತ್ತಳೆ", "kannada", "english"))
#print(translate('edit', 'english', 'hindi'))

