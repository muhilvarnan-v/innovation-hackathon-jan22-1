-- UUIDs for master data is generated using https://www.uuidgenerator.net/version4 UUID v4 --
CREATE TABLE `User` (
  `id` varchar(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `username` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phoneNumber` varchar(40) NOT NULL,
  `isEmailVerified` tinyint(1) NOT NULL,
  `isPhoneVerified` tinyint(1) NOT NULL,
  `password` varchar(100) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `lastUpdatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_username` (`username`),
  UNIQUE KEY `uk_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table `role` (
    `id` varchar(40) NOT NULL,
    `name` varchar(40) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_role_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into role (id, name) values ('d51b1e62-21d3-4e05-a526-161f3dbd33ca','ROLE_USER');
insert into role (id, name) values ('b2b5f11d-0f59-4643-b4f3-8f89abf07a59', 'ROLE_ADMIN');

CREATE TABLE `user_role` (
  `user_id` varchar(40) NOT NULL,
  `role_id` varchar(40) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_user_role_role_id` (`role_id`),
  CONSTRAINT `fk_user_role_role_id` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  KEY `fk_user_role_user_id` (`user_id`),
  CONSTRAINT `fk_user_role_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- By default every user will be considered to have owner role only now --
CREATE TABLE Flytekart_Main.`OrganisationMap` (
  `id` varchar(40) NOT NULL,
  `clientCode` varchar(40) NOT NULL,
  `organisationId` varchar(40) NOT NULL,
  `userId` varchar(40) NOT NULL,
  `createdBy` varchar(40) NOT NULL,
  `lastUpdatedBy` varchar(40) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `lastUpdatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_organisation_map_user_id` (`userId`),
  CONSTRAINT `fk_organisation_map_user_id` FOREIGN KEY (`userId`) REFERENCES `User` (`id`),
  KEY `fk_organisation_map_created_by` (`createdBy`),
  CONSTRAINT `fk_organisation_map_created_by` FOREIGN KEY (`createdBy`) REFERENCES `User` (`id`),
  KEY `fk_organisation_map_last_updated_by` (`lastUpdatedBy`),
  CONSTRAINT `fk_organisation_map_last_updated_by` FOREIGN KEY (`lastUpdatedBy`) REFERENCES `User` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB3;

commit;
