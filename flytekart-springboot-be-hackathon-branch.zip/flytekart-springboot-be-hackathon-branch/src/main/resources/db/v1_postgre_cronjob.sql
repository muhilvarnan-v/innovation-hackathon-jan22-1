-- Create pg_cron extension after installing in the server 
CREATE EXTENSION pg_cron;

-- Add cron job 
INSERT INTO cron.job (schedule, command, database) VALUES (
	'1 */1 * * *', $$checkpeakesales();$$, 'flytekart_english_foods'
);