-- UUIDs for master data is generated using https://www.uuidgenerator.net/version4 UUID v4 --
-- Below is for PostgreSQL --
CREATE TABLE public.User (
  id varchar(40) NOT NULL,
  name varchar(40) NOT NULL,
  username varchar(40) NOT NULL,
  email varchar(40) NOT NULL,
  phoneNumber varchar(40) NOT NULL,
  isEmailVerified boolean NOT NULL,
  isPhoneVerified boolean NOT NULL,
  password varchar(100) NOT NULL,
  createdAt timestamp with time zone DEFAULT NULL,
  lastUpdatedAt timestamp with time zone DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT uk_users_username UNIQUE  (username),
  CONSTRAINT uk_users_email UNIQUE  (email)
) ;

CREATE TABLE public.OrganisationMap (
  id varchar(40) NOT NULL,
  clientCode varchar(40) NOT NULL,
  organisationId varchar(40) NOT NULL,
  userId varchar(40) NOT NULL,
  createdBy varchar(40) NOT NULL,
  lastUpdatedBy varchar(40) NOT NULL,
  createdAt timestamp with time zone DEFAULT NULL,
  lastUpdatedAt timestamp with time zone DEFAULT NULL,
  PRIMARY KEY (id)
 ,
  CONSTRAINT fk_organisation_map_user_id FOREIGN KEY (userId) REFERENCES public.User (id)
 ,
  CONSTRAINT fk_organisation_map_created_by FOREIGN KEY (createdBy) REFERENCES public.User (id)
 ,
  CONSTRAINT fk_organisation_map_last_updated_by FOREIGN KEY (lastUpdatedBy) REFERENCES public.User (id)
) ;

CREATE INDEX fk_organisation_map_user_id ON OrganisationMap (userId);
CREATE INDEX fk_organisation_map_created_by ON OrganisationMap (createdBy);
CREATE INDEX fk_organisation_map_last_updated_by ON OrganisationMap (lastUpdatedBy);

commit;