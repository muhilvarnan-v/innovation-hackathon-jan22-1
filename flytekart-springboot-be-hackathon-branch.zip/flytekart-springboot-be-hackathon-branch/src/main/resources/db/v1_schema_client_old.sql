-- UUIDs for master data is generated using https://www.uuidgenerator.net/version4 UUID v4 --
CREATE TABLE `Employee` (
  `id` varchar(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `username` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phoneNumber` varchar(40) NOT NULL,
  `isEmailVerified` tinyint(1) NOT NULL,
  `isPhoneVerified` tinyint(1) NOT NULL,
  `password` varchar(100) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `lastUpdatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_employees_username` (`username`),
  UNIQUE KEY `uk_employees_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Org types like single store, chain etc --
create table `OrganisationType` (
    `id` varchar(40) NOT NULL,
    `name` varchar(40) NOT NULL,
    `type` varchar(40) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_organisation_type_name` (`name`),
    UNIQUE KEY `uk_organisation_type_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into OrganisationType (id, name, type) values ('a5b4b8ab-9fcc-40e8-802b-ffe91b4e3fea','Single store', 'SINGLE_STORE');
insert into OrganisationType (id, name, type) values ('d7d192e8-c83a-4395-8a7b-21ed39ba9392', 'Chain', 'CHAIN');

-- Business types like restaurant, meat store, grocery store etc --
create table `BusinessType` (
    `id` varchar(40) NOT NULL,
    `name` varchar(40) NOT NULL,
    `type` varchar(40) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_business_type_name` (`name`),
    UNIQUE KEY `uk_business_type_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into BusinessType (id, name, type) values ('f88cedbd-3a37-4c91-a205-cffc05bb07f3','Restaurant', 'RESTAURANT');
insert into BusinessType (id, name, type) values ('a2259e3a-188d-4b6b-a430-b3049bbaa72b', 'Meat store', 'MEAT_STORE');
insert into BusinessType (id, name, type) values ('3a42ea96-c312-415c-a850-35f6b8416fb9', 'Grocery store', 'GROCERY_STORE');

CREATE TABLE `Address` (
  `id` varchar(40) NOT NULL,
  `line1` varchar(100) NOT NULL,
  `line2` varchar(100),
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `zip` varchar(40) NOT NULL,
  `latitude` varchar(40),
  `longitude` varchar(40),
  `createdBy` varchar(40) NOT NULL,
  `lastUpdatedBy` varchar(40) NOT NULL,
  `createdByResourceType` varchar(40) NOT NULL,
  `lastUpdatedByResourceType` varchar(40) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `lastUpdatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `Organisation` (
  `id` varchar(40) NOT NULL,
  `name` varchar(200) NOT NULL,
  `organisationTypeId` varchar(40),
  `businessTypeId` varchar(40),
  `addressId` varchar(40),
  `taxNumber` varchar(40),
  `createdBy` varchar(40) NOT NULL,
  `lastUpdatedBy` varchar(40) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `lastUpdatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_organisation_organisation_type_id` (`organisationTypeId`),
  CONSTRAINT `fk_organisation_organisation_type_id` FOREIGN KEY (`organisationTypeId`) REFERENCES `OrganisationType` (`id`),
  KEY `fk_organisation_business_type_id` (`businessTypeId`),
  CONSTRAINT `fk_organisation_business_type_id` FOREIGN KEY (`businessTypeId`) REFERENCES `BusinessType` (`id`),
  KEY `fk_organisation_address_id` (`addressId`),
  CONSTRAINT `fk_organisation_address_id` FOREIGN KEY (`addressId`) REFERENCES `Address` (`id`),
  KEY `fk_organisation_created_by` (`createdBy`),
  CONSTRAINT `fk_organisation_created_by` FOREIGN KEY (`createdBy`) REFERENCES `Employee` (`id`),
  KEY `fk_organisation_last_updated_by` (`lastUpdatedBy`),
  CONSTRAINT `fk_organisation_last_updated_by` FOREIGN KEY (`lastUpdatedBy`) REFERENCES `Employee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

commit;