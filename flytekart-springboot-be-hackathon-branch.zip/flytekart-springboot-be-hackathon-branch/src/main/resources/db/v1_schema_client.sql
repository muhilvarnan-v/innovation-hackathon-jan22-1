-- UUIDs for master data is generated using https://www.uuidgenerator.net/version4 UUID v4 --
CREATE TABLE public.Employee (
  id varchar(40) NOT NULL,
  name varchar(40) NOT NULL,
  username varchar(40) NOT NULL,
  email varchar(40) NOT NULL,
  phoneNumber varchar(40) NOT NULL,
  isEmailVerified boolean NOT NULL,
  isPhoneVerified boolean NOT NULL,
  password varchar(100) NOT NULL,
  createdAt timestamp with time zone DEFAULT NULL,
  lastUpdatedAt timestamp with time zone DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT uk_employees_username UNIQUE (username),
  CONSTRAINT uk_employees_email UNIQUE  (email)
) ;

-- Org types like single store, chain etc --
create table public.OrganisationType (
    id varchar(40) NOT NULL,
    name varchar(40) NOT NULL,
    type varchar(40) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_organisation_type_name UNIQUE  (name),
    CONSTRAINT uk_organisation_type_type UNIQUE  (type)
);

insert into public.OrganisationType (id, name, type) values ('a5b4b8ab-9fcc-40e8-802b-ffe91b4e3fea','Single store', 'SINGLE_STORE');
insert into public.OrganisationType (id, name, type) values ('d7d192e8-c83a-4395-8a7b-21ed39ba9392', 'Chain', 'CHAIN');

-- Business types like restaurant, meat store, grocery store etc --
create table public.BusinessType (
    id varchar(40) NOT NULL,
    name varchar(40) NOT NULL,
    type varchar(40) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_business_type_name UNIQUE  (name),
    CONSTRAINT uk_business_type_type UNIQUE  (type)
) ;

insert into public.BusinessType (id, name, type) values ('f88cedbd-3a37-4c91-a205-cffc05bb07f3','Restaurant', 'RESTAURANT');
insert into public.BusinessType (id, name, type) values ('a2259e3a-188d-4b6b-a430-b3049bbaa72b', 'Meat store', 'MEAT_STORE');
insert into public.BusinessType (id, name, type) values ('3a42ea96-c312-415c-a850-35f6b8416fb9', 'Grocery store', 'GROCERY_STORE');

CREATE TABLE public.Address (
  id varchar(40) NOT NULL,
  line1 varchar(100) NOT NULL,
  line2 varchar(100),
  city varchar(100) NOT NULL,
  state varchar(100) NOT NULL,
  country varchar(100) NOT NULL,
  zip varchar(40) NOT NULL,
  latitude varchar(40),
  longitude varchar(40),
  createdBy varchar(40) NOT NULL,
  lastUpdatedBy varchar(40) NOT NULL,
  createdByResourceType varchar(40) NOT NULL,
  lastUpdatedByResourceType varchar(40) NOT NULL,
  createdAt timestamp with time zone DEFAULT NULL,
  lastUpdatedAt timestamp with time zone DEFAULT NULL,
  PRIMARY KEY (id)
) ;

CREATE TABLE public.Organisation (
  id varchar(40) NOT NULL,
  name varchar(200) NOT NULL,
  organisationTypeId varchar(40),
  businessTypeId varchar(40),
  addressId varchar(40),
  taxNumber varchar(40),
  createdBy varchar(40) NOT NULL,
  lastUpdatedBy varchar(40) NOT NULL,
  createdAt timestamp with time zone DEFAULT NULL,
  lastUpdatedAt timestamp with time zone DEFAULT NULL,
  PRIMARY KEY (id)
 ,
  CONSTRAINT fk_organisation_organisation_type_id FOREIGN KEY (organisationTypeId) REFERENCES OrganisationType (id)
 ,
  CONSTRAINT fk_organisation_business_type_id FOREIGN KEY (businessTypeId) REFERENCES BusinessType (id)
 ,
  CONSTRAINT fk_organisation_address_id FOREIGN KEY (addressId) REFERENCES Address (id)
 ,
  CONSTRAINT fk_organisation_created_by FOREIGN KEY (createdBy) REFERENCES Employee (id)
 ,
  CONSTRAINT fk_organisation_last_updated_by FOREIGN KEY (lastUpdatedBy) REFERENCES Employee (id)
) ;

CREATE INDEX fk_organisation_organisation_type_id ON Organisation (organisationTypeId);
CREATE INDEX fk_organisation_business_type_id ON Organisation (businessTypeId);
CREATE INDEX fk_organisation_address_id ON Organisation (addressId);
CREATE INDEX fk_organisation_created_by ON Organisation (createdBy);
CREATE INDEX fk_organisation_last_updated_by ON Organisation (lastUpdatedBy);

-- Table: public.category

-- DROP TABLE public.category;

CREATE TABLE public.category
(
    createdAt timestamp with time zone NOT NULL,
    createdBy character varying(40) COLLATE pg_catalog."default" NOT NULL,
    deletedAt timestamp with time zone,
    deletedBy character varying(40) COLLATE pg_catalog."default",
    id character varying(40) COLLATE pg_catalog."default" NOT NULL,
    isActive boolean NOT NULL,
    lastUpdatedBy character varying(40) COLLATE pg_catalog."default" NOT NULL,
    name character varying(200) COLLATE pg_catalog."default" NOT NULL,
    organisationId character varying(40) COLLATE pg_catalog."default" NOT NULL,
    parentCategoryId character varying(40) COLLATE pg_catalog."default",
    lastUpdatedAt timestamp with time zone NOT NULL,
    CONSTRAINT category_pkey PRIMARY KEY (id),
    CONSTRAINT fk_category_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_category_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_category_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_category_organisation_id FOREIGN KEY (organisationId)
        REFERENCES public.organisation (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_category_parent_category_id FOREIGN KEY (parentCategoryId)
        REFERENCES public.category (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE public.category
    OWNER to postgres;
-- Index: fki_fk_category_parent_category_id

-- DROP INDEX public.fki_fk_category_parent_category_id;

CREATE INDEX fki_fk_category_parent_category_id
    ON public.category USING btree
    (parentCategoryId COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE TABLE public.Attribute
(
    id character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_attribute_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_attribute_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_attribute_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.Attribute
    OWNER to postgres;

-- Table: public.AttributeValue

-- DROP TABLE public.AttributeValue;

CREATE TABLE public.AttributeValue
(
    id character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    attributeId character varying(40) NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_attribute_value_attribute_id FOREIGN KEY (attributeId)
        REFERENCES public.attribute (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_attribute_value_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_attribute_value_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_attribute_value_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.AttributeValue
    OWNER to postgres;

CREATE TABLE public.Product
(
    id character varying(40) NOT NULL,
    name character varying(200) NOT NULL,
    description character varying(1000),
    categoryId character varying(40) NOT NULL,
    isActive boolean NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_product_category_id FOREIGN KEY (categoryId)
        REFERENCES public.category (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_product_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_product_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_product_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.Product
    OWNER to postgres;

CREATE TABLE public.Store
(
    id character varying(40) NOT NULL,
    name character varying(200) NOT NULL,
    organisationId character varying(40) NOT NULL,
    addressId character varying(40),
    taxNumber character varying(40),
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_store_organisation_id FOREIGN KEY (organisationId)
        REFERENCES public.organisation (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_store_address_id FOREIGN KEY (addressId)
        REFERENCES public.address (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_store_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_store_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.Store
    OWNER to postgres;

CREATE TABLE public.Variant
(
    id character varying(40) NOT NULL,
    productId character varying(40) NOT NULL,
    sku character varying(100),
    name character varying(100),
    price numeric NOT NULL,
    tax numeric NOT NULL,
    originalPrice numeric,
    isActive boolean NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_variant_product_id FOREIGN KEY (productId)
        REFERENCES public.product (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_variant_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_variant_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_variant_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.Variant
    OWNER to postgres;

CREATE TABLE public.StoreCategory
(
    id character varying(40) NOT NULL,
    storeId character varying(40) NOT NULL,
    categoryId character varying(40) NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_storecategory_store_id FOREIGN KEY (storeId)
        REFERENCES public.store (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_storecategory_category_id FOREIGN KEY (categoryId)
        REFERENCES public.category (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_storecategory_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_storecategory_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_storecategory_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.StoreCategory
    OWNER to postgres;

CREATE TABLE public.StoreProduct
(
    id character varying(40) NOT NULL,
    storeId character varying(40) NOT NULL,
    productId character varying(40) NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_storeproduct_store_id FOREIGN KEY (storeId)
        REFERENCES public.Store (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_storeproduct_product_id FOREIGN KEY (productId)
        REFERENCES public.Product (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_storeproduct_created_by FOREIGN KEY (createdBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_storeproduct_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_storeproduct_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.StoreProduct
    OWNER to postgres;

CREATE TABLE public.StoreVariant
(
    id character varying(40) NOT NULL,
    storeId character varying(40) NOT NULL,
    variantId character varying(40) NOT NULL,
    price numeric NOT NULL,
    tax numeric,
    originalPrice numeric,
    isActive boolean NOT NULL,
    quantity integer NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_store_variant_store_id FOREIGN KEY (storeId)
        REFERENCES public.store (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_store_variant_variant_id FOREIGN KEY (variantId)
        REFERENCES public.variant (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_store_variant_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_store_variant_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_store_variant_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.StoreVariant
    OWNER to postgres;

CREATE TABLE public.VariantAttributeValue
(
    id character varying(40) NOT NULL,
    variantId character varying(40) NOT NULL,
    attributeValueId character varying(40) NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_variant_attributevalue_variant_id FOREIGN KEY (variantId)
        REFERENCES public.variant (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_variant_attributevalue_attributevalue_id FOREIGN KEY (attributeValueId)
        REFERENCES public.attributevalue (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_variant_attributevalue_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_variant_attributevalue_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_variant_attributevalue_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.VariantAttributeValue
    OWNER to postgres;

CREATE TABLE public.Role
(
    id character varying(40) NOT NULL,
    name character varying(60) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE public.Role
    OWNER to postgres;

CREATE TABLE public.User
(
    id character varying(40) NOT NULL,
    name character varying(100),
    username character varying(40) NOT NULL,
    phoneNumber character varying(20),
    email character varying(100),
    password character varying(100),
    createdAt timestamp with time zone DEFAULT NULL,
    lastUpdatedAt timestamp with time zone DEFAULT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_user_user_name UNIQUE (username),
    CONSTRAINT uk_user_email UNIQUE (email)
);

ALTER TABLE public.User
    OWNER to postgres;

CREATE TABLE public.UserRole
(
    id character varying(40) NOT NULL,
    userId character varying(40) NOT NULL,
    roleId character varying(40) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_userrole_user_id FOREIGN KEY (userId)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_userrole_role_id FOREIGN KEY (roleId)
        REFERENCES public.role (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.UserRole
    OWNER to postgres;

CREATE TABLE public.OrderSource
(
    id character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE public.OrderSource
    OWNER to postgres;

-- Insert records into OrderSource table
insert into public.OrderSource (id, name) values ('dfda3c0e-f989-4496-b48d-7a6f4b24e3a1','Android');

CREATE TABLE public.OrderStatus
(
    id character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE public.OrderStatus
    OWNER to postgres;

-- Insert records into OrderStatus table
insert into public.OrderStatus (id, name) values ('37eca0da-6cff-41d1-b44f-dd232ef902f3','IN_PROGRESS');
insert into public.OrderStatus (id, name) values ('56b7ebc6-fa3d-4695-89fe-a3c03f0a7804', 'PLACED');
insert into public.OrderStatus (id, name) values ('f2ffd8d0-4768-4c2e-8daf-8bc78b5c2fe0','CANCELED');
insert into public.OrderStatus (id, name) values ('c6c6b5a6-cd04-425c-8cc4-59f196386ae1', 'ACCEPTED');
insert into public.OrderStatus (id, name) values ('5379e806-d8e2-49c1-a4cf-09153150d80d','PROCESSING');
insert into public.OrderStatus (id, name) values ('3450c6bd-f2dc-442e-bbba-d904b7ccc1cf', 'PROCESSED');
insert into public.OrderStatus (id, name) values ('faa26b42-80f5-4c50-b594-e65b3cf54e21','OUT_FOR_DELIVERY');
insert into public.OrderStatus (id, name) values ('90bb7a8a-72a4-410d-a728-c7dbbf051aca', 'DELIVERED');

CREATE TABLE public.Order
(
    id character varying(40) NOT NULL,
    userId character varying(40),
    storeId character varying(40) NOT NULL,
    orderStatusId character varying(40) NOT NULL,
    orderSourceId character varying(40) NOT NULL,
    deliveryAddressId character varying(40) NOT NULL,
    orderPlacedAt timestamp with time zone,
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    deletedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    employeeDeletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_order_store_id FOREIGN KEY (storeId)
        REFERENCES public.Store (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_order_order_source_id FOREIGN KEY (orderSourceId)
        REFERENCES public.ordersource (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_order_order_status_id FOREIGN KEY (orderStatusId)
        REFERENCES public.orderstatus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_order_delivery_address_id FOREIGN KEY (deliveryAddressId)
        REFERENCES public.address (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_order_user_created_by FOREIGN KEY (createdBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_order_user_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_order_user_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_order_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_order_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_order_employee_deleted_by FOREIGN KEY (employeeDeletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.Order
    OWNER to postgres;

CREATE TABLE public.OrderLog
(
    id character varying(40) NOT NULL,
    orderId character varying(40) NOT NULL,
    orderStatusId character varying(40) NOT NULL,
    description character varying(1000),
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_orderlog_order_id FOREIGN KEY (orderId)
        REFERENCES public.order (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderlog_order_status_id FOREIGN KEY (orderStatusId)
        REFERENCES public.orderstatus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderlog_created_by FOREIGN KEY (createdBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderlog_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderlog_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderlog_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.OrderLog
    OWNER to postgres;

CREATE TABLE public.OrderItemStatus
(
    id character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE public.OrderItemStatus
    OWNER to postgres;

-- Insert records into OrderItemStatus table
insert into public.OrderItemStatus (id, name) values ('e5878f33-9887-47bf-bd56-979bbe3f7598','IN_PROGRESS');
insert into public.OrderItemStatus (id, name) values ('f17c8f22-a18f-464a-b6d1-78d1b4b5409d','DELETED');
insert into public.OrderItemStatus (id, name) values ('46be08c9-573f-4e56-975b-e5e743f71a2e', 'PLACED');
insert into public.OrderItemStatus (id, name) values ('ed4c314f-0243-48e6-b823-c6104b9eea69','CANCELED');
insert into public.OrderItemStatus (id, name) values ('4507b014-6a1f-47d1-95a1-8694811c9dd9', 'ACCEPTED');
insert into public.OrderItemStatus (id, name) values ('5b8526ce-34fa-47ee-b6c5-dde033a55fbf','PROCESSING');
insert into public.OrderItemStatus (id, name) values ('408d55f9-989e-4661-a23a-456df8c56a44', 'PROCESSED');
insert into public.OrderItemStatus (id, name) values ('e258ae48-70f6-4620-9535-26e5a4bc2383','OUT_FOR_DELIVERY');
insert into public.OrderItemStatus (id, name) values ('8b2e6112-464b-4b88-816e-4ed050e3f233', 'DELIVERED');
insert into public.OrderItemStatus (id, name) values ('1935026d-a215-48e3-953d-12e43b5edbec', 'REMOVED');

CREATE TABLE public.OrderItem
(
    id character varying(40) NOT NULL,
    orderId character varying(40) NOT NULL,
    orderItemStatusId character varying(40) NOT NULL,
    storeVariantId character varying(40) NOT NULL,
    unitPrice numeric NOT NULL,
    unitTax numeric,
    quantity integer NOT NULL,
    totalPrice numeric NOT NULL,
    totalTax numeric,
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    deletedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    employeeDeletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_orderitem_order_id FOREIGN KEY (orderId)
        REFERENCES public.order (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitem_order_item_status_id FOREIGN KEY (orderItemStatusId)
        REFERENCES public.orderitemstatus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitem_store_variant_id FOREIGN KEY (storeVariantId)
        REFERENCES public.storevariant (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitem_created_by FOREIGN KEY (createdBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitem_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitem_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitem_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitem_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitem_employee_deleted_by FOREIGN KEY (employeeDeletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.OrderItem
    OWNER to postgres;

CREATE TABLE public.OrderItemLog
(
    id character varying(40) NOT NULL,
    orderItemId character varying(40) NOT NULL,
    orderItemStatusId character varying(40) NOT NULL,
    description character varying(1000),
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_orderitemlog_order_item_id FOREIGN KEY (orderItemId)
        REFERENCES public.orderitem (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitemlog_order_item_status_id FOREIGN KEY (orderItemStatusId)
        REFERENCES public.orderitemstatus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitemlog_created_by FOREIGN KEY (createdBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitemlog_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitemlog_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_orderitemlog_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.OrderItemLog
    OWNER to postgres;

CREATE TABLE public.PaymentType
(
    id character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE public.PaymentType
    OWNER to postgres;

-- Insert records into PaymentType table
insert into public.PaymentType (id, name) values ('78b1aa73-5387-4620-b678-70b0241841ed','COD');
insert into public.PaymentType (id, name) values ('798e614a-802e-4d88-acee-67aeb6dc2878','RAZORPAY');

CREATE TABLE public.PaymentStatus
(
    id character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE public.PaymentStatus
    OWNER to postgres;

-- Insert records into PaymentStatus table
insert into public.PaymentStatus (id, name) values ('8dddf36a-5479-471f-92c2-e8404046dff2','UNPAID');
insert into public.PaymentStatus (id, name) values ('760a6e01-18ec-43b4-96d1-5ed9a7f5ff8d','PAID');

CREATE TABLE public.Payment
(
    id character varying(40) NOT NULL,
    orderId character varying(40) NOT NULL,
    amount numeric NOT NULL,
    paymentTypeId character varying(40) NOT NULL,
    paymentStatusId character varying(40) NOT NULL,
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    deletedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    employeeDeletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_payment_order_id FOREIGN KEY (orderId)
        REFERENCES public.Order (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_payment_payment_type_id FOREIGN KEY (paymentTypeId)
        REFERENCES public.PaymentType (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_payment_payment_status_id FOREIGN KEY (paymentStatusId)
        REFERENCES public.PaymentStatus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_payment_created_by FOREIGN KEY (createdBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_payment_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_payment_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_payment_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_payment_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_payment_employee_deleted_by FOREIGN KEY (employeeDeletedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.Payment
    OWNER to postgres;

CREATE TABLE public.PaymentLog
(
    id character varying(40) NOT NULL,
    paymentId character varying(40) NOT NULL,
    paymentStatusId character varying(40) NOT NULL,
    description character varying(1000) NOT NULL,
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_paymentlog_payment_id FOREIGN KEY (paymentId)
        REFERENCES public.Payment (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_paymentlog_created_by FOREIGN KEY (createdBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_paymentlog_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_paymentlog_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_payment_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.PaymentLog
    OWNER to postgres;

CREATE TABLE public.ReturnOrderStatus
(
    id character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE public.ReturnOrderStatus
    OWNER to postgres;

-- Insert records into ReturnOrderStatus table
insert into public.ReturnOrderStatus (id, name) values ('1eade339-c9f1-4c7c-941d-ab907c757dc5','RETURN_IN_PROGRESS');
insert into public.ReturnOrderStatus (id, name) values ('6393c7e0-fc15-4457-9b07-772eeea158f5','RETURN_PLACED');
insert into public.ReturnOrderStatus (id, name) values ('e8b066c3-a001-4cd9-bc37-87e6b064c8f4', 'RETURN_CANCELED');
insert into public.ReturnOrderStatus (id, name) values ('0dc1f11d-39ba-467f-bc50-829df216cccc','RETURN_REQUEST_ACCEPTED');
insert into public.ReturnOrderStatus (id, name) values ('52047638-23a1-4e69-adee-a5b219a7ec77', 'RETURN_REQUEST_REJECTED');
insert into public.ReturnOrderStatus (id, name) values ('e012fb4b-f0f5-4d80-b545-0f25783a581c','RETURN_PICKED');
insert into public.ReturnOrderStatus (id, name) values ('9fc78fba-da99-40d9-b514-e6556e2b7f54', 'RETURN_RECEIVED');
insert into public.ReturnOrderStatus (id, name) values ('a5054428-39c4-4ee8-8f64-96fd22ca86d6','RETURN_ACCEPTED');
insert into public.ReturnOrderStatus (id, name) values ('1728abc6-9547-4174-95ba-ddf87922b168', 'RETURN_REJECTED');

CREATE TABLE public.ReturnOrderItemStatus
(
    id character varying(40) NOT NULL,
    name character varying(100) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE public.ReturnOrderItemStatus
    OWNER to postgres;

-- Insert records into ReturnOrderItemStatus table
insert into public.ReturnOrderItemStatus (id, name) values ('5d24df91-cfdf-4a59-b7ea-52237096e104','RETURN_IN_PROGRESS');
insert into public.ReturnOrderItemStatus (id, name) values ('3ae37afc-01ae-418a-ba69-a4e7cad8e5b0','RETURN_ITEM_DELETED');
insert into public.ReturnOrderItemStatus (id, name) values ('b33e50e4-47e1-4244-82de-a7609e590872', 'RETURN_PLACED');
insert into public.ReturnOrderItemStatus (id, name) values ('7d62dfee-1a77-44c0-910e-243dabd4eb9b','RETURN_CANCELED');
insert into public.ReturnOrderItemStatus (id, name) values ('38dbc17e-1a82-4292-8aa5-1b14c5f3b396', 'RETURN_REQUEST_ACCEPTED');
insert into public.ReturnOrderItemStatus (id, name) values ('90f53ea5-dd7a-46e8-9d8d-5b57d6fb3203','RETURN_REQUEST_REJECTED');
insert into public.ReturnOrderItemStatus (id, name) values ('fe511528-6af7-439f-94b8-7f43afd829ba', 'RETURN_PICKED');
insert into public.ReturnOrderItemStatus (id, name) values ('d9a5e49f-a7f7-481e-8979-aff1a8461c18','RETURN_RECEIVED');
insert into public.ReturnOrderItemStatus (id, name) values ('923a0e61-59ab-4423-98bc-3ebd86310f7a', 'RETURN_ACCEPTED');
insert into public.ReturnOrderItemStatus (id, name) values ('e73f1abb-5c83-4af9-9374-c4bb06eeaeb7', 'RETURN_REJECTED');

CREATE TABLE public.ReturnOrder
(
    id character varying(40) NOT NULL,
    orderId character varying(40) NOT NULL,
    returnOrderStatusId character varying(40) NOT NULL,
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    deletedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    employeeDeletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_returnorder_order_id FOREIGN KEY (orderId)
        REFERENCES public.Order (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorder_status_id FOREIGN KEY (returnOrderStatusId)
        REFERENCES public.ReturnOrderStatus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorder_created_by FOREIGN KEY (createdBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorder_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorder_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorder_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorder_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorder_employee_deleted_by FOREIGN KEY (employeeDeletedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.ReturnOrder
    OWNER to postgres;

CREATE TABLE public.ReturnOrderItem
(
    id character varying(40) NOT NULL,
    returnOrderId character varying(40) NOT NULL,
    orderItemId character varying(40) NOT NULL,
    returnOrderItemStatusId character varying(40) NOT NULL,
    quantity integer NOT NULL,
    returnTotalPrice numeric NOT NULL,
    returnTotalTax numeric,
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    deletedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    employeeDeletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_returnorderitem_return_order_id FOREIGN KEY (returnOrderId)
        REFERENCES public.ReturnOrder (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitem_order_item_id FOREIGN KEY (orderItemId)
        REFERENCES public.OrderItem (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitem_status_id FOREIGN KEY (returnOrderItemStatusId)
        REFERENCES public.ReturnOrderItemStatus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitem_created_by FOREIGN KEY (createdBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitem_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitem_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitem_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitem_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitem_employee_deleted_by FOREIGN KEY (employeeDeletedBy)
        REFERENCES public.Employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.ReturnOrderItem
    OWNER to postgres;

CREATE TABLE public.ReturnOrderLog
(
    id character varying(40) NOT NULL,
    returnOrderId character varying(40) NOT NULL,
    returnOrderStatusId character varying(40) NOT NULL,
    description character varying(1000),
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_returnorderlog_return_order_id FOREIGN KEY (returnOrderId)
        REFERENCES public.ReturnOrder (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderlog_status_id FOREIGN KEY (returnOrderStatusId)
        REFERENCES public.ReturnOrderStatus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderlog_created_by FOREIGN KEY (createdBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderlog_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderlog_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderlog_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.ReturnOrderLog
    OWNER to postgres;

CREATE TABLE public.ReturnOrderItemLog
(
    id character varying(40) NOT NULL,
    returnOrderItemId character varying(40) NOT NULL,
    returnOrderItemStatusId character varying(40) NOT NULL,
    description character varying(1000),
    createdBy character varying(40),
    lastUpdatedBy character varying(40),
    employeeCreatedBy character varying(40),
    employeeLastUpdatedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_returnorderitemlog_return_order_id FOREIGN KEY (returnOrderItemId)
        REFERENCES public.ReturnOrderItem (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitemlog_status_id FOREIGN KEY (returnOrderItemStatusId)
        REFERENCES public.ReturnOrderItemStatus (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitemlog_created_by FOREIGN KEY (createdBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitemlog_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitemlog_employee_created_by FOREIGN KEY (employeeCreatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_returnorderitemlog_employee_last_updated_by FOREIGN KEY (employeeLastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.ReturnOrderItemLog
    OWNER to postgres;

-- Creating OTP table

CREATE TABLE public.otp
(
    id character varying(40) NOT NULL,
    mobileNumber character varying(40) NOT NULL,
    userType character varying(40) NOT NULL,
    otp character varying(100) NOT NULL,
    purpose character varying(40) NOT NULL,
    expiry timestamp with time zone NOT NULL,
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE public.otp
    OWNER to postgres;

CREATE TABLE IF NOT EXISTS public.EmployeePushToken
(
    id character varying(40) NOT NULL,
    userId character varying(40) NOT NULL,
    token character varying(200) NOT NULL,
    clientType character varying(40) NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_employeepushtoken_user_id FOREIGN KEY (userId)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_employeepushtoken_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_employeepushtoken_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_employeepushtoken_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.EmployeePushToken
    OWNER to postgres;

CREATE TABLE IF NOT EXISTS public.UserPushToken
(
    id character varying(40) NOT NULL,
    userId character varying(40) NOT NULL,
    token character varying(200) NOT NULL,
    clientType character varying(40) NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_userpushtoken_user_id FOREIGN KEY (userId)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_userpushtoken_created_by FOREIGN KEY (createdBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_userpushtoken_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_userpushtoken_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.user (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.UserPushToken
    OWNER to postgres;

CREATE TABLE IF NOT EXISTS public.NotificationSetting
(
    id character varying(40) NOT NULL,
    organisationId character varying(40) NOT NULL,
    serverKey character varying(200) NOT NULL,
    type character varying(40) NOT NULL,
    packageName character varying(100),
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_notificationsetting_organisation_id FOREIGN KEY (organisationId)
        REFERENCES public.Organisation (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_notificationsetting_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_notificationsetting_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_notificationsetting_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.NotificationSetting
    OWNER to postgres;

-- Need to store the fcm token manually for now after creating a Firebase project.

--- Product order report
CREATE OR REPLACE FUNCTION public.product_order_list(
	timeZone character varying DEFAULT 'Asia/Kolkata'::character varying,
	startdate character varying DEFAULT NULL::character varying,
	enddate character varying DEFAULT NULL::character varying,
	categoryIdParam character varying DEFAULT NULL::character varying,
	productIdParam character varying DEFAULT NULL::character varying,
	variantIdParam character varying DEFAULT NULL::character varying,
	startItem integer DEFAULT 0::integer,
	endItem integer DEFAULT 10::integer
)
    RETURNS TABLE(id character varying, productName character varying, variantName character varying, categoryName character varying, orderedQuantity integer, orderedPrice numeric, deliveredQuantity integer, deliveredPrice numeric)
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000
AS $BODY$
begin
	return query
 SELECT V.id, P.name as productName, V.name as variantName
, C.name as categoryName
 ,sum(OI.quantity)::integer AS orderedQuantity, sum(OI.totalprice) AS orderedPrice
, COALESCE(sum(delvy.qty), 0)::integer AS deliveredQuantity
, COALESCE(sum(delvy.price), 0) AS deliveredPrice
 FROM public.order AS O
 INNER JOIN orderitem AS OI ON O.id = OI.orderid AND OI.deletedat is NULL
 INNER JOIN StoreVariant AS SV ON SV.id = OI.storevariantid
INNER JOIN Variant AS V on V.id = SV.variantId and V.isActive = true and V.deletedAt is null
INNER JOIN Product AS P on P.id = V.productId
INNER JOIN Category AS C on C.id = P.categoryId
LEFT JOIN (SELECT OIQ.id, SUM(OIQ.quantity) AS qty, SUM(OIQ.totalprice) AS price FROM public.orderitem AS OIQ
 INNER JOIN public.order AS OQ ON OQ.id = OIQ.orderid
	  INNER JOIN orderitemstatus AS OISQ ON OISQ.id = OIQ.orderitemstatusid
	  WHERE OIQ.deletedat is NULL AND OISQ.name = 'DELIVERED'
		   GROUP BY OIQ.id) AS delvy ON delvy.id = OI.id
 WHERE O.deletedat is NULL
 AND ( startDate = 'NULL' OR (startDate != 'NULL' AND  (O.createdAt at time zone timeZone)::date >=  to_date(startDate, 'yyyy-mm-dd')  AND (O.createdAt at time zone timeZone)::date <=  to_date(endDate, 'yyyy-mm-dd')))
 AND (categoryIdParam = 'NULL' OR C.id = categoryIdParam)
 AND (productIdParam = 'NULL' OR P.id = productIdParam)
 AND (variantIdParam = 'NULL' OR V.id = variantIdParam)
 GROUP BY V.id, P.name, V.name, C.name
 ORDER BY  P.name, V.name, C.name ASC
 OFFSET startItem LIMIT endItem;
 end;
$BODY$;

--- Orders over time report
CREATE OR REPLACE FUNCTION public.orders_by_time(
	timeZone character varying DEFAULT 'Asia/Kolkata'::character varying,
	startdate character varying DEFAULT NULL::character varying,
	enddate character varying DEFAULT NULL::character varying,
	startItem integer DEFAULT 0::integer,
	endItem integer DEFAULT 10::integer
)
    RETURNS TABLE(createdAt date, placedOrders integer, deliveredOrders integer, orderedQuantity integer, orderedPrice numeric, deliveredQuantity integer, deliveredPrice numeric)
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
begin
	return query
SELECT
(O.createdAt at time zone timeZone)::date, count(o.id)::integer AS placedOrders,
count(orderDelvy.delivered)::integer AS deliveredOrders
,sum(OI.quantity)::integer AS orderedQuantity, sum(OI.totalprice) AS orderedPrice
, COALESCE(sum(delvy.qty), 0)::integer AS deliveredQuantity
, COALESCE(sum(delvy.price), 0) AS deliveredPrice
 FROM public.order AS O
 INNER JOIN orderitem AS OI ON O.id = OI.orderid AND OI.deletedat is NULL
LEFT JOIN (SELECT OIQ.id, SUM(OIQ.quantity) AS qty, SUM(OIQ.totalprice) AS price FROM public.orderitem AS OIQ
 INNER JOIN public.order AS OQ ON OQ.id = OIQ.orderid
	  INNER JOIN orderitemstatus AS OISQ ON OISQ.id = OIQ.orderitemstatusid
	  WHERE OIQ.deletedat is NULL AND OISQ.name = 'DELIVERED'
		   GROUP BY OIQ.id) AS delvy ON delvy.id = OI.id
LEFT JOIN (SELECT OQ.createdAt::date, COUNT(OQ.id) AS delivered FROM public.order AS OQ
	  INNER JOIN orderstatus AS OSQ ON OSQ.id = OQ.orderstatusid
	  WHERE OQ.deletedat is NULL AND OSQ.name = 'DELIVERED'
		   GROUP BY OQ.createdAt::date) AS orderDelvy ON orderDelvy.createdAt = O.createdAt::date
 WHERE O.deletedat is NULL
 AND ( startDate = 'NULL' OR (startDate != 'NULL' AND  (O.createdAt at time zone timeZone)::date >=  to_date(startDate, 'yyyy-mm-dd')  AND (O.createdAt at time zone timeZone)::date <=  to_date(endDate, 'yyyy-mm-dd')))
 GROUP BY (O.createdAt at time zone timeZone)::date
 ORDER BY (O.createdAt at time zone timeZone)::date DESC
 OFFSET startItem LIMIT endItem;
 end;
$BODY$;

--- Customer acquisition report
CREATE OR REPLACE FUNCTION public.customer_aquisition(
	timeZone character varying DEFAULT 'Asia/Kolkata'::character varying,
	startdate character varying DEFAULT NULL::character varying,
	enddate character varying DEFAULT NULL::character varying,
	startItem integer DEFAULT 0::integer,
	endItem integer DEFAULT 10::integer
)
    RETURNS TABLE(createdAt date, total integer)
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
begin
	return query
SELECT
(U.createdAt at time zone timeZone)::date, count(U.id)::integer AS placedOrders
 FROM public.user AS U
 WHERE ( startDate = 'NULL' OR (startDate != 'NULL' AND  (U.createdAt at time zone timeZone)::date >=  to_date(startDate, 'yyyy-mm-dd')  AND (U.createdAt at time zone timeZone)::date <=  to_date(endDate, 'yyyy-mm-dd')))
 GROUP BY (U.createdAt at time zone timeZone)::date
 ORDER BY (U.createdAt at time zone timeZone)::date DESC
 OFFSET startItem LIMIT endItem;
 end;
$BODY$;


-- Customer order report
 CREATE OR REPLACE FUNCTION public.customer_order_report(
	timeZone character varying DEFAULT 'Asia/Kolkata'::character varying,
	lastOrderedAfter character varying DEFAULT NULL::character varying,
	lastOrderedBefore character varying DEFAULT NULL::character varying,
	startItem integer DEFAULT 0::integer,
	endItem integer DEFAULT 10::integer
)
   RETURNS TABLE(userId character varying, name character varying, totalOrderCount integer, totalOrderValue numeric, lastOrderedAt DATE)
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
    ROWS 1000

AS $BODY$
begin
	return query
 SELECT U.id, U.name, SUM(OI.quantity)::integer AS totalOrderCount
 , SUM(OI.totalprice) AS totalOrderValue
 , MAX(O.createdAt  at time zone timeZone)::DATE AS lastOrderedAt
 FROM public.user AS U
 INNER JOIN public.order AS O ON O.userid = U.id
	  INNER JOIN orderstatus AS OS ON OS.id = O.orderstatusid
	  INNER JOIN orderitem AS OI ON O.id = OI.orderid AND OI.deletedat is NULL
	  WHERE O.deletedat is NULL AND OS.name = 'DELIVERED'
	  AND ( lastOrderedAfter = 'NULL' OR (lastOrderedAfter != 'NULL' AND  (O.createdAt at time zone timeZone)::date >=  to_date(lastOrderedAfter, 'yyyy-mm-dd')))
	  AND ( lastOrderedBefore = 'NULL' OR (lastOrderedBefore != 'NULL' AND  (O.createdAt at time zone timeZone)::date <=  to_date(lastOrderedBefore, 'yyyy-mm-dd')))
	  GROUP BY U.id, U.name
	  ORDER BY U.name ASC
 OFFSET startItem LIMIT endItem;
 end;
$BODY$;


-- Add column to client schema (Product, Category, Variant)
ALTER TABLE "product" ADD COLUMN imageUrl character varying(1000) DEFAULT NULL;
ALTER TABLE "category" ADD COLUMN imageUrl character varying(1000) DEFAULT NULL;
ALTER TABLE "variant" ADD COLUMN imageUrl character varying(1000) DEFAULT NULL;

-- 8th Jan 2022
ALTER TABLE public."user"
    ADD COLUMN telegramChatId numeric;

CREATE TABLE IF NOT EXISTS public.TelegramUserContext
(
    id character varying(40) NOT NULL,
    userId character varying(40) NOT NULL,
    context character varying(100),
    data character varying(1000),
    lastMessageId numeric,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_telegramusercontext_user_id FOREIGN KEY (userId)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_telegramusercontext_created_by FOREIGN KEY (createdBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_telegramusercontext_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_telegramusercontext_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public."user" (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.TelegramUserContext
    OWNER to postgres;

CREATE TABLE IF NOT EXISTS public.telegramsettings
(
    id character varying(40) NOT NULL,
    tokenId character varying(100) NOT NULL,
    createdBy character varying(40) NOT NULL,
    lastUpdatedBy character varying(40) NOT NULL,
    deletedBy character varying(40),
    createdAt timestamp with time zone NOT NULL,
    lastUpdatedAt timestamp with time zone NOT NULL,
    deletedAt timestamp with time zone,
    PRIMARY KEY (id),
    CONSTRAINT fk_telegramsettings_created_by FOREIGN KEY (createdBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_telegramsettings_last_updated_by FOREIGN KEY (lastUpdatedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT fk_telegramsettings_deleted_by FOREIGN KEY (deletedBy)
        REFERENCES public.employee (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);

ALTER TABLE public.telegramsettings
    OWNER to postgres;

--- Telegram settings have to be inserted manually for now

-- Dynamic pricing 
ALTER TABLE "organisation" ADD COLUMN "isdynamicpricing" BOOLEAN DEFAULT false;
ALTER TABLE "organisation" ADD COLUMN "multiplier" NUMERIC DEFAULT 1.0;
ALTER TABLE "store" ADD COLUMN "peakesale" BOOLEAN DEFAULT false;

-- Cron job --- 

--- Create function to check and update ---- 
create or replace function checkpeakesales()
	RETURNS INTEGER
	language plpgsql as
	$$
declare 
begin
   UPDATE "store" SET "peakesale"=true WHERE "id" IN (
	SELECT "storeid" FROM "order" WHERE "createdat" >= (NOW()- INTERVAL '1 hour') GROUP BY "storeid" HAVING COUNT(*) >= 100
    );

    UPDATE "store" SET "peakesale"=false WHERE "id" IN (
	    SELECT "storeid" FROM "order" WHERE "createdat" >= (NOW()- INTERVAL '1 hour') GROUP BY "storeid" HAVING COUNT(*) < 100
    );
   
   return null;
end;
$$



-- flytekart_english_foods is the database name.  pg_cron works on postgresql database.

-- Reference url::: https://www.postgresqltutorial.com/postgresql-create-function/
-- Reference url::: https://www.postgresqltutorial.com/postgresql-create-function/

insert into public.OrderSource (id, name) values ('1eb49ade-3b41-468c-839f-7aaed0df8d1c','Telegram');

$$;
commit;