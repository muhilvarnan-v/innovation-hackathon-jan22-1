package com.flytekart.web.model.client;

import com.flytekart.web.model.common.DateAudit;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;


@Entity
@Table(name = "Otp", schema = "public")
public class Otp extends DateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;
    
    @NotBlank
    @Size(max = 40)
    private String mobileNumber;
    
    @NotBlank
    @Size(max = 10)
    private String userType;
    @NotBlank
    @Size(min = 4, max = 100)
    private String otp;
    @NotBlank
    @Size(min = 4, max = 40)
    private String purpose;
    
    private Date expiry;


    public Otp(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String Otp) {
        this.otp = Otp;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String Purpose) {
        this.purpose = Purpose;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }


    public Date getExpiry() {
        return expiry;
    }

    public void setExpiry(Date expiry) {
        this.expiry = expiry;
    }
}
