package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.ReturnOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReturnOrderRepository extends JpaRepository<ReturnOrder, String> {
    @Query("from ReturnOrder where deletedBy IS NULL and id=:id")
    ReturnOrder findUnDeletedByReturnOrderId(String id);

    @Query("from ReturnOrder where deletedBy IS NULL and orderId=:orderId")
    List<ReturnOrder> findUnDeletedByOrderId(String orderId);
}
