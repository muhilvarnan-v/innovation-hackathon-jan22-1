package com.flytekart.web.model.client;

import com.flytekart.web.model.common.EmployeeAndUserDateAuditWithDeletion;
import com.flytekart.web.model.dto.ProductOrderReportDTO;
import com.flytekart.web.model.dto.OrderTimeReportDTO;
import com.flytekart.web.model.dto.UserReportDTO;
import com.flytekart.web.model.dto.CustomerOrderReportDTO;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;

import java.util.Date;

import javax.persistence.*;

/**
 * TODO Handle InStoreUserId where InStoreUser in not a verified user.
 * TODO Should we have OrderSource relation here?
 */
@Entity
@NamedNativeQuery(name = "Order.getOrderProductList",
        query = "select * from public.product_order_list(:timeZone, :categoryId, :productId, :variantId, :startDate, :endDate, :pageSize, :pageNumber)",
        resultSetMapping = "Mapping.ProductOrderReportDTO")
@SqlResultSetMapping(name = "Mapping.ProductOrderReportDTO",
        classes = @ConstructorResult(targetClass = ProductOrderReportDTO.class,
                columns = {@ColumnResult(name = "id", type = String.class),
                        @ColumnResult(name = "productName", type = String.class),
                        @ColumnResult(name = "variantName", type = String.class),
                        @ColumnResult(name = "categoryName", type = String.class),
                        @ColumnResult(name = "orderedQuantity", type = Integer.class),
                        @ColumnResult(name = "orderedPrice", type = Double.class),
                        @ColumnResult(name = "deliveredQuantity", type = Integer.class),
                        @ColumnResult(name = "deliveredPrice", type = Double.class)}))

@NamedNativeQuery(name = "Order.getOrderTimeList",
        query = "select * from public.orders_by_time(:timeZone, :startDate, :endDate, :pageSize, :pageNumber)",
        resultSetMapping = "Mapping.OrderTimeReportDTO")
@SqlResultSetMapping(name = "Mapping.OrderTimeReportDTO",
        classes = @ConstructorResult(targetClass = OrderTimeReportDTO.class,
                columns = {@ColumnResult(name = "createdAt", type = Date.class),
                        @ColumnResult(name = "placedOrders", type = Integer.class),
                        @ColumnResult(name = "deliveredOrders", type = Integer.class),
                        @ColumnResult(name = "totalOrderedUnits", type = Integer.class), // totalOrderedUnits
                        @ColumnResult(name = "totalOrderedValue", type = Double.class), // totalOrderedValue
                        @ColumnResult(name = "totalDeliveredUnits", type = Integer.class), // totalDeliveredUnits
                        @ColumnResult(name = "totalDeliveredValue", type = Double.class)})) // totalDeliveredValue

@NamedNativeQuery(name = "Order.getUsers",
        query = "select * from public.customer_aquisition(:timeZone, :startDate, :endDate, :pageSize, :pageNumber)",
        resultSetMapping = "Mapping.UserReportDTO")
@SqlResultSetMapping(name = "Mapping.UserReportDTO",
        classes = @ConstructorResult(targetClass = UserReportDTO.class,
                columns = {@ColumnResult(name = "createdAt", type = Date.class),
                        @ColumnResult(name = "total", type = Integer.class)}))

@NamedNativeQuery(name = "Order.getUserOrdersList",
        query = "select * from public.customer_order_report(:timeZone, :lastOrderedAfter, :lastOrderedBefore, :startItem, :endItem)",
        resultSetMapping = "Mapping.CustomerOrderReportDTO")
@SqlResultSetMapping(name = "Mapping.CustomerOrderReportDTO",
        classes = @ConstructorResult(targetClass = CustomerOrderReportDTO.class,
                columns = {@ColumnResult(name = "userId", type = String.class),
                        @ColumnResult(name = "name", type = String.class),
                        @ColumnResult(name = "totalOrderCount", type = Integer.class),
                        @ColumnResult(name = "totalOrderValue", type = Double.class),
                        @ColumnResult(name = "lastOrderedAt", type = Date.class)}))

@Table(name = "Order", schema = "public")
public class Order extends EmployeeAndUserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @ManyToOne()
    @JoinColumn(name = "userId", referencedColumnName = "id")
    private EndUser user;

    @ManyToOne()
    @JoinColumn(name = "storeId", referencedColumnName = "id")
    private Store store;

    @ManyToOne()
    @JoinColumn(name = "orderStatusId", referencedColumnName = "id")
    private OrderStatus orderStatus;

    @ManyToOne()
    @JoinColumn(name = "orderSourceId", referencedColumnName = "id")
    private OrderSource orderSource;

    @ManyToOne()
    @JoinColumn(name = "deliveryAddressId", referencedColumnName = "id")
    private Address deliveryAddress;

    @Column(name = "orderPlacedAt")
    private Date orderPlacedAt;

    public Order() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public EndUser getUser() {
        return user;
    }

    public void setUser(EndUser user) {
        this.user = user;
    }

    public Store getStore() {
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    public OrderSource getOrderSource() {
        return orderSource;
    }

    public void setOrderSource(OrderSource orderSource) {
        this.orderSource = orderSource;
    }

    public Address getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(Address deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public Date getOrderPlacedAt() {
        return orderPlacedAt;
    }

    public void setOrderPlacedAt(Date orderPlacedAt) {
        this.orderPlacedAt = orderPlacedAt;
    }
}
