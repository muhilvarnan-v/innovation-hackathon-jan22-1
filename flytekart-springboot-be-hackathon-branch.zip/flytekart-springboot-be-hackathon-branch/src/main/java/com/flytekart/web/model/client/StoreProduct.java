package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAuditWithDeletion;
import com.flytekart.web.model.dto.ProductStoreProductDTO;
import com.flytekart.web.model.dto.StoreProductDTO;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@NamedNativeQuery(name = "StoreProduct.findAllProductsWithStoreProductsByStoreId",
        query = "select p.id as id, p.name as name, p.categoryId as categoryId, p.isActive as isActive, sp.id as storeProductId, sp.deletedAt as storeProductDeletedAt, sp.deletedBy as storeProductDeletedBy" +
                " from Product p left join StoreProduct sp on sp.productId = p.id " +
                "and sp.storeId=:storeId where p.categoryId=:categoryId and p.isActive = true and p.deletedAt is null",
        resultSetMapping = "Mapping.ProductStoreProductDTO")
@SqlResultSetMapping(name = "Mapping.ProductStoreProductDTO",
        classes = @ConstructorResult(targetClass = ProductStoreProductDTO.class,
                columns = {@ColumnResult(name = "id", type = String.class),
                        @ColumnResult(name = "name", type = String.class),
                        @ColumnResult(name = "categoryId", type = String.class),
                        @ColumnResult(name = "isActive", type = Boolean.class),
                        @ColumnResult(name = "storeProductId", type = String.class),
                        @ColumnResult(name = "storeProductDeletedAt", type = String.class),
                        @ColumnResult(name = "storeProductDeletedBy", type = String.class)}))

@NamedNativeQuery(name = "StoreProduct.findUndeletedWithVariantsByStoreIdAndCategoryId",
        query = "select sv.id as id, p.id as productId, p.name as productName, v.name as variantName, sv.price as price, sv.tax as tax, sv.originalPrice as originalPrice, c.name as categoryName from StoreVariant sv " +
                "inner join Variant v on v.id = sv.variantId and v.isActive = true and v.deletedAt is null " +
                "inner join Product p on p.id = v.productId " +
                "inner join Category c on c.id = p.categoryId " +
                "where p.id in (" +
                    "select productId from StoreProduct sp " +
                    "inner join Product p on p.id = sp.productId and p.categoryId = :categoryId " +
                    // TODO Category should be active at org level and store level?
                    "and p.isActive = true and p.deletedAt is null " +
                    "where sp.storeId = :storeId and sp.deletedAt is null limit :limit offset :offset " +
                ") and sv.isActive = true and sv.storeId = :storeId and sv.deletedAt is null order by p.name, p.id, sv.price",
        resultSetMapping = "Mapping.StoreProductDTO")
@SqlResultSetMapping(name = "Mapping.StoreProductDTO",
        classes = @ConstructorResult(targetClass = StoreProductDTO.class,
                columns = {@ColumnResult(name = "id", type = String.class),
                        @ColumnResult(name = "productId", type = String.class),
                        @ColumnResult(name = "productName", type = String.class),
                        @ColumnResult(name = "variantName", type = String.class),
                        @ColumnResult(name = "price", type = Double.class),
                        @ColumnResult(name = "tax", type = Double.class),
                        @ColumnResult(name = "originalPrice", type = Double.class),
                        @ColumnResult(name = "categoryName", type = String.class)}))
@Entity
@Table(name = "StoreProduct", schema = "public")
public class StoreProduct extends UserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @ManyToOne()
    @JoinColumn(name = "storeId", referencedColumnName = "id")
    private Store store;

    @ManyToOne()
    @JoinColumn(name = "productId", referencedColumnName = "id")
    private Product product;

    public StoreProduct() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Store getStore() {
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
