package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Each item part of an order.
 */
@Entity
@Table(name = "OrderDeliveryLog", schema = "public")
public class OrderDeliveryLog extends UserDateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String orderDeliveryId;

    @Column(length = 40)
    private String deliveryStatusId;

    @Column(length = 1000)
    private String description;

    public OrderDeliveryLog() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderDeliveryId() {
        return orderDeliveryId;
    }

    public void setOrderDeliveryId(String orderDeliveryId) {
        this.orderDeliveryId = orderDeliveryId;
    }

    public String getDeliveryStatusId() {
        return deliveryStatusId;
    }

    public void setDeliveryStatusId(String deliveryStatusId) {
        this.deliveryStatusId = deliveryStatusId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
