package com.flytekart.web.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ApiResponse<T> {

    private int statusCode;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private T body;

    public ApiResponse(int statusCode, T body) {
        this.statusCode = statusCode;
        this.body = body;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public T getBody() {
        return body;
    }

    public void setBody(T body) {
        this.body = body;
    }
}
