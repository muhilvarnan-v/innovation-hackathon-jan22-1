package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.Product;
import com.flytekart.web.model.client.ProductAttribute;
import com.flytekart.web.model.client.Store;
import com.flytekart.web.model.request.CreateProductAttributeRequest;
import com.flytekart.web.model.request.CreateProductRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.AttributeRepository;
import com.flytekart.web.repository.client.ProductAttributeRepository;
import com.flytekart.web.repository.client.ProductRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.ProductService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * TODO Make updates to get only non-deleted ProductAttributes with active and inactive filter
 * TODO Create a new API to delete a ProductAttribute
 */
@RestController
@RequestMapping("/api/productattributes")
public class ProductAttributeController {

    @Autowired
    private ProductAttributeRepository repository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private AttributeRepository attributeRepository;

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody CreateProductAttributeRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }
        Optional<Product> optionalProduct = productRepository.findById(request.getProductId());
        Optional<Attribute> optionalAttribute = attributeRepository.findById(request.getAttributeId());
        if (optionalProduct.isEmpty() || optionalAttribute.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        ProductAttribute productAttribute = new ProductAttribute();
        productAttribute.setAttribute(optionalAttribute.get());
        productAttribute.setProduct(optionalProduct.get());
        repository.save(productAttribute);
        return ResponseEntity.ok(new ApiResponse<>(200, productAttribute));
    }

    @Transactional
    @GetMapping("/product/{productId}")
    public ResponseEntity<?> getProductAttributesByProductId(@RequestParam String clientId,
                                                        @PathVariable String productId) {
        DBContextHolder.setCurrentDb(clientId);

        Optional<Product> optionalProduct = productRepository.findById(productId);
        if (optionalProduct.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        List<ProductAttribute> productAttributes = repository.findByProductId(productId);
        return ResponseEntity.ok(new ApiResponse<>(200, productAttributes));
    }
}
