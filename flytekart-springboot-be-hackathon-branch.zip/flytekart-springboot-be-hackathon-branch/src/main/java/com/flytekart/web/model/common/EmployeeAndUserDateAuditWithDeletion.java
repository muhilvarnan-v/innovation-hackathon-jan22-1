package com.flytekart.web.model.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.util.Constants;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.util.Date;

@MappedSuperclass
/*@JsonIgnoreProperties(
        value = {"createdBy", "updatedBy"},
        allowGetters = true)*/
/**
 * Can be used for auditing both solely User or solely Employee changes.
 * For cases where createdBy and lastUpdatedBy have employee and user, and deletion audit
 * use EmployeeAndUserDateAuditWithDeletion class
 */
public abstract class EmployeeAndUserDateAuditWithDeletion extends DateAuditWithDeletion {
    @Column
    private String createdBy;
    @Column
    private String lastUpdatedBy;
    @Column
    private String employeeCreatedBy;
    @Column
    private String employeeLastUpdatedBy;
    @Column
    private String deletedBy;
    @Column
    private String employeeDeletedBy;

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getEmployeeCreatedBy() {
        return employeeCreatedBy;
    }

    public void setEmployeeCreatedBy(String employeeCreatedBy) {
        this.employeeCreatedBy = employeeCreatedBy;
    }

    public String getEmployeeLastUpdatedBy() {
        return employeeLastUpdatedBy;
    }

    public void setEmployeeLastUpdatedBy(String employeeLastUpdatedBy) {
        this.employeeLastUpdatedBy = employeeLastUpdatedBy;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public String getEmployeeDeletedBy() {
        return employeeDeletedBy;
    }

    public void setEmployeeDeletedBy(String employeeDeletedBy) {
        this.employeeDeletedBy = employeeDeletedBy;
    }

    @PrePersist
    public void onPrePersist() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        if (userPrincipal.getUserType() == Constants.USER) {
            setCreatedBy(userPrincipal.getId());
            setLastUpdatedBy(userPrincipal.getId());
            setEmployeeCreatedBy(null);
            setEmployeeLastUpdatedBy(null);
        } else {
            setCreatedBy(null);
            setLastUpdatedBy(null);
            setEmployeeCreatedBy(userPrincipal.getId());
            setEmployeeLastUpdatedBy(userPrincipal.getId());
        }
        setCreatedAt(new Date());
        setLastUpdatedAt(new Date());
    }

    @PreUpdate
    public void onPreUpdate() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        if (userPrincipal.getUserType() == Constants.USER) {
            setLastUpdatedBy(userPrincipal.getId());
            setEmployeeLastUpdatedBy(null);
        } else {
            setLastUpdatedBy(null);
            setEmployeeLastUpdatedBy(userPrincipal.getId());
        }
        setLastUpdatedAt(new Date());
    }
}

