package com.flytekart.web.model.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.flytekart.web.model.common.UserDateAudit;
import com.flytekart.web.model.common.UserDateAuditWithDeletion;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "Product", schema = "public")
public class Product extends UserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 200)
    @NotNull(message = "Name cannot be empty")
    private String name;

    @Column(length = 1000)
    private String description;

    @Column(length = 1000)
    private String imageUrl;

    /*@Column(length = 40)
    private String categoryId;*/

    @ManyToOne()
    @JoinColumn(name = "categoryId", referencedColumnName = "id", updatable = false)
    private Category category;

    @Column(length = 40)
    @JsonProperty(value = "isActive")
    private boolean isActive;

    public Product() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @JsonProperty(value = "isActive")
    public boolean isActive() {
        return isActive;
    }

    @JsonProperty(value = "isActive")
    public void setActive(boolean active) {
        isActive = active;
    }

    public String getImageUrl(){
        return imageUrl;
    }
}
