package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.dto.AttributeValueDTO;
import com.flytekart.web.model.request.CreateVariantRequest;
import com.flytekart.web.model.request.CreateVariantVavRequest;
import com.flytekart.web.model.request.EditVariantRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.*;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Make updates to get only non-deleted Variants with active and inactive filter - Done
 * Create an API to make a Variant inactive - Done
 * Create a new API to delete a Variant - Done
 * TODO Update a variant - like sku, description, active status
 */
@RestController
@RequestMapping("/api/variants")
public class VariantController {

    @Autowired
    private VariantService variantService;

    @Autowired
    private ProductService productService;

    @Autowired
    private StoreVariantService storeVariantService;

    @Autowired
    private AttributeService attributeService;

    @Autowired
    private AttributeValueService attributeValueService;

    @Autowired
    private VariantAttributeValueService variantAttributeValueService;

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody CreateVariantRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }
        Product product = productService.getProductByProductId(request.getProductId());
        if (product == null) {
            return ResponseEntity.badRequest().build();
        }
        Variant variant = new Variant();
        variant.setProduct(product);
        variant.setSku(request.getSku());
        variant.setName(request.getName());
        variant.setPrice(request.getPrice());
        variant.setOriginalPrice(request.getOriginalPrice());
        variant.setTax(request.getTax());
        variant.setActive(request.isActive());
        variant.setImageUrl(request.getImageUrl());
        variantService.save(variant);
        return ResponseEntity.ok(new ApiResponse<>(200, variant));
    }

    @PostMapping("/savevav")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> saveVav(@Valid @RequestBody CreateVariantVavRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }
        Product product = productService.getProductByProductId(request.getProductId());
        if (product == null) {
            return ResponseEntity.badRequest().build();
        }
        Variant variant;
        if (request.getId() != null) {
            variant = variantService.getVariantByVariantId(request.getId());
            if (variant == null) {
                return ResponseEntity.badRequest().build();
            }
        } else {
            variant = new Variant();
        }
        variant.setId(request.getId());
        variant.setProduct(product);
        variant.setSku(request.getSku());
        variant.setName(request.getName());
        variant.setPrice(request.getPrice());
        variant.setOriginalPrice(request.getOriginalPrice());
        variant.setTax(request.getTax());
        variant.setActive(request.isActive());
        variantService.save(variant);

        List<VariantAttributeValue> existingVavs = variantAttributeValueService.getVariantAttributeValuesByVariantId(variant.getId());
        if (request.getAttributeValueDTOs() == null) {
            request.setAttributeValueDTOs(new ArrayList<>(0));
        }
        if (existingVavs == null) {
            existingVavs = new ArrayList<>(0);
        }
        List<AttributeValueDTO> foundAttributeValueDTOS = new ArrayList<>(request.getAttributeValueDTOs().size());
        // Delete existing Vavs if not present in the request
        for (VariantAttributeValue existingVav : existingVavs) {
            boolean found = false;
            for (AttributeValueDTO newVav : request.getAttributeValueDTOs()) {
                if (existingVav.getId().equals(newVav.getVariantAttributeValueId())
                        || (existingVav.getAttributeValue().getAttribute().getName().equalsIgnoreCase(newVav.getAttributeName())
                        && existingVav.getAttributeValue().getName().equalsIgnoreCase(newVav.getAttributeValueName()))) {
                    found = true;
                    foundAttributeValueDTOS.add(newVav);
                    break;
                }
            }
            if (!found) {
                existingVav.setDeletedAt(new Date());
                existingVav.setDeletedBy(principal.getId());
                variantAttributeValueService.save(existingVav);
            }
        }

        // Remove existing Vavs from the request
        List<AttributeValueDTO> requestDTOs = request.getAttributeValueDTOs();
        requestDTOs.removeAll(foundAttributeValueDTOS);

        // Create new Vavs
        for (AttributeValueDTO dto : requestDTOs) {
            /**
             * 1. Check if the attribute is available.
             * 2. If no, create new attribute
             * 3. Check if the attributeValue is available for that attribute.
             * 4. If no, create new attributeValue
             * 5. Check if this attribute is available for this variant.
             * 6. If yes, delete the existing Vav
             * 7. Create new Vav record
             */
            Attribute attribute = attributeService.getAttributesByName(dto.getAttributeName());
            if (attribute == null) {
                attribute = new Attribute();
                attribute.setName(dto.getAttributeName());
                attributeService.save(attribute);
            }
            AttributeValue attributeValue = attributeValueService.getAttributeValuesByAttributeIdAndName(attribute.getId(),
                    dto.getAttributeValueName());
            if (attributeValue == null) {
                attributeValue = new AttributeValue();
                attributeValue.setName(dto.getAttributeValueName());
                attributeValue.setAttribute(attribute);
                attributeValueService.save(attributeValue);
            }
            VariantAttributeValue existingVavWithSameA = variantAttributeValueService
                    .getVariantAttributeValueByVariantIdAndAttributeId(variant.getId(), attribute.getId());
            if (existingVavWithSameA != null) {
                existingVavWithSameA.setDeletedAt(new Date());
                existingVavWithSameA.setDeletedBy(principal.getId());
                variantAttributeValueService.save(existingVavWithSameA);
            }
            VariantAttributeValue newVav = new VariantAttributeValue();
            newVav.setVariant(variant);
            newVav.setAttributeValue(attributeValue);
            variantAttributeValueService.save(newVav);
        }

        return ResponseEntity.ok(new ApiResponse<>(200, variant));
    }

    @Transactional
    @GetMapping("/getByProductId/{productId}")
    public ResponseEntity<?> getVariantsByProductId(@RequestParam String clientId,
                                                              @RequestParam(required = false) Boolean isActive,
                                                              @PathVariable String productId) {
        DBContextHolder.setCurrentDb(clientId);

        Product product = productService.getProductByProductId(productId);
        if (product == null) {
            return ResponseEntity.badRequest().build();
        }

        List<Variant> variants = variantService.getVariantsByProductId(productId, isActive);
        return ResponseEntity.ok(new ApiResponse<>(200, variants));
    }

    @Transactional
    @GetMapping("/{variantId}")
    public ResponseEntity<?> getVariantByVariantId(@RequestParam String clientId,
                                                             @PathVariable String variantId) {
        DBContextHolder.setCurrentDb(clientId);

        Variant variant = variantService.getVariantByVariantId(variantId);
        if (variant == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(new ApiResponse<>(200, variant));
    }

    /**
     * Delete a variant by variant id.
     * Store variants should be deleted before deleting a variant.
     *
     * @param clientId  client id
     * @param variantId variant id
     * @return
     */
    @Transactional
    @DeleteMapping("/{variantId}")
    public ResponseEntity<?> deleteVariantByVariantId(@RequestParam String clientId,
                                                                @PathVariable String variantId) {
        DBContextHolder.setCurrentDb(clientId);

        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Variant variant = variantService.getVariantByVariantId(variantId);
        if (variant == null) {
            return ResponseEntity.notFound().build();
        }

        List<StoreVariant> storeVariants = storeVariantService.getStoreVariantsByVariantId(variantId);
        if (storeVariants != null && storeVariants.size() > 0) {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse(400,
                            "Store variants should be deleted before deleting a variant."));
        }

        variant.setDeletedBy(principal.getId());
        variant.setDeletedAt(new Date());
        variantService.save(variant);
        return ResponseEntity.ok(new ApiResponse<>(200, variant));
    }

    /**
     * Is this required, if we make a new edit API?
     * Make a variant active or inactive by variant id.
     * Store variants should be deleted before deleting a variant.
     *
     * @param clientId  client id
     * @param status    true = make active, false = make inactive
     * @param variantId variant id
     * @return
     */
    @Transactional
    @PostMapping("/changeStatus/{variantId}")
    public ResponseEntity<?> changeActiveStatusByVariantId(@RequestParam String clientId,
                                                                     @RequestParam boolean status,
                                                                     @PathVariable String variantId) {
        DBContextHolder.setCurrentDb(clientId);

        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Variant variant = variantService.getVariantByVariantId(variantId);
        if (variant == null) {
            return ResponseEntity.notFound().build();
        }

        if (!status) { // To make a variant inactive, storeVariants should be inactive
            List<StoreVariant> storeVariants = storeVariantService
                    .getActiveStoreVariantByVariantId(variantId);
            if (storeVariants != null || storeVariants.size() > 0) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(400,
                                "Store variants should be inactive before making a variant inactive."));
            }
        }

        variant.setActive(status);
        variantService.save(variant);
        return ResponseEntity.ok(new ApiResponse<>(200, variant));
    }

    @Transactional
    @PostMapping("/{variantId}")
    public ResponseEntity<?> editVariantByVariantId(@Valid @RequestBody EditVariantRequest request,
                                                              @RequestParam String clientId,
                                                              @PathVariable String variantId) {
        DBContextHolder.setCurrentDb(clientId);

        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Variant variant = variantService.getVariantByVariantId(variantId);
        if (variant == null) {
            return ResponseEntity.notFound().build();
        }

        // TODO Uncomment this after StoreVariants are fixed
        /*if (!request.isActive()) { // To make a variant inactive, storeVariants should be inactive
            List<StoreVariant> storeVariants = storeVariantService
                    .getActiveStoreVariantByVariantId(variantId);
            if (storeVariants != null || storeVariants.size() > 0) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(400,
                                "Store variants should be inactive before making a variant inactive."));
            }
        }*/

        variant.setActive(request.isActive());
        variant.setSku(request.getSku());
        variant.setName(request.getName());
        variant.setPrice(request.getPrice());
        variant.setOriginalPrice(request.getOriginalPrice());
        variant.setTax(request.getTax());
        variantService.save(variant);
        return ResponseEntity.ok(new ApiResponse<>(200, variant));
    }
}
