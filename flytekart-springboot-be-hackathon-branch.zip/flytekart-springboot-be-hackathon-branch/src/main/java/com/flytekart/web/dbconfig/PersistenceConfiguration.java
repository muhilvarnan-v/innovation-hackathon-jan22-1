package com.flytekart.web.dbconfig;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * https://medium.com/innomizetech/dynamic-multi-database-application-with-spring-boot-7c61a743e914
 * https://stackoverflow.com/questions/46935382/spring-boot-change-connection-dynamically
 * https://grobmeier.solutions/spring-multitenancy-switch-database-at-runtime.html
 * https://javadeveloperzone.com/hibernate/spring-hibernate-xml-multi-tenancy-example/
 * https://dzone.com/articles/dynamic-multi-tenancy-using-java-spring-boot-sprin
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = "com.flytekart.web",
        entityManagerFactoryRef = "multiEntityManager",
        transactionManagerRef = "multiTransactionManager"
)
public class PersistenceConfiguration {
    private final String PACKAGE_SCAN = "com.flytekart.web";

    @Value("${app.datasource.main.jdbc-url}")
    private String jdbcUrl;

    @Value("${app.datasource.main.jdbc-db}")
    private String jdbcDB;

    @Value("${app.datasource.main.username}")
    private String username;

    @Value("${app.datasource.main.password}")
    private String password;

    @Primary
    @Bean(name = "mainDataSource")
    @ConfigurationProperties("app.datasource.main")
    public DataSource mainDataSource() {
        /*DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/flytekart_main?allowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC&useLegacyDatetimeCode=false");
        dataSource.setUsername("root");
        dataSource.setPassword("Flytekart_1");
        return dataSource;*/
        return DataSourceBuilder.create().type(HikariDataSource.class).build();
    }
    @Bean(name = "multiRoutingDataSource")
    public DataSource multiRoutingDataSource() {
        MultiRoutingDataSource multiRoutingDataSource = new MultiRoutingDataSource(
                jdbcUrl, jdbcDB, username, password);
        multiRoutingDataSource.setDefaultTargetDataSource(mainDataSource());
        return multiRoutingDataSource;
    }
    @Bean(name = "multiEntityManager")
    public LocalContainerEntityManagerFactoryBean multiEntityManager() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(multiRoutingDataSource());
        em.setPackagesToScan(PACKAGE_SCAN);
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(hibernateProperties());
        return em;
    }
    @Bean(name = "multiTransactionManager")
    public PlatformTransactionManager multiTransactionManager() {
        JpaTransactionManager transactionManager
                = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(
                multiEntityManager().getObject());
        return transactionManager;
    }
    @Primary
    @Bean(name = "dbSessionFactory")
    public LocalSessionFactoryBean dbSessionFactory() {
        LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
        sessionFactoryBean.setDataSource(multiRoutingDataSource());
        sessionFactoryBean.setPackagesToScan(PACKAGE_SCAN);
        sessionFactoryBean.setHibernateProperties(hibernateProperties());
        return sessionFactoryBean;
    }
    private Properties hibernateProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.show_sql", true);
        properties.put("hibernate.format_sql", true);
        properties.put("hibernate.dialect", "org.hibernate.dialect.PostgreSQL94Dialect");
        return properties;
    }
}
