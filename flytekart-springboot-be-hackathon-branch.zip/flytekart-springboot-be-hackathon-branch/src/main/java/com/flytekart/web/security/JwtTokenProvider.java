package com.flytekart.web.security;

import com.flytekart.web.util.Constants;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.repository.query.QueryLookupStrategy;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class JwtTokenProvider {

    @Value("${app.jwtSecret}")
    private String jwtSecret;

    @Value("${app.jwtExpirationInMs}")
    private long jwtExpirationInMs;

    public String generateToken(Authentication authentication, String clientId) {
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();

        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpirationInMs);
        Map<String, String> claimsMap = new HashMap<>(1);
        claimsMap.put(Constants.USER_TYPE, userPrincipal.getUserType());
        claimsMap.put(Claims.SUBJECT, userPrincipal.getId());

        Key key = Keys.hmacShaKeyFor((jwtSecret + clientId).getBytes(StandardCharsets.UTF_8));
        return Jwts.builder()
                .setSubject(userPrincipal.getId())
                .setClaims(claimsMap)
                .setIssuedAt(new Date())
                .setExpiration(expiryDate)
                .signWith(key)
                .compact();
    }

    public String getUserIdFromJwt(String token, String clientId) {
        Claims claims = Jwts.parserBuilder().setSigningKey((jwtSecret + clientId).getBytes(StandardCharsets.UTF_8))
                .build().parseClaimsJws(token).getBody();
        return claims.getSubject();
    }

    public String getUserTypeFromJwt(String token, String clientId) {
        Claims claims = Jwts.parserBuilder().setSigningKey((jwtSecret + clientId).getBytes(StandardCharsets.UTF_8))
                .build().parseClaimsJws(token).getBody();
        return claims.get(Constants.USER_TYPE).toString();
    }

    public boolean validateToken(String authToken, String clientId) {
        try {
            Jwts.parserBuilder().setSigningKey((jwtSecret + clientId).getBytes(StandardCharsets.UTF_8)).build().parseClaimsJws(authToken);
        } catch (MalformedJwtException | ExpiredJwtException
                | UnsupportedJwtException | IllegalArgumentException
                | SignatureException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
}
