package com.flytekart.web.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CreateStoreVariantRequest {

    @Size(min = 1, max = 40)
    private String storeVariantId;

    @Size(min = 1, max = 40)
    private String storeId;

    @Size(min = 1, max = 40)
    private String variantId;

    @NotNull
    private Double price;

    private Double tax;

    private Double originalPrice;

    @NotNull
    @JsonProperty(value = "isActive")
    private boolean isActive;

    private int quantity;

    public String getStoreVariantId() {
        return storeVariantId;
    }

    public void setStoreVariantId(String storeVariantId) {
        this.storeVariantId = storeVariantId;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getVariantId() {
        return variantId;
    }

    public void setVariantId(String variantId) {
        this.variantId = variantId;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public Double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(Double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
