package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.Order;
import com.flytekart.web.model.client.OrderSource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderSourceRepository extends JpaRepository<OrderSource, String> {
    OrderSource findByName(String name);
}
