package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, String> {
    @Query("from Product where deletedBy IS NULL and categoryId=:categoryId order by name")
    List<Product> findUnDeletedByCategoryId(String categoryId);

    @Query("from Product where deletedBy IS NULL and id=:id")
    Product findUnDeletedByProductId(String id);

    @Query("from Product where deletedBy IS NULL and categoryId=:categoryId and name=:productName")
    Product findUnDeletedByCategoryIdAndProductName(String categoryId, String productName);
}
