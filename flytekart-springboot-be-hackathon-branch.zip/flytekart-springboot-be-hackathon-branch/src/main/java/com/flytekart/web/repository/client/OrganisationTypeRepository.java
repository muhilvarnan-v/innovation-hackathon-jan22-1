package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.OrganisationType;
import com.flytekart.web.model.client.Role;
import com.flytekart.web.model.client.RoleName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrganisationTypeRepository extends JpaRepository<OrganisationType, String> {
    Optional<OrganisationType> findByName(String name);
}