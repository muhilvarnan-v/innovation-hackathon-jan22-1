package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.EmployeePushToken;
import com.flytekart.web.model.client.Store;
import com.flytekart.web.model.client.UserPushToken;
import com.flytekart.web.model.request.*;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.StoreRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.AddressService;
import com.flytekart.web.service.NotificationService;
import com.flytekart.web.service.OrganisationService;
import com.flytekart.web.service.StoreService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @PostMapping("/saveEmployeePushToken")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> saveEmployeePushToken(@Valid @RequestBody CreateEmployeePushTokenRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        if (!request.getClientType().equals(Constants.ANDROID)) {
            return ResponseEntity.badRequest().build();
        }

        /**
         * 1. Check if there is an undeleted push token for userId, token and clientType combination.
         * 2. If available, don't save. Just send the record back as response.
         * 3. If not available, check if there is push token for token and clientType combination.
         * 4. If available, update the userId column and send the response.
         * 5. If not available, create a new record and send the response.
         * 6. Manage FCM topics
         */
        EmployeePushToken employeePushToken = notificationService.getUnDeletedEmployeePushTokenByUserIdAndTokenAndClientType(
                request.getUserId(), request.getToken(), request.getClientType());
        if (employeePushToken != null) {
            // No change happened
            return ResponseEntity.ok(new ApiResponse<>(200, employeePushToken));
        }

        employeePushToken = notificationService.getUnDeletedEmployeePushTokenByTokenAndClientType(
                request.getToken(), request.getClientType());
        if (employeePushToken != null) {
            // Mapped user id changed
            String oldEmployeeId = employeePushToken.getUserId();
            employeePushToken.setUserId(principal.getId());
            notificationService.saveEmployeePushToken(employeePushToken);
            notificationService.unSubscribeTokenFromSpecificEmployeeTopic(employeePushToken.getToken(), oldEmployeeId);
            notificationService.subscribeTokenToSpecificEmployeeTopic(employeePushToken.getToken(), principal.getId());
            return ResponseEntity.ok(new ApiResponse<>(200, employeePushToken));
        }

        employeePushToken = new EmployeePushToken();
        employeePushToken.setUserId(principal.getId());
        employeePushToken.setToken(request.getToken());
        employeePushToken.setClientType(request.getClientType());
        notificationService.saveEmployeePushToken(employeePushToken);
        notificationService.subscribeTokenToSpecificEmployeeTopic(employeePushToken.getToken(), principal.getId());
        notificationService.subscribeTokenToAllEmployeesTopic(employeePushToken.getToken(), clientId);

        return ResponseEntity.ok(new ApiResponse<>(200, employeePushToken));
    }

    @PostMapping("/deleteEmployeePushToken")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> deleteEmployeePushToken(@Valid @RequestBody DeleteEmployeePushTokenRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        /**
         * 1. Check if there is an undeleted EmployeePushToken with the given id.
         * 2. Soft delete it.
         * 3. Manage FCM topics.
         */
        EmployeePushToken employeePushToken = notificationService.getUnDeletedEmployeePushTokenById(request.getId());
        if (employeePushToken == null) {
            return ResponseEntity.notFound().build();
        }
        employeePushToken.setDeletedBy(principal.getId());
        employeePushToken.setDeletedAt(new Date());
        notificationService.saveEmployeePushToken(employeePushToken);
        notificationService.unSubscribeTokenFromSpecificEmployeeTopic(employeePushToken.getToken(), employeePushToken.getUserId());
        notificationService.unSubscribeTokenFromAllEmployeesTopic(employeePushToken.getToken(), clientId);

        return ResponseEntity.ok(new ApiResponse<>(200, employeePushToken));
    }

    @PostMapping("/saveUserPushToken")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> saveUserPushToken(@Valid @RequestBody CreateUserPushTokenRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        if (!request.getClientType().equals(Constants.ANDROID)) {
            return ResponseEntity.badRequest().build();
        }

        /**
         * 1. Check if there is an undeleted push token for userId, token and clientType combination.
         * 2. If available, don't save. Just send the record back as response.
         * 3. If not available, check if there is push token for token and clientType combination.
         * 4. If available, update the userId column and send the response.
         * 5. If not available, create a new record and send the response.
         * 6. Manage FCM topics
         */
        UserPushToken userPushToken = notificationService.getUnDeletedUserPushTokenByUserIdAndTokenAndClientType(
                request.getUserId(), request.getToken(), request.getClientType());
        if (userPushToken != null) {
            // No change happened
            return ResponseEntity.ok(new ApiResponse<>(200, userPushToken));
        }

        userPushToken = notificationService.getUnDeletedUserPushTokenByTokenAndClientType(
                request.getToken(), request.getClientType());
        if (userPushToken != null) {
            // Mapped user id changed
            String oldEmployeeId = userPushToken.getUserId();
            userPushToken.setUserId(principal.getId());
            notificationService.saveUserPushToken(userPushToken);
            notificationService.unSubscribeTokenFromSpecificUserTopic(userPushToken.getToken(), oldEmployeeId);
            notificationService.subscribeTokenToSpecificUserTopic(userPushToken.getToken(), principal.getId());
            return ResponseEntity.ok(new ApiResponse<>(200, userPushToken));
        }

        userPushToken = new UserPushToken();
        userPushToken.setUserId(principal.getId());
        userPushToken.setToken(request.getToken());
        userPushToken.setClientType(request.getClientType());
        notificationService.saveUserPushToken(userPushToken);
        notificationService.subscribeTokenToSpecificUserTopic(userPushToken.getToken(), principal.getId());

        return ResponseEntity.ok(new ApiResponse<>(200, userPushToken));
    }

    @PostMapping("/deleteUserPushToken")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> deleteUserPushToken(@Valid @RequestBody DeleteUserPushTokenRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        /**
         * 1. Check if there is an undeleted EmployeePushToken with the given id.
         * 2. Soft delete it.
         * 3. Manage FCM topics.
         */
        UserPushToken userPushToken = notificationService.getUnDeletedUserPushTokenById(request.getId());
        if (userPushToken == null) {
            return ResponseEntity.notFound().build();
        }
        userPushToken.setDeletedBy(principal.getId());
        userPushToken.setDeletedAt(new Date());
        notificationService.saveUserPushToken(userPushToken);
        notificationService.unSubscribeTokenFromSpecificUserTopic(userPushToken.getToken(), userPushToken.getUserId());

        return ResponseEntity.ok(new ApiResponse<>(200, userPushToken));
    }


}
