package com.flytekart.web.util;

import com.flytekart.web.model.client.Otp;
import com.flytekart.web.repository.client.OtpRepository;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;
@Component
public class SendSms {

    @Value("${app.fast2sms.api_key}")
    private String fast2smsAPI;
    @Value("${app.env}")
    private String env;

    @Autowired
    OtpRepository otpRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    public String genOtp() {
        if (env.equals(Constants.Env.PRODUCTION)) {
            Random r = new Random(System.currentTimeMillis());
            return Integer.toString(((1 + r.nextInt(2)) * 100000 + r.nextInt(100000)));
        } else {
            return Constants.SAMPLE_OTP;
        }
    }
    
    @Transactional
    public Otp sendOtp(String clientId, String toPhoneNumber,
                                            String userId, String userType,
                                            String purpose) {

        Date expiry =  new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(15));
        String genOtp = genOtp();
        System.out.println(expiry);
        System.out.println("otp Id");
        System.out.println(genOtp);
        Otp otp = new Otp();
        otp.setOtp(passwordEncoder.encode(genOtp));
        otp.setExpiry(expiry);
        otp.setMobileNumber(toPhoneNumber);
        otp.setPurpose(purpose);
        otp.setUserType(userType);
        Otp result = otpRepository.save(otp);
        //toPhoneNumber = toPhoneNumber.replace(Constants.HYPHEN, Constants.EMPTY);
        if (env.equals(Constants.Env.PRODUCTION)) {
            sendMessage("otp", toPhoneNumber, genOtp);
        }
		return result;
    }

    private String sendMessage(String route, String toNumber, String message){
        try {
            if (toNumber.startsWith("+")) {
                String[] numbers = toNumber.split("-");
                if (numbers.length > 1) toNumber = numbers[1];
            }
            HttpResponse response = Unirest.post("https://www.fast2sms.com/dev/bulkV2")
            .header("authorization", fast2smsAPI)
            .header("Content-Type", "application/x-www-form-urlencoded")
            .body("variables_values="+message+"&route="+route+"&numbers="+toNumber)
            .asString();
            return "success";

        } catch (UnirestException e) {
            return "fail";
        }
      
    }

}
