package com.flytekart.web.model.client;

import com.flytekart.web.model.common.EmployeeAndUserDateAuditWithDeletion;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Handles returns.
 * Each ReturnOrder contains multiple ReturnOrderItems
 */
@Entity
@Table(name = "ReturnOrder", schema = "public")
public class ReturnOrder extends EmployeeAndUserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String orderId;

    @Column(length = 40)
    private String returnOrderStatusId;

    public ReturnOrder() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getReturnOrderStatusId() {
        return returnOrderStatusId;
    }

    public void setReturnOrderStatusId(String returnOrderStatusId) {
        this.returnOrderStatusId = returnOrderStatusId;
    }
}
