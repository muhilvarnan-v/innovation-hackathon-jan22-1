package com.flytekart.web.controller;

import com.flytekart.web.model.client.OrganisationType;
import com.flytekart.web.model.client.Role;
import com.flytekart.web.model.request.CreateOrganisationRequest;
import com.flytekart.web.repository.client.CRoleRepository;
import com.flytekart.web.repository.client.OrganisationRepository;
import com.flytekart.web.repository.client.OrganisationTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@Controller
public class OrganisationTypeController {

    @Autowired
    private OrganisationTypeRepository repository;

    public OrganisationType getOrganisationTypeByName(String name) {
        Optional<OrganisationType> optional = repository.findByName(name);
        if (optional.isPresent()) {
            return optional.get();
        }
        return null;
    }

    public OrganisationType getOrganisationTypeById(String name) {
        Optional<OrganisationType> optional = repository.findById(name);
        if (optional.isPresent()) {
            return optional.get();
        }
        return null;
    }
}
