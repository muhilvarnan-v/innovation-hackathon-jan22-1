package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.AttributeValue;
import com.flytekart.web.model.client.VariantAttributeValue;
import com.flytekart.web.model.request.CreateAttributeValueRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.model.response.AttributeResponse;
import com.flytekart.web.repository.client.AttributeRepository;
import com.flytekart.web.repository.client.AttributeValueRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.AttributeValueService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * Make updates to get non-deleted AttributeValues - Done
 * Create a new API to delete an AttributeValue - Done
 */
@RestController
@RequestMapping("/api/attributeValues")
public class AttributeValueController {

    @Autowired
    private AttributeValueService attributeValueService;

    @Autowired
    private AttributeRepository attributeRepository;

    /**
     * Create and edit AttributeValues.
     * TODO How to restrict edits of AttributeValues? Should we allow edits at all?
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody CreateAttributeValueRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        AttributeValue attributeValue;
        if (request.getId() == null) {
            attributeValue = CreateAttributeValueRequest.getAttributeValue(request);
        } else {
            AttributeValue existingAttributeValue = attributeValueService
                    .getAttributeValueByAttributeValueId(request.getId());
            if (existingAttributeValue == null) {
                return ResponseEntity.notFound().build();
            }
            attributeValue = CreateAttributeValueRequest.getAttributeValue(request, existingAttributeValue);
        }
        attributeValueService.save(attributeValue);
        return ResponseEntity.ok(new ApiResponse<>(200, attributeValue));
    }

    /**
     * Get all attribute values of a given attribute id
     * @param clientId
     * @param attributeId
     * @param prefix
     * @return
     */
    @Transactional
    @GetMapping("/getByAttributeId/{attributeId}")
    public ResponseEntity<?> getAttributeValuesByAttributeId(@RequestParam String clientId,
                                                                       @RequestParam(required = false) String prefix,
                                                        @PathVariable @Valid String attributeId) {
        DBContextHolder.setCurrentDb(clientId);

        Optional<Attribute> optionalAttribute = attributeRepository.findById(attributeId);
        if (optionalAttribute.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        List<AttributeValue> attributeValues;
        if (StringUtils.hasText(prefix)) {
            attributeValues =  attributeValueService.getAttributeValueByAttributeIdAndPrefix(attributeId, prefix);
        } else {
            attributeValues =  attributeValueService.getAttributeValuesByAttributeId(attributeId);
        }

        return ResponseEntity.ok(new ApiResponse<>(200, attributeValues));
    }

    /**
     * Get all attribute values
     * @param clientId
     * @return
     */
    @Transactional
    @GetMapping("/")
    public ResponseEntity<?> getAllAttributeValues(@RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);

        List<AttributeResponse> attributeResponses =  attributeValueService.getAllAttributeValues();

        return ResponseEntity.ok(new ApiResponse<>(200, attributeResponses));
    }

    /**
     * Soft delete attribute value using id
     * @param clientId
     * @param attributeValueId
     * @return
     */
    @Transactional
    @DeleteMapping("/{attributeValueId}")
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> deleteAttributeValueById(@RequestParam String clientId,
                                                                       @PathVariable String attributeValueId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        AttributeValue attributeValue = attributeValueService
                .getAttributeValueByAttributeValueId(attributeValueId);
        if (attributeValue == null) {
            return ResponseEntity.notFound().build();
        }

        attributeValue.setDeletedBy(principal.getId());
        attributeValue.setDeletedAt(new Date());
        attributeValueService.save(attributeValue);
        return ResponseEntity.ok(new ApiResponse<>(200, attributeValue));
    }
}
