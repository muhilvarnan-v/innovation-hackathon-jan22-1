package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAudit;
import com.flytekart.web.model.common.UserDateAuditWithDeletion;
import com.flytekart.web.model.dto.CategoryStoreCategoryDTO;
import com.flytekart.web.model.dto.StoreCategoryDTO;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@NamedNativeQuery(name = "StoreCategory.findAllCategoriesWithStoreCategoriesByStoreId",
        query = "select c.id as id, c.name as name, c.parentCategoryId as parentCategoryId, c.isActive as isActive, sc.id as storeCategoryId, sc.deletedAt as storeCategoryDeletedAt, sc.deletedBy as storeCategoryDeletedBy" +
                " from Category c left join StoreCategory sc on sc.categoryId = c.id " +
                "and sc.storeId=:storeId where c.isActive = true and c.deletedAt is null",
        resultSetMapping = "Mapping.CategoryStoreCategoryDTO")
@SqlResultSetMapping(name = "Mapping.CategoryStoreCategoryDTO",
        classes = @ConstructorResult(targetClass = CategoryStoreCategoryDTO.class,
                columns = {@ColumnResult(name = "id", type = String.class),
                        @ColumnResult(name = "name", type = String.class),
                        @ColumnResult(name = "parentCategoryId", type = String.class),
                        @ColumnResult(name = "isActive", type = Boolean.class),
                        @ColumnResult(name = "storeCategoryId", type = String.class),
                        @ColumnResult(name = "storeCategoryDeletedAt", type = String.class),
                        @ColumnResult(name = "storeCategoryDeletedBy", type = String.class)}))

@NamedNativeQuery(name = "StoreCategory.findUndeletedDTOByStoreId",
        query = "select c.id as id, c.name as name, c.parentCategoryId as parentCategoryId, c.isActive as isActive, sc.id as storeCategoryId" +
                " from Category c inner join StoreCategory sc on sc.categoryId = c.id " +
                "and sc.storeId=:storeId and sc.deletedAt is null where c.isActive = true and c.deletedAt is null",
        resultSetMapping = "Mapping.StoreCategoryDTO")
@SqlResultSetMapping(name = "Mapping.StoreCategoryDTO",
        classes = @ConstructorResult(targetClass = StoreCategoryDTO.class,
                columns = {@ColumnResult(name = "id", type = String.class),
                        @ColumnResult(name = "name", type = String.class),
                        @ColumnResult(name = "parentCategoryId", type = String.class),
                        @ColumnResult(name = "isActive", type = Boolean.class),
                        @ColumnResult(name = "storeCategoryId", type = String.class)}))

@Entity
@Table(name = "StoreCategory", schema = "public")
public class StoreCategory extends UserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @ManyToOne()
    @JoinColumn(name = "storeId", referencedColumnName = "id")
    private Store store;

    @ManyToOne()
    @JoinColumn(name = "categoryId", referencedColumnName = "id")
    private Category category;

    public StoreCategory() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Store getStore() {
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}
