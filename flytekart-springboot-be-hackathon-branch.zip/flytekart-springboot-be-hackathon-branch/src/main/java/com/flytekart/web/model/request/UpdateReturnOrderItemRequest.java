package com.flytekart.web.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class UpdateReturnOrderItemRequest {

    @NotBlank
    @Size(min = 1, max = 40)
    private String returnOrderItemId;

    @NotNull
    private int quantity;

    public String getReturnOrderItemId() {
        return returnOrderItemId;
    }

    public void setReturnOrderItemId(String returnOrderItemId) {
        this.returnOrderItemId = returnOrderItemId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
