package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.ProductAttribute;
import com.flytekart.web.model.client.Variant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VariantRepository extends JpaRepository<Variant, String> {
    List<Variant> findByProductId(String productId);

    @Query("from Variant where deletedBy IS NULL and id=:id")
    Variant findUnDeletedByVariantId(String id);

    @Query("from Variant where deletedBy IS NULL and productId=:productId and name=:variantName")
    Variant findUnDeletedByProductIdAndVariantName(String productId, String variantName);

    @Query("from Variant where deletedBy IS NULL and productId=:productId")
    List<Variant> findUnDeletedByProductId(String productId);

    @Query("from Variant where deletedBy IS NULL and productId=:productId and isActive=:isActive")
    List<Variant> findUnDeletedByProductId(String productId, boolean isActive);

    @Query("from Variant where deletedBy IS NULL")
    List<Variant> findAllUndeleted();

    @Query("from Variant where deletedBy IS NULL and isActive=:isActive")
    List<Variant> findAllUndeleted(boolean isActive);
}
