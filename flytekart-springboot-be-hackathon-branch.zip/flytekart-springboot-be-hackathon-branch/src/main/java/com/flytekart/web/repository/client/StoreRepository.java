package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Product;
import com.flytekart.web.model.client.Store;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StoreRepository extends JpaRepository<Store, String> {
    List<Store> findByOrganisationId(String organisationId);

    List<Store> findAllByOrderByNameAsc();

    List<Store> findByName(String name);

    // Using Havershine formula
    @Query(value = "select * from (select *, \n" +
            "( 6371 * acos( cos( radians(:lat) ) * cos( radians( a.latitude ) ) * cos( radians( a.longitude ) - radians(:lng) ) + sin( radians(:lat) ) * sin( radians( a.latitude ) ) ) ) As distance\n" +
            "from store s\n" +
            "inner join address a on a.id = s.addressId) sd\n" +
            "where distance is not null and distance < :radius order by distance", nativeQuery = true)
    List<Store> findNearestByLatLng(double lat, double lng, int radius);
}
