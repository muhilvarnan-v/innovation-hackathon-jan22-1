package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.dto.CategoryStoreCategoryDTO;
import com.flytekart.web.model.dto.ProductStoreProductDTO;
import com.flytekart.web.model.dto.StoreProductDTO;
import com.flytekart.web.model.request.CreateStoreProductRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.model.response.StoreProductWithVariantsResponse;
import com.flytekart.web.repository.client.CategoryRepository;
import com.flytekart.web.repository.client.ProductRepository;
import com.flytekart.web.repository.client.StoreRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.StoreProductService;
import com.flytekart.web.service.OrganisationService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/storeProducts")
public class StoreProductController {

    @Autowired
    private StoreProductService storeProductService;

    @Autowired
    private StoreRepository storeRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired 
    private OrganisationService organisationService;

    /*@Autowired
    private EntityManager em;*/

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody CreateStoreProductRequest request,
                                            @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        if (request.getStoreProductId() != null) {
            StoreProduct storeProduct = storeProductService.getStoreProductById(request.getStoreProductId());
            if (storeProduct != null) {
                if (request.isActive()) {
                    storeProduct.setDeletedAt(null);
                    storeProduct.setDeletedBy(null);
                } else {
                    storeProduct.setDeletedAt(new Date());
                    storeProduct.setDeletedBy(principal.getId());
                }
                storeProductService.save(storeProduct);
                boolean isActive = (storeProduct.getDeletedAt() == null);
                String deletedAt = (storeProduct.getDeletedAt() == null) ? null : storeProduct.getDeletedAt().toString();
                ProductStoreProductDTO dto = new ProductStoreProductDTO(
                        storeProduct.getProduct().getId(), storeProduct.getProduct().getName(),
                        storeProduct.getProduct().getCategory().getId(),
                        isActive, storeProduct.getId(), deletedAt,
                        storeProduct.getDeletedBy());
                return ResponseEntity.ok(new ApiResponse<>(200, dto));
            } else {
                return ResponseEntity.badRequest().build();
            }
        }

        if (request.getStoreId() == null || request.getProductId() == null) {
            return ResponseEntity.badRequest().build();
        }

        Optional<Store> optionalStore = storeRepository.findById(request.getStoreId());
        Optional<Product> optionalProduct = productRepository.findById(request.getProductId());
        if (optionalStore.isEmpty() || optionalProduct.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        StoreProduct storeProduct = storeProductService
                .getStoreProductByStoreIdAndProductId(request.getStoreId(), request.getProductId());
        if (storeProduct != null) {
            if (request.isActive()) {
                storeProduct.setDeletedAt(null);
                storeProduct.setDeletedBy(null);
            } else {
                storeProduct.setDeletedAt(new Date());
                storeProduct.setDeletedBy(principal.getId());
            }
            storeProductService.save(storeProduct);
            boolean isActive = (storeProduct.getDeletedAt() == null);
            String deletedAt = (storeProduct.getDeletedAt() == null) ? null : storeProduct.getDeletedAt().toString();
            ProductStoreProductDTO dto = new ProductStoreProductDTO(
                    storeProduct.getProduct().getId(), storeProduct.getProduct().getName(),
                    storeProduct.getProduct().getCategory().getId(),
                    isActive, storeProduct.getId(), deletedAt,
                    storeProduct.getDeletedBy());
            return ResponseEntity.ok(new ApiResponse<>(200, dto));
        }

        // TODO A combination of storeId and categoryId should be unique.
        StoreProduct newStoreProduct = new StoreProduct();
        newStoreProduct.setStore(optionalStore.get());
        newStoreProduct.setProduct(optionalProduct.get());
        if (request.isActive()) {
            newStoreProduct.setDeletedAt(null);
            newStoreProduct.setDeletedBy(null);
        } else {
            newStoreProduct.setDeletedAt(new Date());
            newStoreProduct.setDeletedBy(principal.getId());
        }
        storeProductService.save(newStoreProduct);
        boolean isActive = (newStoreProduct.getDeletedAt() == null);
        String deletedAt = (newStoreProduct.getDeletedAt() == null) ? null : newStoreProduct.getDeletedAt().toString();
        ProductStoreProductDTO dto = new ProductStoreProductDTO(
                newStoreProduct.getProduct().getId(), newStoreProduct.getProduct().getName(),
                newStoreProduct.getProduct().getCategory().getId(),
                isActive, newStoreProduct.getId(), deletedAt,
                newStoreProduct.getDeletedBy());
        return ResponseEntity.ok(new ApiResponse<>(200, dto));
    }

    @Transactional
    @GetMapping("/store/{storeId}")
    // TODO Should we use NamedEntityGraphs and EntityGraphs for get queries?
    public ResponseEntity<?> getStoreProductsByStoreId(@RequestParam String clientId,
                                                                 @RequestParam(required = false) String categoryId,
                                                                 @PathVariable String storeId) {
        DBContextHolder.setCurrentDb(clientId);

        Optional<Store> optionalStore = storeRepository.findById(storeId);
        if (optionalStore.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        if (categoryId != null) {
            Optional<Category> optionalCategory = categoryRepository.findById(categoryId);
            if (optionalCategory.isEmpty()) {
                return ResponseEntity.badRequest().build();
            }
        }

        if (categoryId != null) {
            List<StoreProduct> storeProducts
                    = storeProductService.getStoreProductsByStoreIdAndCategoryId(optionalStore.get().getId(), categoryId);
            return ResponseEntity.ok(new ApiResponse<>(200, storeProducts));
        } else {
            List<StoreProduct> storeProducts
                    = storeProductService.getStoreProductsByStoreId(optionalStore.get().getId());
            return ResponseEntity.ok(new ApiResponse<>(200, storeProducts));
        }
    }

    @Transactional
    @GetMapping("/withVariants/store/{storeId}")
    // TODO Should we use NamedEntityGraphs and EntityGraphs for get queries?
    public ResponseEntity<?> getStoreProductsWithVariantsByStoreId(@RequestParam String clientId,
                                                                 @RequestParam(required = true) String categoryId,
                                                                 @RequestParam(required = true) int pageSize,
                                                                 @RequestParam(required = true) int pageNumber,
                                                                 @PathVariable String storeId) {
        DBContextHolder.setCurrentDb(clientId);
        Double multiplier = 1.0;

        Optional<Store> optionalStore = storeRepository.findById(storeId);
        if (optionalStore.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        if (categoryId != null) {
            Optional<Category> optionalCategory = categoryRepository.findById(categoryId);
            if (optionalCategory.isEmpty()) {
                return ResponseEntity.badRequest().build();
            }
        }

        List<StoreProductDTO> storeProducts
                = storeProductService.getStoreProductsWithVariantsByStoreIdAndCategoryId(
                        optionalStore.get().getId(), categoryId, pageSize, pageNumber);
        List<StoreProductWithVariantsResponse> response = new ArrayList<>(storeProducts.size());
        Organisation organisation = organisationService.getOrganisation();
        if (organisation.getIsDynamicPricing() == true && optionalStore.get().getPeakeSale() == true) {
            multiplier = organisation.getMultiplier();
        }
        for (StoreProductDTO dto: storeProducts) {
            StoreProductWithVariantsResponse responseItem = new StoreProductWithVariantsResponse();
            responseItem.setProductId(dto.getProductId());
            
            if (!response.contains(responseItem)) {
                responseItem.setProductId(dto.getProductId());
                responseItem.setProductName(dto.getProductName());
                response.add(responseItem);
            } else {
                responseItem = response.get(response.indexOf(responseItem));
            }
            List<StoreProductWithVariantsResponse.Variant> variants = responseItem.getVariants();
            if (variants == null) {
                variants = new ArrayList<>(5);
                responseItem.setVariants(variants);
            }

            StoreProductWithVariantsResponse.Variant variant = new StoreProductWithVariantsResponse.Variant(
                    responseItem.getProductId(), responseItem.getProductName(),
                    dto.getId(), dto.getVariantName(), dto.getCategoryName(),
                    dto.getPrice() * multiplier, dto.getTax() * multiplier, dto.getOriginalPrice()
            );
            variants.add(variant);
        }
        return ResponseEntity.ok(new ApiResponse<>(200, response));
    }

    @Transactional
    @GetMapping("/withAllProducts/store/{storeId}")
    public ResponseEntity<?> getAllProductsWithStoreProductsByStoreId(@RequestParam String clientId,
                                                                                @RequestParam String categoryId,
                                                                                @PathVariable String storeId) {
        DBContextHolder.setCurrentDb(clientId);

        Optional<Store> optionalStore = storeRepository.findById(storeId);
        if (optionalStore.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        Optional<Category> optionalCategory = categoryRepository.findById(categoryId);
        if (optionalCategory.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        List<ProductStoreProductDTO> storeProducts
                = storeProductService.getAllProductsWithStoreProductsByStoreId(storeId, categoryId);
        return ResponseEntity.ok(new ApiResponse<>(200, storeProducts));
    }

}
