package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Variant;
import com.flytekart.web.model.client.VariantAttributeValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VariantAttributeValueRepository extends JpaRepository<VariantAttributeValue, String> {
    List<VariantAttributeValue> findByVariantId(String variantId);

    @Query("from VariantAttributeValue where deletedBy IS NULL and variantId=:variantId")
    List<VariantAttributeValue> findUnDeletedByVariantId(String variantId);

    @Query("from VariantAttributeValue where deletedBy IS NULL and variantId=:variantId and attributeValueId=:attributeValueId")
    VariantAttributeValue findUnDeletedByVariantIdAndAttributeValueId(String variantId, String attributeValueId);

    @Query(
            value = "select vav " +
                    "from VariantAttributeValue vav inner join AttributeValue av on vav.attributeValueId = av.id " +
                    "where vav.deletedBy IS NULL and vav.variantId=?1 and av.attributeId=?2", nativeQuery = true
    )
    VariantAttributeValue findUnDeletedByVariantIdAndAttributeId(String variantId, String attributeId);

    @Query("from VariantAttributeValue where deletedBy IS NULL")
    List<VariantAttributeValue> findAllUndeleted();

    @Query("from VariantAttributeValue where deletedBy IS NULL and id=:id")
    VariantAttributeValue findUnDeletedByVariantAttributeValueId(String id);
}
