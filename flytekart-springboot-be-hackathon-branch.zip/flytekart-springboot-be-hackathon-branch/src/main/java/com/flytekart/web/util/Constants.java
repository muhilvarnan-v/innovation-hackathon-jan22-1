package com.flytekart.web.util;
import org.springframework.beans.factory.annotation.Value;


public class Constants {

    public static final String USER = "User";
    public static final String EMPLOYEE = "Employee";
    public static final String MAIN = "main";
    public static final String USER_TYPE = "userType";
    public static final String CLIENT_ID = "clientId";
    public static final String USERNAME_SEPARATOR = "###";
    public static final String SAMPLE_OTP = "123456";
    public static final String PURPOSE_LOGIN = "login";
    public static final String HYPHEN = "-";
    public static final String EMPTY = "";
    public static final String ANDROID = "android";
    public static final String TITLE = "title";
    public static final String BODY = "body";
    public static final String NEW_ORDER = "New order";
    public static final String ORDER_UPDATE = "Order update";
    public static final String NOTIFICATION_NEW_ORDER = "%s: A new order worth %s is placed.";
    public static final String NOTIFICATION_ORDER_ACCEPTED = "Your order worth %s is accepted.";
    public static final String NOTIFICATION_ORDER_PROCESSING = "Your order worth %s is processing.";
    public static final String NOTIFICATION_ORDER_PROCESSED = "Your order worth %s is processed.";
    public static final String NOTIFICATION_ORDER_OUT_FOR_DELIVERY = "Your order worth %s is out for delivery.";
    public static final String NOTIFICATION_ORDER_DELIVERED = "Your order worth %s is delivered.";
    public static final String CURRENCY_RUPEE_PREFIX = "Rs";
    public static final String SPACE = " ";
    public static final String TO = "to";
    public static final String NOTIFICATION = "notification";
    public static final String AUTHORIZATION = "authorization";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION_JSON = "application/json";
    public static final String KEY_PREFIX = "key=";
    public static final String DOT = ".";
    public static final String REGISTRATION_TOKENS = "registration_tokens";
    public static final String REGISTRATION_IDS = "registration_ids";
    public static final String RESTRICTED_PACKAGE_NAME = "restricted_package_name";
    public static final String TOPICS = "/topics/%s";
    @Value("${app.twilio.account_sid}")
    public static String TWILIO_ACCOUNT_SID;
    @Value("${app.twilio.auth_token}")
    public static String TWILIO_AUTH_TOKEN;
    @Value("${app.twilio.phone_nubmer}")
    public static String TWILIO_PHONE_NUMBER;

    public static final class FCMURLs {
        public static final String ADD_TOKEN_TO_A_TOPIC = "https://iid.googleapis.com/iid/v1:batchAdd";
        public static final String REMOVE_TOKEN_FROM_A_TOPIC = "https://iid.googleapis.com/iid/v1:batchRemove";
        public static final String SEND_PUSH_NOTIFICATION = "https://fcm.googleapis.com/fcm/send";
    }

    // TODO Should we move these status values to String enum types?
    public static final class OrderStatus {
        public static final String IN_PROGRESS = "IN_PROGRESS";
        public static final String PLACED = "PLACED";
        public static final String CANCELED = "CANCELED";
        public static final String ACCEPTED = "ACCEPTED";
        public static final String PROCESSING = "PROCESSING";
        public static final String PROCESSED = "PROCESSED";
        public static final String OUT_FOR_DELIVERY = "OUT_FOR_DELIVERY";
        public static final String DELIVERED = "DELIVERED";
    }

    public static final class OrderItemStatus {
        public static final String IN_PROGRESS = "IN_PROGRESS";
        public static final String DELETED = "DELETED";
        public static final String PLACED = "PLACED";
        public static final String CANCELED = "CANCELED";
        public static final String ACCEPTED = "ACCEPTED";
        public static final String PROCESSING = "PROCESSING";
        public static final String PROCESSED = "PROCESSED";
        public static final String OUT_FOR_DELIVERY = "OUT_FOR_DELIVERY";
        public static final String DELIVERED = "DELIVERED";
        public static final String REMOVED = "REMOVED";
    }

    public static final class ReturnOrderStatus {
        public static final String RETURN_IN_PROGRESS = "RETURN_IN_PROGRESS";
        public static final String RETURN_PLACED = "RETURN_PLACED";
        public static final String RETURN_CANCELED = "RETURN_CANCELED";
        public static final String RETURN_REQUEST_ACCEPTED = "RETURN_REQUEST_ACCEPTED";
        public static final String RETURN_REQUEST_REJECTED = "RETURN_REQUEST_REJECTED";
        public static final String RETURN_PICKED = "RETURN_PICKED";
        public static final String RETURN_RECEIVED = "RETURN_RECEIVED";
        public static final String RETURN_ACCEPTED = "RETURN_ACCEPTED";
        public static final String RETURN_REJECTED = "RETURN_REJECTED";
    }

    public static final class ReturnOrderItemStatus {
        public static final String RETURN_IN_PROGRESS = "RETURN_IN_PROGRESS";
        public static final String RETURN_ITEM_DELETED = "RETURN_ITEM_DELETED";
        public static final String RETURN_PLACED = "RETURN_PLACED";
        public static final String RETURN_CANCELED = "RETURN_CANCELED";
        public static final String RETURN_REQUEST_ACCEPTED = "RETURN_REQUEST_ACCEPTED";
        public static final String RETURN_REQUEST_REJECTED = "RETURN_REQUEST_REJECTED";
        public static final String RETURN_PICKED = "RETURN_PICKED";
        public static final String RETURN_RECEIVED = "RETURN_RECEIVED";
        public static final String RETURN_ACCEPTED = "RETURN_ACCEPTED";
        public static final String RETURN_REJECTED = "RETURN_REJECTED";
    }

    public static final class PaymentStatus {
        public static final String UNPAID = "UNPAID";
        public static final String PAID = "PAID";
    }

    public static final class PaymentType {
        public static final String COD = "COD"; // Covers both cash on delivery and pay on delivery
        public static final String RAZORPAY = "RAZORPAY"; // Covers both cash on delivery and pay on delivery
    }

    public static final class UserType {
        public static final String USER = "USER";
        public static final String EMPLOYEE = "EMPLOYEE";
    }

    public static final class CountryCode {
        public static final String INDIA = "+91";
    }

    public static final class Env {
        public static final String LOCAL = "local";
        public static final String STAGING = "staging";
        public static final String PRODUCTION = "production";
    }

}
