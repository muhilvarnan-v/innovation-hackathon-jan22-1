package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.request.*;
import com.flytekart.web.model.response.APIError;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.model.response.OrderResponse;
import com.flytekart.web.repository.client.*;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.OrderService;
import com.flytekart.web.service.ReturnOrderService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

/**
 * Controller for returns
 */
@RestController
@RequestMapping("/api/returnorders")
public class ReturnOrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private ReturnOrderService returnOrderService;

    @Autowired
    private ReturnOrderLogRepository returnOrderLogRepository;

    @Autowired
    private ReturnOrderItemLogRepository returnOrderItemLogRepository;

    @Autowired
    private ReturnOrderStatusRepository returnOrderStatusRepository;

    @Autowired
    private ReturnOrderItemStatusRepository returnOrderItemStatusRepository;

    @Autowired
    private ReturnOrderRepository returnOrderRepository;

    @Autowired
    private ReturnOrderItemRepository returnOrderItemRepository;

    /**
     * Add a delivered item to a return request.
     * Check if the order item & order are valid and if the order is delivered.
     * TODO Check return policy for timings. Currently we don't have any return policy
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/addReturnOrderItem")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> addReturnOrderItem(@Valid @RequestBody ReturnOrderItemRequest request,
                                                          @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        if (request.getQuantity() <= 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "Invalid quantity"));
        }

        OrderItemStatus removedOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.REMOVED);

        OrderItem orderItem = orderService.getOrderItemByOrderItemId(request.getOrderItemId());
        if (orderItem == null || orderItem.getDeletedAt() != null
                || orderItem.getOrderItemStatusId().equals(removedOrderItemStatus.getId())) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This item is not in the order"));
        }

        Order order = orderService.getOrderByOrderId(orderItem.getOrderId());
        if (order == null || !principal.getId().equals(order.getUser().getId()) || order.getOrderStatus() == null) {
            return ResponseEntity.notFound().build();
        }

        if (!order.getOrderStatus().getName().equals(Constants.OrderStatus.DELIVERED)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be returned"));
        }

        // Check if the orderItem was previously returned
        List<ReturnOrderItem> returnOrderItems = returnOrderItemRepository.findUnDeletedByOrderItemId(request.getOrderItemId());
        if (returnOrderItems != null && returnOrderItems.size() > 0) {
            int totalReturnQuantity = 0;
            for (ReturnOrderItem forReturnOrderItem : returnOrderItems) {
                totalReturnQuantity = totalReturnQuantity + forReturnOrderItem.getQuantity();
            }
            totalReturnQuantity = totalReturnQuantity + request.getQuantity();

            if (totalReturnQuantity >= orderItem.getQuantity()) {
                return ResponseEntity.badRequest().body(new APIError(400,
                                        "This order cannot be return"));
            }
        }

        // Check if returnOrderItem is already present in current return order. Update if yes
        ReturnOrderStatus returnInProgressOrderStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_IN_PROGRESS);
        // Create Order record if it is a new order
        ReturnOrder returnOrder = new ReturnOrder();
        returnOrder.setOrderId(order.getId());
        returnOrder.setReturnOrderStatusId(returnInProgressOrderStatus.getId());

        returnOrderRepository.save(returnOrder);

        // Add OrderLog record
        ReturnOrderLog returnOrderLog = new ReturnOrderLog();
        returnOrderLog.setReturnOrderId(returnOrder.getId());
        returnOrderLog.setReturnOrderStatusId(returnOrder.getReturnOrderStatusId());
        returnOrderLog.setDescription("Added to return");
        returnOrderLogRepository.save(returnOrderLog);

        // If same item comes again, need to update existing order item
        ReturnOrderItem newReturnOrderItem = null;
        List<ReturnOrderItem> returnOrderItemsByReturnOrderId = returnOrderService.getReturnOrderItemsByReturnOrderId(returnOrder.getId());
        for (ReturnOrderItem returnOrderItem : returnOrderItemsByReturnOrderId) {
            if (returnOrderItem.getOrderItemId().equals(request.getOrderItemId())
                    && orderItem.getDeletedAt() == null) {
                newReturnOrderItem = returnOrderItem;
                break;
            }
        }

        if (newReturnOrderItem != null) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be placed"));
        }

        newReturnOrderItem = new ReturnOrderItem();
        newReturnOrderItem.setReturnOrderId(returnOrder.getId());
        newReturnOrderItem.setOrderItemId(request.getOrderItemId());
        newReturnOrderItem.setQuantity(request.getQuantity());
        /*newReturnOrderItem.setUnitPrice(orderItem.getUnitPrice());
        newReturnOrderItem.setUnitTax(orderItem.getUnitTax());*/
        BigDecimal totalPriceBD = new BigDecimal(orderItem.getUnitPrice())
                .multiply(new BigDecimal(newReturnOrderItem.getQuantity()))
                .setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalTaxBD = new BigDecimal(orderItem.getUnitTax())
                .multiply(new BigDecimal(newReturnOrderItem.getQuantity()))
                .setScale(2, RoundingMode.HALF_UP);
        newReturnOrderItem.setReturnTotalPrice(totalPriceBD.doubleValue());
        newReturnOrderItem.setReturnTotalTax(totalTaxBD.doubleValue());
        ReturnOrderItemStatus returnOrderItemStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_IN_PROGRESS);
        newReturnOrderItem.setReturnOrderItemStatusId(returnOrderItemStatus.getId());
        returnOrderItemRepository.save(newReturnOrderItem);

        // Add a record to ReturnOrderItemLog
        ReturnOrderItemLog returnOrderItemLog = new ReturnOrderItemLog();
        returnOrderItemLog.setReturnOrderItemId(newReturnOrderItem.getId());
        returnOrderItemLog.setReturnOrderItemStatusId(newReturnOrderItem.getReturnOrderItemStatusId());
        returnOrderItemLog.setDescription("Added to order");
        returnOrderItemLogRepository.save(returnOrderItemLog);

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }

    @PostMapping("/updateReturnOrderItemQuantity")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateReturnOrderItemQuantity(@Valid @RequestBody UpdateReturnOrderItemRequest request,
                                                                     @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        if (request.getQuantity() <= 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "Invalid quantity"));
        }

        ReturnOrderItem returnOrderItem = returnOrderService.getReturnOrderItemByReturnOrderItemId(request.getReturnOrderItemId());
        ReturnOrderItemStatus inProgressStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_IN_PROGRESS);
        if (returnOrderItem == null || returnOrderItem.getDeletedAt() != null
                || !returnOrderItem.getReturnOrderItemStatusId().equals(inProgressStatus.getId())) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This item is not in the order or the return order is not valid"));
        }
        OrderItem orderItem = orderService.getOrderItemByOrderItemId(returnOrderItem.getOrderItemId());
        Order order = orderService.getOrderByOrderId(orderItem.getOrderId());
        if (order == null || !principal.getId().equals(order.getUser().getId()) || order.getOrderStatus() == null) {
            return ResponseEntity.notFound().build();
        }

        // Check if the orderItem was previously returned
        List<ReturnOrderItem> returnOrderItems = returnOrderItemRepository.findUnDeletedByOrderItemId(orderItem.getId());
        if (returnOrderItems != null && returnOrderItems.size() > 0) {
            int totalReturnQuantity = 0;
            for (ReturnOrderItem forReturnOrderItem : returnOrderItems) {
                if (forReturnOrderItem.getId().equals(request.getReturnOrderItemId())) {
                    totalReturnQuantity = totalReturnQuantity + request.getQuantity();
                } else {
                    totalReturnQuantity = totalReturnQuantity + forReturnOrderItem.getQuantity();
                }
            }

            if (totalReturnQuantity > orderItem.getQuantity()) {
                return ResponseEntity.badRequest().body(new APIError(400,
                                        "This order cannot be return"));
            }
        }

        returnOrderItem.setQuantity(request.getQuantity());
        /*newReturnOrderItem.setUnitPrice(orderItem.getUnitPrice());
        newReturnOrderItem.setUnitTax(orderItem.getUnitTax());*/
        BigDecimal totalPriceBD = new BigDecimal(orderItem.getUnitPrice())
                .multiply(new BigDecimal(returnOrderItem.getQuantity()))
                .setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalTaxBD = new BigDecimal(orderItem.getUnitTax())
                .multiply(new BigDecimal(returnOrderItem.getQuantity()))
                .setScale(2, RoundingMode.HALF_UP);
        returnOrderItem.setReturnTotalPrice(totalPriceBD.doubleValue());
        returnOrderItem.setReturnTotalTax(totalTaxBD.doubleValue());
        ReturnOrderItemStatus returnOrderItemStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_IN_PROGRESS);
        returnOrderItem.setReturnOrderItemStatusId(returnOrderItemStatus.getId());
        returnOrderItemRepository.save(returnOrderItem);

        // Add a record to ReturnOrderItemLog
        ReturnOrderItemLog returnOrderItemLog = new ReturnOrderItemLog();
        returnOrderItemLog.setReturnOrderItemId(returnOrderItem.getId());
        returnOrderItemLog.setReturnOrderItemStatusId(returnOrderItem.getReturnOrderItemStatusId());
        returnOrderItemLog.setDescription("Updated quantity");
        returnOrderItemLogRepository.save(returnOrderItemLog);

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }

    @PostMapping("/removeReturnOrderItem")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> removeReturnOrderItem(@Valid @RequestBody RemoveReturnOrderItemRequest request,
                                                       @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        ReturnOrderItem returnOrderItem = returnOrderService.getReturnOrderItemByReturnOrderItemId(request.getReturnOrderItemId());
        ReturnOrderItemStatus inProgressStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_IN_PROGRESS);
        if (returnOrderItem == null
                || !returnOrderItem.getReturnOrderItemStatusId().equals(inProgressStatus.getId())) {
            return ResponseEntity.notFound().build();
        }

        ReturnOrderItemStatus deletedStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_ITEM_DELETED);
        returnOrderItem.setReturnOrderItemStatusId(deletedStatus.getId());
        returnOrderItem.setDeletedBy(principal.getId());
        returnOrderItem.setDeletedAt(new Date());
        returnOrderItemRepository.save(returnOrderItem);

        ReturnOrder returnOrder = returnOrderService.getReturnOrderByReturnOrderId(returnOrderItem.getReturnOrderId());
        Order order = orderService.getOrderByOrderId(returnOrder.getOrderId());

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }

    @PostMapping("/placeReturnOrder")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> placeReturnOrder(@Valid @RequestBody PlaceReturnOrderRequest request,
                                                        @RequestParam String clientId) {

        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        // Check if return order is valid
        ReturnOrder returnOrder = returnOrderService.getReturnOrderByReturnOrderId(request.getReturnOrderId());
        ReturnOrderStatus inProgressReturnOrderStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_IN_PROGRESS);
        if (returnOrder == null || returnOrder.getDeletedAt() != null
                || !returnOrder.getReturnOrderStatusId().equals(inProgressReturnOrderStatus.getId())) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be placed"));
        }

        Order order = orderService.getOrderByOrderId(returnOrder.getOrderId());

        // Update order status to Placed
        ReturnOrderStatus placedOrderStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_PLACED);
        returnOrder.setReturnOrderStatusId(placedOrderStatus.getId());
        orderService.save(order);

        ReturnOrderLog returnOrderLog = new ReturnOrderLog();
        returnOrderLog.setReturnOrderId(returnOrder.getId());
        returnOrderLog.setReturnOrderStatusId(returnOrder.getReturnOrderStatusId());
        returnOrderLog.setDescription("Return order placed");
        returnOrderLogRepository.save(returnOrderLog);

        // Update status of order items to Placed
        ReturnOrderItemStatus placedOrderItemStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_PLACED);
        List<ReturnOrderItem> returnOrderItems = returnOrderService.getReturnOrderItemsByReturnOrderId(request.getReturnOrderId());
        for (ReturnOrderItem returnOrderItem : returnOrderItems) {
            returnOrderItem.setReturnOrderItemStatusId(placedOrderItemStatus.getId());
            returnOrderItemRepository.save(returnOrderItem);

            // Add a record to OrderItemLog
            ReturnOrderItemLog returnOrderItemLog = new ReturnOrderItemLog();
            returnOrderItemLog.setReturnOrderItemId(returnOrderItem.getId());
            returnOrderItemLog.setReturnOrderItemStatusId(returnOrderItem.getReturnOrderItemStatusId());
            returnOrderItemLog.setDescription("Return order placed");
            returnOrderItemLogRepository.save(returnOrderItemLog);
        }

        // TODO Send notifications to store asynchronously

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }

    @PostMapping("/updateReturnOrderStatusToRequestAccepted")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateReturnOrderStatusToRequestAccepted(@Valid @RequestBody UpdateReturnOrderStatusRequest request,
                                                                   @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        // Check if return order is valid
        ReturnOrder returnOrder = returnOrderService.getReturnOrderByReturnOrderId(request.getReturnOrderId());
        ReturnOrderStatus placedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_PLACED);
        if (returnOrder == null || !placedStatus.getId().equals(returnOrder.getReturnOrderStatusId())) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        List<ReturnOrderItem> returnOrderItems = returnOrderService.getReturnOrderItemsByReturnOrderId(request.getReturnOrderId());
        if (returnOrderItems == null || returnOrderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This return order cannot be accepted"));
        }

        // Update order status to request accepted
        ReturnOrderStatus requestAcceptedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_REQUEST_ACCEPTED);
        returnOrder.setReturnOrderStatusId(requestAcceptedStatus.getId());
        returnOrderService.save(returnOrder);

        ReturnOrderLog returnOrderLog = new ReturnOrderLog();
        returnOrderLog.setReturnOrderId(returnOrder.getId());
        returnOrderLog.setReturnOrderStatusId(returnOrder.getReturnOrderStatusId());
        returnOrderLog.setDescription("Return order request accepted");
        returnOrderLogRepository.save(returnOrderLog);

        // Update status of order items to request accepted
        ReturnOrderItemStatus requestAcceptedItemStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_REQUEST_ACCEPTED);
        for (ReturnOrderItem returnOrderItem : returnOrderItems) {
            if (returnOrderItem.getDeletedAt() != null) {
                returnOrderItem.setReturnOrderItemStatusId(requestAcceptedItemStatus.getId());
                returnOrderItemRepository.save(returnOrderItem);

                // Add a record to OrderItemLog
                ReturnOrderItemLog returnOrderItemLog = new ReturnOrderItemLog();
                returnOrderItemLog.setReturnOrderItemId(returnOrderItem.getId());
                returnOrderItemLog.setReturnOrderItemStatusId(returnOrderItem.getReturnOrderItemStatusId());
                returnOrderItemLog.setDescription("Return order request accepted");
                returnOrderItemLogRepository.save(returnOrderItemLog);
            }
        }

        // TODO Send notifications to user asynchronously

        Order order = orderService.getOrderByOrderId(returnOrder.getOrderId());

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }

    @PostMapping("/updateReturnOrderStatusToRequestRejected")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateReturnOrderStatusToRequestRejected(@Valid @RequestBody UpdateReturnOrderStatusRequest request,
                                                                   @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        // Check if return order is valid
        ReturnOrder returnOrder = returnOrderService.getReturnOrderByReturnOrderId(request.getReturnOrderId());
        ReturnOrderStatus placedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_PLACED);
        if (returnOrder == null || !placedStatus.getId().equals(returnOrder.getReturnOrderStatusId())) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        List<ReturnOrderItem> returnOrderItems = returnOrderService.getReturnOrderItemsByReturnOrderId(request.getReturnOrderId());
        if (returnOrderItems == null || returnOrderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This return order cannot be accepted"));
        }

        // Update order status to request rejected
        ReturnOrderStatus requestRejectedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_REQUEST_REJECTED);
        returnOrder.setReturnOrderStatusId(requestRejectedStatus.getId());
        returnOrderService.save(returnOrder);

        ReturnOrderLog returnOrderLog = new ReturnOrderLog();
        returnOrderLog.setReturnOrderId(returnOrder.getId());
        returnOrderLog.setReturnOrderStatusId(returnOrder.getReturnOrderStatusId());
        returnOrderLog.setDescription("Return order request rejected");
        returnOrderLogRepository.save(returnOrderLog);

        // Update status of order items to request rejected
        ReturnOrderItemStatus requestRejectedItemStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_REQUEST_REJECTED);
        for (ReturnOrderItem returnOrderItem : returnOrderItems) {
            if (returnOrderItem.getDeletedAt() != null) {
                returnOrderItem.setReturnOrderItemStatusId(requestRejectedItemStatus.getId());
                returnOrderItemRepository.save(returnOrderItem);

                // Add a record to OrderItemLog
                ReturnOrderItemLog returnOrderItemLog = new ReturnOrderItemLog();
                returnOrderItemLog.setReturnOrderItemId(returnOrderItem.getId());
                returnOrderItemLog.setReturnOrderItemStatusId(returnOrderItem.getReturnOrderItemStatusId());
                returnOrderItemLog.setDescription("Return order request rejected");
                returnOrderItemLogRepository.save(returnOrderItemLog);
            }
        }

        // TODO Send notifications to user asynchronously

        Order order = orderService.getOrderByOrderId(returnOrder.getOrderId());

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }

    @PostMapping("/updateReturnOrderStatusToPicked")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateReturnOrderStatusToPicked(@Valid @RequestBody UpdateReturnOrderStatusRequest request,
                                                                   @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        // Check if return order is valid
        ReturnOrder returnOrder = returnOrderService.getReturnOrderByReturnOrderId(request.getReturnOrderId());
        ReturnOrderStatus requestAcceptedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_REQUEST_ACCEPTED);
        if (returnOrder == null || !requestAcceptedStatus.getId().equals(returnOrder.getReturnOrderStatusId())) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        List<ReturnOrderItem> returnOrderItems = returnOrderService.getReturnOrderItemsByReturnOrderId(request.getReturnOrderId());
        if (returnOrderItems == null || returnOrderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This return order cannot be accepted"));
        }

        // Update order status to picked
        ReturnOrderStatus pickedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_PICKED);
        returnOrder.setReturnOrderStatusId(pickedStatus.getId());
        returnOrderService.save(returnOrder);

        ReturnOrderLog returnOrderLog = new ReturnOrderLog();
        returnOrderLog.setReturnOrderId(returnOrder.getId());
        returnOrderLog.setReturnOrderStatusId(returnOrder.getReturnOrderStatusId());
        returnOrderLog.setDescription("Return order request picked");
        returnOrderLogRepository.save(returnOrderLog);

        // Update status of order items to picked
        ReturnOrderItemStatus pickedItemStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_PICKED);
        for (ReturnOrderItem returnOrderItem : returnOrderItems) {
            if (returnOrderItem.getDeletedAt() != null) {
                returnOrderItem.setReturnOrderItemStatusId(pickedItemStatus.getId());
                returnOrderItemRepository.save(returnOrderItem);

                // Add a record to OrderItemLog
                ReturnOrderItemLog returnOrderItemLog = new ReturnOrderItemLog();
                returnOrderItemLog.setReturnOrderItemId(returnOrderItem.getId());
                returnOrderItemLog.setReturnOrderItemStatusId(returnOrderItem.getReturnOrderItemStatusId());
                returnOrderItemLog.setDescription("Return order request picked");
                returnOrderItemLogRepository.save(returnOrderItemLog);
            }
        }

        // TODO Send notifications to user asynchronously

        Order order = orderService.getOrderByOrderId(returnOrder.getOrderId());

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }

    @PostMapping("/updateReturnOrderStatusToReceived")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateReturnOrderStatusToReceived(@Valid @RequestBody UpdateReturnOrderStatusRequest request,
                                                                   @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        // Check if return order is valid
        ReturnOrder returnOrder = returnOrderService.getReturnOrderByReturnOrderId(request.getReturnOrderId());
        ReturnOrderStatus requestPickedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_PICKED);
        if (returnOrder == null || !requestPickedStatus.getId().equals(returnOrder.getReturnOrderStatusId())) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        List<ReturnOrderItem> returnOrderItems = returnOrderService.getReturnOrderItemsByReturnOrderId(request.getReturnOrderId());
        if (returnOrderItems == null || returnOrderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This return order cannot be accepted"));
        }

        // Update order status to received
        ReturnOrderStatus receivedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_RECEIVED);
        returnOrder.setReturnOrderStatusId(receivedStatus.getId());
        returnOrderService.save(returnOrder);

        ReturnOrderLog returnOrderLog = new ReturnOrderLog();
        returnOrderLog.setReturnOrderId(returnOrder.getId());
        returnOrderLog.setReturnOrderStatusId(returnOrder.getReturnOrderStatusId());
        returnOrderLog.setDescription("Return order received");
        returnOrderLogRepository.save(returnOrderLog);

        // Update status of order items to received
        ReturnOrderItemStatus receivedItemStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_RECEIVED);
        for (ReturnOrderItem returnOrderItem : returnOrderItems) {
            if (returnOrderItem.getDeletedAt() != null) {
                returnOrderItem.setReturnOrderItemStatusId(receivedItemStatus.getId());
                returnOrderItemRepository.save(returnOrderItem);

                // Add a record to OrderItemLog
                ReturnOrderItemLog returnOrderItemLog = new ReturnOrderItemLog();
                returnOrderItemLog.setReturnOrderItemId(returnOrderItem.getId());
                returnOrderItemLog.setReturnOrderItemStatusId(returnOrderItem.getReturnOrderItemStatusId());
                returnOrderItemLog.setDescription("Return order received");
                returnOrderItemLogRepository.save(returnOrderItemLog);
            }
        }

        // TODO Send notifications to user asynchronously

        Order order = orderService.getOrderByOrderId(returnOrder.getOrderId());

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }

    /**
     * Accepting a return.
     * TODO Add refund amount to the request or have a refunded status
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/updateReturnOrderStatusToAccepted")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateReturnOrderStatusToAccepted(@Valid @RequestBody UpdateReturnOrderStatusRequest request,
                                                                   @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        // Check if return order is valid
        ReturnOrder returnOrder = returnOrderService.getReturnOrderByReturnOrderId(request.getReturnOrderId());
        ReturnOrderStatus receivedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_RECEIVED);
        if (returnOrder == null || !receivedStatus.getId().equals(returnOrder.getReturnOrderStatusId())) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        List<ReturnOrderItem> returnOrderItems = returnOrderService.getReturnOrderItemsByReturnOrderId(request.getReturnOrderId());
        if (returnOrderItems == null || returnOrderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This return order cannot be accepted"));
        }

        // Update order status to accepted
        ReturnOrderStatus acceptedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_ACCEPTED);
        returnOrder.setReturnOrderStatusId(acceptedStatus.getId());
        returnOrderService.save(returnOrder);

        ReturnOrderLog returnOrderLog = new ReturnOrderLog();
        returnOrderLog.setReturnOrderId(returnOrder.getId());
        returnOrderLog.setReturnOrderStatusId(returnOrder.getReturnOrderStatusId());
        returnOrderLog.setDescription("Return order accepted");
        returnOrderLogRepository.save(returnOrderLog);

        // Update status of order items to accepted
        ReturnOrderItemStatus acceptedItemStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_ACCEPTED);
        for (ReturnOrderItem returnOrderItem : returnOrderItems) {
            if (returnOrderItem.getDeletedAt() != null) {
                returnOrderItem.setReturnOrderItemStatusId(acceptedItemStatus.getId());
                returnOrderItemRepository.save(returnOrderItem);

                // Add a record to OrderItemLog
                ReturnOrderItemLog returnOrderItemLog = new ReturnOrderItemLog();
                returnOrderItemLog.setReturnOrderItemId(returnOrderItem.getId());
                returnOrderItemLog.setReturnOrderItemStatusId(returnOrderItem.getReturnOrderItemStatusId());
                returnOrderItemLog.setDescription("Return order accepted");
                returnOrderItemLogRepository.save(returnOrderItemLog);
            }
        }

        // TODO Send notifications to user asynchronously

        Order order = orderService.getOrderByOrderId(returnOrder.getOrderId());

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }

    @PostMapping("/updateReturnOrderStatusToRejected")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateReturnOrderStatusToRejected(@Valid @RequestBody UpdateReturnOrderStatusRequest request,
                                                                   @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        // Check if return order is valid
        ReturnOrder returnOrder = returnOrderService.getReturnOrderByReturnOrderId(request.getReturnOrderId());
        ReturnOrderStatus receivedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_RECEIVED);
        if (returnOrder == null || !receivedStatus.getId().equals(returnOrder.getReturnOrderStatusId())) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        List<ReturnOrderItem> returnOrderItems = returnOrderService.getReturnOrderItemsByReturnOrderId(request.getReturnOrderId());
        if (returnOrderItems == null || returnOrderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This return order cannot be accepted"));
        }

        // Update order status to Placed
        ReturnOrderStatus rejectedStatus = returnOrderStatusRepository.findByName(Constants.ReturnOrderStatus.RETURN_REJECTED);
        returnOrder.setReturnOrderStatusId(rejectedStatus.getId());
        returnOrderService.save(returnOrder);

        ReturnOrderLog returnOrderLog = new ReturnOrderLog();
        returnOrderLog.setReturnOrderId(returnOrder.getId());
        returnOrderLog.setReturnOrderStatusId(returnOrder.getReturnOrderStatusId());
        returnOrderLog.setDescription("Return order rejected");
        returnOrderLogRepository.save(returnOrderLog);

        // Update status of order items to accepted
        ReturnOrderItemStatus rejectedItemStatus = returnOrderItemStatusRepository.findByName(Constants.ReturnOrderItemStatus.RETURN_REJECTED);
        for (ReturnOrderItem returnOrderItem : returnOrderItems) {
            if (returnOrderItem.getDeletedAt() != null) {
                returnOrderItem.setReturnOrderItemStatusId(rejectedItemStatus.getId());
                returnOrderItemRepository.save(returnOrderItem);

                // Add a record to OrderItemLog
                ReturnOrderItemLog returnOrderItemLog = new ReturnOrderItemLog();
                returnOrderItemLog.setReturnOrderItemId(returnOrderItem.getId());
                returnOrderItemLog.setReturnOrderItemStatusId(returnOrderItem.getReturnOrderItemStatusId());
                returnOrderItemLog.setDescription("Return order rejected");
                returnOrderItemLogRepository.save(returnOrderItemLog);
            }
        }

        // TODO Send notifications to user asynchronously

        Order order = orderService.getOrderByOrderId(returnOrder.getOrderId());

        // Frame Order response and return
        // TODO OrderResponse should include related returns
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse<>(200, orderResponse));
    }
}
