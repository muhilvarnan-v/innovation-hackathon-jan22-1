package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, String> {
    @Query("from Payment where deletedBy IS NULL and orderId=:id")
    List<Payment> findUnDeletedByOrderId(String id);

    @Query("from Payment where deletedBy IS NULL and id=:id")
    Payment findUnDeletedByPaymentId(String id);
}
