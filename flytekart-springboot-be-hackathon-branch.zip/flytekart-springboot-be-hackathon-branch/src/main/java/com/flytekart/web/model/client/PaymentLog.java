package com.flytekart.web.model.client;

import com.flytekart.web.model.common.EmployeeAndUserDateAudit;
import com.flytekart.web.model.common.UserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Each item part of an order.
 */
@Entity
@Table(name = "PaymentLog", schema = "public")
public class PaymentLog extends EmployeeAndUserDateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String paymentId;

    @Column(length = 40)
    private String paymentStatusId;

    @Column(length = 1000)
    private String description;

    public PaymentLog() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public String getPaymentStatusId() {
        return paymentStatusId;
    }

    public void setPaymentStatusId(String paymentStatusId) {
        this.paymentStatusId = paymentStatusId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
