package com.flytekart.web.service;

import com.flytekart.web.model.client.EmployeePushToken;
import com.flytekart.web.model.client.NotificationSetting;
import com.flytekart.web.model.client.UserPushToken;
import com.flytekart.web.repository.client.EmployeePushTokenRepository;
import com.flytekart.web.repository.client.NotificationSettingRepository;
import com.flytekart.web.repository.client.UserPushTokenRepository;
import com.flytekart.web.util.Constants;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

// A few methods might change when we have web or iOS notifications.
// A few methods might change when we have Telegram, WhatsApp or SMS notifications

/**
 * Central service for all notifications
 */
@Service
public class NotificationService {

    @Autowired
    EmployeePushTokenRepository employeePushTokenRepository;

    @Autowired
    UserPushTokenRepository userPushTokenRepository;

    @Autowired
    NotificationSettingRepository notificationSettingRepository;

    @Autowired
    FirebaseMessagingService firebaseService;

    @Value("${app.env}")
    private String env;

    public EmployeePushToken getUnDeletedEmployeePushTokenByUserIdAndTokenAndClientType(String userId, String token,
                                                                                        String clientType) {
        EmployeePushToken employeePushToken = null;
        if (StringUtils.hasText(userId) && StringUtils.hasText(token) && StringUtils.hasText(clientType)) {
            List<EmployeePushToken> employeePushTokens = employeePushTokenRepository
                    .findUnDeletedByUserIdAndTokenAndClientType(userId, token, clientType);
            if (employeePushTokens != null && employeePushTokens.size() > 0) {
                employeePushToken = employeePushTokens.get(0);
            }
        }
        return employeePushToken;
    }

    public EmployeePushToken getUnDeletedEmployeePushTokenByTokenAndClientType(String token,
                                                                               String clientType) {
        EmployeePushToken employeePushToken = null;
        if (StringUtils.hasText(token) && StringUtils.hasText(clientType)) {
            List<EmployeePushToken> employeePushTokens = employeePushTokenRepository
                    .findUnDeletedByTokenAndClientType(token, clientType);
            if (employeePushTokens != null && employeePushTokens.size() > 0) {
                employeePushToken = employeePushTokens.get(0);
            }
        }
        return employeePushToken;
    }

    public List<EmployeePushToken> getUnDeletedEmployeePushTokensByUserId(String userId) {
        List<EmployeePushToken> employeePushTokens = null;
        if (StringUtils.hasText(userId)) {
            employeePushTokens = employeePushTokenRepository
                    .findUnDeletedByUserId(userId);
        }
        return employeePushTokens;
    }

    public EmployeePushToken getUnDeletedEmployeePushTokenById(String id) {
        EmployeePushToken employeePushToken = null;
        if (StringUtils.hasText(id)) {
            employeePushToken = employeePushTokenRepository.findUnDeletedById(id);
        }
        return employeePushToken;
    }

    public EmployeePushToken saveEmployeePushToken(EmployeePushToken employeePushToken) {
        employeePushTokenRepository.save(employeePushToken);
        return employeePushToken;
    }

    public void sendPushNotificationByClientId(String title, String body, String clientId) {
        String topic = clientId + "-ALLEMPLOYEES";
        firebaseService.sendNotificationToATopic(title, body, topic);
    }

    public void subscribeTokenToAllEmployeesTopic(String token, String clientId) {
        String topic = clientId + "-ALLEMPLOYEES";
        firebaseService.saveTokenToATopic(token, topic);
    }

    public void unSubscribeTokenFromAllEmployeesTopic(String token, String clientId) {
        String topic = clientId + "-ALLEMPLOYEES";
        firebaseService.deleteTokenFromATopic(token, topic);
    }

    public void subscribeTokenToSpecificEmployeeTopic(String token, String employeeId) {
        String topic = employeeId + "-EMPLOYEE";
        firebaseService.saveTokenToATopic(token, topic);
    }

    public void unSubscribeTokenFromSpecificEmployeeTopic(String token, String employeeId) {
        String topic = employeeId + "-EMPLOYEE";
        firebaseService.deleteTokenFromATopic(token, topic);
    }

    public UserPushToken getUnDeletedUserPushTokenByUserIdAndTokenAndClientType(String userId, String token,
                                                                                        String clientType) {
        UserPushToken userPushToken = null;
        if (StringUtils.hasText(userId) && StringUtils.hasText(token) && StringUtils.hasText(clientType)) {
            List<UserPushToken> userPushTokens = userPushTokenRepository
                    .findUnDeletedByUserIdAndTokenAndClientType(userId, token, clientType);
            if (userPushTokens != null && userPushTokens.size() > 0) {
                userPushToken = userPushTokens.get(0);
            }
        }
        return userPushToken;
    }

    public UserPushToken getUnDeletedUserPushTokenByTokenAndClientType(String token,
                                                                               String clientType) {
        UserPushToken employeePushToken = null;
        if (StringUtils.hasText(token) && StringUtils.hasText(clientType)) {
            List<UserPushToken> userPushTokens = userPushTokenRepository
                    .findUnDeletedByTokenAndClientType(token, clientType);
            if (userPushTokens != null && userPushTokens.size() > 0) {
                employeePushToken = userPushTokens.get(0);
            }
        }
        return employeePushToken;
    }

    public List<UserPushToken> getUnDeletedUserPushTokensByUserId(String userId) {
        List<UserPushToken> userPushTokens = null;
        if (StringUtils.hasText(userId)) {
            userPushTokens = userPushTokenRepository
                    .findUnDeletedByUserId(userId);
        }
        return userPushTokens;
    }

    public UserPushToken getUnDeletedUserPushTokenById(String id) {
        UserPushToken userPushToken = null;
        if (StringUtils.hasText(id)) {
            userPushToken = userPushTokenRepository.findUnDeletedById(id);
        }
        return userPushToken;
    }

    public UserPushToken saveUserPushToken(UserPushToken userPushToken) {
        userPushTokenRepository.save(userPushToken);
        return userPushToken;
    }

    public void subscribeTokenToSpecificUserTopic(String token, String userId) {
        String topic = userId + "-USER";
        // Instead of FirebaseService, we need to make FCM Legacy API call here.
        List<NotificationSetting> notificationSettings = notificationSettingRepository.findUnDeleted();
        if (notificationSettings!=null && notificationSettings.size() > 0) {
            NotificationSetting notificationSetting = notificationSettings.get(0);
            String key = notificationSetting.getServerKey();
            String serverKey = Constants.KEY_PREFIX + key;
            firebaseService.saveTokenToATopicUsingServerKey(token, topic, serverKey);
        }
    }

    public void unSubscribeTokenFromSpecificUserTopic(String token, String userId) {
        String topic = userId + "-USER";
        // Instead of FirebaseService, we need to make FCM Legacy API call here.
        List<NotificationSetting> notificationSettings = notificationSettingRepository.findUnDeleted();
        if (notificationSettings!=null && notificationSettings.size() > 0) {
            NotificationSetting notificationSetting = notificationSettings.get(0);
            String key = notificationSetting.getServerKey();
            String serverKey = Constants.KEY_PREFIX + key;
            firebaseService.deleteTokenFromATopicUsingServerKey(token, topic, serverKey);
        }
    }

    @Async
    public void sendPushNotificationByUserId(String title, String body, String userId) {
        String topic = userId + "-USER";
        // Instead of Firebase SDK, we need to make FCM Legacy API call here.
        List<NotificationSetting> notificationSettings = notificationSettingRepository.findUnDeleted();
        if (notificationSettings!=null && notificationSettings.size() > 0) {
            NotificationSetting notificationSetting = notificationSettings.get(0);
            String key = notificationSetting.getServerKey();
            String serverKey = Constants.KEY_PREFIX + key;
            StringBuilder packageNameBuilder = new StringBuilder(notificationSetting.getPackageName());
            if (!env.equals(Constants.Env.PRODUCTION)) {
                packageNameBuilder.append(Constants.DOT).append(env);
            }
            firebaseService.sendNotificationToATopicUsingServerKey(title, body, topic, serverKey, packageNameBuilder.toString());
        }
    }

    @Async
    public void sendPushNotificationByFCMKeyAndServerKey(String title, String body, String userId) {
        // Instead of Firebase SDK, we need to make FCM Legacy API call here.
        List<UserPushToken> userPushTokens = userPushTokenRepository.findUnDeletedByUserId(userId);
        if (userPushTokens != null && userPushTokens.size() > 0) {
            int size = userPushTokens.size();
            if (size > 10) { // Send to only 10 devices
                size = 10;
            }
            List<String> fcmKeys = new ArrayList<>(size);
            for (int i = 0; i < size; i++) {
                fcmKeys.add(userPushTokens.get(i).getToken());
            }
            List<NotificationSetting> notificationSettings = notificationSettingRepository.findUnDeleted();
            if (notificationSettings!=null && notificationSettings.size() > 0) {
                NotificationSetting notificationSetting = notificationSettings.get(0);
                String key = notificationSetting.getServerKey();
                String serverKey = Constants.KEY_PREFIX + key;
                StringBuilder packageNameBuilder = new StringBuilder(notificationSetting.getPackageName());
                if (!env.equals(Constants.Env.PRODUCTION)) {
                    packageNameBuilder.append(Constants.DOT).append(env);
                }
                firebaseService.sendNotificationToFCMKeysUsingServerKey(title, body, fcmKeys,
                        serverKey, packageNameBuilder.toString());
            }
        }
    }
}
