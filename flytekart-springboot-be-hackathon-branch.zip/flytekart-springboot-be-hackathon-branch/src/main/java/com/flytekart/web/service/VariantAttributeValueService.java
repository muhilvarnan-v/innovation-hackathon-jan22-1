package com.flytekart.web.service;

import com.flytekart.web.model.client.Variant;
import com.flytekart.web.model.client.VariantAttributeValue;
import com.flytekart.web.repository.client.VariantAttributeValueRepository;
import com.flytekart.web.repository.client.VariantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class VariantAttributeValueService {

    @Autowired
    private VariantAttributeValueRepository variantAttributeValueRepository;

    public List<VariantAttributeValue> getVariantAttributeValuesByVariantId(String variantId) {
        List<VariantAttributeValue> variantAttributeValues;
        if (StringUtils.hasText(variantId)) {
            variantAttributeValues = variantAttributeValueRepository.findUnDeletedByVariantId(variantId);
        } else {
            variantAttributeValues = variantAttributeValueRepository.findAllUndeleted();
        }
        return variantAttributeValues;
    }

    public VariantAttributeValue getVariantAttributeValueByVariantAttributeValueId(String variantAttributeValueId) {
        VariantAttributeValue variantAttributeValue;
        if (StringUtils.hasText(variantAttributeValueId)) {
            variantAttributeValue =  variantAttributeValueRepository
                    .findUnDeletedByVariantAttributeValueId(variantAttributeValueId);
        } else {
            variantAttributeValue = null;
        }
        return variantAttributeValue;
    }

    public VariantAttributeValue getVariantAttributeValueByVariantIdAndAttributeValueId(String variantId, String attributeValueId) {
        VariantAttributeValue variantAttributeValue;
        if (StringUtils.hasText(variantId) && StringUtils.hasText(attributeValueId)) {
            variantAttributeValue =  variantAttributeValueRepository
                    .findUnDeletedByVariantIdAndAttributeValueId(variantId, attributeValueId);
        } else {
            variantAttributeValue = null;
        }
        return variantAttributeValue;
    }

    public VariantAttributeValue getVariantAttributeValueByVariantIdAndAttributeId(String variantId, String attributeId) {
        VariantAttributeValue variantAttributeValue;
        if (StringUtils.hasText(variantId) && StringUtils.hasText(attributeId)) {
            variantAttributeValue =  variantAttributeValueRepository
                    .findUnDeletedByVariantIdAndAttributeId(variantId, attributeId);
        } else {
            variantAttributeValue = null;
        }
        return variantAttributeValue;
    }

    public VariantAttributeValue save(VariantAttributeValue variantAttributeValue) {
        variantAttributeValueRepository.save(variantAttributeValue);
        return variantAttributeValue;
    }
}
