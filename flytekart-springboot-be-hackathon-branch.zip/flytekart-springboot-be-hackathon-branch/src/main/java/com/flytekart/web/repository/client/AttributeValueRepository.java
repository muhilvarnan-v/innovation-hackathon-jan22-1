package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.AttributeValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AttributeValueRepository extends JpaRepository<AttributeValue, String> {
    List<AttributeValue> findByAttributeId(String attributeId);

    @Query("from AttributeValue where deletedBy IS NULL and id=:id")
    AttributeValue findUnDeletedByAttributeValueId(String id);

    @Query("from AttributeValue where deletedBy IS NULL and attributeId=:attributeId and upper(name) = upper(:name)")
    List<AttributeValue> findUnDeletedByAttributeIdAndName(String attributeId, String name);

    @Query("from AttributeValue where deletedBy IS NULL and attributeId=:attributeId order by name")
    List<AttributeValue> findUnDeletedByAttributeId(String attributeId);

    @Query("from AttributeValue where deletedBy IS NULL order by name")
    List<AttributeValue> findAllUndeleted();

    /**
     * TODO This query is inefficient if we don't have INDEX by upper(name)
     * @return
     */
    @Query("from Attribute where deletedBy IS NULL " +
            "and attributeId=:attributeId and upper(name) like upper('%:prefix%') order by name")
    List<AttributeValue> findUnDeletedByPrefixIgnoreCaseContaining(String attributeId, String prefix);
}
