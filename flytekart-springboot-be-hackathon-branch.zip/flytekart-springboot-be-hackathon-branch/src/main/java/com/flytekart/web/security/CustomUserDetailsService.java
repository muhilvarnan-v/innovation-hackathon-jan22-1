package com.flytekart.web.security;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.Employee;
import com.flytekart.web.model.main.User;
import com.flytekart.web.model.client.EndUser;
import com.flytekart.web.model.client.Otp;
import com.flytekart.web.repository.client.EmployeeRepository;
import com.flytekart.web.repository.client.OtpRepository;
import com.flytekart.web.repository.main.UserRepository;
import com.flytekart.web.repository.client.EndUserRepository;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Optional;

/**
 * TODO Need to implement a new Custom AuthenticationProvider to avoid if else conditions here.
 * Also Custom AuthenticationProvider is required to support FB, Google etc 3rd party auth
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    EndUserRepository endUserRepository;

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    OtpRepository otpRepository;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String usernameOrEmail) throws UsernameNotFoundException {
        // Let people login with either username or email
        String db = DBContextHolder.getCurrentDb();
        if (db == null || db.equals(Constants.MAIN)) {
            User user = userRepository.findByUsernameOrEmail(usernameOrEmail, usernameOrEmail)
                    .orElseThrow(() ->
                            new UsernameNotFoundException("User not found with username or email : " + usernameOrEmail)
                    );

            return UserPrincipal.create(user);
        } else if (usernameOrEmail.endsWith(Constants.USERNAME_SEPARATOR)){
            String newUsernameOrEmail = usernameOrEmail.substring(0, usernameOrEmail.length() - Constants.USERNAME_SEPARATOR.length());
            Employee employee = employeeRepository.findByPhoneNumber(newUsernameOrEmail)
                    .orElseThrow(() ->
                            new UsernameNotFoundException("Employee not found with username or email : " + newUsernameOrEmail)
                    );

            Otp otp = otpRepository.findByMobileNoAndPurposeAndUserType(employee.getPhoneNumber(),
                    Constants.PURPOSE_LOGIN, Constants.UserType.EMPLOYEE, new Date());
            employee.setPassword(otp.getOtp());

            return UserPrincipal.create(employee);
        } else {
            Optional<EndUser> user = endUserRepository.findByPhoneNumber(usernameOrEmail);
            
            if(!user.isPresent()) new UsernameNotFoundException("User not found with username or email : " + usernameOrEmail);

            Otp otp = otpRepository.findByMobileNoAndPurposeAndUserType(user.get().getPhoneNumber(),
                    Constants.PURPOSE_LOGIN, Constants.UserType.USER, new Date());
            user.get().setPassword(otp.getOtp());

            return UserPrincipal.create(user.get());
        }
    }

    // This method is used by JWTAuthenticationFilter
    //@Transactional
    public UserDetails loadUserById(String userId, String userType, String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal userPrincipal;
        if (clientId.equals(Constants.MAIN)) {
            User user = userRepository.findById(userId).orElseThrow(
                    () -> new UsernameNotFoundException("User not found with id : " + userId)
            );
            userPrincipal = UserPrincipal.create(user);
        } else if (userType.equals(Constants.USER)){
            EndUser endUser = endUserRepository.findById(userId).orElseThrow(
                    () -> new UsernameNotFoundException("User not found with id : " + userId)
            );
            userPrincipal = UserPrincipal.create(endUser);
        } else {
            Optional<Employee> optional = employeeRepository.findById(userId);
            /*Employee employee = employeeRepository.findById(userId).orElseThrow(
                    () -> new UsernameNotFoundException("Employee not found with id : " + userId)
            );*/
            userPrincipal = UserPrincipal.create(optional.get());
        }

        return userPrincipal;
    }
}
