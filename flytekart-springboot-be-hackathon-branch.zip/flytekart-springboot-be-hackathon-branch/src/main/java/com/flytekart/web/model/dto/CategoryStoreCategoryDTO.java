package com.flytekart.web.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

public class CategoryStoreCategoryDTO {

    private String id;

    private String name;

    private String parentCategoryId;

    @JsonProperty(value = "isActive")
    private boolean isActive;

    private String storeCategoryId;
    private String storeCategoryDeletedAt;
    private String storeCategoryDeletedBy;

    public CategoryStoreCategoryDTO(String id, String name, String parentCategoryId, boolean isActive,
                                    String storeCategoryId, String storeCategoryDeletedAt, String storeCategoryDeletedBy) {
        this.id = id;
        this.name = name;
        this.parentCategoryId = parentCategoryId;
        this.isActive = isActive;
        this.storeCategoryId = storeCategoryId;
        this.storeCategoryDeletedAt = storeCategoryDeletedAt;
        this.storeCategoryDeletedBy = storeCategoryDeletedBy;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getParentCategoryId() {
        return parentCategoryId;
    }

    public void setParentCategoryId(String parentCategoryId) {
        this.parentCategoryId = parentCategoryId;
    }

    @JsonProperty(value = "isActive")
    public boolean isActive() {
        return isActive;
    }

    @JsonProperty(value = "isActive")
    public void setActive(boolean active) {
        isActive = active;
    }

    public String getStoreCategoryId() {
        return storeCategoryId;
    }

    public void setStoreCategoryId(String storeCategoryId) {
        this.storeCategoryId = storeCategoryId;
    }

    public String getStoreCategoryDeletedAt() {
        return storeCategoryDeletedAt;
    }

    public void setStoreCategoryDeletedAt(String storeCategoryDeletedAt) {
        this.storeCategoryDeletedAt = storeCategoryDeletedAt;
    }

    public String getStoreCategoryDeletedBy() {
        return storeCategoryDeletedBy;
    }

    public void setStoreCategoryDeletedBy(String storeCategoryDeletedBy) {
        this.storeCategoryDeletedBy = storeCategoryDeletedBy;
    }
}
