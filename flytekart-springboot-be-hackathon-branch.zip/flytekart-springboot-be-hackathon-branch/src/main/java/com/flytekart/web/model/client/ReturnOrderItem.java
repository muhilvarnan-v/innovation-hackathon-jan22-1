package com.flytekart.web.model.client;

import com.flytekart.web.model.common.EmployeeAndUserDateAuditWithDeletion;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Handles each item in a return order.
 */
@Entity
@Table(name = "ReturnOrderItem", schema = "public")
public class ReturnOrderItem extends EmployeeAndUserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String returnOrderId;

    @Column(length = 40)
    private String orderItemId;

    @Column(length = 40)
    private String returnOrderItemStatusId;

    @Column()
    private int quantity;

    @Column()
    private double returnTotalPrice;

    @Column()
    private double returnTotalTax;

    public ReturnOrderItem() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getReturnOrderId() {
        return returnOrderId;
    }

    public void setReturnOrderId(String returnOrderId) {
        this.returnOrderId = returnOrderId;
    }

    public String getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }

    public String getReturnOrderItemStatusId() {
        return returnOrderItemStatusId;
    }

    public void setReturnOrderItemStatusId(String returnOrderItemStatusId) {
        this.returnOrderItemStatusId = returnOrderItemStatusId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getReturnTotalPrice() {
        return returnTotalPrice;
    }

    public void setReturnTotalPrice(double returnTotalPrice) {
        this.returnTotalPrice = returnTotalPrice;
    }

    public double getReturnTotalTax() {
        return returnTotalTax;
    }

    public void setReturnTotalTax(double returnTotalTax) {
        this.returnTotalTax = returnTotalTax;
    }
}
