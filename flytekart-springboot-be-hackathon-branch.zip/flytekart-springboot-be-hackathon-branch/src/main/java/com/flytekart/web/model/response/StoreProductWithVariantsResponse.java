package com.flytekart.web.model.response;

import java.util.List;
import java.util.Objects;

public class StoreProductWithVariantsResponse {
    String productId;
    String productName;
    List<Variant> variants;

    public static class Variant {
        String productId;
        String productName;
        String storeVariantId;
        String variantName;
        String categoryName;
        Double price;
        Double tax;
        Double originalPrice;

        public Variant(String productId, String productName,
                       String storeVariantId, String variantName, String categoryName,
                       Double price, Double tax, Double originalPrice) {
            this.productId = productId;
            this.productName = productName;
            this.storeVariantId = storeVariantId;
            this.variantName = variantName;
            this.categoryName = categoryName;
            this.price = price;
            this.tax = tax;
            this.originalPrice = originalPrice;
        }

        public String getProductId() {
            return productId;
        }

        public void setProductId(String productId) {
            this.productId = productId;
        }

        public String getProductName() {
            return productName;
        }

        public void setProductName(String productName) {
            this.productName = productName;
        }

        public String getStoreVariantId() {
            return storeVariantId;
        }

        public void setStoreVariantId(String storeVariantId) {
            this.storeVariantId = storeVariantId;
        }

        public String getVariantName() {
            return variantName;
        }

        public void setVariantName(String variantName) {
            this.variantName = variantName;
        }

        public String getCategoryName() {
            return categoryName;
        }

        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }

        public Double getPrice() {
            return price;
        }

        public void setPrice(Double price) {
            this.price = price;
        }

        public Double getTax() {
            return tax;
        }

        public void setTax(Double tax) {
            this.tax = tax;
        }

        public Double getOriginalPrice() {
            return originalPrice;
        }

        public void setOriginalPrice(Double originalPrice) {
            this.originalPrice = originalPrice;
        }
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<Variant> getVariants() {
        return variants;
    }

    public void setVariants(List<Variant> variants) {
        this.variants = variants;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StoreProductWithVariantsResponse that = (StoreProductWithVariantsResponse) o;
        return productId.equals(that.productId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(productId);
    }
}
