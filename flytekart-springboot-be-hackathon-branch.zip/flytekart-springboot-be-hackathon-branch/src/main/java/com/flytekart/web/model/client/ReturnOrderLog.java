package com.flytekart.web.model.client;

import com.flytekart.web.model.common.EmployeeAndUserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * ReturnOrderLog
 */
@Entity
@Table(name = "ReturnOrderLog", schema = "public")
public class ReturnOrderLog extends EmployeeAndUserDateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String returnOrderId;

    @Column(length = 40)
    private String returnOrderStatusId;

    @Column(length = 1000)
    private String description;

    public ReturnOrderLog() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getReturnOrderId() {
        return returnOrderId;
    }

    public void setReturnOrderId(String returnOrderId) {
        this.returnOrderId = returnOrderId;
    }

    public String getReturnOrderStatusId() {
        return returnOrderStatusId;
    }

    public void setReturnOrderStatusId(String returnOrderStatusId) {
        this.returnOrderStatusId = returnOrderStatusId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
