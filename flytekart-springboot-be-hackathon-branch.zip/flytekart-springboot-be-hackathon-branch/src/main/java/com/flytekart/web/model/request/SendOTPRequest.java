package com.flytekart.web.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class SendOTPRequest {

    @NotBlank
    @Size(min = 10, max = 10)
    private String phoneNumber;

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
