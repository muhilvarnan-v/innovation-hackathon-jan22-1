package com.flytekart.web.model.client;

import com.flytekart.web.model.common.EmployeeAndUserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * ReturnOrderItemLog
 */
@Entity
@Table(name = "ReturnOrderItemLog", schema = "public")
public class ReturnOrderItemLog extends EmployeeAndUserDateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String returnOrderItemId;

    @Column(length = 40)
    private String returnOrderItemStatusId;

    @Column(length = 1000)
    private String description;

    public ReturnOrderItemLog() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getReturnOrderItemId() {
        return returnOrderItemId;
    }

    public void setReturnOrderItemId(String returnOrderItemId) {
        this.returnOrderItemId = returnOrderItemId;
    }

    public String getReturnOrderItemStatusId() {
        return returnOrderItemStatusId;
    }

    public void setReturnOrderItemStatusId(String returnOrderItemStatusId) {
        this.returnOrderItemStatusId = returnOrderItemStatusId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
