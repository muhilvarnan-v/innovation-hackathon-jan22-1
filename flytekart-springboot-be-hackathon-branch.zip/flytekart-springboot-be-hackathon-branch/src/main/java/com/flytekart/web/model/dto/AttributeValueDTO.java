package com.flytekart.web.model.dto;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Objects;

public class AttributeValueDTO {

    @Size(min = 1, max = 40)
    private String variantAttributeValueId;

    @Size(min = 1, max = 40)
    private String attributeValueId;

    @NotNull
    @Column(length = 100)
    private String attributeName;

    @NotNull
    @Column(length = 100)
    private String attributeValueName;

    public String getVariantAttributeValueId() {
        return variantAttributeValueId;
    }

    public void setVariantAttributeValueId(String variantAttributeValueId) {
        this.variantAttributeValueId = variantAttributeValueId;
    }

    public String getAttributeValueId() {
        return attributeValueId;
    }

    public void setAttributeValueId(String attributeValueId) {
        this.attributeValueId = attributeValueId;
    }

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public String getAttributeValueName() {
        return attributeValueName;
    }

    public void setAttributeValueName(String attributeValueName) {
        this.attributeValueName = attributeValueName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttributeValueDTO dto = (AttributeValueDTO) o;
        return attributeName.equals(dto.attributeName) && attributeValueName.equals(dto.attributeValueName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(attributeName, attributeValueName);
    }
}
