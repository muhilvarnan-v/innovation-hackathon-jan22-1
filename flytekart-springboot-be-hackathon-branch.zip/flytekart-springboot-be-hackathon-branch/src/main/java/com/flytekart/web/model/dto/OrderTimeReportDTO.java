package com.flytekart.web.model.dto;

import java.util.Date;

public class OrderTimeReportDTO {
 
    private Date createdAt;

    private Integer placedOrders;

    private Integer deliveredOrders;

    private Integer totalOrderedUnits;

    private Double totalOrderedValue;

    private Integer totalDeliveredUnits;

    private Double totalDeliveredValue;

    public OrderTimeReportDTO(Date createdAt, Integer placedOrders, Integer deliveredOrders, Integer totalOrderedUnits, Double totalOrderedValue, Integer totalDeliveredUnits, Double totalDeliveredValue) {
        this.createdAt = createdAt;
        this.placedOrders = placedOrders;
        this.deliveredOrders = deliveredOrders;
        this.totalOrderedUnits = totalOrderedUnits;
        this.totalOrderedValue = totalOrderedValue;
        this.totalDeliveredUnits = totalDeliveredUnits;
        this.totalDeliveredValue = totalDeliveredValue;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getPlacedOrders() {
        return placedOrders;
    }

    public void setPlacedOrders(Integer placedOrders) {
        this.placedOrders = placedOrders;
    }

    public Integer getDeliveredOrders() {
        return deliveredOrders;
    }

    public void setDeliveredOrders(Integer deliveredOrders) {
        this.deliveredOrders = deliveredOrders;
    }

    public Integer getTotalOrderedUnits() {
        return totalOrderedUnits;
    }

    public void setTotalOrderedUnits(Integer totalOrderedUnits) {
        this.totalOrderedUnits = totalOrderedUnits;
    }

    public Double getTotalOrderedValue() {
        return totalOrderedValue;
    }

    public void setTotalOrderedValue(Double totalOrderedValue) {
        this.totalOrderedValue = totalOrderedValue;
    }

    public Integer getTotalDeliveredUnits() {
        return totalDeliveredUnits;
    }

    public void setTotalDeliveredUnits(Integer totalDeliveredUnits) {
        this.totalDeliveredUnits = totalDeliveredUnits;
    }

    public Double getTotalDeliveredValue() {
        return totalDeliveredValue;
    }

    public void setTotalDeliveredValue(Double totalDeliveredValue) {
        this.totalDeliveredValue = totalDeliveredValue;
    }
}
