package com.flytekart.web.controller;

import com.flytekart.web.model.client.BusinessType;
import com.flytekart.web.model.client.OrganisationType;
import com.flytekart.web.repository.client.BusinessTypeRepository;
import com.flytekart.web.repository.client.OrganisationTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@Controller
public class BusinessTypeController {

    @Autowired
    private BusinessTypeRepository repository;

    public BusinessType getBusinessTypeByName(String name) {
        Optional<BusinessType> optional = repository.findByName(name);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            return null;
        }
    }
}
