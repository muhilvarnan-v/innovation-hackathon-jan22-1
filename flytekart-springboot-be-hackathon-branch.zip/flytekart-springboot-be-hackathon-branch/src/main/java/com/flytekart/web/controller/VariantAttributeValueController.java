package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.AttributeValue;
import com.flytekart.web.model.client.Product;
import com.flytekart.web.model.client.Variant;
import com.flytekart.web.model.client.VariantAttributeValue;
import com.flytekart.web.model.request.CreateVariantAttributeValueRequest;
import com.flytekart.web.model.request.DeleteVariantAttributeValueRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.*;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.AttributeValueService;
import com.flytekart.web.service.VariantAttributeValueService;
import com.flytekart.web.service.VariantService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * TODO Make updates to get only non-deleted VariantAttributeValues
 * Create a new API to delete a variantAttribute - Done
 */
@RestController
@RequestMapping("/api/variantAttributeValues")
public class VariantAttributeValueController {

    @Autowired
    private VariantAttributeValueService variantAttributeValueService;

    @Autowired
    private VariantService variantService;

    @Autowired
    private AttributeValueService attributeValueService;

    @Autowired
    private AttributeValueRepository attributeValueRepository;

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody CreateVariantAttributeValueRequest request,
                                            @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Variant variant = variantService.getVariantByVariantId(request.getVariantId());
        AttributeValue attributeValue = attributeValueService.getAttributeValueByAttributeValueId(request.getAttributeValueId());
        if (variant == null || attributeValue == null) {
            return ResponseEntity.badRequest().build();
        }

        // There shouldn't be any VariantAttributeValue with the same Variant and AttributeValue combination
        VariantAttributeValue variantAttributeValue = variantAttributeValueService
                .getVariantAttributeValueByVariantIdAndAttributeValueId(variant.getId(), attributeValue.getId());
        if (variantAttributeValue != null) {
            return ResponseEntity.badRequest().build();
        }

        // There shouldn't be any VariantAttributeValue with the same Variant and Attribute combination
        variantAttributeValue = variantAttributeValueService
                .getVariantAttributeValueByVariantIdAndAttributeId(variant.getId(), attributeValue.getAttribute().getId());
        if (variantAttributeValue != null) {
            return ResponseEntity.badRequest().build();
        }

        variantAttributeValue = new VariantAttributeValue();
        variantAttributeValue.setVariant(variant);
        variantAttributeValue.setAttributeValue(attributeValue);
        variantAttributeValueService.save(variantAttributeValue);
        return ResponseEntity.ok(new ApiResponse<>(200, variantAttributeValue));
    }

    @Transactional
    @GetMapping("/getByVariantId/{variantId}")
    public ResponseEntity<?> getAttributeValuesByVariantId(@RequestParam String clientId,
                                                        @PathVariable String variantId) {
        DBContextHolder.setCurrentDb(clientId);

        Variant variant = variantService.getVariantByVariantId(variantId);
        if (variant == null) {
            return ResponseEntity.badRequest().build();
        }

        List<VariantAttributeValue> variantAttributeValues
                = variantAttributeValueService.getVariantAttributeValuesByVariantId(variantId);
        return ResponseEntity.ok(new ApiResponse<>(200, variantAttributeValues));
    }

    @Transactional
    @PostMapping("/deleteById")
    public ResponseEntity<?> deleteById(@Valid @RequestBody DeleteVariantAttributeValueRequest request,
                                                  @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        VariantAttributeValue value = variantAttributeValueService
                .getVariantAttributeValueByVariantAttributeValueId(request.getId());
        if (value == null) {
            return ResponseEntity.badRequest().build();
        }
        value.setDeletedAt(new Date());
        value.setDeletedBy(principal.getId());
        variantAttributeValueService.save(value);

        return ResponseEntity.ok(new ApiResponse<>(200, variantAttributeValueService));
    }

    @Transactional
    @DeleteMapping("/{variantAttributeValueId}")
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> deleteVariantAttributeValueById(@RequestParam String clientId,
                                                        @PathVariable String variantAttributeValueId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        VariantAttributeValue variantAttributeValue = variantAttributeValueService
                .getVariantAttributeValueByVariantAttributeValueId(variantAttributeValueId);
        if (variantAttributeValue == null) {
            return ResponseEntity.notFound().build();
        }

        variantAttributeValue.setDeletedBy(principal.getId());
        variantAttributeValue.setDeletedAt(new Date());
        variantAttributeValueService.save(variantAttributeValue);
        return ResponseEntity.ok(new ApiResponse<>(200, variantAttributeValue));
    }
}
