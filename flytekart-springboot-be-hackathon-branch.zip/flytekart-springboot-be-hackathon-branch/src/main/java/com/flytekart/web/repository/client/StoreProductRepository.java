package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.StoreCategory;
import com.flytekart.web.model.client.StoreProduct;
import com.flytekart.web.model.dto.CategoryStoreCategoryDTO;
import com.flytekart.web.model.dto.ProductStoreProductDTO;
import com.flytekart.web.model.dto.StoreProductDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StoreProductRepository extends JpaRepository<StoreProduct, String> {
    List<StoreProduct> findByStoreId(String storeId);

    @Query("from StoreProduct where id=:id")
    StoreProduct findByStoreProductId(String id);

    @Query("from StoreProduct where storeId=:storeId and productId=:productId")
    StoreProduct findByStoreIdAndProductId(String storeId, String productId);

    @Query(nativeQuery = true,
            value = "select sp.* from StoreProduct sp " +
                    "inner join Product p on sp.productId = p.id and p.name=:productName " +
                    "where sp.storeId=:storeId")
    StoreProduct findByStoreIdAndProductName(String storeId, String productName);

    @Query("from StoreProduct where deletedBy IS NULL and storeId=:storeId")
    List<StoreProduct> findUndeletedByStoreId(String storeId);

    //@Query("from StoreProduct where deletedBy IS NULL and storeId=:storeId and categoryId=:categoryId")
    @Query(
            value = "select sp.* " +
                    "from StoreProduct sp inner join Product p on p.id = sp.productId and p.deletedAt is null and p.categoryId = :categoryId" +
                    " where sp.deletedAt is null and sp.storeId = :storeId",
            nativeQuery = true
    )
    List<StoreProduct> findUndeletedByStoreIdAndCategoryId(String categoryId, String storeId);

    @Query(name = "StoreProduct.findUndeletedWithVariantsByStoreIdAndCategoryId", nativeQuery = true)
    List<StoreProductDTO> findUndeletedWithVariantsByStoreIdAndCategoryId(String categoryId,
                                                                          String storeId, int limit, int offset);

    @Query("from StoreProduct where deletedBy IS NULL")
    List<StoreProduct> findAllUndeleted();

    @Query("from StoreProduct where deletedBy IS NULL and productId=:productId")
    List<StoreProduct> findUndeletedByProductId(String productId);

    List<StoreProduct> findByProductId(String productId);

    @Query(name = "StoreProduct.findAllProductsWithStoreProductsByStoreId", nativeQuery = true)
    List<ProductStoreProductDTO> findAllProductsWithStoreProductsByStoreId(String storeId, String categoryId);
}
