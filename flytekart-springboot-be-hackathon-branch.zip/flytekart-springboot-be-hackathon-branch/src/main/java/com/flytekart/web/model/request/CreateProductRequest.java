package com.flytekart.web.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.AttributeValue;
import com.flytekart.web.model.client.Category;
import com.flytekart.web.model.client.Product;

import javax.validation.constraints.Size;

public class CreateProductRequest {

    @Size(min = 1, max = 40)
    private String id;

    @Size(min = 1, max = 100)
    private String name;

    @Size(max = 1000)
    private String description;

    @Size(min = 1, max = 40)
    private String categoryId;

    @JsonProperty(value = "isActive")
    private boolean isActive;
    @Size(max = 1000)
    private String imageUrl;

    public CreateProductRequest() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    @JsonProperty(value = "isActive")
    public boolean isActive() {
        return isActive;
    }

    @JsonProperty(value = "isActive")
    public void setActive(boolean active) {
        isActive = active;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public static Product getProduct(CreateProductRequest requestBody, Category category) {
        Product product = new Product();
        product.setId(requestBody.getId());
        product.setActive(requestBody.isActive());
        product.setName(requestBody.getName());
        product.setDescription(requestBody.getDescription());
        product.setCategory(category);
        product.setImageUrl(requestBody.getImageUrl());
        return product;
    }

    public static Product getProduct(CreateProductRequest requestBody, Product managedProduct, Category category) {
        managedProduct.setActive(requestBody.isActive());
        managedProduct.setName(requestBody.getName());
        managedProduct.setCategory(category);
        managedProduct.setDescription(requestBody.getDescription());
        managedProduct.setImageUrl(requestBody.getImageUrl());
        return managedProduct;
    }
}
