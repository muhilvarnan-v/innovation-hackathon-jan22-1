package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.Category;
import com.flytekart.web.model.client.Product;
import com.flytekart.web.model.request.CreateProductRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.CategoryRepository;
import com.flytekart.web.repository.client.ProductRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.OrderService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import com.flytekart.web.model.dto.CustomerOrderReportDTO;
import com.flytekart.web.model.dto.OrderTimeReportDTO;
import com.flytekart.web.model.dto.ProductOrderReportDTO;
import com.flytekart.web.model.dto.UserReportDTO;

import javax.validation.Valid;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/reports")
public class ReportsController {

    @Autowired
    private OrderService service;

    /**
     * Get products for orders
     * @param clientId
     * @param categoryId
     * @return
     */
    @Transactional
    @GetMapping("/orders")
    // @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getOrderReports(@RequestParam String clientId,
                                                        @RequestParam(required = false, defaultValue = "Asia/Kolkata") String timeZone, 
                                                        @RequestParam(required = false, defaultValue = "NULL") String categoryId, 
                                                        @RequestParam(required = false, defaultValue = "NULL") String productId,
                                                        @RequestParam(required = false, defaultValue = "NULL") String variantId,
                                                        @RequestParam(required = false, defaultValue = "NULL") String startDate,
                                                        @RequestParam(required = false, defaultValue = "NULL") String endDate,
                                                        @RequestParam(required = false, defaultValue = "10") int pageSize,
                                                        @RequestParam(required = false, defaultValue = "0") int pageNumber
                                                        ) {
        DBContextHolder.setCurrentDb(clientId);
        int startItem = pageNumber * pageSize;
        int endItem = pageSize;
        List<ProductOrderReportDTO> products = service.getOrderProductsReport(timeZone, categoryId, productId, variantId, startDate, endDate, startItem, endItem);
        return ResponseEntity.ok(new ApiResponse<>(200, products));
    }

    /**
     * Get Orders By Data
     * @param clientId
     * @return
     */
    @Transactional
    @GetMapping("/ordersovertime")
    // @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getOrdersOverTime(@RequestParam String clientId,
                                                        @RequestParam(required = false, defaultValue = "Asia/Kolkata") String timeZone, 
                                                        @RequestParam(required = false, defaultValue = "NULL") String startDate,
                                                        @RequestParam(required = false, defaultValue = "NULL") String endDate,
                                                        @RequestParam(required = false, defaultValue = "10") int pageSize,
                                                        @RequestParam(required = false, defaultValue = "0") int pageNumber
                                                        ) {
        DBContextHolder.setCurrentDb(clientId);
        int startItem = pageNumber * pageSize;
        int endItem = pageSize;
        List<OrderTimeReportDTO> orders = service.getOrderTimeReport(timeZone, startDate, endDate, startItem, endItem);
        return ResponseEntity.ok(new ApiResponse<>(200, orders));
    }

    /**
     * Get Orders By Data
     * @param clientId
     * @return
     */
    @Transactional
    @GetMapping("/customer")
    // @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getCustomerAquisitionReport(@RequestParam String clientId,
                                                        @RequestParam(required = false, defaultValue = "Asia/Kolkata") String timeZone, 
                                                        @RequestParam(required = false, defaultValue = "NULL") String startDate,
                                                        @RequestParam(required = false, defaultValue = "NULL") String endDate,
                                                        @RequestParam(required = false, defaultValue = "10") int pageSize,
                                                        @RequestParam(required = false, defaultValue = "0") int pageNumber
                                                        ) {
        DBContextHolder.setCurrentDb(clientId);
        int startItem = pageNumber * pageSize;
        int endItem = pageSize;
        List<UserReportDTO> users = service.getUserReport(timeZone, startDate, endDate, startItem, endItem);
        return ResponseEntity.ok(new ApiResponse<>(200, users));
    }

    /**
     * Get Orders By user
     * @param clientId
     * @return
     */
    @Transactional
    @GetMapping("/customerorders")
    // @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getCustomerOrderReport(@RequestParam String clientId,
                                                         @RequestParam(required = false, defaultValue = "Asia/Kolkata") String timeZone, 
                                                        @RequestParam(required = false, defaultValue = "NULL") String lastOrderedAfter,
                                                        @RequestParam(required = false, defaultValue = "NULL") String lastOrderedBefore,
                                                        @RequestParam(required = false, defaultValue = "10") int pageSize,
                                                        @RequestParam(required = false, defaultValue = "0") int pageNumber
                                                        ) {
        DBContextHolder.setCurrentDb(clientId);
        int startItem = pageNumber * pageSize;
        int endItem = pageSize;
        List<CustomerOrderReportDTO> userOrders = service.getUserOrderReport(timeZone, lastOrderedAfter, lastOrderedBefore, startItem, endItem);
        return ResponseEntity.ok(new ApiResponse<>(200, userOrders));
    }
    
}
