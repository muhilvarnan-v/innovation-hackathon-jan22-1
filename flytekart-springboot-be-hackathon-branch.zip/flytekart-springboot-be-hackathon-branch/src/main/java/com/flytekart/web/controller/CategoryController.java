package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.CategoryRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.*;
import com.flytekart.web.util.Constants;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.*;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    @Autowired
    private CategoryRepository repository;

    @Autowired
    private ProductService productService;

    @Autowired
    private VariantService variantService;

    @Autowired
    private AttributeService attributeService;

    @Autowired
    private AttributeValueService attributeValueService;

    @Autowired
    private VariantAttributeValueService variantAttributeValueService;

    @Autowired
    private OrganisationService organisationService;

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody Category category, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        if (category.getId() == null) {
            Organisation organisation = organisationService.getOrganisation();
            category.setOrganisationId(organisation.getId());
        }

        repository.save(category);
        return ResponseEntity.ok(new ApiResponse<>(200, category));
    }

    //@SneakyThrows
    @Transactional
    @GetMapping("/")
    //@PreAuthorize() // Use PreAuthorize after we implement Roles for Employees and Users
    public ResponseEntity<?> getAllCategories(@RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        List<Category> categories =  repository.findAllUnDeleted();
        return ResponseEntity.ok(new ApiResponse<>(200, categories));
    }

    @Transactional
    @GetMapping("/{parentCategoryId}")
    //@PreAuthorize() // Use PreAuthorize after we implement Roles for Employees and Users
    public ResponseEntity<?> getSubCategories(@RequestParam String clientId, @PathVariable String parentCategoryId) {
        DBContextHolder.setCurrentDb(clientId);
        List<Category> categories =  repository.findByParentCategoryIdUnDeleted(parentCategoryId);
        return ResponseEntity.ok(new ApiResponse<>(200, categories));
    }

    @Transactional
    @PostMapping("/delete/{categoryId}")
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> deleteCategory(@RequestParam String clientId, @PathVariable String categoryId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Optional<Category> optionalCategory = repository.findByIdUnDeleted(categoryId);
        if (optionalCategory.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Check if there are any sub-categories under this category
        List<Category> categories =  repository.findByParentCategoryIdUnDeleted(categoryId);
        if (!categories.isEmpty()) {
            return ResponseEntity.badRequest().body(new ApiResponse<>(400, "This category has sub-categories. Please delete sub-categories first, to delete this category."));
        }

        // Check if there are any products under this product
        List<Product> products = productService.getProductsByCategoryId(categoryId);
        if (!products.isEmpty()) {
            return ResponseEntity.badRequest().body(new ApiResponse<>(400, "This category has items. Please delete items first, to delete this category."));
        }

        Category managedCategory = optionalCategory.get();
        managedCategory.setDeletedAt(new Date());
        managedCategory.setDeletedBy(principal.getId());

        return ResponseEntity.ok(new ApiResponse<>(200, managedCategory));
    }

    @Transactional
    @PostMapping("/upload")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> uploadFile(@RequestPart(value= "file") final MultipartFile multipartFile,
                                        @RequestParam(value="clientId") final String clientId) {

        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        final File file = new File(multipartFile.getOriginalFilename());
        try (final FileOutputStream outputStream = new FileOutputStream(file)) {
            outputStream.write(multipartFile.getBytes());
        } catch (final IOException ex) {
            //LOGGER.error("Error converting the multi-part file to file= ", ex.getMessage());
        }

        try {
            Organisation organisation = organisationService.getOrganisation();
            String weightAttributeString = "Weight";
            String quantityAttributeString = "Quantity";

            CSVReader reader = new CSVReader(new FileReader(file));
            Category category;
            Product product;
            Variant variant;
            String[] lineInArray;
            boolean skippedFirstLine = false;
            while ((lineInArray = reader.readNext()) != null) {
                if (skippedFirstLine) {
                    String categoryName = lineInArray[0];
                    String productName = lineInArray[1];
                    String variantName = lineInArray[2];
                    String weightAttributeValueString = lineInArray[3];
                    String quantityAttributeValueString = lineInArray[4];
                    String priceString = lineInArray[5];
                    double priceDouble = Double.parseDouble(priceString);

                    Optional<Category> categoryOptional = repository.findByNameUnDeleted(categoryName);
                    if (categoryOptional.isEmpty()) {
                        category = new Category();
                        category.setName(categoryName);
                        category.setActive(true);
                        category.setOrganisationId(organisation.getId());
                        repository.save(category);
                    } else {
                        category = categoryOptional.get();
                    }

                    product = productService.getProductByCategoryIdAndProductName(category.getId(), productName);
                    if (product == null) {
                        product = new Product();
                        product.setName(productName);
                        product.setCategory(category);
                        product.setActive(true);
                        productService.save(product);
                    }

                    // Save variant
                    variant = variantService.getVariantByProductIdAndVariantName(product.getId(), variantName);
                    if (variant == null) {
                        variant = new Variant();
                        variant.setName(variantName);
                        variant.setProduct(product);
                        variant.setActive(true);
                    }
                    variant.setPrice(priceDouble);
                    variant.setTax(0.0);
                    variantService.save(variant);

                    if (StringUtils.hasText(weightAttributeValueString)) {
                        // Save/Get weight attribute
                        Attribute attribute = attributeService.getAttributesByName(weightAttributeString);
                        if (attribute == null) {
                            attribute = new Attribute();
                            attribute.setName(weightAttributeString);
                            attributeService.save(attribute);
                        }

                        // Save/Get weight attributeValue
                        AttributeValue attributeValue = attributeValueService
                                .getAttributeValuesByAttributeIdAndName(attribute.getId(), weightAttributeValueString);
                        if (attributeValue == null) {
                            attributeValue = new AttributeValue();
                            attributeValue.setName(weightAttributeValueString);
                            attributeValue.setAttribute(attribute);
                            attributeValueService.save(attributeValue);
                        }

                        // Save variant attributeValue
                        VariantAttributeValue vav = variantAttributeValueService
                                .getVariantAttributeValueByVariantIdAndAttributeId(variant.getId(), attributeValue.getId());
                        if (vav == null) {
                            vav = new VariantAttributeValue();
                            vav.setVariant(variant);
                            vav.setAttributeValue(attributeValue);
                            variantAttributeValueService.save(vav);
                        }

                    }

                    if (StringUtils.hasText(quantityAttributeValueString)) {
                        // Save/Get weight attribute
                        Attribute attribute = attributeService.getAttributesByName(quantityAttributeString);
                        if (attribute == null) {
                            attribute = new Attribute();
                            attribute.setName(quantityAttributeString);
                            attributeService.save(attribute);
                        }

                        // Save/Get weight attributeValue
                        AttributeValue attributeValue = attributeValueService
                                .getAttributeValuesByAttributeIdAndName(attribute.getId(), quantityAttributeValueString);
                        if (attributeValue == null) {
                            attributeValue = new AttributeValue();
                            attributeValue.setName(quantityAttributeValueString);
                            attributeValue.setAttribute(attribute);
                            attributeValueService.save(attributeValue);
                        }

                        // Save variant attributeValue
                        VariantAttributeValue vav = variantAttributeValueService
                                .getVariantAttributeValueByVariantIdAndAttributeId(variant.getId(), attributeValue.getId());
                        if (vav == null) {
                            vav = new VariantAttributeValue();
                            vav.setVariant(variant);
                            vav.setAttributeValue(attributeValue);
                            variantAttributeValueService.save(vav);
                        }
                    }

                    //System.out.println(lineInArray[0] + lineInArray[1] + "etc...");
                } else {
                    skippedFirstLine = true;
                }
            }
            reader.close();
        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        } finally {

        }

        return ResponseEntity.ok(new ApiResponse<>(200, "Success"));
    }

    @Async
    private File convertMultiPartFileToFile(final MultipartFile multipartFile) {
        final File file = new File(multipartFile.getOriginalFilename());
        try (final FileOutputStream outputStream = new FileOutputStream(file)) {
            outputStream.write(multipartFile.getBytes());
        } catch (final IOException ex) {
            //LOGGER.error("Error converting the multi-part file to file= ", ex.getMessage());
        }
        return file;
    }
}
