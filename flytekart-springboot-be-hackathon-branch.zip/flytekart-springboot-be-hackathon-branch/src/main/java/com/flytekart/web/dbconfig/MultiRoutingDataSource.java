package com.flytekart.web.dbconfig;

import com.flytekart.web.util.Constants;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import javax.sql.DataSource;
import java.util.HashMap;

public class MultiRoutingDataSource extends AbstractRoutingDataSource {

    private ThreadLocal<DataSource> d;
    private String jdbcUrl;
    private String jdbcDb;
    private String username;
    private String password;

    MultiRoutingDataSource(String jdbcUrl, String jdbcDB, String username, String password) {
        // We won't actually use target data sources. But Spring boot needs it to start.
        this.jdbcUrl = jdbcUrl;
        this.jdbcDb = jdbcDB;
        this.username = username;
        this.password = password;
        setTargetDataSources(new HashMap<>(1));
    }

    @Override
    protected Object determineCurrentLookupKey() {
        return DBContextHolder.getCurrentDb();
    }

    /**
     * TODO Need to change to Redis/Cache based Datasource
     * @return
     */
    @Override
    protected DataSource determineTargetDataSource() {
        String dbString;
        Object lookupKey = determineCurrentLookupKey();
        if (lookupKey != null && !lookupKey.toString().equalsIgnoreCase(Constants.MAIN)) {
            dbString = "flytekart_" + lookupKey.toString();
            //url = "jdbc:postgresql://localhost:5432/" + dbString;
        } else {
            //dbString = "flytekart_main";
            dbString = jdbcDb;
        }
        String url = jdbcUrl + dbString;
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.postgresql.Driver");
        dataSource.setUrl(url);
        /*dataSource.setUsername("postgres");
        dataSource.setPassword("Flytekart_1");*/
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }
}
