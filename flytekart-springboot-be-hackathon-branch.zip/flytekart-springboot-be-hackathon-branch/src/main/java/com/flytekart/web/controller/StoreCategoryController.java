package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.dto.CategoryStoreCategoryDTO;
import com.flytekart.web.model.dto.StoreCategoryDTO;
import com.flytekart.web.model.request.CreateStoreCategoryRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.CategoryRepository;
import com.flytekart.web.repository.client.StoreRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.StoreCategoryService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/storeCategories")
public class StoreCategoryController {

    @Autowired
    private StoreCategoryService storeCategoryService;

    @Autowired
    private StoreRepository storeRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    /*@Autowired
    private EntityManager em;*/

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody CreateStoreCategoryRequest request,
                                            @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        if (request.getStoreCategoryId() != null) {
            StoreCategory storeCategory = storeCategoryService.getStoreCategoryById(request.getStoreCategoryId());
            if (storeCategory != null) {
                if (request.isActive()) {
                    storeCategory.setDeletedAt(null);
                    storeCategory.setDeletedBy(null);
                } else {
                    storeCategory.setDeletedAt(new Date());
                    storeCategory.setDeletedBy(principal.getId());
                }
                storeCategoryService.save(storeCategory);
                boolean isActive = (storeCategory.getDeletedAt() == null);
                String deletedAt = (storeCategory.getDeletedAt() == null) ? null : storeCategory.getDeletedAt().toString();
                CategoryStoreCategoryDTO dto = new CategoryStoreCategoryDTO(
                        storeCategory.getCategory().getId(), storeCategory.getCategory().getName(), storeCategory.getCategory().getParentCategoryId(),
                        isActive, storeCategory.getId(), deletedAt,
                        storeCategory.getDeletedBy());
                return ResponseEntity.ok(new ApiResponse<>(200, dto));
            } else {
                return ResponseEntity.badRequest().build();
            }
        }

        if (request.getStoreId() == null || request.getCategoryId() == null) {
            return ResponseEntity.badRequest().build();
        }

        Optional<Store> optionalStore = storeRepository.findById(request.getStoreId());
        Optional<Category> optionalCategory = categoryRepository.findById(request.getCategoryId());
        if (optionalStore.isEmpty() || optionalCategory.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        StoreCategory storeCategory = storeCategoryService
                .getStoreCategoryByStoreIdAndCategoryId(request.getStoreId(), request.getCategoryId());
        if (storeCategory != null) {
            if (request.isActive()) {
                storeCategory.setDeletedAt(null);
                storeCategory.setDeletedBy(null);
            } else {
                storeCategory.setDeletedAt(new Date());
                storeCategory.setDeletedBy(principal.getId());
            }
            storeCategoryService.save(storeCategory);
            boolean isActive = (storeCategory.getDeletedAt() == null);
            String deletedAt = (storeCategory.getDeletedAt() == null) ? null : storeCategory.getDeletedAt().toString();
            CategoryStoreCategoryDTO dto = new CategoryStoreCategoryDTO(
                    storeCategory.getCategory().getId(), storeCategory.getCategory().getName(), storeCategory.getCategory().getParentCategoryId(),
                    isActive, storeCategory.getId(), deletedAt,
                    storeCategory.getDeletedBy());
            return ResponseEntity.ok(new ApiResponse<>(200, dto));
        }

        // TODO A combination of storeId and categoryId should be unique.
        StoreCategory newStoreCategory = new StoreCategory();
        newStoreCategory.setStore(optionalStore.get());
        newStoreCategory.setCategory(optionalCategory.get());
        if (request.isActive()) {
            newStoreCategory.setDeletedAt(null);
            newStoreCategory.setDeletedBy(null);
        } else {
            newStoreCategory.setDeletedAt(new Date());
            newStoreCategory.setDeletedBy(principal.getId());
        }
        storeCategoryService.save(newStoreCategory);
        boolean isActive = (newStoreCategory.getDeletedAt() == null);
        String deletedAt = (newStoreCategory.getDeletedAt() == null) ? null : newStoreCategory.getDeletedAt().toString();
        CategoryStoreCategoryDTO dto = new CategoryStoreCategoryDTO(
                newStoreCategory.getCategory().getId(), newStoreCategory.getCategory().getName(), newStoreCategory.getCategory().getParentCategoryId(),
                isActive, newStoreCategory.getId(), deletedAt,
                newStoreCategory.getDeletedBy());
        return ResponseEntity.ok(new ApiResponse<>(200, dto));
    }

    @Transactional
    @GetMapping("/store/{storeId}")
    public ResponseEntity<?> getStoreCategoriesByStoreId(@RequestParam String clientId,
                                                                   @PathVariable String storeId) {
        DBContextHolder.setCurrentDb(clientId);

        Optional<Store> optionalStore = storeRepository.findById(storeId);
        if (optionalStore.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        List<StoreCategoryDTO> storeCategories
                = storeCategoryService.getStoreCategoriesByStoreId(optionalStore.get().getId());
        return ResponseEntity.ok(new ApiResponse<>(200, storeCategories));
    }

    @Transactional
    @GetMapping("/withAllCategories/store/{storeId}")
    // TODO Should we use NamedEntityGraphs and EntityGraphs for get queries?
    public ResponseEntity<?> getAllCategoriesWithStoreCategoriesByStoreId(@RequestParam String clientId,
                                                                   @PathVariable String storeId) {
        DBContextHolder.setCurrentDb(clientId);

        Optional<Store> optionalStore = storeRepository.findById(storeId);
        if (optionalStore.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        List<CategoryStoreCategoryDTO> storeCategories
                = storeCategoryService.getAllCategoriesWithStoreCategoriesByStoreId(optionalStore.get().getId());
        return ResponseEntity.ok(new ApiResponse<>(200, storeCategories));
    }

}
