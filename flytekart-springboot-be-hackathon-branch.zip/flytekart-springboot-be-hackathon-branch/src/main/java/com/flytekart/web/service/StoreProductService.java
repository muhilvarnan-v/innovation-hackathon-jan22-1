package com.flytekart.web.service;

import com.flytekart.web.model.client.StoreCategory;
import com.flytekart.web.model.client.StoreProduct;
import com.flytekart.web.model.dto.CategoryStoreCategoryDTO;
import com.flytekart.web.model.dto.ProductStoreProductDTO;
import com.flytekart.web.model.dto.StoreProductDTO;
import com.flytekart.web.repository.client.StoreCategoryRepository;
import com.flytekart.web.repository.client.StoreProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;


@Service
public class StoreProductService {

    @Autowired
    private StoreProductRepository storeProductRepository;

    public StoreProduct getStoreProductById(String id) {
        StoreProduct storeProduct;
        if (StringUtils.hasText(id)) {
            storeProduct =  storeProductRepository.findByStoreProductId(id);
        } else {
            storeProduct = null;
        }
        return storeProduct;
    }

    public StoreProduct getStoreProductByStoreIdAndProductId(String storeId, String productId) {
        StoreProduct storeProduct;
        if (StringUtils.hasText(storeId)) {
            storeProduct =  storeProductRepository.findByStoreIdAndProductId(storeId, productId);
        } else {
            storeProduct = null;
        }
        return storeProduct;
    }

    public StoreProduct getStoreProductByStoreIdAndProductName(String storeId, String productName) {
        StoreProduct storeProduct;
        if (StringUtils.hasText(storeId)) {
            storeProduct =  storeProductRepository.findByStoreIdAndProductName(storeId, productName);
        } else {
            storeProduct = null;
        }
        return storeProduct;
    }

    public List<StoreProduct> getStoreProductsByStoreId(String storeId) {
        List<StoreProduct> storeProducts;
        if (StringUtils.hasText(storeId)) {
            storeProducts =  storeProductRepository.findUndeletedByStoreId(storeId);
        } else {
            storeProducts = null;
        }
        return storeProducts;
    }

    public List<StoreProduct> getStoreProductsByStoreIdAndCategoryId(String storeId, String categoryId) {
        List<StoreProduct> storeProducts;
        if (StringUtils.hasText(storeId)) {
            storeProducts =  storeProductRepository.findUndeletedByStoreIdAndCategoryId(categoryId, storeId);
        } else {
            storeProducts = null;
        }
        return storeProducts;
    }

    public List<StoreProductDTO> getStoreProductsWithVariantsByStoreIdAndCategoryId(String storeId, String categoryId,
                                                                                    int pageSize, int pageNumber) {
        List<StoreProductDTO> storeProducts;
        if (StringUtils.hasText(storeId)) {
            int offset = pageNumber * pageSize;
            storeProducts =  storeProductRepository.findUndeletedWithVariantsByStoreIdAndCategoryId(
                    categoryId, storeId, pageSize, offset);
        } else {
            storeProducts = null;
        }
        return storeProducts;
    }

    public List<ProductStoreProductDTO> getAllProductsWithStoreProductsByStoreId(String storeId, String categoryId) {
        List<ProductStoreProductDTO> storeProducts;
        if (StringUtils.hasText(storeId)) {
            storeProducts =  storeProductRepository.findAllProductsWithStoreProductsByStoreId(storeId, categoryId);
        } else {
            storeProducts = null;
        }
        return storeProducts;
    }

    public StoreProduct save(StoreProduct storeProduct) {
        storeProductRepository.save(storeProduct);
        return storeProduct;
    }
}
