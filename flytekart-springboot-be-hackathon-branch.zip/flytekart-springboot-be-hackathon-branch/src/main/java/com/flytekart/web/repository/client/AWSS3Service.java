package com.flytekart.web.repository.client;

import org.springframework.web.multipart.MultipartFile;
import java.net.URL;

public interface AWSS3Service {

	URL uploadFile(MultipartFile multipartFile, String clientId);
}
