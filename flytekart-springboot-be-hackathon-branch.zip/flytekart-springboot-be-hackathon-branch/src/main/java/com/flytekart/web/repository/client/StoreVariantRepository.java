package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.StoreVariant;
import com.flytekart.web.model.client.VariantAttributeValue;
import com.flytekart.web.model.dto.ProductStoreProductDTO;
import com.flytekart.web.model.dto.VariantStoreVariantDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StoreVariantRepository extends JpaRepository<StoreVariant, String> {
    List<StoreVariant> findByStoreId(String storeId);

    Optional<StoreVariant> findById(String id);

    @Query(name = "StoreVariant.findDTOByStoreVariantId", nativeQuery = true)
    VariantStoreVariantDTO findDTOByStoreVariantId(String id);

    @Query("from StoreVariant where deletedBy IS NULL and id=:id")
    StoreVariant findUndeletedByStoreVariantId(String id);

    @Query("from StoreVariant where deletedBy IS NULL and storeId=:storeId")
    List<StoreVariant> findUndeletedByStoreId(String storeId);

    @Query(nativeQuery = true, value =
            "select sv.* from StoreVariant sv " +
                    "inner join Variant v on sv.variantId = v.id and v.productId = :productId " +
                    "where sv.deletedBy IS NULL and sv.storeId=:storeId")
    List<StoreVariant> findUndeletedByStoreIdAndProductId(String storeId, String productId);

    @Query(nativeQuery = true, value =
            "select sv.* from StoreVariant sv " +
                    "inner join Variant v on sv.variantId = v.id and v.productId = :productId and v.name = :variantName " +
                    "where sv.deletedBy IS NULL and sv.storeId=:storeId")
    List<StoreVariant> findUndeletedByStoreIdAndProductIdAndVariantName(String storeId, String productId, String variantName);

    @Query("from StoreVariant where deletedBy IS NULL")
    List<StoreVariant> findAllUndeleted();

    @Query("from StoreVariant where deletedBy IS NULL and variantId=:variantId")
    List<StoreVariant> findUndeletedByVariantId(String variantId);

    List<StoreVariant> findByVariantId(String variantId);

    @Query("from StoreVariant where deletedBy IS NULL and variantId=:variantId and isActive=true")
    List<StoreVariant> findActiveAndUndeletedByVariantId(String variantId);

    @Query(name = "StoreVariant.findAllVariantsWithStoreVariantsByStoreId", nativeQuery = true)
    List<VariantStoreVariantDTO> findAllVariantsWithStoreVariantsByStoreId(String storeId, String productId);

    @Query("from StoreVariant where storeId=:storeId and variantId=:variantId")
    StoreVariant findByStoreIdAndVariantId(String storeId, String variantId);
}
