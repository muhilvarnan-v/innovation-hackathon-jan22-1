package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.EmployeePushToken;
import com.flytekart.web.model.client.UserPushToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserPushTokenRepository extends JpaRepository<UserPushToken, String> {
    @Query("from UserPushToken where userId=:userId and token=:token " +
            "and clientType=:clientType and deletedBy IS NULL")
    List<UserPushToken> findUnDeletedByUserIdAndTokenAndClientType(
            @Param("userId") String userId,
            @Param("token") String token,
            @Param("clientType") String clientType);

    @Query("from UserPushToken where token=:token " +
            "and clientType=:clientType and deletedBy IS NULL")
    List<UserPushToken> findUnDeletedByTokenAndClientType(
            @Param("token") String token,
            @Param("clientType") String clientType);

    @Query("from UserPushToken where userId=:userId and deletedBy IS NULL")
    List<UserPushToken> findUnDeletedByUserId(@Param("userId") String userId);

    @Query("from UserPushToken where id=:id and deletedBy IS NULL")
    UserPushToken findUnDeletedById(@Param("id") String id);
}
