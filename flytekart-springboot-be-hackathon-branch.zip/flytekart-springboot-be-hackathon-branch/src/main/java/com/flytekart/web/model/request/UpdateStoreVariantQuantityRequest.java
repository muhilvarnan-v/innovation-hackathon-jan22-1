package com.flytekart.web.model.request;

public class UpdateStoreVariantQuantityRequest {

    private int quantity;

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
