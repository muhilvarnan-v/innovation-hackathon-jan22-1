package com.flytekart.web.service;

import com.flytekart.web.model.client.Address;
import com.flytekart.web.repository.client.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class AddressService {

    @Autowired
    AddressRepository repository;

    public Address getAddressById(String id) {
        Address address = repository.findById(id).orElse(null);
        return address;
    }

    public Address save(Address address) {
        if (address.getId() == null) {
            repository.save(address);
            return address;
        } else {
            Address existingAddress = repository.findById(address.getId()).get();
            existingAddress.setLine1(address.getLine1());
            existingAddress.setLine2(address.getLine2());
            existingAddress.setCity(address.getCity());
            existingAddress.setState(address.getState());
            existingAddress.setCountry(address.getCountry());
            existingAddress.setZip(address.getZip());
            existingAddress.setLatitude(address.getLatitude());
            existingAddress.setLongitude(address.getLongitude());
            repository.save(existingAddress);
            return existingAddress;
        }
    }
}
