package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name = "OrderDelivery", schema = "public")
public class OrderDelivery extends UserDateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String orderId;

    @Column(length = 40)
    private String deliveryStatusId;

    @Column(length = 40)
    private String deliveryEmployeeId;

    public OrderDelivery() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getDeliveryStatusId() {
        return deliveryStatusId;
    }

    public void setDeliveryStatusId(String deliveryStatusId) {
        this.deliveryStatusId = deliveryStatusId;
    }

    public String getDeliveryEmployeeId() {
        return deliveryEmployeeId;
    }

    public void setDeliveryEmployeeId(String deliveryEmployeeId) {
        this.deliveryEmployeeId = deliveryEmployeeId;
    }
}
