package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.request.*;
import com.flytekart.web.model.response.APIError;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.model.response.OrderResponse;
import com.flytekart.web.repository.client.AddressRepository;
import com.flytekart.web.repository.client.StoreRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.*;
import com.flytekart.web.util.Constants;
import com.flytekart.web.util.Utilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * Add an OrderItem - Done
 * Remove an OrderItem - Done
 * Change OrderItem quantity - Done
 * Delete an Order?
 * Get an Order by id - Done
 * Get Orders by userId - Paginated - Done
 * Get Orders by userId - Filters by orderSource - Paginated - Done
 * Get Orders at a Store - Paginated
 * Get Orders at a Store - Filter by date - Paginated
 * Get all Orders in an Org - Paginated
 * Get all Orders in an Org - Filter by date - Paginated
 * TODO Place an Order with multiple Order Items at once
 */
@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private StoreVariantService storeVariantService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private StoreRepository storeRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private OrganisationService organisationService;

    /**
     * Adding a single order item to an order for first time or while the order is in in-progress state.
     * TODO Handle addition in In-Store order and addition by employee
     * TODO How can a store employee update user's order?
     * All items in an order should be from same store. May be we can manage this while paying and placing the order
     * Shouldn't be able to add/edit items if the order is not in progress by user.
     * If same item comes again, need to update existing order item
     * TODO Employee should be able to add/edit items even if the order is not in progress.
     *
     * @param request  AddOrderItemRequest
     * @param clientId clientId
     * @return Updated order
     */
    @PostMapping("/addOrderItem")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> addOrderItem(@Valid @RequestBody AddOrderItemRequest request,
                                                    @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        if (request.getQuantity() <= 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "Invalid quantity"));
        }

        // Check item availability
        StoreVariant storeVariant =
                storeVariantService.getUndeletedStoreVariantByStoreVariantId(request.getStoreVariantId());
        if (storeVariant == null) {
            // Send bad request/store variant invalid
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This product is invalid"));
        }

        if (!storeVariant.isActive()) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This product is inactive"));
        }

        if (storeVariant.getQuantity() < request.getQuantity()) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "Required quantity of the product is not available"));
        }

        OrderStatus orderStatus = orderService.findOrderStatusByName(Constants.OrderStatus.IN_PROGRESS);
        // Create Order record if it is a new order
        Order order;
        if (request.getOrderId() == null) {
            order = new Order();
            EndUser user = new EndUser();
            user.setId(request.getUserId());
            order.setUser(user);
            order.setStore(storeVariant.getStore());

            OrderSource orderSource = orderService.findOrderSourceByName(request.getOrderSource());
            order.setOrderSource(orderSource);

            order.setOrderStatus(orderStatus);

            orderService.save(order);

            // Add OrderLog record
            orderService.addOrderLog(order, "Added to cart");
        } else {
            // Check if orderId is valid
            order = orderService.getOrderByOrderId(request.getOrderId());
            if (order == null || !principal.getId().equals(order.getUser().getId())) {
                return ResponseEntity.notFound().build();
            }
        }

        // Shouldn't be able to add/edit items if the order is not in progress by user.
        if (!order.getOrderStatus().getId().equals(orderStatus.getId())) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be placed"));
        }

        // If same item comes again, need to update existing order item
        OrderItem newOrderItem = new OrderItem();
        List<OrderItem> orderItems = orderService.getOrderItemsByOrderId(order.getId());
        for (OrderItem orderItem : orderItems) {
            if (orderItem.getStoreVariant().getId().equals(request.getStoreVariantId())
                    && orderItem.getDeletedAt() == null) {
                newOrderItem = orderItem;
                break;
            }
        }

        // TODO Should we have this check while placing order only?
        // All items in an order should be from same store. May be we can manage this while paying and placing the order
        if (!storeVariant.getStore().getId().equals(order.getStore().getId())) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "Items in this order are from different stores."));
        }

        // TODO Move this to OrderService or OrderItemService?
        // Add OrderItem to Order
        newOrderItem.setOrderId(order.getId());
        newOrderItem.setStoreVariant(storeVariant);
        newOrderItem.setQuantity(request.getQuantity());
        newOrderItem.setUnitPrice(storeVariant.getPrice());
        newOrderItem.setUnitTax(storeVariant.getTax());
        BigDecimal totalPriceBD = BigDecimal.valueOf(storeVariant.getPrice())
                .multiply(new BigDecimal(newOrderItem.getQuantity()))
                .setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalTaxBD = BigDecimal.valueOf(storeVariant.getTax())
                .multiply(new BigDecimal(newOrderItem.getQuantity()))
                .setScale(2, RoundingMode.HALF_UP);
        newOrderItem.setTotalPrice(totalPriceBD.doubleValue());
        newOrderItem.setTotalTax(totalTaxBD.doubleValue());
        OrderItemStatus orderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.IN_PROGRESS);
        newOrderItem.setOrderItemStatusId(orderItemStatus.getId());
        orderService.saveOrderItem(newOrderItem);

        // Add a record to OrderItemLog
        orderService.addOrderItemLog(newOrderItem, "Added to order");

        // Frame Order response and return
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Take storeId, orderItems, address.
     * Check if the address is deliverable by the store.
     * Check availability of items.
     * Create order in placed status, if the paymentType is COD.
     * Create order in in-progress status, if the paymentType is anything else.
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/createOrder")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> createOrder(@Valid @RequestBody CreateOrderRequest request,
                                                   @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        // Check if storeId is valid
        String storeId = request.getOrder().storeId;
        Optional<Store> optionalStore = storeRepository.findById(storeId);
        if (optionalStore.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // Check if the address is valid
        String deliveryAddressId = request.getOrder().deliveryAddressId;
        Optional<Address> optionalAddress = addressRepository.findById(deliveryAddressId);
        if (optionalAddress.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        // TODO Check if the address is deliverable by the store

        // Check dynamic pricing multiplier
        Double multiplier = 1.0;
        Organisation organisation = organisationService.getOrganisation();
        if (organisation.getIsDynamicPricing() == true && optionalStore.get().getPeakeSale() == true) {
            multiplier = organisation.getMultiplier();
        }

        // Check if each item is valid and available
        if (request.getOrderItems() == null || request.getOrderItems().size() == 0) {
            return ResponseEntity.badRequest().build();
        }

        OrderSource orderSource = orderService.findOrderSourceByName(request.getOrder().orderSource);
        if (orderSource == null) {
            return ResponseEntity.badRequest().build();
        }

        PaymentType paymentType = paymentService.findPaymentTypeByName(request.getOrder().paymentType);
        if (paymentType == null) {
            return ResponseEntity.badRequest().build();
        }

        OrderStatus orderStatus;
        OrderItemStatus orderItemStatus;
        System.out.println("PaymentType: " + paymentType.getName());
        if (paymentType.getName().equals(Constants.PaymentType.COD)) {
            orderStatus = orderService.findOrderStatusByName(Constants.OrderItemStatus.PLACED);
            orderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.PLACED);
        } else {
            orderStatus = orderService.findOrderStatusByName(Constants.OrderItemStatus.IN_PROGRESS);
            orderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.IN_PROGRESS);
        }

        Store store = null;
        List<OrderItem> orderItems = new ArrayList<>(request.getOrderItems().size());
        for (CreateOrderRequest.OrderItemDTO orderItemDTO : request.getOrderItems()) {
            String storeVariantId = orderItemDTO.storeVariantId;
            StoreVariant storeVariant = storeVariantService.getStoreVariantByStoreVariantId(storeVariantId);

            if (storeVariant == null || !storeVariant.isActive()
                    || storeVariant.getDeletedAt() != null || storeVariant.getStore().getId() != storeId) {
                return ResponseEntity.badRequest().build();
            }

            if (storeVariant.getQuantity() < orderItemDTO.quantity
                    || orderItemDTO.quantity < 1) {
                return ResponseEntity.badRequest().body(new APIError(400,
                                        "Invalid quantity"));
            }
            // Data is good
            OrderItem newOrderItem = new OrderItem();
            newOrderItem.setStoreVariant(storeVariant);
            newOrderItem.setQuantity(orderItemDTO.quantity);
            newOrderItem.setUnitPrice(storeVariant.getPrice() * multiplier);
            BigDecimal totalPriceBD = BigDecimal.valueOf(storeVariant.getPrice() * multiplier)
                    .multiply(new BigDecimal(newOrderItem.getQuantity()))
                    .setScale(2, RoundingMode.HALF_UP);
            newOrderItem.setTotalPrice(totalPriceBD.doubleValue());
            if (storeVariant.getTax() != null) {
                newOrderItem.setUnitTax(storeVariant.getTax() * multiplier);
                BigDecimal totalTaxBD = BigDecimal.valueOf(storeVariant.getTax() * multiplier)
                        .multiply(new BigDecimal(newOrderItem.getQuantity()))
                        .setScale(2, RoundingMode.HALF_UP);
                newOrderItem.setTotalTax(totalTaxBD.doubleValue());
            }
            newOrderItem.setOrderItemStatusId(orderItemStatus.getId());
            orderItems.add(newOrderItem);

            if (store == null) {
                store = storeVariant.getStore();
            }
        }

        Order order = new Order();
        EndUser user = new EndUser();
        user.setId(principal.getId());
        order.setUser(user);
        order.setStore(store);
        order.setDeliveryAddress(optionalAddress.get());

        order.setOrderSource(orderSource);

        order.setOrderStatus(orderStatus);
        if (orderStatus.getName().equals(Constants.OrderStatus.PLACED)) {
            order.setOrderPlacedAt(new Date());
        }

        orderService.save(order);

        // Add OrderLog record
        orderService.addOrderLog(order, "Order created");

        for (OrderItem orderItem : orderItems) {
            // TODO Move this to OrderService or OrderItemService?
            // Add OrderItem to Order
            orderItem.setOrderId(order.getId());
            orderService.saveOrderItem(orderItem);

            // Add a record to OrderItemLog
            orderService.addOrderItemLog(orderItem, "Added to order");
        }

        // Frame Order response and return
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        if (order.getOrderStatus().getName().equals(Constants.OrderStatus.PLACED)) {
            // Send notifications to store asynchronously
            String total = Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal());
            String storeName = order.getStore().getName();
            String notificationBody = String.format(Constants.NOTIFICATION_NEW_ORDER, storeName, total);
            notificationService.sendPushNotificationByClientId(Constants.NEW_ORDER, notificationBody, clientId);
        }

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Create order for Telegram
     * TODO Move this to order service
     * @param request
     * @param clientId
     * @return order id
     */
    public String createOrderForTelegram(CreateOrderRequest request, String clientId, EndUser user) {
        DBContextHolder.setCurrentDb(clientId);

        // Check if storeId is valid
        String storeId = request.getOrder().storeId;
        Optional<Store> optionalStore = storeRepository.findById(storeId);
        if (optionalStore.isEmpty()) {
            // TODO Return failure
            //return ResponseEntity.notFound().build();
        }

        // Check if the address is valid
        String deliveryAddressId = request.getOrder().deliveryAddressId;
        Optional<Address> optionalAddress = addressRepository.findById(deliveryAddressId);
        if (optionalAddress.isEmpty()) {
            // TODO Return failure
            //return ResponseEntity.notFound().build();
        }

        // TODO Check if the address is deliverable by the store

        // Check if each item is valid and available
        if (request.getOrderItems() == null || request.getOrderItems().size() == 0) {
            // TODO Return failure
            //return ResponseEntity.badRequest().build();
        }

        OrderSource orderSource = orderService.findOrderSourceByName(request.getOrder().orderSource);
        if (orderSource == null) {
            // TODO Return failure
            //return ResponseEntity.badRequest().build();
        }

        PaymentType paymentType = paymentService.findPaymentTypeByName(request.getOrder().paymentType);
        if (paymentType == null) {
            // TODO Return failure
            //return ResponseEntity.badRequest().build();
        }

        OrderStatus orderStatus;
        OrderItemStatus orderItemStatus;
        System.out.println("PaymentType: " + paymentType.getName());
        if (paymentType.getName().equals(Constants.PaymentType.COD)) {
            orderStatus = orderService.findOrderStatusByName(Constants.OrderItemStatus.PLACED);
            orderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.PLACED);
        } else {
            orderStatus = orderService.findOrderStatusByName(Constants.OrderItemStatus.IN_PROGRESS);
            orderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.IN_PROGRESS);
        }

        Store store = null;
        List<OrderItem> orderItems = new ArrayList<>(request.getOrderItems().size());
        for (CreateOrderRequest.OrderItemDTO orderItemDTO : request.getOrderItems()) {
            String storeVariantId = orderItemDTO.storeVariantId;
            StoreVariant storeVariant = storeVariantService.getStoreVariantByStoreVariantId(storeVariantId);

            if (storeVariant == null || !storeVariant.isActive()
                    || storeVariant.getDeletedAt() != null || storeVariant.getStore().getId() != storeId) {
                // TODO Return failure
                //return ResponseEntity.badRequest().build();
            }

            if (storeVariant.getQuantity() < orderItemDTO.quantity
                    || orderItemDTO.quantity < 1) {
                // TODO Return failure
                /*return ResponseEntity.badRequest().body(new APIError(400,
                        "Invalid quantity"));*/
            }
            // Data is good
            OrderItem newOrderItem = new OrderItem();
            newOrderItem.setStoreVariant(storeVariant);
            newOrderItem.setQuantity(orderItemDTO.quantity);
            newOrderItem.setUnitPrice(storeVariant.getPrice());
            BigDecimal totalPriceBD = BigDecimal.valueOf(storeVariant.getPrice())
                    .multiply(new BigDecimal(newOrderItem.getQuantity()))
                    .setScale(2, RoundingMode.HALF_UP);
            newOrderItem.setTotalPrice(totalPriceBD.doubleValue());
            if (storeVariant.getTax() != null) {
                newOrderItem.setUnitTax(storeVariant.getTax());
                BigDecimal totalTaxBD = BigDecimal.valueOf(storeVariant.getTax())
                        .multiply(new BigDecimal(newOrderItem.getQuantity()))
                        .setScale(2, RoundingMode.HALF_UP);
                newOrderItem.setTotalTax(totalTaxBD.doubleValue());
            }
            newOrderItem.setOrderItemStatusId(orderItemStatus.getId());
            orderItems.add(newOrderItem);

            if (store == null) {
                store = storeVariant.getStore();
            }
        }

        Order order = new Order();
        order.setUser(user);
        order.setStore(store);
        order.setDeliveryAddress(optionalAddress.get());

        order.setOrderSource(orderSource);

        order.setOrderStatus(orderStatus);
        if (orderStatus.getName().equals(Constants.OrderStatus.PLACED)) {
            order.setOrderPlacedAt(new Date());
        }

        orderService.save(order);

        // Add OrderLog record
        orderService.addOrderLog(order, "Order created");

        for (OrderItem orderItem : orderItems) {
            // TODO Move this to OrderService or OrderItemService?
            // Add OrderItem to Order
            orderItem.setOrderId(order.getId());
            orderService.saveOrderItem(orderItem);

            // Add a record to OrderItemLog
            orderService.addOrderItemLog(orderItem, "Added to order");
        }

        // Frame Order response and return
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        if (order.getOrderStatus().getName().equals(Constants.OrderStatus.PLACED)) {
            // Send notifications to store asynchronously
            String total = Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal());
            String storeName = order.getStore().getName();
            String notificationBody = String.format(Constants.NOTIFICATION_NEW_ORDER, storeName, total);
            notificationService.sendPushNotificationByClientId(Constants.NEW_ORDER, notificationBody, clientId);
        }

        return orderResponse.getOrder().getId();
    }


    /**
     * TODO Handle removal in In-Store order and removal by employee
     * TODO How can a store employee update user's order?
     *
     * @param request  RemoveOrderItemRequest
     * @param clientId
     * @return
     */
    @PostMapping("/removeOrderItem")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> removeOrderItem(@Valid @RequestBody RemoveOrderItemRequest request,
                                                       @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        OrderItem orderItem = orderService.getOrderItemByOrderItemId(request.getOrderItemId());
        OrderItemStatus inprogressOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.IN_PROGRESS);
        if (orderItem == null || !inprogressOrderItemStatus.getId().equals(orderItem.getOrderItemStatusId())) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be edited"));
        }

        Order order = orderService.getOrderByOrderId(orderItem.getOrderId());
        if (order == null || !principal.getId().equals(order.getUser().getId()) || order.getOrderStatus() == null) {
            return ResponseEntity.notFound().build();
        }

        if (order.getOrderStatus().getName().equals(Constants.OrderStatus.IN_PROGRESS)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be edited"));
        }

        OrderItemStatus deletedStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.DELETED);
        orderItem.setOrderItemStatusId(deletedStatus.getId());
        orderItem.setDeletedBy(principal.getId());
        orderItem.setDeletedAt(new Date());
        orderService.saveOrderItem(orderItem);

        // Add a record to OrderItemLog
        orderService.addOrderItemLog(orderItem, "Removed from order");

        // Frame Order response and return
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * For placing a COD order by end user
     * Check if current status is IN_PROGRESS
     * Check if all items are available in inventory.
     * TODO Check if delivery location is serviceable
     * Create unpaid COD payment record and related log record
     * Place order and update statuses of OrderItems
     * Add OrderLog
     * Add OrderItemLog
     * TODO Send notifications to store asynchronously
     *
     * @param request  UpdateOrderStatusRequest
     * @param clientId
     * @return
     */
    @PostMapping("/placeCODOrder")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> placeCODOrder(@Valid @RequestBody UpdateOrderStatusRequest request,
                                                     @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null || !principal.getId().equals(order.getUser().getId())) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        if (!order.getOrderStatus().getName().equals(Constants.OrderStatus.IN_PROGRESS)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be placed"));
        }

        List<OrderItem> orderItems = orderService.getOrderItemsByOrderId(request.getOrderId());
        if (orderItems == null || orderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be placed"));
        }

        for (OrderItem orderItem : orderItems) {
            // Check item
            StoreVariant storeVariant = orderItem.getStoreVariant();
            if (storeVariant == null) {
                // Send bad request/store variant invalid
                return ResponseEntity.badRequest().body(new APIError(400,
                                        "This order cannot be placed"));
            }

            if (!storeVariant.isActive()) {
                // Send bad request/store variant invalid
                return ResponseEntity.badRequest().body(new APIError(400,
                                        storeVariant.getVariant().getProduct().getName() +
                                                " is not available."));
            }

            if (storeVariant.getQuantity() < orderItem.getQuantity()) {
                // Send bad request/store variant invalid
                // TODCreateOrderRequestO Use string formatter for the error msg
                // TODO Need to show variant name and not product name
                // TODO Use entityGraph so that we don't retrieve product
                // TODO Should we use projection?
                return ResponseEntity.badRequest().body(new APIError(400,
                                        storeVariant.getVariant().getProduct().getName() +
                                                ": Available quantity is " + storeVariant.getQuantity() +
                                                ". Requested quantity is " + orderItem.getQuantity()));
            }
        }

        // TODO Check if delivery location is serviceable

        OrderResponse orderResponse = orderService.generateOrderResponse(order, orderItems);
        PaymentType paymentType = paymentService.findPaymentTypeByName(Constants.PaymentType.COD);
        PaymentStatus paymentStatus = paymentService.findPaymentStatusByName(Constants.PaymentStatus.UNPAID);

        // Create unpaid payment record
        Payment payment = new Payment();
        payment.setOrderId(order.getId());
        payment.setAmount(orderResponse.getOrderTotal().getTotal());
        payment.setPaymentType(paymentType);
        payment.setPaymentStatus(paymentStatus);
        paymentService.save(payment);

        // Create related paymentLog record
        paymentService.addPaymentLog(payment, "Generated unpaid COD payment");

        // Update order status to Placed
        OrderStatus placedOrderStatus = orderService.findOrderStatusByName(Constants.OrderStatus.PLACED);
        order.setOrderStatus(placedOrderStatus);
        orderService.save(order);

        orderService.addOrderLog(order, "Order placed");

        // Update status of order items to Placed
        OrderItemStatus placedOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.PLACED);
        for (OrderItem orderItem : orderItems) {
            orderItem.setOrderItemStatusId(placedOrderItemStatus.getId());
            orderService.saveOrderItem(orderItem);

            // Add a record to OrderItemLog
            orderService.addOrderItemLog(orderItem, "Order placed");
        }

        // Send notifications to store asynchronously
        String total = Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal());
        String notificationBody = String.format(Constants.NOTIFICATION_NEW_ORDER, total);
        notificationService.sendPushNotificationByClientId(Constants.NEW_ORDER, notificationBody, clientId);

        // Existing orderResponse will suffice and no need to build it again
        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Order acceptance is by employee.
     * To accept order, we won't validate inventory. We will leave the decision to the user.
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/updateOrderStatusToAccepted")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateOrderStatusToAccepted(@Valid @RequestBody UpdateOrderStatusRequest request,
                                                                   @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        // Current statis should be PLACED only
        if (!order.getOrderStatus().getName().equals(Constants.OrderStatus.PLACED)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        List<OrderItem> orderItems = orderService.getOrderItemsByOrderId(request.getOrderId());
        if (orderItems == null || orderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        // Update order status to Placed
        OrderStatus acceptedOrderStatus = orderService.findOrderStatusByName(Constants.OrderStatus.ACCEPTED);
        order.setOrderStatus(acceptedOrderStatus);
        orderService.save(order);

        orderService.addOrderLog(order, "Order accepted");

        // Update status of order items to Placed
        OrderItemStatus acceptedOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.ACCEPTED);
        for (OrderItem orderItem : orderItems) {
            if (orderItem.getDeletedAt() == null) {
                orderItem.setOrderItemStatusId(acceptedOrderItemStatus.getId());
                orderService.saveOrderItem(orderItem);

                // Add a record to OrderItemLog
                orderService.addOrderItemLog(orderItem, "Order accepted");
            }
        }

        OrderResponse orderResponse = orderService.generateOrderResponse(order, orderItems);

        // Send notifications to user asynchronously
        String total = Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal());
        String notificationBody = String.format(Constants.NOTIFICATION_ORDER_ACCEPTED, total);
        notificationService.sendPushNotificationByUserId(Constants.ORDER_UPDATE, notificationBody,
                orderResponse.getOrder().getUser().getId());

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Update order status to processing by employee
     * To process order, we won't validate inventory. We will leave the decision to the user.
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/updateOrderStatusToProcessing")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateOrderStatusToProcessing(@Valid @RequestBody UpdateOrderStatusRequest request,
                                                                     @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        // Current state should be ACCEPTED only
        if (!order.getOrderStatus().getName().equals(Constants.OrderStatus.ACCEPTED)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        List<OrderItem> orderItems = orderService.getOrderItemsByOrderId(request.getOrderId());
        if (orderItems == null || orderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        // Update order status to processing
        OrderStatus processingOrderStatus = orderService.findOrderStatusByName(Constants.OrderStatus.PROCESSING);
        order.setOrderStatus(processingOrderStatus);
        orderService.save(order);

        orderService.addOrderLog(order, "Order processing");

        // Update status of order items to processing
        OrderItemStatus processingOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.PROCESSING);
        for (OrderItem orderItem : orderItems) {
            if (orderItem.getDeletedAt() == null) {
                orderItem.setOrderItemStatusId(processingOrderItemStatus.getId());
                orderService.saveOrderItem(orderItem);

                // Add a record to OrderItemLog
                orderService.addOrderItemLog(orderItem, "Order processing");
            }
        }

        OrderResponse orderResponse = orderService.generateOrderResponse(order, orderItems);

        // Send notifications to user asynchronously
        String total = Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal());
        String notificationBody = String.format(Constants.NOTIFICATION_ORDER_PROCESSING, total);
        notificationService.sendPushNotificationByUserId(Constants.ORDER_UPDATE, notificationBody,
                orderResponse.getOrder().getUser().getId());

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Update order status to processed by employee
     * To process order, we won't validate inventory. We will leave the decision to the user.
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/updateOrderStatusToProcessed")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateOrderStatusToProcessed(@Valid @RequestBody UpdateOrderStatusRequest request,
                                                                    @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        // Current state should be PROCESSING only
        if (!order.getOrderStatus().getName().equals(Constants.OrderStatus.PROCESSING)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        List<OrderItem> orderItems = orderService.getOrderItemsByOrderId(request.getOrderId());
        if (orderItems == null || orderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        // Update order status to Placed
        OrderStatus processedOrderStatus = orderService.findOrderStatusByName(Constants.OrderStatus.PROCESSED);
        order.setOrderStatus(processedOrderStatus);
        orderService.save(order);

        orderService.addOrderLog(order, "Order processed");

        // Update status of order items to processed
        OrderItemStatus processedOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.PROCESSED);
        for (OrderItem orderItem : orderItems) {
            if (orderItem.getDeletedAt() == null) {
                orderItem.setOrderItemStatusId(processedOrderItemStatus.getId());
                orderService.saveOrderItem(orderItem);

                // Add a record to OrderItemLog
                orderService.addOrderItemLog(orderItem, "Order processed");
            }
        }

        OrderResponse orderResponse = orderService.generateOrderResponse(order, orderItems);

        // Send notifications to user asynchronously
        String total = Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal());
        String notificationBody = String.format(Constants.NOTIFICATION_ORDER_PROCESSED, total);
        notificationService.sendPushNotificationByUserId(Constants.ORDER_UPDATE, notificationBody,
                orderResponse.getOrder().getUser().getId());

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Update order status to out for delivery by employee
     * To process order, we won't validate inventory. We will leave the decision to the user.
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/updateOrderStatusToOutForDelivery")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateOrderStatusToOutForDelivery(@Valid @RequestBody UpdateOrderStatusRequest request,
                                                                         @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        // Current state should be PROCESSING only
        if (!order.getOrderStatus().getName().equals(Constants.OrderStatus.PROCESSED)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        List<OrderItem> orderItems = orderService.getOrderItemsByOrderId(request.getOrderId());
        if (orderItems == null || orderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        // Update order status to Placed
        OrderStatus ofdOrderStatus = orderService.findOrderStatusByName(Constants.OrderStatus.OUT_FOR_DELIVERY);
        order.setOrderStatus(ofdOrderStatus);
        orderService.save(order);

        orderService.addOrderLog(order, "Order out for delivery");

        // Update status of order items to ofd
        OrderItemStatus ofdOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.OUT_FOR_DELIVERY);
        for (OrderItem orderItem : orderItems) {
            if (orderItem.getDeletedAt() == null) {
                orderItem.setOrderItemStatusId(ofdOrderItemStatus.getId());
                orderService.saveOrderItem(orderItem);

                // Add a record to OrderItemLog
                orderService.addOrderItemLog(orderItem, "Order out for delivery");
            }
        }

        OrderResponse orderResponse = orderService.generateOrderResponse(order, orderItems);

        // Send notifications to user asynchronously
        String total = Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal());
        String notificationBody = String.format(Constants.NOTIFICATION_ORDER_OUT_FOR_DELIVERY, total);
        notificationService.sendPushNotificationByUserId(Constants.ORDER_UPDATE, notificationBody,
                orderResponse.getOrder().getUser().getId());

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Update order status to delivered by employee
     * To deliver order, we won't validate inventory. We will leave the decision to the user.
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/updateOrderStatusToDelivered")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateOrderStatusToDelivered(@Valid @RequestBody UpdateOrderStatusRequest request,
                                                                    @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null) {
            // Send bad request/store variant invalid
            return ResponseEntity.notFound().build();
        }

        // Current state should be OFD only
        if (!order.getOrderStatus().getName().equals(Constants.OrderStatus.OUT_FOR_DELIVERY)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        List<OrderItem> orderItems = orderService.getOrderItemsByOrderId(request.getOrderId());
        if (orderItems == null || orderItems.size() == 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be accepted"));
        }

        // Update order status to delivered
        OrderStatus deliveredOrderStatus = orderService.findOrderStatusByName(Constants.OrderStatus.DELIVERED);
        order.setOrderStatus(deliveredOrderStatus);
        orderService.save(order);

        orderService.addOrderLog(order, "Order delivered");

        // Update status of order items to delivered
        OrderItemStatus ofdOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.DELIVERED);
        for (OrderItem orderItem : orderItems) {
            if (orderItem.getDeletedAt() == null) {
                orderItem.setOrderItemStatusId(ofdOrderItemStatus.getId());
                orderService.saveOrderItem(orderItem);

                // Add a record to OrderItemLog
                orderService.addOrderItemLog(orderItem, "Order delivered");
            }
        }

        OrderResponse orderResponse = orderService.generateOrderResponse(order, orderItems);

        // Send notifications to user asynchronously
        String total = Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal());
        String notificationBody = String.format(Constants.NOTIFICATION_ORDER_DELIVERED, total);
        notificationService.sendPushNotificationByUserId(Constants.ORDER_UPDATE, notificationBody,
                orderResponse.getOrder().getUser().getId());

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Update order quantity when the order status is in progress
     * TODO Handle update in In-Store order and updation by employee
     * Store employee cannot update user's order in 'in progress' state.
     * Store employee can update user's order after the order state becomes placed.
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/updateOrderItemQuantity")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateOrderItemQuantity(@Valid @RequestBody UpdateOrderItemRequest request,
                                                               @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        if (request.getQuantity() <= 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "Invalid quantity"));
        }

        OrderItem orderItem = orderService.getOrderItemByOrderItemId(request.getOrderItemId());
        if (orderItem == null || orderItem.getDeletedAt() == null) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This item is not in the order"));
        }
        Order order = orderService.getOrderByOrderId(orderItem.getOrderId());
        if (order == null || !principal.getId().equals(order.getUser().getId()) || order.getOrderStatus() == null) {
            return ResponseEntity.notFound().build();
        }

        if (!order.getOrderStatus().getName().equals(Constants.OrderStatus.IN_PROGRESS)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be edited"));
        }

        // Check item
        StoreVariant storeVariant = orderItem.getStoreVariant();
        if (storeVariant == null) {
            // Send bad request/store variant invalid
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This product is invalid"));
        }

        orderItem.setQuantity(request.getQuantity());
        orderService.saveOrderItem(orderItem);

        // Add a record to OrderItemLog
        orderService.addOrderItemLog(orderItem, "Updated order item quantity");

        // Frame Order response and return
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Update a placed order by an employee. Orders can be updated after placing and before delivery
     * Quantity can be increased, decreased.
     * We won't check the inventory for availability, as order is being updated by an employee
     * TODO Take care of refund charge at item level. Currently 100% will be refunded. Meaning 'refund charge' = 0
     * User shouldn't be able to update a 'REMOVED' or deleted order
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/updateOrderItemOfPlacedOrder")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateOrderItemOfPlacedOrder(@Valid @RequestBody UpdateOrderItemOfPlacedRequest request,
                                                                    @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        if (request.getQuantity() <= 0) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "Invalid quantity"));
        }

        OrderItemStatus removedOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.REMOVED);
        OrderItem orderItem = orderService.getOrderItemByOrderItemId(request.getOrderItemId());
        if (orderItem == null || orderItem.getDeletedAt() == null
                || orderItem.getOrderItemStatusId().equals(removedOrderItemStatus.getId())) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This item is not in the order"));
        }
        Order order = orderService.getOrderByOrderId(orderItem.getOrderId());
        if (order == null || !principal.getId().equals(order.getUser().getId()) || order.getOrderStatus() == null) {
            return ResponseEntity.notFound().build();
        }

        if (!(
                order.getOrderStatus().getName().equals(Constants.OrderStatus.PLACED)
                        || order.getOrderStatus().getName().equals(Constants.OrderStatus.ACCEPTED)
                        || order.getOrderStatus().getName().equals(Constants.OrderStatus.PROCESSING)
                        || order.getOrderStatus().getName().equals(Constants.OrderStatus.PROCESSED)
                        || order.getOrderStatus().getName().equals(Constants.OrderStatus.OUT_FOR_DELIVERY)
        )) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be edited"));
        }

        // Check item for getting latest price
        StoreVariant storeVariant = orderItem.getStoreVariant();
        if (storeVariant == null) {
            // Send bad request/store variant invalid
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This product is invalid"));
        }

        int originalQuantity = orderItem.getQuantity();
        orderItem.setQuantity(request.getQuantity());
        BigDecimal totalPriceBD = new BigDecimal(storeVariant.getPrice())
                .multiply(new BigDecimal(orderItem.getQuantity()))
                .setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalTaxBD = new BigDecimal(storeVariant.getTax())
                .multiply(new BigDecimal(orderItem.getQuantity()))
                .setScale(2, RoundingMode.HALF_UP);
        orderItem.setTotalPrice(totalPriceBD.doubleValue());
        orderItem.setTotalTax(totalTaxBD.doubleValue());
        orderService.saveOrderItem(orderItem);

        // Add a record to OrderItemLog
        orderService.addOrderItemLog(orderItem, "Updated order item quantity from " +
                originalQuantity + " to " + orderItem.getQuantity());

        // Frame Order response and return
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Remove a placed order item by an employee. Order items can be updated after placing and before delivery
     * We won't check the inventory for availability, as order is being updated by an employee
     * TODO Take care of refund charge at item level. Currently 100% will be refunded. Meaning 'refund charge' = 0
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/removeOrderItemOfPlacedOrder")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> removeOrderItemOfPlacedOrder(@Valid @RequestBody RemoveOrderItemOfPlacedRequest request,
                                                                    @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        OrderItem orderItem = orderService.getOrderItemByOrderItemId(request.getOrderItemId());
        if (orderItem == null || orderItem.getDeletedAt() == null) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This item is not in the order"));
        }
        Order order = orderService.getOrderByOrderId(orderItem.getOrderId());
        if (order == null || !principal.getId().equals(order.getUser().getId()) || order.getOrderStatus() == null) {
            return ResponseEntity.notFound().build();
        }

        if (!(
                order.getOrderStatus().getName().equals(Constants.OrderStatus.PLACED)
                        || order.getOrderStatus().getName().equals(Constants.OrderStatus.ACCEPTED)
                        || order.getOrderStatus().getName().equals(Constants.OrderStatus.PROCESSING)
                        || order.getOrderStatus().getName().equals(Constants.OrderStatus.PROCESSED)
                        || order.getOrderStatus().getName().equals(Constants.OrderStatus.OUT_FOR_DELIVERY)
        )) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be edited"));
        }

        OrderItemStatus removedOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.REMOVED);
        orderItem.setOrderItemStatusId(removedOrderItemStatus.getId());
        orderService.saveOrderItem(orderItem);

        // Add a record to OrderItemLog
        orderService.addOrderItemLog(orderItem, "Order item removed");

        // Frame Order response and return
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    /**
     * Cancel a placed order by user, before it goes into accepted state.
     * All Order Items go into cancelled state. Order will go into cancelled state.
     * Currently refund amount will be 100%.
     * For COD orders there won't be any actual refund as the money isn't paid yet.
     *
     * @param request
     * @param clientId
     * @return
     */
    @PostMapping("/cancelPlacedOrder")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> cancelPlacedOrder(@Valid @RequestBody CancelPlacedOrderRequest request,
                                                         @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.USER) {
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null || !principal.getId().equals(order.getUser().getId()) || order.getOrderStatus() == null) {
            return ResponseEntity.notFound().build();
        }

        if (!order.getOrderStatus().getName().equals(Constants.OrderStatus.PLACED)) {
            return ResponseEntity.badRequest().body(new APIError(400,
                                    "This order cannot be canceled"));
        }

        List<OrderItem> orderItems = orderService.getOrderItemsByOrderId(request.getOrderId());
        /*if (orderItems == null) {
            return ResponseEntity.badRequest().body(
                    new ApiResponse<Void>(400,
                            new APIError("STORE_VARIANT_NOT_IN_ORDER",
                                    "This item is not in the order")));
        }*/

        OrderItemStatus canceledOrderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.CANCELED);
        for (OrderItem orderItem : orderItems) {
            orderItem.setOrderItemStatusId(canceledOrderItemStatus.getId());
            orderService.saveOrderItem(orderItem);

            // Add a record to OrderItemLog
            orderService.addOrderItemLog(orderItem, "Order canceled");
        }

        OrderStatus canceledOrderStatus = orderService.findOrderStatusByName(Constants.OrderStatus.CANCELED);
        order.setOrderStatus(canceledOrderStatus);
        orderService.save(order);

        // Add a record to OrderLog
        orderService.addOrderLog(order, "Order canceled");

        // TODO Raise a refund request

        // Frame Order response and return
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    @GetMapping("/get/{orderId}")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> getOrderByOrderId(@RequestParam String clientId,
                                                         @PathVariable String orderId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();

        Order order = orderService.getOrderByOrderId(orderId);
        if (order == null || order.getOrderStatus() == null) {
            return ResponseEntity.notFound().build();
        }

        // Only employee or the ordered user should have access to view the order
        // TODO Need to move this logic to add and remove methods
        if (!(principal.getUserType() == Constants.EMPLOYEE)
                && !(principal.getUserType() == Constants.USER && principal.getId().equals(order.getUser().getId()))) {
            return ResponseEntity.notFound().build();
        }

        // Frame Order response and return
        OrderResponse orderResponse = orderService.generateOrderResponse(order);

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    @GetMapping("/getByUserId/{userId}")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> getOrdersByUserId(@RequestParam String clientId,
                                                         @RequestParam int pageNumber,
                                                         @RequestParam @Min(1) @Max(50) int pageSize,
                                                         @RequestParam(required = false) String orderSource,
                                                         @RequestParam(required = false) String storeId,
                                                         @PathVariable String userId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();

        // Only employee or the ordered user should have access to view the orders
        if (!(principal.getUserType() == Constants.EMPLOYEE)
                && !(principal.getUserType() == Constants.USER && principal.getId().equals(userId))) {
            return ResponseEntity.notFound().build();
        }

        /*if (pageSize < 1 || pageSize > 50) {
            return ResponseEntity.badRequest().body(new ApiResponse<Void>(400,
                    new APIError("INVALID_PAGE_SIZE",
                            "Page size should be between 1 and 50")));
        }*/

        // TODO Move this to OrderService and handle and null case
        OrderSource orderSourceObj = orderService.findOrderSourceByName(orderSource);

        List<Order> orders = orderService.getOrdersByUserId(userId, pageNumber, pageSize,
                orderSourceObj);

        List<OrderResponse> orderResponses;
        if (orders == null) {
            orderResponses = new ArrayList<>();
            return ResponseEntity.ok(
                    new ApiResponse(200, orderResponses));
        }

        orderResponses = new ArrayList<>(orders.size());

        for (Order order : orders) {
            // Frame Order response and return
            OrderResponse orderResponse = orderService.generateOrderResponse(order);

            orderResponses.add(orderResponse);
        }

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponses));
    }

    @GetMapping("/getByStoreId/{storeId}")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> getOrdersByStoreId(@RequestParam String clientId,
                                                          @RequestParam int pageNumber,
                                                          @RequestParam @Min(1) @Max(50) int pageSize,
                                                          @RequestParam(required = false) String orderSource,
                                                          @PathVariable String storeId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();

        // Only employee should have access to view the orders by storeId
        if (!(principal.getUserType() == Constants.EMPLOYEE)) {
            return ResponseEntity.notFound().build();
        }

        /*if (pageSize < 1 || pageSize > 50) {
            return ResponseEntity.badRequest().body(new ApiResponse<Void>(400,
                    new APIError("INVALID_PAGE_SIZE",
                            "Page size should be between 1 and 50")));
        }*/

        // TODO Move this to OrderService and handle and null case
        OrderSource orderSourceObj = orderService.findOrderSourceByName(orderSource);

        List<Order> orders = orderService.getOrdersByStoreId(storeId, pageNumber, pageSize,
                orderSourceObj);

        List<OrderResponse> orderResponses;
        if (orders == null) {
            orderResponses = new ArrayList<>();
            return ResponseEntity.ok(
                    new ApiResponse(200, orderResponses));
        }

        orderResponses = new ArrayList<>(orders.size());

        for (Order order : orders) {
            // Frame Order response and return
            OrderResponse orderResponse = orderService.generateOrderResponse(order);

            orderResponses.add(orderResponse);
        }

        return ResponseEntity.ok(
                new ApiResponse(200, orderResponses));
    }

}
