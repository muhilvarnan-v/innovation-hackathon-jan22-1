package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.request.CODPaymentRequest;
import com.flytekart.web.model.request.CODPaymentRequest2;
import com.flytekart.web.model.request.CreateRazorpayOrderRequest;
import com.flytekart.web.model.request.VerifyRazorpayPaymentRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.model.response.CreateRazorpayOrderResponse;
import com.flytekart.web.model.response.OrderResponse;
import com.flytekart.web.repository.client.PaymentLogRepository;
import com.flytekart.web.repository.client.PaymentRepository;
import com.flytekart.web.repository.client.PaymentStatusRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.NotificationService;
import com.flytekart.web.service.OrderService;
import com.flytekart.web.service.PaymentService;
import com.flytekart.web.util.Constants;
import com.flytekart.web.util.Utilities;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * Make updates to get only non-deleted Variants with active and inactive filter - Done
 * Create an API to make a Variant inactive - Done
 * Create a new API to delete a Variant - Done
 * TODO Update a variant - like sku, description, active status
 */
@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private PaymentStatusRepository paymentStatusRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private PaymentLogRepository paymentLogRepository;

    @Autowired
    private OrderService orderService;

    @Autowired
    private NotificationService notificationService;

    @PostMapping("/collectCODPayment2")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> placeCODOrder(@Valid @RequestBody CODPaymentRequest2 request,
                                                     @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Optional<Payment> paymentOptional = paymentRepository.findById(request.getPaymentId());
        if (paymentOptional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Payment payment = paymentOptional.get();

        Order order = orderService.getOrderByOrderId(payment.getOrderId());
        OrderStatus deliveredStatus = orderService.findOrderStatusByName(Constants.OrderStatus.DELIVERED);

        if (order == null || !order.getOrderStatus().getId().equals(deliveredStatus.getId())) {
            return ResponseEntity.notFound().build();
        }

        // Mark payment as paid
        PaymentStatus paidStatus = paymentStatusRepository.findByName(Constants.PaymentStatus.PAID);
        payment.setPaymentStatus(paidStatus);
        paymentRepository.save(payment);

        // TODO Put paymentLog

        OrderResponse orderResponse = orderService.generateOrderResponse(order);
        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    @PostMapping("/collectCODPayment")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> collectCODPayment(@Valid @RequestBody CODPaymentRequest request,
                                                     @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null) {
            return ResponseEntity.notFound().build();
        }

        PaymentType paymentType = paymentService.findPaymentTypeByName(Constants.PaymentType.COD);
        PaymentStatus paymentStatus = paymentService.findPaymentStatusByName(Constants.PaymentStatus.PAID);

        // Create paid payment record
        Payment payment = new Payment();
        payment.setOrderId(order.getId());
        payment.setAmount(request.getAmount());
        payment.setPaymentType(paymentType);
        payment.setPaymentStatus(paymentStatus);
        paymentService.save(payment);

        // Create related paymentLog record
        paymentService.addPaymentLog(payment, "Generated paid COD payment of " + request.getAmount());

        OrderResponse orderResponse = orderService.generateOrderResponse(order);
        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }

    @PostMapping("/createRazorpayOrder")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> createRazorpayOrder(@Valid @RequestBody CreateRazorpayOrderRequest request,
                                                     @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() == Constants.EMPLOYEE) { // EndUser is paying the payment
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null) {
            return ResponseEntity.notFound().build();
        }

        PaymentType paymentType = paymentService.findPaymentTypeByName(Constants.PaymentType.RAZORPAY);
        PaymentStatus paymentStatus = paymentService.findPaymentStatusByName(Constants.PaymentStatus.UNPAID);

        // Create paid payment record
        Payment payment = new Payment();
        payment.setOrderId(order.getId());
        payment.setAmount(request.getAmount());
        payment.setPaymentType(paymentType);
        payment.setPaymentStatus(paymentStatus);
        paymentService.save(payment);

        // Create related paymentLog record
        paymentService.addPaymentLog(payment, "Generated unpaid Razorpay payment of " + request.getAmount());
        String razorpayOrderId = null;

        try {
            RazorpayClient razorpayClient = new RazorpayClient("rzp_test_fZpy6ZIbWm8oCi", "BLOQ9K4XAunx2sBqQPCH1wuZ");
            JSONObject options = new JSONObject();
            options.put("amount", request.getAmount() * 100); // Note: The amount should be in paise.
            options.put("currency", "INR");
            options.put("receipt", payment.getId());
            com.razorpay.Order razorpayOrder = razorpayClient.Orders.create(options);
            System.out.println(razorpayOrder.toString());
            razorpayOrderId = razorpayOrder.get("id");
            //return ResponseEntity.ok(new ApiResponse<>(200, razorpayOrder.get("id")));
        } catch (RazorpayException e) {
            e.printStackTrace();
        }

        //OrderResponse orderResponse = orderService.generateOrderResponse(order);
        CreateRazorpayOrderResponse response = new CreateRazorpayOrderResponse();
        response.setOrderId(order.getId());
        response.setPaymentId(payment.getId());
        response.setRazorpayOrderId(razorpayOrderId);
        response.setAmount(request.getAmount());
        response.setPaymentMode(paymentType.getName());
        return ResponseEntity.ok(
                new ApiResponse(200, response));
    }

    /**
     * Capture payment in Razorpay.
     * Uncaptured payments will be automatically refunded by Razorpay.
     * @param request VerifyRazorpayPaymentRequest contains order and payment ids
     * @param clientId
     * @return OrderResponse
     */
    @PostMapping("/validateRazorpayPayment")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> validateRazorpayPayment(@Valid @RequestBody VerifyRazorpayPaymentRequest request,
                                                     @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() == Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        Order order = orderService.getOrderByOrderId(request.getOrderId());
        if (order == null) {
            return ResponseEntity.notFound().build();
        }

        Payment payment = paymentService.getUndeletedPaymentById(request.getPaymentId());
        if (payment == null) {
            return ResponseEntity.notFound().build();
        }

        try {
            RazorpayClient razorpayClient = new RazorpayClient("rzp_test_fZpy6ZIbWm8oCi", "BLOQ9K4XAunx2sBqQPCH1wuZ");
            JSONObject captureRequest = new JSONObject();
            captureRequest.put("amount", request.getAmount() * 100);
            captureRequest.put("currency", "INR");
            com.razorpay.Payment capture = razorpayClient.Payments.capture(request.getRazorpayPaymentId(), captureRequest);
            //Utils.verifyPaymentSignature()
        } catch (RazorpayException e) {
            e.printStackTrace();
            // TODO Identify the types of issues that come here
            return ResponseEntity.badRequest().build();
        }

        PaymentStatus paymentStatus = paymentService.findPaymentStatusByName(Constants.PaymentStatus.PAID);

        // Mark payment as paid
        payment.setPaymentStatus(paymentStatus);
        paymentService.save(payment);

        // Create related paymentLog record
        paymentService.addPaymentLog(payment, "Paid Razorpay payment of " + request.getAmount());

        // If all payments are completed, mark the order as placed
        List<Payment> payments = paymentService.getPaymentsByOrderId(order.getId());
        double paidTotal = 0;
        for (Payment eachPayment : payments) {
            if (eachPayment.getPaymentStatus().getName().equals(Constants.PaymentStatus.PAID)) {
                paidTotal = paidTotal + eachPayment.getAmount();
            }
        }

        OrderResponse orderResponse = orderService.generateOrderResponse(order);
        if (paidTotal >= orderResponse.getOrderTotal().getTotal()) {
            OrderStatus orderStatus = orderService.findOrderStatusByName(Constants.OrderItemStatus.PLACED);
            OrderItemStatus orderItemStatus = orderService.findOrderItemStatusByName(Constants.OrderItemStatus.PLACED);
            order.setOrderStatus(orderStatus);
            if (orderStatus.getName().equals(Constants.OrderStatus.PLACED)) {
                order.setOrderPlacedAt(new Date());
            }
            orderService.save(order);

            // Add OrderLog record
            orderService.addOrderLog(order, "Order placed");

            for (OrderItem orderItem : orderResponse.getOrderItems()) {
                if (orderItem.getDeletedAt() == null) {
                    orderItem.setOrderItemStatusId(orderItemStatus.getId());
                    orderService.saveOrderItem(orderItem);

                    // Add a record to OrderItemLog
                    orderService.addOrderItemLog(orderItem, "Order item placed");
                }
            }
        }
        if (order.getOrderStatus().getName().equals(Constants.OrderStatus.PLACED)) {
            // Send notifications to store asynchronously
            String total = Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal());
            String storeName = order.getStore().getName();
            String notificationBody = String.format(Constants.NOTIFICATION_NEW_ORDER, storeName, total);
            notificationService.sendPushNotificationByClientId(Constants.NEW_ORDER, notificationBody, clientId);
        }
        return ResponseEntity.ok(
                new ApiResponse(200, orderResponse));
    }
}
