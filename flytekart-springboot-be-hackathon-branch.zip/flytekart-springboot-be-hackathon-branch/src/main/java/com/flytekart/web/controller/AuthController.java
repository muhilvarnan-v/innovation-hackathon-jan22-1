package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.main.User;
import com.flytekart.web.model.request.*;
import com.flytekart.web.model.response.*;
import com.flytekart.web.repository.client.EmployeeRepository;
import com.flytekart.web.repository.main.UserRepository;
import com.flytekart.web.repository.client.EndUserRepository;
import com.flytekart.web.security.JwtTokenProvider;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.FirebaseMessagingService;
import com.flytekart.web.util.Constants;
import com.flytekart.web.util.SendSms;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;


import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.net.URI;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Value("${app.twilio.account_sid}")
    private String twilioAccountSid;

    @Value("${app.twilio.auth_token}")
    private String twilioAuthToken;

    @Value("${app.twilio.phone_number}")
    private String twilioPhoneNumber;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    UserRepository userRepository;

    @Autowired
    EndUserRepository endUserRepository;

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    SendSms sendsms;

    @Autowired
    FirebaseMessagingService firebaseService;

    /*@Autowired
    RoleRepository roleRepository;

    @Autowired
    EndUserRoleRepository endUserRoleRepository;*/

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    /**
     * Authenticates user to main DB or client DB
     * @param loginRequest
     * @param clientId
     * @return
     */
    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest,
                                              @RequestParam(required = false) String clientId) {
        if (clientId == null) {
            clientId = Constants.MAIN;
            DBContextHolder.setCurrentDb(clientId);
        } else {
            DBContextHolder.setCurrentDb(clientId);
        }

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getUsernameOrEmail(),
                        loginRequest.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = jwtTokenProvider.generateToken(authentication, clientId);
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(new ApiResponse(200, new JwtAuthenticationResponse(jwt, userPrincipal)));
    }

    @PostMapping("/employeesignin")
    public ResponseEntity<?> authenticateEmployee(@Valid @RequestBody LoginRequest loginRequest,
                                              @RequestParam(required = true) @Size(min = 4, max = 12) String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        String employeeUsername = loginRequest.getUsernameOrEmail() + Constants.USERNAME_SEPARATOR;
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(employeeUsername,
                        loginRequest.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = jwtTokenProvider.generateToken(authentication, clientId);
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(new ApiResponse(200, new JwtAuthenticationResponse(jwt, userPrincipal)));
    }

    /**
     * Registers both client users and main user
     * @param signUpRequest
     * @param clientId
     * @return
     * @throws Exception
     */
    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest,
                                          @RequestParam(required = false) String clientId) throws Exception {
            URI location;
            if (clientId == null || clientId.equals(Constants.MAIN)) {
                DBContextHolder.setCurrentDb(Constants.MAIN);
                if (userRepository.existsByUsername(signUpRequest.getUsername())) {
                    return new ResponseEntity(new ApiResponseOld(false,
                            "Username is already taken!"), HttpStatus.BAD_REQUEST);
                }
    
                if (userRepository.existsByEmail(signUpRequest.getEmail())) {
                    return new ResponseEntity(new ApiResponseOld(false,
                            "Email address is already in use!"), HttpStatus.BAD_REQUEST);
                }
    
                User user = new User(signUpRequest.getName(), signUpRequest.getUsername(),
                        signUpRequest.getEmail(), signUpRequest.getPhoneNumber(), signUpRequest.getPassword());
                user.setPassword(passwordEncoder.encode(user.getPassword()));
                /*Role userRole = roleRepository.findByName(RoleName.ROLE_USER).orElseThrow(() -> new Exception("User Role not set."));
                user.setRoles(Collections.singleton(userRole));*/
                /*Utilities.verifyPhoneNumber("CLIENT_NAME", signUpRequest.getPhoneNumber(),
                        twilioAccountSid, twilioAuthToken, twilioPhoneNumber);*/
                User result = userRepository.save(user);
                location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}")
                        .buildAndExpand(result.getUsername()).toUri();
            } else {
                DBContextHolder.setCurrentDb(clientId);
                if (endUserRepository.existsByUsername(signUpRequest.getUsername())) {
                    return new ResponseEntity(new ApiResponseOld(false,
                            "Username is already taken!"), HttpStatus.BAD_REQUEST);
                }
    
                if (endUserRepository.existsByEmail(signUpRequest.getEmail())) {
                    return new ResponseEntity(new ApiResponseOld(false,
                            "Email address is already in use!"), HttpStatus.BAD_REQUEST);
                }
    
                EndUser user = new EndUser(signUpRequest.getName(), signUpRequest.getUsername(), signUpRequest.getPhoneNumber(),
                        signUpRequest.getEmail(), signUpRequest.getPassword());
                user.setPassword(passwordEncoder.encode(user.getPassword()));
                /*EndUserRole userRole = endUserRoleRepository.findByName(EndUserRoleName.ROLE_USER).orElseThrow(() -> new Exception("User Role not set."));
                user.setRoles(Collections.singleton(userRole));*/
    
                EndUser result = endUserRepository.save(user);
                location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}")
                        .buildAndExpand(result.getUsername()).toUri();
            }
    
            return ResponseEntity.created(location).body(new ApiResponseOld(true, "User registered successfully."));
    }

    @PostMapping("/otplogin")
    @Transactional
    public ResponseEntity<?> userOtpLogin(@Valid @RequestBody SendOTPRequest request,
                                          @RequestParam(required = false) String clientId) throws Exception {
        
        DBContextHolder.setCurrentDb(clientId);

        String phoneNumber = Constants.CountryCode.INDIA + Constants.HYPHEN + request.getPhoneNumber();
        Optional<EndUser> existingUser = endUserRepository.findByPhoneNumber(phoneNumber);
        if (!existingUser.isPresent()) {
            UUID usernameUUID = UUID.randomUUID();
            UUID passwordUUID = UUID.randomUUID();
            EndUser user = new EndUser(null, usernameUUID.toString(), phoneNumber,
                    null, passwordEncoder.encode(passwordUUID.toString()));
            EndUser result = endUserRepository.save(user);
            sendsms.sendOtp(clientId, result.getPhoneNumber(), result.getId(), Constants.UserType.USER,  Constants.PURPOSE_LOGIN);
        } else {
            sendsms.sendOtp(clientId, existingUser.get().getPhoneNumber(), existingUser.get().getId(), Constants.UserType.USER,  Constants.PURPOSE_LOGIN);
        }
        return ResponseEntity.ok(new ApiResponse(200, "OTP Sent successfully."));
    }

    @PostMapping("/employeeotplogin")
    public ResponseEntity<?> employeeOtpLogin(@Valid @RequestBody SendOTPRequest request,
                                          @RequestParam(required = false) String clientId) throws Exception {
        
        DBContextHolder.setCurrentDb( clientId);

        String phoneNumber = Constants.CountryCode.INDIA + Constants.HYPHEN + request.getPhoneNumber();
        Optional<Employee> existingEMP = employeeRepository.findByPhoneNumber(phoneNumber);
        if (existingEMP.isPresent()) {
            sendsms.sendOtp(clientId, phoneNumber, existingEMP.get().getId(), Constants.UserType.EMPLOYEE,  "login");
            return ResponseEntity.ok(new ApiResponse(200, "OTP sent successfully."));
        } else {
            /*return ResponseEntity.badRequest().body(new ApiResponse(404,
                    new APIError("USER_NOT_AVAILABLE", "User not available")));*/

            return ResponseEntity.badRequest().body(new APIError(404,"User not available"));
        }
    }

    @PostMapping("/otpverify")
    public ResponseEntity<?> otpVerify(@Valid @RequestBody OtpRequest otpRequest,
                                              @RequestParam(required = true) @Size(min = 4, max = 12) String clientId) {
        DBContextHolder.setCurrentDb(clientId);

        String employeeUsername = Constants.CountryCode.INDIA + Constants.HYPHEN
                + otpRequest.getPhoneNumber();
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(employeeUsername,
                otpRequest.getOtp())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = jwtTokenProvider.generateToken(authentication, clientId);
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(new ApiResponse(200, new JwtAuthenticationResponse(jwt, userPrincipal)));
    }

    @PostMapping("/employeeotpverify")
    public ResponseEntity<?> employeeOtpVerify(@Valid @RequestBody OtpRequest otpRequest,
                                              @RequestParam(required = true) @Size(min = 4, max = 12) String clientId) {
        DBContextHolder.setCurrentDb(clientId);

        String employeeUsername = Constants.CountryCode.INDIA + Constants.HYPHEN
                + otpRequest.getPhoneNumber() + Constants.USERNAME_SEPARATOR;
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(employeeUsername,
                otpRequest.getOtp())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = jwtTokenProvider.generateToken(authentication, clientId);
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(new ApiResponse(200, new JwtAuthenticationResponse(jwt, userPrincipal)));
    }

    @PostMapping("/changePassword")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> changePassword(@Valid @RequestBody ChangePasswordRequest request,
                                            @RequestParam(required = false) String clientId) {
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();

        if (passwordEncoder.matches(request.getOldPassword(), principal.getPassword())) {
            if (clientId == null || clientId.equals(Constants.MAIN)) {
                DBContextHolder.setCurrentDb(Constants.MAIN);
                Optional<User> optionalUser = userRepository.findById(principal.getId());
                User user = optionalUser.get();
                user.setPassword(passwordEncoder.encode(request.getNewPassword()));
                userRepository.save(user);
            } else {
                DBContextHolder.setCurrentDb(clientId);
                if (principal.getUserType().equals(Constants.EMPLOYEE)) {
                    Optional<Employee> optionalEmployee = employeeRepository.findById(principal.getId());
                    Employee employee = optionalEmployee.get();
                    employee.setPassword(passwordEncoder.encode(request.getNewPassword()));
                    employeeRepository.save(employee);
                } else {
                    Optional<User> optionalUser = userRepository.findById(principal.getId());
                    User user = optionalUser.get();
                    user.setPassword(passwordEncoder.encode(request.getNewPassword()));
                    userRepository.save(user);
                }
            }
            return ResponseEntity.ok(new ApiResponse<>(200, "Password updated successfully."));
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/createTestOrder")
    public ResponseEntity<?> createTestOrder(@RequestParam() String token) throws FirebaseMessagingException {
        // Razorpay test keys: rzp_test_fZpy6ZIbWm8oCi / BLOQ9K4XAunx2sBqQPCH1wuZ
        try {
            RazorpayClient razorpayClient = new RazorpayClient("rzp_test_fZpy6ZIbWm8oCi", "BLOQ9K4XAunx2sBqQPCH1wuZ");
            JSONObject options = new JSONObject();
            options.put("amount", 5000); // Note: The amount should be in paise.
            options.put("currency", "INR");
            options.put("receipt", "txn_123456");
            Order order = razorpayClient.Orders.create(options);
            System.out.println(order.toString());
            return ResponseEntity.ok(new ApiResponse<>(200, order.get("id")));
        } catch (RazorpayException e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok(new ApiResponse<>(200, token));
    }

    // @PostMapping("/otp/verify")
    // public ResponseEntity<?> verifyOTP(@Valid @RequestBody OTPVerify otpVerification) {
        
    // }

}
