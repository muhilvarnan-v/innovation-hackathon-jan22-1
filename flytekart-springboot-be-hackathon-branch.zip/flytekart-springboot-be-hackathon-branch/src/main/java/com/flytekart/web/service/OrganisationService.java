package com.flytekart.web.service;

import com.flytekart.web.model.client.Organisation;
import com.flytekart.web.repository.client.OrganisationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrganisationService {

    @Autowired
    OrganisationRepository repository;

    public Organisation getOrganisation() {
        return repository.findFirstByOrderByIdAsc().get();
    }
}
