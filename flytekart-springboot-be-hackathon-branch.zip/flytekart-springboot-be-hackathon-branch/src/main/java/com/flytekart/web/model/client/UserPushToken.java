package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAuditWithDeletion;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name = "UserPushToken", schema = "public")
// User will be Employee for audit columns
public class UserPushToken extends UserDateAuditWithDeletion {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String userId;

    @Column(length = 200)
    private String token;

    @Column(length = 40)
    private String clientType; // android/ios/web

    public UserPushToken() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }
}
