package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.main.OrganisationMap;
import com.flytekart.web.model.main.User;
import com.flytekart.web.model.request.CreateOrganisationRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.model.response.ApiResponseOld;
import com.flytekart.web.repository.client.EmployeeRepository;
import com.flytekart.web.repository.client.OrganisationMapRepository;
import com.flytekart.web.repository.client.OrganisationRepository;
import com.flytekart.web.repository.main.UserRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.OrganisationService;
import com.flytekart.web.util.Constants;
import com.flytekart.web.util.Utilities;
import org.apache.ibatis.jdbc.ScriptRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// TODO Need to move some code to OrganisationService and EmployeeService
@RestController
@RequestMapping("/api/organisation")
public class OrganisationController {

    @Value("${app.datasource.main.jdbc-url}")
    private String jdbcUrl;

    @Value("${app.datasource.main.jdbc-db}")
    private String jdbcDB;

    @Value("${app.datasource.main.username}")
    private String username;

    @Value("${app.datasource.main.password}")
    private String password;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private OrganisationRepository organisationRepository;

    @Autowired
    private OrganisationMapRepository organisationMapRepository;

    @Autowired
    private AddressController addressController;

    @Autowired
    private OrganisationTypeController organisationTypeController;

    @Autowired
    private BusinessTypeController businessTypeController;

    @Autowired
    private OrganisationService organisationService;

    /*@GetMapping("/users/{username}")
    @PreAuthorize("hasRole('USER')")
    //@PreAuthorize("hasRole('USER') && #username == authentication.name")
    public UserProfile getCurrentUser(@PathVariable("username") String username) {
        User user = userRepository.findByUsername(username).orElseThrow(() -> new ResourceNotFoundException("User", "username", username));
        return new UserProfile(user.getId(), user.getUsername(), user.getName());
    }*/

    @PostMapping("/")
    //@PreAuthorize("hasRole('USER') && #username == authentication.name")
    /**
     * 1. Validate input. Also only verified users should be able to create Orgs
     * 2. Create Org DB. Run all CREATE sql statements to get the DB ready.
     * 3. Create Employee record in Org DB
     * 4. Create Org record in Org DB with Employee as the createdBy
     * 5. Shift to Main DB
     * 6. Create OrgMap record
     * 7. Return success msg
     *
     * TODO Add Role for Employee
     */
    public ResponseEntity<ApiResponseOld> createOrganisation(@Valid @RequestBody CreateOrganisationRequest request) {
        // Generate client DB name dynamically
        String clientCode = generateClientCode(request.getName());
        String dbName = "flytekart_" + clientCode; // TODO This should use String format functions

        // SQL command to create a database in MySQL.
        // TODO Need to do something about ENCODING, COLLATE and CTYPE
        String sqlTemplate = "CREATE DATABASE %s\n" +
                "    WITH \n" +
                "    OWNER = postgres\n" +
                /*"    ENCODING = 'LATIN9'\n" +
                "    LC_COLLATE = 'en_US.ISO8859-15'\n" +
                "    LC_CTYPE = 'en_US.ISO8859-15'\n" +*/
                "    TABLESPACE = pg_default\n" +
                "    CONNECTION LIMIT = -1;";
        String sql = String.format(sqlTemplate, dbName); //"CREATE DATABASE " + dbName;

        boolean isDBCreationSuccess;
        try (Connection conn = DriverManager.getConnection(jdbcUrl, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.execute();
            isDBCreationSuccess = true;
        } catch (Exception e) {
            isDBCreationSuccess = false;
            e.printStackTrace();
        }

        if (isDBCreationSuccess) {
            String newDBUrl = jdbcUrl + dbName; // TODO This should use String format functions
            Connection con;
            boolean isSetUpSuccess;
            try {
                con = DriverManager.getConnection(newDBUrl, username, password);
                //Initialize the script runner
                ScriptRunner sr = new ScriptRunner(con);
                //Creating a reader object
                Reader reader = new BufferedReader(new FileReader("src/main/resources/db/v1_schema_client.sql"));
                //Running the script
                sr.runScript(reader);
                isSetUpSuccess = true;
            } catch (SQLException | FileNotFoundException e) {
                isSetUpSuccess = false;
                e.printStackTrace();
            }
            if (isSetUpSuccess) {
                Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
                Employee employee = saveNewEmployee(clientCode, userPrincipal);
                Organisation organisation = saveNewOrganisation(clientCode, request, employee);

                createOrganisationMap(clientCode, userPrincipal, organisation);

                return ResponseEntity.ok(new ApiResponseOld(true,
                        "Organisation created successfully."));
            } else {
                return ResponseEntity.ok(new ApiResponseOld(true,
                        "Organisation DB created successfully. But setting the DB up failed."));
            }
        } else {
            return ResponseEntity.badRequest().body(new ApiResponseOld(false,
                    "Organisation creation failed."));
        }
    }

    /**
     * Create new Employee based on the logged in User of main DB
     * @param clientCode
     * @param userPrincipal
     */
    private Employee saveNewEmployee(String clientCode, UserPrincipal userPrincipal) {
        DBContextHolder.setCurrentDb(Constants.MAIN);
        Optional<User> userOptional = userRepository.findByUsername(userPrincipal.getUsername());
        User user = userOptional.get();

        DBContextHolder.setCurrentDb(clientCode);
        Employee newEmployee = new Employee();
        newEmployee.setName(user.getName());
        newEmployee.setUsername(user.getUsername());
        newEmployee.setEmail(user.getEmail());
        newEmployee.setPhoneNumber(user.getPhoneNumber());
        newEmployee.setEmailVerified(user.isEmailVerified());
        newEmployee.setPhoneVerified(user.isPhoneVerified());
        newEmployee.setPassword(user.getPassword());

        return employeeRepository.save(newEmployee);
    }

    private Organisation saveNewOrganisation(String clientCode, CreateOrganisationRequest request, Employee employee) {
        DBContextHolder.setCurrentDb(clientCode);

        OrganisationType organisationType
                = organisationTypeController.getOrganisationTypeByName(request.getOrganisationTypeName());
        BusinessType businessType
                = businessTypeController.getBusinessTypeByName(request.getBusinessTypeName());

        Address address = null;
        if (request.getAddress() != null) {
            address = addressController.save(request.getAddress());
        }

        Organisation organisation = new Organisation();
        organisation.setName(request.getName());
        organisation.setOrganisationType(organisationType);
        organisation.setBusinessType(businessType);
        organisation.setAddress(address);
        organisation.setTaxNumber(request.getTaxNumber());
        organisation.setCreatedBy(employee.getId());
        organisation.setLastUpdatedBy(employee.getId());

        return organisationRepository.save(organisation);
    }

    private OrganisationMap createOrganisationMap(String clientCode, UserPrincipal userPrincipal,
                                                  Organisation organisation) {
        DBContextHolder.setCurrentDb(Constants.MAIN);

        OrganisationMap map = new OrganisationMap();
        map.setClientCode(clientCode);
        map.setUserId(userPrincipal.getId());
        map.setOrganisationId(organisation.getId());

        organisationMapRepository.save(map);
        return map;
    }

    /**
     * Generate clientCode from OrgName.
     * If it's already being used, generate from OrgName and businessType.
     * If it's already being used, generate from OrgName and random string.
     * Max length of the name should be 12 characters.
     * This is a recurring function to generate unique clientCode
     * @param organisationName
     * @return
     */
    private String generateClientCode(String organisationName) {
        String clientCode = organisationName.replaceAll("[^a-zA-Z0-9]+", "")
                .substring(0, Math.min(organisationName.length(), 12)).toLowerCase();

        if (checkIfClientCodeIsUnique(clientCode)) {
            return clientCode;
        } else {
            return generateClientCode(clientCode.substring(0, Math.min(organisationName.length(), 9))
                    + Utilities.getNewRandomString(3));
        }
    }

    private boolean checkIfClientCodeIsUnique(String clientCode) {
        DBContextHolder.setCurrentDb(Constants.MAIN);
        Optional<OrganisationMap> optional = organisationMapRepository.findByClientCode(clientCode);
        if (optional.isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * This is called by Main user
     * @return
     */
    @GetMapping("/organisationMap")
    private ResponseEntity<?> getOrganisationsOfMainUser() {
        DBContextHolder.setCurrentDb(Constants.MAIN);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();

        Optional<List<OrganisationMap>> optional = organisationMapRepository.findByUserId(userPrincipal.getId());

        List<Organisation> organisations = new ArrayList<>();
        if (optional.isPresent()) {
            List<OrganisationMap> organisationMaps = optional.get();

            for (OrganisationMap organisationMap : organisationMaps) {
                DBContextHolder.setCurrentDb(organisationMap.getClientCode());
                Organisation organisation = organisationService.getOrganisation();
                organisations.add(organisation);
            }
        }
        return ResponseEntity.ok(new ApiResponse(200, organisations));
    }

    /**
     * This can be called by both employees and end users
     * @param clientId
     * @return
     */
    @Transactional
    @GetMapping("/")
    private ResponseEntity<?> getOrganisationByClientId(@RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        Organisation organisation = organisationService.getOrganisation();
        return ResponseEntity.ok(new ApiResponse(200, organisation));
    }

    @Transactional
    @PostMapping("/edit/")
    @PreAuthorize("isAuthenticated()")
    private ResponseEntity<?> editOrganisation(@Valid @RequestBody Organisation organisation,
            @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        Organisation managedOrganisation = organisationService.getOrganisation();

        Address managedAddress = managedOrganisation.getAddress();
        if (managedAddress != null) {
            if (organisation.getAddress() != null) {
                Address address = organisation.getAddress();;
                managedAddress.setLine1(address.getLine1());
                managedAddress.setLine2(address.getLine2());
                managedAddress.setCity(address.getCity());
                managedAddress.setState(address.getState());
                managedAddress.setCountry(address.getCountry());
                managedAddress.setZip(address.getZip());
                managedAddress.setLatitude(address.getLatitude());
                managedAddress.setLongitude(address.getLongitude());
                addressController.save(managedAddress);
            } else {
                managedOrganisation.setAddress(null);
            }
        } else {
            if (organisation.getAddress() != null) {
                Address savedAddress = addressController.save(organisation.getAddress());
                managedOrganisation.setAddress(savedAddress);
            }
        }

        managedOrganisation.setName(organisation.getName());
        OrganisationType organisationType = organisationTypeController.getOrganisationTypeById(organisation.getOrganisationType().getId());
        managedOrganisation.setOrganisationType(organisationType);
        // We won't allow users to change business type.
        // They need to create new Organisation for new business type,
        // as client DB will be created based on business type.
        managedOrganisation.setTaxNumber(organisation.getTaxNumber());

        // Update address first
        organisationRepository.save(managedOrganisation);
        return ResponseEntity.ok(new ApiResponse(200, managedOrganisation));
    }
}
