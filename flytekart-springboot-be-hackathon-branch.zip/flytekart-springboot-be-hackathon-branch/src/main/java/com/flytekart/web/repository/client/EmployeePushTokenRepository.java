package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.EmployeePushToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeePushTokenRepository extends JpaRepository<EmployeePushToken, String> {
    @Query("from EmployeePushToken where userId=:userId and token=:token " +
            "and clientType=:clientType and deletedBy IS NULL")
    List<EmployeePushToken> findUnDeletedByUserIdAndTokenAndClientType(
            @Param("userId") String userId,
            @Param("token") String token,
            @Param("clientType") String clientType);

    @Query("from EmployeePushToken where token=:token " +
            "and clientType=:clientType and deletedBy IS NULL")
    List<EmployeePushToken> findUnDeletedByTokenAndClientType(
            @Param("token") String token,
            @Param("clientType") String clientType);

    @Query("from EmployeePushToken where userId=:userId and deletedBy IS NULL")
    List<EmployeePushToken> findUnDeletedByUserId(@Param("userId") String userId);

    @Query("from EmployeePushToken where deletedBy IS NULL")
    List<EmployeePushToken> findAllUnDeleted();

    @Query("from EmployeePushToken where id=:id and deletedBy IS NULL")
    EmployeePushToken findUnDeletedById(@Param("id") String id);
}
