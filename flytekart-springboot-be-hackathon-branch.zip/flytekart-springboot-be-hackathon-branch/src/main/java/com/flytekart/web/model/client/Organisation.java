package com.flytekart.web.model.client;

import com.flytekart.web.model.common.DateAudit;
import com.flytekart.web.model.common.UserDateAudit;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "Organisation", schema = "public")
public class Organisation extends DateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 200)
    @NotBlank(message = "Name cannot be empty")
    private String name;

    // Single store, multi store
    @ManyToOne()
    @JoinColumn(name = "organisationTypeId", referencedColumnName = "id")
    private OrganisationType organisationType;

    @ManyToOne()
    @JoinColumn(name = "businessTypeId", referencedColumnName = "id")
    private BusinessType businessType;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "addressId", referencedColumnName = "id")
    private Address address;

    @Column(length = 40)
    private String taxNumber;

    @Column
    private String createdBy;

    @Column
    private String lastUpdatedBy;

    @Column 
    private Boolean isDynamicPricing;

    @Column
    private Double multiplier;


    public Organisation() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public OrganisationType getOrganisationType() {
        return organisationType;
    }

    public void setOrganisationType(OrganisationType organisationType) {
        this.organisationType = organisationType;
    }

    public BusinessType getBusinessType() {
        return businessType;
    }

    public void setBusinessType(BusinessType businessType) {
        this.businessType = businessType;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public void setIsDynamicPricing(Boolean isDynamicPricing) {
        this.isDynamicPricing = isDynamicPricing;
    }

    public Boolean getIsDynamicPricing() {
        return isDynamicPricing;
    }

    public void setMultiplier(Double multiplier) {
        this.multiplier = multiplier;
    }

    public Double getMultiplier() {
        return multiplier;
    }
}
