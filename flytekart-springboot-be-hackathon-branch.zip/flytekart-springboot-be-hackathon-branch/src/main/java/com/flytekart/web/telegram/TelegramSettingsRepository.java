package com.flytekart.web.telegram;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TelegramSettingsRepository extends JpaRepository<TelegramSettings, String> {

    @Query("from TelegramSettings where deletedBy IS NULL")
    List<TelegramSettings> findUnDeleted();
}
