package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.exception.ResourceNotFoundException;
import com.flytekart.web.model.main.User;
import com.flytekart.web.model.main.UserProfile;
import com.flytekart.web.repository.main.UserRepository;
import com.flytekart.web.util.Constants;
import com.flytekart.web.util.Utilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/users/{username}")
    @PreAuthorize("hasRole('USER')")
    //@PreAuthorize("hasRole('USER') && #username == authentication.name")
    public UserProfile getCurrentUser(@PathVariable("username") String username) {
        DBContextHolder.setCurrentDb(Constants.MAIN);
        User user = userRepository.findByUsername(username).orElseThrow(() -> new ResourceNotFoundException("User", "username", username));
        return new UserProfile(user.getId(), user.getUsername(), user.getName());
    }

    @GetMapping("/test")
    //@PreAuthorize("hasRole('USER') && #username == authentication.name")
    public boolean test() {
        return userRepository.existsByUsername("test");
    }
}


