package com.flytekart.web.model.response;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CreateRazorpayOrderResponse {

    @NotBlank
    @Size(min = 1, max = 40)
    private String orderId;

    @NotBlank
    @Size(min = 1, max = 40)
    private String paymentId;

    @NotBlank
    @Size(min = 1, max = 40)
    private String razorpayOrderId;

    @NotNull
    private double amount;

    @NotBlank
    @Size(min = 1, max = 40)
    private String paymentMode;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public String getRazorpayOrderId() {
        return razorpayOrderId;
    }

    public void setRazorpayOrderId(String razorpayOrderId) {
        this.razorpayOrderId = razorpayOrderId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }
}
