package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.Category;
import com.flytekart.web.model.client.Product;
import com.flytekart.web.model.request.CreateProductRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.CategoryRepository;
import com.flytekart.web.repository.client.ProductRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.ProductService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * TODO Make updates to get only non-deleted products with active and inactive filter
 * TODO Create a new API to make a product inactive
 * TODO Create a new API to delete a product
 */
@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductRepository repository;

    @Autowired
    private ProductService service;

    @Autowired
    private CategoryRepository categoryRepository;

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody CreateProductRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }
        Product product;
        Optional<Category> optionalCategory = categoryRepository.findById(request.getCategoryId());
        if (optionalCategory.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        if (request.getId() == null) {
            product = CreateProductRequest.getProduct(request, optionalCategory.get());
        } else {
            Optional<Product> optionalProduct = repository.findById(request.getId());
            if (optionalProduct.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            product = CreateProductRequest.getProduct(request, optionalProduct.get(), optionalCategory.get());
        }
        repository.save(product);
        return ResponseEntity.ok(new ApiResponse<>(200, product));
    }

    /**
     * Get products
     * Get products by category id
     * @param clientId
     * @param categoryId
     * @return
     */
    @Transactional
    @GetMapping("/")
    public ResponseEntity<?> getAllProducts(@RequestParam String clientId,
                                                        @RequestParam(required = false) String categoryId) {
        DBContextHolder.setCurrentDb(clientId);
        List<Product> products = service.getProductsByCategoryId(categoryId);
        return ResponseEntity.ok(new ApiResponse<>(200, products));
    }

    @Transactional
    @GetMapping("/{id}")
    public ResponseEntity<?> getProductById(@RequestParam String clientId,
                                                        @PathVariable String id) {
        DBContextHolder.setCurrentDb(clientId);
        Product product = service.getProductByProductId(id);
        if (product == null) {
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok(new ApiResponse<>(200, product));
    }
}
