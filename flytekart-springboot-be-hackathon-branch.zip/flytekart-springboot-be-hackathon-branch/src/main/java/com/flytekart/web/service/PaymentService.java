package com.flytekart.web.service;

import com.flytekart.web.model.client.Payment;
import com.flytekart.web.model.client.PaymentLog;
import com.flytekart.web.model.client.PaymentStatus;
import com.flytekart.web.model.client.PaymentType;
import com.flytekart.web.repository.client.PaymentLogRepository;
import com.flytekart.web.repository.client.PaymentRepository;
import com.flytekart.web.repository.client.PaymentStatusRepository;
import com.flytekart.web.repository.client.PaymentTypeRepository;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private PaymentTypeRepository paymentTypeRepository;

    @Autowired
    private PaymentStatusRepository paymentStatusRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private PaymentLogRepository paymentLogRepository;

    public List<Payment> getPaymentsByOrderId(String orderId) {
        List<Payment> payments = paymentRepository.findUnDeletedByOrderId(orderId);
        return payments;
    }

    public Payment getUndeletedPaymentById(String paymentId) {
        Payment payment = paymentRepository.findUnDeletedByPaymentId(paymentId);
        return payment;
    }

    public PaymentLog addPaymentLog(Payment payment, String message) {
        PaymentLog paymentLog = new PaymentLog();
        paymentLog.setPaymentId(payment.getId());
        paymentLog.setPaymentStatusId(payment.getPaymentStatus().getId());
        paymentLog.setDescription(message);
        paymentLogRepository.save(paymentLog);
        return paymentLog;
    }

    public PaymentType findPaymentTypeByName(String paymentType) {
        return paymentTypeRepository.findByName(paymentType);
    }

    public PaymentStatus findPaymentStatusByName(String paymentStatus) {
        return paymentStatusRepository.findByName(paymentStatus);
    }

    public Payment save(Payment payment) {
        return paymentRepository.save(payment);
    }
}
