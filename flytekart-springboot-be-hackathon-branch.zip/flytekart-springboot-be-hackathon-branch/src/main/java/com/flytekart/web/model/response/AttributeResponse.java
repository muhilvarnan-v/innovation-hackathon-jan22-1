package com.flytekart.web.model.response;

import com.flytekart.web.model.client.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class AttributeResponse {
    private Attribute attribute;
    private List<AttributeValue> attributeValues;

    public Attribute getAttribute() {
        return attribute;
    }

    public void setAttribute(Attribute attribute) {
        this.attribute = attribute;
    }

    public List<AttributeValue> getAttributeValues() {
        return attributeValues;
    }

    public void setAttributeValues(List<AttributeValue> attributeValues) {
        this.attributeValues = attributeValues;
    }
}
