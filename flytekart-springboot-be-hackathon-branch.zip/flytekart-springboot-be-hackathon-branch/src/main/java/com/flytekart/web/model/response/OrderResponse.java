package com.flytekart.web.model.response;

import com.flytekart.web.model.client.Order;
import com.flytekart.web.model.client.OrderItem;
import com.flytekart.web.model.client.Payment;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class OrderResponse {
    private Order order;
    private List<OrderItem> orderItems;
    private List<Payment> payments;
    // TODO Add discounts list
    private OrderTotal orderTotal;

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    public List<Payment> getPayments() {
        return payments;
    }

    public void setPayments(List<Payment> payments) {
        this.payments = payments;
    }

    public OrderTotal getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(OrderTotal orderTotal) {
        this.orderTotal = orderTotal;
    }

    public void generateTotals() {
        OrderTotal orderTotal = null;
        if (orderItems != null) {
            orderTotal = new OrderTotal();
            BigDecimal totalPriceBigDecimal = new BigDecimal(0);
            for (OrderItem orderItem : orderItems) {
                // TODO Need to add condition so that removed orderItems won't be calculated here
                if (orderItem.getDeletedAt() == null) {
                    totalPriceBigDecimal = totalPriceBigDecimal.add(BigDecimal.valueOf(orderItem.getTotalPrice()));
                }
            }
            totalPriceBigDecimal = totalPriceBigDecimal.setScale(2, RoundingMode.HALF_UP);
            orderTotal.setTotalPrice(totalPriceBigDecimal.doubleValue());

            BigDecimal totalTaxBigDecimal = new BigDecimal(0);
            for (OrderItem orderItem : orderItems) {
                totalTaxBigDecimal = totalTaxBigDecimal.add(BigDecimal.valueOf(orderItem.getTotalTax()));
            }
            totalTaxBigDecimal = totalTaxBigDecimal.setScale(2, RoundingMode.HALF_UP);
            orderTotal.setTotalTax(totalTaxBigDecimal.doubleValue());

            BigDecimal totalBigDecimal = totalPriceBigDecimal.add(totalTaxBigDecimal)
                    .setScale(2, RoundingMode.HALF_UP);
            orderTotal.setTotal(totalBigDecimal.doubleValue());
        }

        this.orderTotal = orderTotal;
    }

    public static class OrderTotal {
        private double totalPrice;
        private double totalTax;
        private double total;

        public double getTotalPrice() {
            return totalPrice;
        }

        public void setTotalPrice(double totalPrice) {
            this.totalPrice = totalPrice;
        }

        public double getTotalTax() {
            return totalTax;
        }

        public void setTotalTax(double totalTax) {
            this.totalTax = totalTax;
        }

        public double getTotal() {
            return total;
        }

        public void setTotal(double total) {
            this.total = total;
        }
    }
}
