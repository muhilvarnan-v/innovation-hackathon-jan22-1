package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.EndUserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EndUserRoleRepository extends JpaRepository<EndUserRole, String> {
    //Optional<EndUserRole> findByName(EndUserRoleName roleName);
}