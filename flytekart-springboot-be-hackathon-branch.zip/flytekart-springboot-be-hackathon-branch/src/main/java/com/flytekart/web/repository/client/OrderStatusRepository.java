package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.OrderSource;
import com.flytekart.web.model.client.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderStatusRepository extends JpaRepository<OrderStatus, String> {
    OrderStatus findByName(String name);
}
