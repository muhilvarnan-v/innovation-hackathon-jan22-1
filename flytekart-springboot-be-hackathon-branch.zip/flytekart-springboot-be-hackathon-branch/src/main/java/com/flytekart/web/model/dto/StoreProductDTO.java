package com.flytekart.web.model.dto;

public class StoreProductDTO {

    private String id;

    private String productId;

    private String productName;

    private String variantName;

    private String categoryName;

    private Double price;

    private Double tax;

    private Double originalPrice;

    public StoreProductDTO(String id, String productId, String productName, String variantName, Double price,
                           Double tax, Double originalPrice, String categoryName) {
        this.id = id;
        this.productId = productId;
        this.productName = productName;
        this.variantName = variantName;
        this.price = price;
        this.tax = tax;
        this.originalPrice = originalPrice;
        this.categoryName = categoryName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getVariantName() {
        return variantName;
    }

    public void setVariantName(String variantName) {
        this.variantName = variantName;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public Double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(Double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}
