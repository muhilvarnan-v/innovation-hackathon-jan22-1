package com.flytekart.web.service;

import com.flytekart.web.util.Constants;
import com.google.firebase.messaging.*;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FirebaseMessagingService {
    private final FirebaseMessaging firebaseMessaging;

    @Value("${app.packageName}")
    private String packageName;

    public FirebaseMessagingService(FirebaseMessaging firebaseMessaging) {
        this.firebaseMessaging = firebaseMessaging;
    }

    public String sendNotification(String token) throws FirebaseMessagingException {
        Map<String, String> data = new HashMap<>(2);
        data.put("title", "Hello FLd");
        data.put("body", "Hello FLd");

        Notification notification = Notification
                .builder()
                .setTitle("Hello FL")
                .setBody("Hello FL")
                .build();

        AndroidConfig.Builder builder = AndroidConfig.builder();
        builder.setRestrictedPackageName(packageName);
        Message message = Message
                .builder()
                .setToken(token)
                .setNotification(notification)
                .putAllData(data)
                .setAndroidConfig(builder.build())
                .build();

        return firebaseMessaging.send(message);
    }

    public void sendNotificationToATopic(String title, String body, String topic) {
        Map<String, String> data = new HashMap<>(2);
        data.put(Constants.TITLE, title);
        data.put(Constants.BODY, body);

        Notification notification = Notification
                .builder()
                .setTitle(title)
                .setBody(body)
                .build();

        AndroidConfig.Builder builder = AndroidConfig.builder();
        builder.setRestrictedPackageName(packageName);
        Message message = Message
                .builder()
                .setTopic(topic)
                .setNotification(notification)
                .putAllData(data)
                .setAndroidConfig(builder.build())
                .build();

        /*try {
            System.out.println("Sending a push notification to: " + topic + " with title: " + title + " and body: " + body);
            String messageId = firebaseMessaging.send(message);
            System.out.println("Message ID: " + messageId);
        } catch (FirebaseMessagingException e) {
            e.printStackTrace();
        }*/
        firebaseMessaging.sendAsync(message);
    }

    /**
     * @param title
     * @param body
     * @param topic
     * @param serverKey
     */
    public void sendNotificationToATopicUsingServerKey(String title, String body, String topic,
                                                       String serverKey, String packageName) {
        JSONObject bodyJson = new JSONObject();
        bodyJson.put(Constants.TO, String.format(Constants.TOPICS, topic));
        bodyJson.put(Constants.RESTRICTED_PACKAGE_NAME, packageName);

        JSONObject notificationJson = new JSONObject();
        notificationJson.put(Constants.TITLE, title);
        notificationJson.put(Constants.BODY, body);

        bodyJson.put(Constants.NOTIFICATION, notificationJson);

        try {
            HttpResponse<String> stringHttpResponse = Unirest.post("https://fcm.googleapis.com/fcm/send")
                    .header(Constants.AUTHORIZATION, serverKey)
                    .header(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON)
                    .body(bodyJson).asString();
            String resBody = stringHttpResponse.getBody();
            System.out.println(resBody);
        } catch (UnirestException e) {
            e.printStackTrace();
        }
    }

    public void sendNotificationToFCMKeysUsingServerKey(String title, String body, List<String> fcmKeys,
                                                        String serverKey, String packageName) {
        JSONObject bodyJson = new JSONObject();
        bodyJson.put(Constants.REGISTRATION_IDS, fcmKeys);
        bodyJson.put(Constants.RESTRICTED_PACKAGE_NAME, packageName);

        JSONObject notificationJson = new JSONObject();
        notificationJson.put(Constants.TITLE, title);
        notificationJson.put(Constants.BODY, body);

        bodyJson.put(Constants.NOTIFICATION, notificationJson);

        Unirest.post(Constants.FCMURLs.SEND_PUSH_NOTIFICATION)
                .header(Constants.AUTHORIZATION, serverKey)
                .header(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON)
                .body(bodyJson).asStringAsync();
    }

    public void saveTokenToATopic(String token, String topic) {
        List<String> tokenList = new ArrayList<>(1);
        tokenList.add(token);
        firebaseMessaging.subscribeToTopicAsync(tokenList, topic);
    }

    public void deleteTokenFromATopic(String token, String topic) {
        List<String> tokenList = new ArrayList<>(1);
        tokenList.add(token);
        firebaseMessaging.unsubscribeFromTopicAsync(tokenList, topic);
    }

    /**
     * https://selvaganesh93.medium.com/firebase-cloud-messaging-important-rest-apis-be79260022b5
     * @param token
     * @param topic
     * @param serverKey
     */
    public void saveTokenToATopicUsingServerKey(String token, String topic, String serverKey) {
        List<String> tokenList = new ArrayList<>(1);
        tokenList.add(token);
        JSONObject bodyJson = new JSONObject();
        bodyJson.put(Constants.TO, String.format(Constants.TOPICS, topic));
        bodyJson.put(Constants.REGISTRATION_TOKENS, tokenList);

        Unirest.post(Constants.FCMURLs.ADD_TOKEN_TO_A_TOPIC)
                .header(Constants.AUTHORIZATION, serverKey)
                .header(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON)
                .body(bodyJson).asStringAsync();
    }

    public void deleteTokenFromATopicUsingServerKey(String token, String topic, String serverKey) {
        List<String> tokenList = new ArrayList<>(1);
        tokenList.add(token);
        JSONObject bodyJson = new JSONObject();
        bodyJson.put(Constants.TO, String.format(Constants.TOPICS, topic));
        bodyJson.put(Constants.REGISTRATION_TOKENS, tokenList);

        Unirest.post(Constants.FCMURLs.REMOVE_TOKEN_FROM_A_TOPIC)
                .header(Constants.AUTHORIZATION, serverKey)
                .header(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON)
                .body(bodyJson).asStringAsync();
    }
}
