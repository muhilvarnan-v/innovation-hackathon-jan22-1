package com.flytekart.web.model.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
/*@JsonIgnoreProperties(
        value = {"createdBy", "lastUpdatedBy"},
        allowGetters = true)*/
/**
 * Can be used for auditing both solely User or solely Employee changes.
 * For cases where createdBy and lastUpdatedBy have polymorphism, use PolyMorphicUserDateAudit class
 */
public abstract class UserDateAudit extends DateAudit {
    @CreatedBy
    @JsonProperty(value = "createdBy")
    private String createdBy;
    @LastModifiedBy
    @JsonProperty(value = "lastUpdatedBy")
    private String lastUpdatedBy;

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
}

