package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAuditWithDeletion;
import com.flytekart.web.model.dto.VariantStoreVariantDTO;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

// Availability status is based on isActive field and not deletedAt for StoreVariant
@NamedNativeQuery(name = "StoreVariant.findAllVariantsWithStoreVariantsByStoreId",
        query = "select v.id as id, v.name as name, v.productId as productId, v.sku as sku, v.price as price, v.tax as tax, " +
                "v.originalPrice as originalPrice, v.isActive as isActive, sv.id as storeVariantId, " +
                "sv.isActive as storeVariantIsActive, sv.price as storeVariantPrice, sv.tax as storeVariantTax, " +
                "sv.originalPrice as storeVariantOriginalPrice, sv.quantity as storeVariantQuantity, sv.deletedAt as storeVariantDeletedAt, " +
                "sv.deletedBy as storeVariantDeletedBy " +
                "from Variant v left join StoreVariant sv on sv.variantId = v.id " +
                "and sv.storeId=:storeId and sv.deletedBy is null where v.productId=:productId and v.isActive = true and v.deletedBy is null",
        resultSetMapping = "Mapping.VariantStoreVariantDTO")
@NamedNativeQuery(name = "StoreVariant.findDTOByStoreVariantId",
        query = "select v.id as id, v.name as name, v.productId as productId, v.sku as sku, v.price as price, v.tax as tax, " +
                "v.originalPrice as originalPrice, v.isActive as isActive, sv.id as storeVariantId, " +
                "sv.isActive as storeVariantIsActive, sv.price as storeVariantPrice, sv.tax as storeVariantTax, " +
                "sv.originalPrice as storeVariantOriginalPrice, sv.quantity as storeVariantQuantity, sv.deletedAt as storeVariantDeletedAt, " +
                "sv.deletedBy as storeVariantDeletedBy " +
                "from Variant v inner join StoreVariant sv on sv.variantId = v.id " +
                "and sv.id=:id where v.isActive = true and v.deletedAt is null",
        resultSetMapping = "Mapping.VariantStoreVariantDTO")
@SqlResultSetMapping(name = "Mapping.VariantStoreVariantDTO",
        classes = @ConstructorResult(targetClass = VariantStoreVariantDTO.class,
                columns = {@ColumnResult(name = "id", type = String.class),
                        @ColumnResult(name = "name", type = String.class),
                        @ColumnResult(name = "productId", type = String.class),
                        @ColumnResult(name = "sku", type = String.class),
                        @ColumnResult(name = "price", type = Double.class),
                        @ColumnResult(name = "tax", type = Double.class),
                        @ColumnResult(name = "originalPrice", type = Double.class),
                        @ColumnResult(name = "isActive", type = Boolean.class),
                        @ColumnResult(name = "storeVariantId", type = String.class),
                        @ColumnResult(name = "storeVariantIsActive", type = Boolean.class),
                        @ColumnResult(name = "storeVariantPrice", type = Double.class),
                        @ColumnResult(name = "storeVariantTax", type = Double.class),
                        @ColumnResult(name = "storeVariantOriginalPrice", type = Double.class),
                        @ColumnResult(name = "storeVariantQuantity", type = Integer.class),
                        @ColumnResult(name = "storeVariantDeletedAt", type = String.class),
                        @ColumnResult(name = "storeVariantDeletedBy", type = String.class)}))
@Entity
@Table(name = "StoreVariant", schema = "public")
public class StoreVariant extends UserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @ManyToOne()
    @JoinColumn(name = "storeId", referencedColumnName = "id", updatable = false)
    private Store store;

    @ManyToOne()
    @JoinColumn(name = "variantId", referencedColumnName = "id", updatable = false)
    private Variant variant;

    @Column()
    private Double price;

    @Column()
    private Double tax;

    @Column()
    private Double originalPrice;

    @Column()
    private boolean isActive;

    @Column()
    private int quantity;


    public StoreVariant() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Store getStore() {
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    public Variant getVariant() {
        return variant;
    }

    public void setVariant(Variant variant) {
        this.variant = variant;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public Double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(Double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
