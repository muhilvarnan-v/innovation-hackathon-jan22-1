package com.flytekart.web.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class AddOrderItemRequest {

    @Size(min = 1, max = 40)
    private String userId;

    @Size(min = 1, max = 40)
    private String orderId;

    @NotBlank
    @Size(min = 1, max = 40)
    private String storeVariantId;

    @NotBlank
    @Size(min = 1, max = 40)
    private String storeId;

    @Size(min = 1, max = 40)
    private String orderSource;

    @NotNull
    private int quantity;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getStoreVariantId() {
        return storeVariantId;
    }

    public void setStoreVariantId(String storeVariantId) {
        this.storeVariantId = storeVariantId;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getOrderSource() {
        return orderSource;
    }

    public void setOrderSource(String orderSource) {
        this.orderSource = orderSource;
    }
}
