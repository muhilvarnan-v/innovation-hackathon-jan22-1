package com.flytekart.web.service;

import com.flytekart.web.model.client.StoreCategory;
import com.flytekart.web.model.client.StoreVariant;
import com.flytekart.web.model.dto.CategoryStoreCategoryDTO;
import com.flytekart.web.model.dto.StoreCategoryDTO;
import com.flytekart.web.repository.client.StoreCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;


@Service
public class StoreCategoryService {

    @Autowired
    private StoreCategoryRepository storeCategoryRepository;

    public StoreCategory getStoreCategoryById(String id) {
        StoreCategory storeCategory;
        if (StringUtils.hasText(id)) {
            storeCategory =  storeCategoryRepository.findByStoreCategoryId(id);
        } else {
            storeCategory = null;
        }
        return storeCategory;
    }

    public StoreCategory getStoreCategoryByStoreIdAndCategoryId(String storeId, String categoryId) {
        StoreCategory storeCategory;
        if (StringUtils.hasText(storeId)) {
            storeCategory =  storeCategoryRepository.findByStoreIdAndCategoryId(storeId, categoryId);
        } else {
            storeCategory = null;
        }
        return storeCategory;
    }

    public StoreCategory getStoreCategoryByStoreIdAndCategoryName(String storeId, String categoryName) {
        StoreCategory storeCategory = null;
        if (StringUtils.hasText(storeId)) {
            List<StoreCategory> storeCategories =
                    storeCategoryRepository.findByStoreIdAndCategoryName(storeId, categoryName);
            if (storeCategories != null && storeCategories.size() > 0) {
                storeCategory = storeCategories.get(0);
            }
        }
        return storeCategory;
    }

    public List<StoreCategoryDTO> getStoreCategoriesByStoreId(String storeId) {
        List<StoreCategoryDTO> storeCategories;
        if (StringUtils.hasText(storeId)) {
            storeCategories =  storeCategoryRepository.findUndeletedDTOByStoreId(storeId);
        } else {
            storeCategories = null;
        }
        return storeCategories;
    }

    public List<CategoryStoreCategoryDTO> getAllCategoriesWithStoreCategoriesByStoreId(String storeId) {
        List<CategoryStoreCategoryDTO> storeCategories;
        if (StringUtils.hasText(storeId)) {
            storeCategories =  storeCategoryRepository.findAllCategoriesWithStoreCategoriesByStoreId(storeId);
        } else {
            storeCategories = null;
        }
        return storeCategories;
    }

    public StoreCategory save(StoreCategory storeCategory) {
        storeCategoryRepository.save(storeCategory);
        return storeCategory;
    }
}
