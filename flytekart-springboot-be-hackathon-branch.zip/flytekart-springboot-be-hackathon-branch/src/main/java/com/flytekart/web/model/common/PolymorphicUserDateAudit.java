package com.flytekart.web.model.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.flytekart.web.security.UserPrincipal;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;

@MappedSuperclass
@JsonIgnoreProperties(
        value = {"createdBy", "updatedBy"},
        allowGetters = true)
/**
 * Can be used for auditing both solely User or solely Employee changes.
 * For cases where createdBy and lastUpdatedBy have polymorphism, use PolyMorphicUserDateAudit class
 */
public abstract class PolymorphicUserDateAudit extends DateAudit {
    @Column
    private String createdBy;
    @Column
    private String lastUpdatedBy;
    @Column
    private String createdByResourceType;
    @Column
    private String lastUpdatedByResourceType;

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getCreatedByResourceType() {
        return createdByResourceType;
    }

    public void setCreatedByResourceType(String createdByResourceType) {
        this.createdByResourceType = createdByResourceType;
    }

    public String getLastUpdatedByResourceType() {
        return lastUpdatedByResourceType;
    }

    public void setLastUpdatedByResourceType(String lastUpdatedByResourceType) {
        this.lastUpdatedByResourceType = lastUpdatedByResourceType;
    }

    @PrePersist
    public void onPrePersist() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        setCreatedBy(userPrincipal.getId());
        setLastUpdatedBy(userPrincipal.getId());
        setCreatedByResourceType(userPrincipal.getUserType());
        setLastUpdatedByResourceType(userPrincipal.getUserType());
        setCreatedAt(new Date());
        setLastUpdatedAt(new Date());
    }

    @PreUpdate
    public void onPreUpdate() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        setLastUpdatedBy(userPrincipal.getId());
        setLastUpdatedByResourceType(userPrincipal.getUserType());
        setLastUpdatedAt(new Date());
    }
}

