package com.flytekart.web.model.request;

import javax.validation.constraints.Size;

public class CreateVariantAttributeValueRequest {

    @Size(min = 1, max = 40)
    private String variantId;

    @Size(min = 1, max = 40)
    private String attributeValueId;

    public String getVariantId() {
        return variantId;
    }

    public void setVariantId(String variantId) {
        this.variantId = variantId;
    }

    public String getAttributeValueId() {
        return attributeValueId;
    }

    public void setAttributeValueId(String attributeValueId) {
        this.attributeValueId = attributeValueId;
    }

}
