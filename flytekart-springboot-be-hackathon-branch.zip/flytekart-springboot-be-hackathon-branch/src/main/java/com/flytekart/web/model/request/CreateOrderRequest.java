package com.flytekart.web.model.request;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

public class CreateOrderRequest {
    private OrderDTO order;
    private List<OrderItemDTO> orderItems;
    private OrderTotal orderTotal;

    public static class OrderDTO {
        @Size(min = 1, max = 40)
        public String id;
        @Size(min = 1, max = 40)
        @NotBlank(message = "Please login to place the order")
        public String userId;
        @Size(min = 1, max = 40)
        @NotBlank(message = "Please select a store")
        public String storeId;
        @Size(min = 1, max = 40)
        @NotBlank(message = "Please provide order status")
        public String orderStatus;
        @Size(min = 1, max = 40)
        @NotBlank(message = "Please provide order source")
        public String orderSource;
        @Size(min = 1, max = 40)
        @NotBlank(message = "Please provide delivery address")
        public String deliveryAddressId;
        @Size(min = 1, max = 40)
        @NotBlank(message = "Please provide payment type")
        public String paymentType;
    }

    public static class OrderItemDTO {
        @Size(min = 1, max = 40)
        public String id;
        @Size(min = 1, max = 40)
        public String orderId;
        @Size(min = 1, max = 40)
        @NotBlank(message = "Please provide order status")
        public String orderItemStatus;
        @Size(min = 1, max = 40)
        @NotBlank(message = "Please provide product")
        public String productId;
        @Size(min = 1, max = 40)
        @NotBlank(message = "Please provide product")
        public String storeVariantId;
        @Min(1)
        @NotBlank(message = "Please provide quantity")
        public int quantity;
        public double unitPrice;
        public double unitTax;
        public double totalPrice;
        public double totalTax;
    }

    public static class OrderTotal {
        private double totalPrice;
        private double totalTax;
        private double total;
    }

    public OrderDTO getOrder() {
        return order;
    }

    public void setOrder(OrderDTO order) {
        this.order = order;
    }

    public List<OrderItemDTO> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItemDTO> orderItems) {
        this.orderItems = orderItems;
    }

    public OrderTotal getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(OrderTotal orderTotal) {
        this.orderTotal = orderTotal;
    }
}
