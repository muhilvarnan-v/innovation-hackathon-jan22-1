package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAudit;
import com.flytekart.web.model.common.UserDateAuditWithDeletion;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name = "Variant", schema = "public")
public class Variant extends UserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @ManyToOne()
    @JoinColumn(name = "productId", referencedColumnName = "id", updatable = false)
    private Product product;

    @Column(length = 100)
    private String sku;

    @Column(length = 100)
    private String name;

    @Column()
    private Double price;

    @Column()
    private Double tax;

    @Column()
    private Double originalPrice;

    @Column()
    private boolean isActive;

    @Column(length = 1000)
    private String imageUrl;

    public Variant() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public Double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(Double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
