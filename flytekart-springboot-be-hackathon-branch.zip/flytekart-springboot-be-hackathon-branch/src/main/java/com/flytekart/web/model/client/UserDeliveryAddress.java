package com.flytekart.web.model.client;

import com.flytekart.web.model.common.DateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

// TODO May need to implement validation error responses like here - https://www.baeldung.com/spring-boot-bean-validation

/**
 * TODO Need to introduce isActive or deletedBy keys to support deletion of user addresses
 */
@Entity
@Table(name = "UserDeliveryAddress", schema = "public")
public class UserDeliveryAddress extends DateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "userId")
    private EndUser user;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "addressId", referencedColumnName = "id")
    private Address address;

    private String deliveryAddressTypeId;


    public UserDeliveryAddress() {
    }

    /*public UserDeliveryAddress(@NotBlank @Size(max = 40) String userId, @NotBlank @Size(max = 40) String addressId,
                               @NotBlank @Size(max = 40) String deliveryAddressTypeId) {
        this.userId = userId;
        this.addressId = addressId;
        this.deliveryAddressTypeId = deliveryAddressTypeId;
    }*/

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public EndUser getUser() {
        return user;
    }

    public void setUser(EndUser user) {
        this.user = user;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getDeliveryAddressTypeId() {
        return deliveryAddressTypeId;
    }

    public void setDeliveryAddressTypeId(String deliveryAddressTypeId) {
        this.deliveryAddressTypeId = deliveryAddressTypeId;
    }
}
