package com.flytekart.web.telegram;

import com.flytekart.web.model.client.Order;
import com.flytekart.web.util.Constants;
import com.pengrad.telegrambot.TelegramBot;
import com.pengrad.telegrambot.request.SetWebhook;
import com.pengrad.telegrambot.response.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TelegramService {

    @Value("${app.telegram.webhookurl}")
    private String webhookUrl;

    @Autowired
    TelegramUserContextRepository telegramUserContextRepository;

    @Autowired
    TelegramSettingsRepository telegramSettingsRepository;

    public void addTelegramBot(String clientId, String botTokenId) {
        String url = webhookUrl + "/api/telegram/getUpdate/" + clientId;
        TelegramBot bot = new TelegramBot(botTokenId);
        SetWebhook removeRequest = new SetWebhook().url(Constants.EMPTY);
        bot.execute(removeRequest); // Remove older webhooks
        SetWebhook request = new SetWebhook()
                .url(url);
        BaseResponse response = bot.execute(request);
        System.out.println("TelegramService-addTelegramBot: " + response.isOk());
    }

    public TelegramUserContext save(TelegramUserContext telegramUserContext) {
        telegramUserContext.setCreatedBy(telegramUserContext.getUser().getId());
        telegramUserContext.setLastUpdatedBy(telegramUserContext.getUser().getId());
        telegramUserContextRepository.save(telegramUserContext);
        return telegramUserContext;
    }

    public TelegramSettings getTelegramSettings() {
        TelegramSettings telegramSettings = null;
        List<TelegramSettings> telegramSettingsList = telegramSettingsRepository.findUnDeleted();
        if (telegramSettingsList != null && telegramSettingsList.size() > 0) {
            telegramSettings = telegramSettingsList.get(0);
        }
        return telegramSettings;
    }
}
