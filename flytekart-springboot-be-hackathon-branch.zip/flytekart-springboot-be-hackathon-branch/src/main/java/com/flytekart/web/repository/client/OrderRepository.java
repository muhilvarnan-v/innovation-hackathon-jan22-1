package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Order;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.flytekart.web.model.dto.ProductOrderReportDTO;
import com.flytekart.web.model.dto.UserReportDTO;
import com.flytekart.web.model.dto.CustomerOrderReportDTO;
import com.flytekart.web.model.dto.OrderTimeReportDTO;

import java.util.Date;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, String> {
    @Query("from Order where deletedBy IS NULL and id=:id")
    Order findUnDeletedByOrderId(String id);

    @Query("from Order where deletedBy IS NULL and userId=:userId " +
            "and orderPlacedAt IS NOT NULL ORDER BY orderPlacedAt DESC")
    List<Order> findUnDeletedByUserId(String userId, Pageable pageable);

    @Query("from Order where deletedBy IS NULL and storeId=:storeId " +
            "and orderPlacedAt IS NOT NULL ORDER BY orderPlacedAt DESC")
    List<Order> findUnDeletedByStoreId(String storeId, Pageable pageable);

    @Query("from Order where deletedBy IS NULL and userId=:userId " +
            "and orderSourceId=:orderSourceId and orderPlacedAt IS NOT NULL ORDER BY orderPlacedAt DESC")
    List<Order> findUnDeletedByUserIdAndOrderSourceId(String userId, String orderSourceId, Pageable pageable);

    @Query("from Order where deletedBy IS NULL and storeId=:storeId " +
            "and orderSourceId=:orderSourceId and orderPlacedAt IS NOT NULL ORDER BY orderPlacedAt DESC")
    List<Order> findUnDeletedByStoreIdAndOrderSourceId(String storeId, String orderSourceId, Pageable pageable);

    // @Query(value = "Order.productList", nativeQuery = true)
    @Query(nativeQuery = true)
    List<ProductOrderReportDTO> getOrderProductList(String timeZone, String categoryId, String productId, String variantId, String startDate, String endDate, int pageSize, int pageNumber);

    // @Query(value = "Order.productList", nativeQuery = true)
    @Query(nativeQuery = true)
    List<OrderTimeReportDTO> getOrderTimeList(String timeZone, String startDate, String endDate, int pageSize, int pageNumber);

    // @Query(value = "Order.productList", nativeQuery = true)
    @Query(nativeQuery = true)
    List<UserReportDTO> getUsers(String timeZone,String startDate, String endDate, int pageSize, int pageNumber);

    // @Query(value = "Order.productList", nativeQuery = true)
    @Query(nativeQuery = true)
    List<CustomerOrderReportDTO> getUserOrdersList(String timeZone, String lastOrderedAfter, String lastOrderedBefore, int startItem, int endItem);
}
