package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Attribute;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AttributeRepository extends JpaRepository<Attribute, String> {
    @Query("from Attribute where name like :prefix%")
    List<Attribute> findAttributesByPrefix(@Param("prefix") String prefix);

    /**
     * Runs "from Attribute where upper(name) like upper(%:prefix%)
     * TODO This query is inefficient if we don't have INDEX by upper(name)
     * @param name
     * @return
     */
    List<Attribute> findByNameIgnoreCaseContaining(String name);

    /**
     * TODO This query is inefficient if we don't have INDEX by upper(name)
     * @return
     */
    //@Query("from Attribute where upper(name) like upper('%:prefix%') and deletedBy IS NULL") TODO Need to add audit fields
    @Query("from Attribute where upper(name) like upper(concat('%', :prefix,'%')) and deletedBy IS NULL")
    List<Attribute> findUnDeletedByNameIgnoreCaseContaining(String prefix);

    @Query("from Attribute where upper(name) = upper(:name) and deletedBy IS NULL")
    Attribute findUnDeletedByNameIgnoreCase(String name);

    @Query("from Attribute where deletedBy IS NULL")
    List<Attribute> findAllUndeleted();
}
