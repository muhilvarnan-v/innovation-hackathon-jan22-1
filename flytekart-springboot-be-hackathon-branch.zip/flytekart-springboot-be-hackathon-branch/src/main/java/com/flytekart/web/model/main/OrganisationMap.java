package com.flytekart.web.model.main;

import com.flytekart.web.model.common.UserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

// TODO May need to implement validation error responses like here - https://www.baeldung.com/spring-boot-bean-validation

@Entity
@Table(name = "OrganisationMap", schema = "public")
public class OrganisationMap extends UserDateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;
    @NotBlank
    @Size(min = 3, max = 40)
    private String clientCode;
    @NotBlank
    @Size(max = 40)
    private String userId;
    @NotBlank
    @Size(max = 40)
    private String organisationId;

    public OrganisationMap() {
    }

    public OrganisationMap(@NotBlank @Size(min = 3, max = 40) String clientCode, @NotBlank @Size(max = 40) String userId,
                           @NotBlank @Size(max = 40) String organisationId) {
        this.clientCode = clientCode;
        this.userId = userId;
        this.organisationId = organisationId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClientCode() {
        return clientCode;
    }

    public void setClientCode(String clientCode) {
        this.clientCode = clientCode;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrganisationId() {
        return organisationId;
    }

    public void setOrganisationId(String organisationId) {
        this.organisationId = organisationId;
    }
}