package com.flytekart.web.model.client;

import com.flytekart.web.model.common.EmployeeAndUserDateAuditWithDeletion;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name = "Payment", schema = "public")
public class Payment extends EmployeeAndUserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String orderId;

    @Column()
    private double amount;

    @ManyToOne()
    @JoinColumn(name = "paymentTypeId", referencedColumnName = "id")
    private PaymentType paymentType;

    @ManyToOne()
    @JoinColumn(name = "paymentStatusId", referencedColumnName = "id")
    private PaymentStatus paymentStatus;

    public Payment() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(PaymentType paymentType) {
        this.paymentType = paymentType;
    }

    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
}
