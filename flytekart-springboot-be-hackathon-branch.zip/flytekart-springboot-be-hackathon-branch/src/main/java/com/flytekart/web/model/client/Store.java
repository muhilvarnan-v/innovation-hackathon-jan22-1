package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 * TODO Need to take care of soft deletion
 */
@Entity
@Table(name = "Store", schema = "public")
public class Store extends UserDateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 200)
    @NotNull(message = "Name cannot be empty")
    private String name;

    @Column(length = 40)
    private String organisationId;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "addressId", referencedColumnName = "id")
    private Address address;

    @Column(length = 40)
    private String taxNumber;

    @Column
    private Boolean peakeSale;

    public Store() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrganisationId() {
        return organisationId;
    }

    public void setOrganisationId(String organisationId) {
        this.organisationId = organisationId;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public void setPeakeSale(Boolean peakeSale){
        this.peakeSale = peakeSale;
    }

    public Boolean getPeakeSale(){
        return peakeSale;
    }
}
