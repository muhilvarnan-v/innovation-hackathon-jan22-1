package com.flytekart.web.repository.client;

import com.flytekart.web.model.main.OrganisationMap;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrganisationMapRepository extends JpaRepository<OrganisationMap, String> {
    Optional<OrganisationMap> findByClientCode(String clientCode);
    Optional<List<OrganisationMap>> findByUserId(String userId);
}
