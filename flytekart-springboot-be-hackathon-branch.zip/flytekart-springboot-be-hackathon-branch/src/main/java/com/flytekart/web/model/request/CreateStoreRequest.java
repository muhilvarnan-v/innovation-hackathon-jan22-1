package com.flytekart.web.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.flytekart.web.model.client.Address;
import com.flytekart.web.model.client.Product;
import com.flytekart.web.model.client.Store;

import javax.validation.constraints.Size;

public class CreateStoreRequest {

    @Size(min = 1, max = 40)
    private String id;

    @Size(min = 1, max = 100)
    private String name;

    @Size(min = 1, max = 40)
    private String organisationId;

    private String taxNumber;

    private Address address;

    public CreateStoreRequest() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrganisationId() {
        return organisationId;
    }

    public void setOrganisationId(String organisationId) {
        this.organisationId = organisationId;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public static Store getStore(CreateStoreRequest requestBody) {
        Store store = new Store();
        store.setName(requestBody.getName());
        store.setOrganisationId(requestBody.getOrganisationId());
        store.setTaxNumber(requestBody.getTaxNumber());
        store.setAddress(store.getAddress());

        return store;
    }

    public static Store getStore(CreateStoreRequest requestBody, Store managedStore) {
        managedStore.setName(requestBody.getName());
        managedStore.setOrganisationId(requestBody.getOrganisationId());
        managedStore.setTaxNumber(requestBody.getTaxNumber());
        managedStore.setAddress(requestBody.getAddress());

        return managedStore;
    }
}
