package com.flytekart.web.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CreateStoreCategoryRequest {

    @Size(min = 1, max = 40)
    private String storeCategoryId;

    @Size(min = 1, max = 40)
    private String storeId;

    @Size(min = 1, max = 40)
    private String categoryId;

    @NotNull
    @JsonProperty(value = "isActive")
    private boolean isActive;

    public String getStoreCategoryId() {
        return storeCategoryId;
    }

    public void setStoreCategoryId(String storeCategoryId) {
        this.storeCategoryId = storeCategoryId;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
}
