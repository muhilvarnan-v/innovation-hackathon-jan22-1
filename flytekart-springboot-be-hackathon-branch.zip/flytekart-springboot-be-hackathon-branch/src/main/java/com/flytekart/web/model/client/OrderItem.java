package com.flytekart.web.model.client;

import com.flytekart.web.model.common.EmployeeAndUserDateAuditWithDeletion;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Each item part of an order.
 * TODO Should we maintain total = totalPrice + totalTax - totalDiscount
 */
@Entity
@Table(name = "OrderItem", schema = "public")
public class OrderItem extends EmployeeAndUserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 40)
    private String orderId;

    @Column(length = 40)
    private String orderItemStatusId;

    @ManyToOne()
    @JoinColumn(name = "storeVariantId", referencedColumnName = "id")
    private StoreVariant storeVariant;

    @Column()
    private double unitPrice;

    @Column()
    private double unitTax;

    @Column()
    private int quantity;

    @Column()
    private double totalPrice;

    @Column()
    private double totalTax;

    /*@Column()
    private double unitDiscount;

    @Column()
    private double totalDiscount;*/

    public OrderItem() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderItemStatusId() {
        return orderItemStatusId;
    }

    public void setOrderItemStatusId(String orderItemStatusId) {
        this.orderItemStatusId = orderItemStatusId;
    }

    public StoreVariant getStoreVariant() {
        return storeVariant;
    }

    public void setStoreVariant(StoreVariant storeVariant) {
        this.storeVariant = storeVariant;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public double getUnitTax() {
        return unitTax;
    }

    public void setUnitTax(double unitTax) {
        this.unitTax = unitTax;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public double getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(double totalTax) {
        this.totalTax = totalTax;
    }

    /*public double getUnitDiscount() {
        return unitDiscount;
    }

    public void setUnitDiscount(double unitDiscount) {
        this.unitDiscount = unitDiscount;
    }

    public double getTotalDiscount() {
        return totalDiscount;
    }

    public void setTotalDiscount(double totalDiscount) {
        this.totalDiscount = totalDiscount;
    }*/
}
