package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAudit;
import com.flytekart.web.model.common.UserDateAuditWithDeletion;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name = "VariantAttributeValue", schema = "public")
public class VariantAttributeValue extends UserDateAuditWithDeletion {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @ManyToOne()
    @JoinColumn(name = "variantId", referencedColumnName = "id", updatable = false)
    private Variant variant;

    @ManyToOne()
    @JoinColumn(name = "attributeValueId", referencedColumnName = "id", updatable = false)
    private AttributeValue attributeValue;

    public VariantAttributeValue() {
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Variant getVariant() {
        return variant;
    }

    public void setVariant(Variant variant) {
        this.variant = variant;
    }

    public AttributeValue getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(AttributeValue attributeValue) {
        this.attributeValue = attributeValue;
    }
}
