package com.flytekart.web.service;

import com.flytekart.web.model.client.*;
import com.flytekart.web.model.response.OrderResponse;
import com.flytekart.web.repository.client.*;
import org.hibernate.exception.SQLGrammarException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessResourceUsageException;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.flytekart.web.model.dto.CustomerOrderReportDTO;
import com.flytekart.web.model.dto.OrderTimeReportDTO;
import com.flytekart.web.model.dto.ProductOrderReportDTO;
import com.flytekart.web.model.dto.UserReportDTO;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private OrderLogRepository orderLogRepository;

    @Autowired
    private OrderItemLogRepository orderItemLogRepository;

    @Autowired
    private VariantRepository variantRepository;

    @Autowired
    private OrderStatusRepository orderStatusRepository;

    @Autowired
    private OrderItemStatusRepository orderItemStatusRepository;

    @Autowired
    private OrderSourceRepository orderSourceRepository;

    @Autowired
    private PaymentService paymentService;

    public List<Variant> getVariantsByProductId(String productId, Boolean isActive) {
        List<Variant> variants;
        if (StringUtils.hasText(productId)) {
            if(isActive == null) {
                variants = variantRepository.findUnDeletedByProductId(productId);
            } else {
                variants = variantRepository.findUnDeletedByProductId(productId, isActive);
            }
        } else if (isActive == null) {
            variants = variantRepository.findAllUndeleted();
        } else {
            variants = variantRepository.findAllUndeleted(isActive);
        }
        return variants;
    }

    public List<Order> getOrdersByUserId(String userId, int pageNumber, int pageSize, OrderSource orderSource) {
        List<Order> orders = null;
        try {
            if (StringUtils.hasText(userId)) {
                if (orderSource == null) {
                    orders = orderRepository.findUnDeletedByUserId(userId, PageRequest.of(pageNumber, pageSize));
                    //orders = ordersPage.getContent();
                } else {
                    orders = orderRepository.findUnDeletedByUserIdAndOrderSourceId(userId, orderSource.getId(),
                            PageRequest.of(pageNumber, pageSize));
                }
            }
        } catch (InvalidDataAccessResourceUsageException | SQLGrammarException e) {
            // Probably higher pageNumber
        }
        return orders;
    }

    public List<Order> getOrdersByStoreId(String storeId, int pageNumber, int pageSize, OrderSource orderSource) {
        List<Order> orders = null;
        try {
            if (StringUtils.hasText(storeId)) {
                if (orderSource == null) {
                    orders = orderRepository.findUnDeletedByStoreId(storeId, PageRequest.of(pageNumber, pageSize));
                    //orders = ordersPage.getContent();
                } else {
                    orders = orderRepository.findUnDeletedByStoreIdAndOrderSourceId(storeId, orderSource.getId(),
                            PageRequest.of(pageNumber, pageSize));
                }
            }
        } catch (InvalidDataAccessResourceUsageException | SQLGrammarException e) {
            // Probably higher pageNumber
        }
        return orders;
    }

    public Order getOrderByOrderId(String orderId) {
        Order order;
        if (StringUtils.hasText(orderId)) {
            order =  orderRepository.findUnDeletedByOrderId(orderId);
        } else {
            order = null;
        }
        return order;
    }

    public List<OrderItem> getOrderItemsByOrderId(String orderId) {
        List<OrderItem> orderItems;
        if (StringUtils.hasText(orderId)) {
            orderItems = orderItemRepository.findUnDeletedByOrderId(orderId);
        } else {
            orderItems = null;
        }
        return orderItems;
    }

    public List<Payment> getPaymentsByOrderId(String orderId) {
        List<Payment> payments;
        if (StringUtils.hasText(orderId)) {
            payments = paymentService.getPaymentsByOrderId(orderId); //findUnDeletedByOrderId(orderId);
        } else {
            payments = null;
        }
        return payments;
    }

    public OrderItem getOrderItemByOrderItemId(String orderItemId) {
        OrderItem orderItem;
        if (StringUtils.hasText(orderItemId)) {
            orderItem =  orderItemRepository.findUnDeletedByOrderItemId(orderItemId);
        } else {
            orderItem = null;
        }
        return orderItem;
    }

    public Order save(Order order) {
        orderRepository.save(order);
        return order;
    }

    /**
     * TODO Should we make this async?
     * @param order Order
     * @param message message
     * @return
     */
    public OrderLog addOrderLog(Order order, String message) {
        OrderLog orderLog = new OrderLog();
        orderLog.setOrderId(order.getId());
        orderLog.setOrderStatusId(order.getOrderStatus().getId());
        orderLog.setDescription(message);
        orderLogRepository.save(orderLog);
        return orderLog;
    }

    public OrderItem saveOrderItem(OrderItem orderItem) {
        orderItemRepository.save(orderItem);
        return orderItem;
    }

    public List<ProductOrderReportDTO> getOrderProductsReport(String timeZone, String categoryId, String productId, String variantId, String startDate, String endDate, int startItem, int endItem) {
        List<ProductOrderReportDTO> products =  orderRepository.getOrderProductList(timeZone, categoryId, productId, variantId, startDate, endDate, startItem, endItem);
        return products;
    }

    public List<OrderTimeReportDTO> getOrderTimeReport(String timeZone, String startDate, String endDate, int startItem, int endItem) {
        
        
        List<OrderTimeReportDTO> orders =  orderRepository.getOrderTimeList(timeZone, startDate, endDate, startItem, endItem);
       
        return orders;
    }

    public List<UserReportDTO> getUserReport(String timeZone, String startDate, String endDate, int startItem, int endItem) {
        
        
        List<UserReportDTO> users =  orderRepository.getUsers(timeZone, startDate, endDate, startItem, endItem);
       
        return users;
    }

    public List<CustomerOrderReportDTO> getUserOrderReport(String timeZone, String lastOrderedAfter, String lastOrderedBefore, int startItem, int endItem) {
        
        
        List<CustomerOrderReportDTO> usersOrders =  orderRepository.getUserOrdersList(timeZone, lastOrderedAfter, lastOrderedBefore, startItem, endItem);
       
        return usersOrders;
    }

    /**
     * TODO Should we make this async?
     * @param orderItem OrderItem
     * @param message message
     * @return
     */
    public OrderItemLog addOrderItemLog(OrderItem orderItem, String message) {
        OrderItemLog orderItemLog = new OrderItemLog();
        orderItemLog.setOrderItemId(orderItem.getId());
        orderItemLog.setOrderItemStatusId(orderItem.getOrderItemStatusId());
        orderItemLog.setDescription(message);
        orderItemLogRepository.save(orderItemLog);
        return orderItemLog;
    }

    public OrderStatus findOrderStatusByName(String name) {
        return orderStatusRepository.findByName(name);
    }

    public Optional<OrderStatus> findOrderStatusById(String id) {
        return orderStatusRepository.findById(id);
    }

    public OrderItemStatus findOrderItemStatusByName(String name) {
        return orderItemStatusRepository.findByName(name);
    }

    public Optional<OrderItemStatus> findOrderItemStatusById(String id) {
        return orderItemStatusRepository.findById(id);
    }

    public OrderSource findOrderSourceByName(String name) {
        return orderSourceRepository.findByName(name);
    }

    // TODO OrderResponse should include related returns
    public OrderResponse generateOrderResponse(Order order) {
        List<OrderItem> orderItems = getOrderItemsByOrderId(order.getId());
        List<Payment> payments = getPaymentsByOrderId(order.getId());
        OrderResponse orderResponse = generateOrderResponse(order, orderItems, payments);
        return orderResponse;
    }

    // TODO OrderResponse should include related returns
    public OrderResponse generateOrderResponse(Order order, List<OrderItem> orderItems) {
        List<Payment> payments = getPaymentsByOrderId(order.getId());
        OrderResponse orderResponse = generateOrderResponse(order, orderItems, payments);
        return orderResponse;
    }

    // TODO OrderResponse should include related returns
    public OrderResponse generateOrderResponse(Order order, List<OrderItem> orderItems,
                                               List<Payment> payments) {
        OrderResponse orderResponse = new OrderResponse();
        orderResponse.setOrder(order);
        orderResponse.setOrderItems(orderItems);
        orderResponse.setPayments(payments);
        orderResponse.generateTotals();
        return orderResponse;
    }
}
