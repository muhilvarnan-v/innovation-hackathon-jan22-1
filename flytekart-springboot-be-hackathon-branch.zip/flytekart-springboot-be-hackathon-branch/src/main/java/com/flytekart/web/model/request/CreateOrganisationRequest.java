package com.flytekart.web.model.request;

import com.flytekart.web.model.client.Address;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class CreateOrganisationRequest {
    @NotBlank
    @Size(min = 4, max = 40)
    private String name;
    @NotBlank
    @Size(min = 4, max = 40)
    private String organisationTypeName; // Change to enum or string constant
    @NotBlank
    @Size(min = 4, max = 40)
    private String businessTypeName; // Change to enum or string constant
    @NotBlank
    @Size(min = 4, max = 40)
    private String taxNumber;

    private Address address;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrganisationTypeName() {
        return organisationTypeName;
    }

    public void setOrganisationTypeName(String organisationTypeName) {
        this.organisationTypeName = organisationTypeName;
    }

    public String getBusinessTypeName() {
        return businessTypeName;
    }

    public void setBusinessTypeName(String businessTypeName) {
        this.businessTypeName = businessTypeName;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}
