package com.flytekart.web.model.dto;

import java.util.Date;

public class CustomerOrderReportDTO {
 
    private String userId;

    private String name;

    private Integer totalOrderCount;

    private Double totalOrderValue;

    private Date lastOrderedAt;


    public CustomerOrderReportDTO(String userId, String name, Integer totalOrderCount,
                                    Double totalOrderValue, Date lastOrderedAt) {
        this.userId = userId;
        this.name = name;
        this.totalOrderCount = totalOrderCount;
        this.totalOrderValue = totalOrderValue;
        this.lastOrderedAt = lastOrderedAt;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getTotalOrderCount() {
        return totalOrderCount;
    }

    public void setTotalOrderCount(Integer totalOrderCount) {
        this.totalOrderCount = totalOrderCount;
    }

    public Double getTotalOrderValue() {
        return totalOrderValue;
    }

    public void setTotalOrderValue(Double totalOrderValue) {
        this.totalOrderValue = totalOrderValue;
    }

    public Date getLastOrderedAt() {
        return lastOrderedAt;
    }

    public void setLastOrderedAt(Date lastOrderedAt) {
        this.lastOrderedAt = lastOrderedAt;
    }

}
