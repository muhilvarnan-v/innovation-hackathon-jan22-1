package com.flytekart.web.model.client;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_TEST
}
