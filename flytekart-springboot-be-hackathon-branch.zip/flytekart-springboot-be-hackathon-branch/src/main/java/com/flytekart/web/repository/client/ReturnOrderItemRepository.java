package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.OrderItem;
import com.flytekart.web.model.client.ReturnOrderItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReturnOrderItemRepository extends JpaRepository<ReturnOrderItem, String> {
    @Query("from ReturnOrderItem where deletedBy IS NULL and returnOrderId=:returnOrderId")
    List<ReturnOrderItem> findUnDeletedByReturnOrderId(String returnOrderId);

    @Query("from ReturnOrderItem where deletedBy IS NULL and id=:id")
    ReturnOrderItem findUnDeletedByReturnOrderItemId(String id);

    @Query("from ReturnOrderItem where deletedBy IS NULL and orderItemId=:orderItemId")
    List<ReturnOrderItem> findUnDeletedByOrderItemId(String orderItemId);
}
