package com.flytekart.web.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class RemoveOrderItemRequest {

    @NotBlank
    @Size(min = 1, max = 40)
    private String orderItemId;

    public String getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }
}
