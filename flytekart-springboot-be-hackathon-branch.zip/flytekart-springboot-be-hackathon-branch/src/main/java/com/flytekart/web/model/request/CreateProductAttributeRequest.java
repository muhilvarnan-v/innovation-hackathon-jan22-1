package com.flytekart.web.model.request;

import javax.validation.constraints.Size;

public class CreateProductAttributeRequest {

    @Size(min = 1, max = 40)
    private String productId;

    @Size(min = 1, max = 40)
    private String attributeId;

    public CreateProductAttributeRequest() {
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(String attributeId) {
        this.attributeId = attributeId;
    }
}
