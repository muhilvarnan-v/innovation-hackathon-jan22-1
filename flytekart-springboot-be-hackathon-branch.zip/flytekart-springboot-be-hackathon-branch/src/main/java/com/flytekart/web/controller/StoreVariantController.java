package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.dto.VariantStoreVariantDTO;
import com.flytekart.web.model.request.CreateStoreVariantRequest;
import com.flytekart.web.model.request.EditStoreVariantRequest;
import com.flytekart.web.model.request.UpdateStoreVariantQuantityRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.*;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.ProductService;
import com.flytekart.web.service.StoreVariantService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * TODO Make updates to get only non-deleted productVariants with active and inactive filter
 * TODO Create a new API to make a productVariant inactive
 * TODO Create a new API to delete a productVariant
 */
@RestController
@RequestMapping("/api/storeVariants")
public class StoreVariantController {

    @Autowired
    private StoreVariantService storeVariantService;

    @Autowired
    private StoreRepository storeRepository;

    @Autowired
    private VariantRepository variantRepository;

    @Autowired
    private ProductService productService;

    /*@Autowired
    private EntityManager em;*/

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody CreateStoreVariantRequest request,
                                            @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }
        StoreVariant storeVariant = null;
        if (request.getStoreVariantId() != null) {
            storeVariant = storeVariantService.getStoreVariantByStoreVariantId(request.getStoreVariantId());
        }
        Optional<Store> optionalStore = null;
        Optional<Variant> optionalVariant = null;
        if (storeVariant == null) {
            if (request.getStoreId() == null || request.getVariantId() == null) {
                return ResponseEntity.badRequest().build();
            }
            optionalStore = storeRepository.findById(request.getStoreId());
            optionalVariant = variantRepository.findById(request.getVariantId());
            if (optionalStore.isEmpty() || optionalVariant.isEmpty()) {
                return ResponseEntity.badRequest().build();
            }
            storeVariant = storeVariantService.getStoreVariantByStoreIdAndVariantId(request.getStoreId(), request.getVariantId());
        }
        // A combination of storeId and variantId should be unique.
        if (storeVariant == null) {
            storeVariant = new StoreVariant();
            storeVariant.setStore(optionalStore.get());
            storeVariant.setVariant(optionalVariant.get());
        }
        storeVariant.setPrice(request.getPrice());
        storeVariant.setTax(request.getTax());
        storeVariant.setOriginalPrice(request.getOriginalPrice());
        storeVariant.setActive(request.isActive());
        storeVariant.setQuantity(request.getQuantity());
        storeVariant.setDeletedAt(null);
        storeVariant.setDeletedBy(null);
        storeVariantService.save(storeVariant);
        return ResponseEntity.ok(new ApiResponse<>(200, storeVariant));
    }

    @Transactional
    @GetMapping("/getDTO/{id}")
    public ResponseEntity<?> getStoreVariantDTOById(@RequestParam String clientId,
                                                        @PathVariable String id) {
        DBContextHolder.setCurrentDb(clientId);

        VariantStoreVariantDTO dto = storeVariantService.getStoreVariantDTOByStoreVariantId(id);
        if (dto == null) {
            return ResponseEntity.badRequest().build();
        }

        return ResponseEntity.ok(new ApiResponse<>(200, dto));
    }

    @Transactional
    @GetMapping("/store/{storeId}")
    // TODO Should we use NamedEntityGraphs and EntityGraphs for get queries?
    public ResponseEntity<?> getVariantsByStoreId(@RequestParam String clientId,
                                                        @PathVariable String storeId) {
        DBContextHolder.setCurrentDb(clientId);

        Optional<Store> optionalStore = storeRepository.findById(storeId);
        if (optionalStore.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        List<StoreVariant> storeVariants
                = storeVariantService.getStoreVariantsByStoreId(optionalStore.get().getId());
        return ResponseEntity.ok(new ApiResponse<>(200, storeVariants));
    }

    @Transactional
    @DeleteMapping("/{storeVariantId}")
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> deleteVariantAttributeValueById(@RequestParam String clientId,
                                                                       @PathVariable String storeVariantId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        StoreVariant storeVariant =
                storeVariantService.getUndeletedStoreVariantByStoreVariantId(storeVariantId);
        if (storeVariant == null) {
            return ResponseEntity.notFound().build();
        }

        storeVariant.setDeletedBy(principal.getId());
        storeVariant.setDeletedAt(new Date());
        storeVariantService.save(storeVariant);
        return ResponseEntity.ok(new ApiResponse<>(200, storeVariant));
    }

    @Transactional
    @PostMapping("/{storeVariantId}/updateQuantity")
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateQuantityByStoreVariantId(@RequestParam String clientId,
            @Valid @RequestBody UpdateStoreVariantQuantityRequest request,
            @PathVariable String storeVariantId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        StoreVariant storeVariant =
                storeVariantService.getUndeletedStoreVariantByStoreVariantId(storeVariantId);
        if (storeVariant == null) {
            return ResponseEntity.notFound().build();
        }

        storeVariant.setQuantity(request.getQuantity());
        storeVariantService.save(storeVariant);
        return ResponseEntity.ok(new ApiResponse<>(200, storeVariant));
    }

    @Transactional
    @PostMapping("/{storeVariantId}")
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> updateStoreVariant(@RequestParam String clientId,
            @Valid @RequestBody EditStoreVariantRequest request,
            @PathVariable String storeVariantId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }

        StoreVariant storeVariant =
                storeVariantService.getUndeletedStoreVariantByStoreVariantId(storeVariantId);
        if (storeVariant == null) {
            return ResponseEntity.notFound().build();
        }

        storeVariant.setQuantity(request.getQuantity());
        storeVariant.setPrice(request.getPrice());
        storeVariant.setTax(request.getTax());
        storeVariant.setOriginalPrice(request.getOriginalPrice());
        storeVariant.setActive(request.isActive());
        storeVariantService.save(storeVariant);
        return ResponseEntity.ok(new ApiResponse<>(200, storeVariant));
    }

    @Transactional
    @GetMapping("/withAllVariants/store/{storeId}")
    public ResponseEntity<?> getAllVariantsWithStoreVariantsByStoreId(@RequestParam String clientId,
                                                                                @RequestParam String productId,
                                                                                @PathVariable String storeId) {
        DBContextHolder.setCurrentDb(clientId);

        Optional<Store> optionalStore = storeRepository.findById(storeId);
        if (optionalStore.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        Product product = productService.getProductByProductId(productId);
        if (product == null) {
            return ResponseEntity.badRequest().build();
        }

        List<VariantStoreVariantDTO> storeVariants
                = storeVariantService.getAllVariantsWithStoreVariantsByStoreId(storeId, productId);
        return ResponseEntity.ok(new ApiResponse<>(200, storeVariants));
    }
}
