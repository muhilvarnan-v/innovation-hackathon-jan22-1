package com.flytekart.web.model.client;

import com.flytekart.web.model.common.DateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

// TODO May need to implement validation error responses like here - https://www.baeldung.com/spring-boot-bean-validation

@Entity
@Table(name = "Employee", schema = "public"
        , uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "username"
        }),
        @UniqueConstraint(columnNames = {
                "email"
        })
})
public class Employee extends DateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;
    @NotBlank
    @Size(max = 40)
    private String name;
    @NotBlank
    @Size(min = 4, max = 40)
    private String username;
    @NotBlank
    @Size(min = 4, max = 40)
    private String email;
    @NotBlank
    @Size(min = 4, max = 100)
    private String password;
    @NotBlank
    @Size(min = 4, max = 20)
    /**
     * Phone number will be saved in this format: countryCode<hyphen>phoneNumber
     * Eg 1: +91-XXXXXXXXXX
     * Eg 2: +1-XXXXXXXXXX
     * Hyphen separated the country code and phone number.
     */
    private String phoneNumber;
    @Column(columnDefinition="tinyint(1) default 0") // For MySql
    private boolean isEmailVerified;
    @Column(columnDefinition="tinyint(1) default 0") // For MySql
    private boolean isPhoneVerified;

    /*@ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "EmployeeRole",
            joinColumns = @JoinColumn(name = "employeeId"),
            inverseJoinColumns = @JoinColumn(name = "roleId"))
    private Set<Role> roles = new HashSet<>();*/

    public Employee() {
    }

    public Employee(@NotBlank @Size(max = 40) String name, @NotBlank @Size(min = 4, max = 40) String username,
                    @NotBlank @Size(min = 4, max = 40) String email, @Size(min = 4, max = 20) String phoneNumber,
                    @NotBlank @Size(min = 4, max = 100) String password) {
        this.name = name;
        this.username = username;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public boolean isEmailVerified() {
        return isEmailVerified;
    }

    public void setEmailVerified(boolean emailVerified) {
        isEmailVerified = emailVerified;
    }

    public boolean isPhoneVerified() {
        return isPhoneVerified;
    }

    public void setPhoneVerified(boolean phoneVerified) {
        isPhoneVerified = phoneVerified;
    }

    /*public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }*/
}
