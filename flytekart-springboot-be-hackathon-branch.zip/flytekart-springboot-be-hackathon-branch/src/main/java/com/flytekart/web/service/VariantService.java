package com.flytekart.web.service;

import com.flytekart.web.model.client.Variant;
import com.flytekart.web.repository.client.VariantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class VariantService {

    @Autowired
    private VariantRepository variantRepository;

    public List<Variant> getVariantsByProductId(String productId, Boolean isActive) {
        List<Variant> variants;
        if (StringUtils.hasText(productId)) {
            if(isActive == null) {
                variants = variantRepository.findUnDeletedByProductId(productId);
            } else {
                variants = variantRepository.findUnDeletedByProductId(productId, isActive.booleanValue());
            }
        } else if (isActive == null) {
            variants = variantRepository.findAllUndeleted();
        } else {
            variants = variantRepository.findAllUndeleted(isActive.booleanValue());
        }
        return variants;
    }

    public Variant getVariantByVariantId(String variantId) {
        Variant variant;
        if (StringUtils.hasText(variantId)) {
            variant =  variantRepository.findUnDeletedByVariantId(variantId);
        } else {
            variant = null;
        }
        return variant;
    }

    public Variant getVariantByProductIdAndVariantName(String productId, String variantName) {
        Variant variant;
        if (StringUtils.hasText(productId) && StringUtils.hasText(variantName)) {
            variant =  variantRepository.findUnDeletedByProductIdAndVariantName(productId, variantName);
        } else {
            variant = null;
        }
        return variant;
    }

    public Variant save(Variant variant) {
        variantRepository.save(variant);
        return variant;
    }
}
