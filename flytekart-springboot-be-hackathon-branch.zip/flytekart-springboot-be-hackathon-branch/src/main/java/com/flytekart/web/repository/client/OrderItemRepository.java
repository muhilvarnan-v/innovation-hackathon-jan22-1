package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Order;
import com.flytekart.web.model.client.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderItemRepository extends JpaRepository<OrderItem, String> {
    @Query("from OrderItem where deletedBy IS NULL and orderId=:orderId")
    List<OrderItem> findUnDeletedByOrderId(String orderId);

    @Query("from OrderItem where deletedBy IS NULL and id=:id")
    OrderItem findUnDeletedByOrderItemId(String id);
}
