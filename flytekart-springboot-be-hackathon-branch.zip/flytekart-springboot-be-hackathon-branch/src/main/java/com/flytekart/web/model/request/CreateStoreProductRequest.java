package com.flytekart.web.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CreateStoreProductRequest {

    @Size(min = 1, max = 40)
    private String storeProductId;

    @Size(min = 1, max = 40)
    private String storeId;

    @Size(min = 1, max = 40)
    private String productId;

    @NotNull
    @JsonProperty(value = "isActive")
    private boolean isActive;

    public String getStoreProductId() {
        return storeProductId;
    }

    public void setStoreProductId(String storeProductId) {
        this.storeProductId = storeProductId;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
}
