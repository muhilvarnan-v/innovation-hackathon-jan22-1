package com.flytekart.web.telegram;

import com.flytekart.web.model.client.EndUser;
import com.flytekart.web.model.common.UserDateAuditWithDeletion;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "TelegramUserContext", schema = "public")
public class TelegramUserContext extends UserDateAuditWithDeletion {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @OneToOne()
    @JoinColumn(name = "userId", referencedColumnName = "id")
    private EndUser user;

    @Column(length = 100)
    private String context;

    @Column(length = 1000)
    private String data;

    private int lastMessageId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public EndUser getUser() {
        return user;
    }

    public void setUser(EndUser user) {
        this.user = user;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getLastMessageId() {
        return lastMessageId;
    }

    public void setLastMessageId(int lastMessageId) {
        this.lastMessageId = lastMessageId;
    }
}
