package com.flytekart.web.model.client;

import com.flytekart.web.model.common.UserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * This is a helper table to help us with filtering and filer results counts
 */
@Entity
@Table(name = "ProductAttribute", schema = "public")
public class ProductAttribute extends UserDateAudit {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    /*@Column(length = 40)
    private String productId;*/

    @ManyToOne()
    @JoinColumn(name = "productId", referencedColumnName = "id", updatable = false)
    private Product product;

    /*@Column(length = 40)
    private String attributeId;*/

    @ManyToOne()
    @JoinColumn(name = "attributeId", referencedColumnName = "id", updatable = false)
    private Attribute attribute;

    public ProductAttribute() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /*public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(String attributeId) {
        this.attributeId = attributeId;
    }*/

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Attribute getAttribute() {
        return attribute;
    }

    public void setAttribute(Attribute attribute) {
        this.attribute = attribute;
    }
}
