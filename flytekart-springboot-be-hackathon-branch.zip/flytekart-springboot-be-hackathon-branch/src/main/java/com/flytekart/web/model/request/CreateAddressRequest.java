package com.flytekart.web.model.request;

import com.flytekart.web.model.common.PolymorphicUserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CreateAddressRequest {
    @Size(min = 1, max = 40)
    private String id;

    @Size(min = 1, max = 100)
    @NotNull(message = "Address line 1 cannot be empty")
    private String line1;

    @Size(min = 1, max = 100)
    private String line2;

    @Size(min = 1, max = 100)
    @NotBlank(message = "City cannot be empty")
    private String city;

    @Size(min = 1, max = 100)
    @NotNull(message = "State cannot be empty")
    private String state;

    @Size(min = 1, max = 100)
    @NotNull(message = "Country cannot be empty")
    private String country;

    @Size(min = 1, max = 40)
    @NotNull(message = "Zip cannot be empty")
    private String zip;

    @NotNull
    private double latitude;

    @NotNull
    private double longitude;

    public CreateAddressRequest() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLine1() {
        return line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
