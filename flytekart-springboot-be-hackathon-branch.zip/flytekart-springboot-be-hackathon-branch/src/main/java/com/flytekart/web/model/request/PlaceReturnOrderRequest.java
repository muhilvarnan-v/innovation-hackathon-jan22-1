package com.flytekart.web.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class PlaceReturnOrderRequest {

    @NotBlank
    @Size(min = 1, max = 40)
    private String returnOrderId;

    public String getReturnOrderId() {
        return returnOrderId;
    }

    public void setReturnOrderId(String returnOrderId) {
        this.returnOrderId = returnOrderId;
    }
}
