package com.flytekart.web.model.request;

import com.flytekart.web.model.dto.AttributeValueDTO;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

public class CreateVariantVavRequest {

    @Size(min = 1, max = 40)
    private String id;

    @Size(min = 1, max = 40)
    private String productId;

    @Size(max = 40)
    private String sku;

    @Size(min = 1, max = 100)
    private String name;

    @NotNull
    private Double price;

    private Double originalPrice;

    private Double tax;

    @NotNull
    private boolean isActive;

    private List<AttributeValueDTO> attributeValueDTOs;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(Double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public List<AttributeValueDTO> getAttributeValueDTOs() {
        return attributeValueDTOs;
    }

    public void setAttributeValueDTOs(List<AttributeValueDTO> attributeValueDTOs) {
        this.attributeValueDTOs = attributeValueDTOs;
    }
}
