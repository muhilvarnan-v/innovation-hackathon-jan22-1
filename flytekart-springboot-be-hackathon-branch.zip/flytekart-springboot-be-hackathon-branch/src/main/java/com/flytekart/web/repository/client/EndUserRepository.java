package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.EndUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EndUserRepository extends JpaRepository<EndUser, String> {
    Optional<EndUser> findByEmail(String email);

    Optional<EndUser> findByUsernameOrEmail(String username, String email);

    Optional<EndUser> findByUsername(String username);

    Optional<EndUser> findByPhoneNumber(String phoneNumber);

    Boolean existsByUsername(String username);

    Boolean existsByEmail(String email);

    @Query("from EndUser where telegramChatId=:telegramChatId")
    List<EndUser> findUnDeletedByChatId(long telegramChatId);
}
