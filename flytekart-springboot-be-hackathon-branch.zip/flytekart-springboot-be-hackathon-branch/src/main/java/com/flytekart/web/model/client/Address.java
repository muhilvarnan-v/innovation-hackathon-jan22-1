package com.flytekart.web.model.client;

import com.flytekart.web.model.common.PolymorphicUserDateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "Address", schema = "public")
public class Address extends PolymorphicUserDateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;

    @Column(length = 100)
    @NotNull(message = "Address line 1 cannot be empty")
    private String line1;

    @Column(length = 100)
    private String line2;

    @Column(length = 100)
    @NotBlank(message = "City cannot be empty")
    private String city;

    @Column(length = 100)
    @NotNull(message = "State cannot be empty")
    private String state;

    @Column(length = 100)
    @NotNull(message = "Country cannot be empty")
    private String country;

    @Column(length = 40)
    @NotNull(message = "Zip cannot be empty")
    private String zip;

    @Column(length = 40)
    private Double latitude;

    @Column(length = 40)
    private Double longitude;

    public Address() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLine1() {
        return line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return id + ",\n" +
                line1 + ",\n" +
                line2 + ",\n" +
                city + ",\n" +
                state + ",\n" +
                country + ",\n" +
                zip;
    }
}
