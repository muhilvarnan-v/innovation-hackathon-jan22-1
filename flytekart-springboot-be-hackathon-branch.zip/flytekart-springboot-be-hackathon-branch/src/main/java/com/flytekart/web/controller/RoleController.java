package com.flytekart.web.controller;

import com.flytekart.web.model.client.Role;
import com.flytekart.web.model.request.CreateOrganisationRequest;
import com.flytekart.web.repository.client.OrganisationRepository;
import com.flytekart.web.repository.client.CRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/role")
public class RoleController {

    @Autowired
    private CRoleRepository roleRepository;

    @Autowired
    private OrganisationRepository organisationRepository;

    /*@GetMapping("/users/{username}")
    @PreAuthorize("hasRole('USER')")
    //@PreAuthorize("hasRole('USER') && #username == authentication.name")
    public UserProfile getCurrentUser(@PathVariable("username") String username) {
        User user = userRepository.findByUsername(username).orElseThrow(() -> new ResourceNotFoundException("User", "username", username));
        return new UserProfile(user.getId(), user.getUsername(), user.getName());
    }*/

    @PostMapping("/")
    //@PreAuthorize("hasRole('USER') && #username == authentication.name")
    /**
     * TODO
     * 1. Need create Organisation object and save it.
     * 2. Need to return saved object or success msg
     */
    public boolean createOrganisation(@Valid @RequestBody CreateOrganisationRequest request) {
        organisationRepository.save(null);
        return false;
    }

    @GetMapping("/")
    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }
}
