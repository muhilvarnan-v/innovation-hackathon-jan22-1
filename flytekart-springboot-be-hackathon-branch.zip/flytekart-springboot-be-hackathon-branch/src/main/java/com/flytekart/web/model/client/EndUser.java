package com.flytekart.web.model.client;

import com.flytekart.web.model.common.DateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

// TODO May need to implement validation error responses like here - https://www.baeldung.com/spring-boot-bean-validation

@Entity
@Table(name = "User", schema = "public"
        , uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "username"
        }),
        @UniqueConstraint(columnNames = {
                "email"
        })
})
public class EndUser extends DateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;
    
    @Size(max = 100)
    private String name;
    @NotBlank
    @Size(min = 10, max = 40)
    private String username;

    @Size(min = 6, max = 20)
    @Column(name = "phoneNumber")
    private String phoneNumber;
    
    @Size(min = 4, max = 100)
    private String email;
    
    @Size(min = 4, max = 100)
    private String password;

    private Long telegramChatId;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "UserRole",
            joinColumns = @JoinColumn(name = "UserId"),
            inverseJoinColumns = @JoinColumn(name = "RoleId"))
    private Set<Role> roles = new HashSet<>();

    public EndUser() {
    }

    public EndUser(@Size(max = 40) String name, @NotBlank @Size(min = 10, max = 1) String username,
                   @Size(min = 6, max = 20) String phoneNumber, @Size(min = 4, max = 40) String email,
                   @Size(min = 4, max = 100) String password) {
        this.name = name;
        this.username = username;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getTelegramChatId() {
        return telegramChatId;
    }

    public void setTelegramChatId(Long telegramChatId) {
        this.telegramChatId = telegramChatId;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
}
