package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.Store;
import com.flytekart.web.model.request.CreateStoreRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.StoreRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.AddressService;
import com.flytekart.web.service.OrganisationService;
import com.flytekart.web.service.StoreService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/stores")
public class StoreController {

    @Autowired
    private OrganisationService organisationService;

    @Autowired
    private StoreRepository repository;

    @Autowired
    private AddressService addressService;

    @Autowired
    private StoreService storeService;

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody CreateStoreRequest request, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }
        Store store;
        if (request.getId() == null) {
            store = CreateStoreRequest.getStore(request);
        } else {
            Optional<Store> optionalStore = repository.findById(request.getId());
            if (optionalStore.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            store = CreateStoreRequest.getStore(request, optionalStore.get());
        }
        // Get Spring managed address object into store object
        if (request.getAddress() != null) {
            store.setAddress(addressService.save(request.getAddress()));
        }
        String organisationId = organisationService.getOrganisation().getId();
        store.setOrganisationId(organisationId);
        repository.save(store);
        return ResponseEntity.ok(new ApiResponse<>(200, store));
    }

    /**
     * Get store for an organisation. For now each client DB will have only one organisation
     *
     * @param clientId
     * @return
     */
    @Transactional
    @GetMapping("/")
    public ResponseEntity<?> getStoresForAnOrganisationId(@RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        List<Store> stores = repository.findAllByOrderByNameAsc();
        return ResponseEntity.ok(new ApiResponse<>(200, stores));
    }

    /**
     * Get store by organisation id. For now each client DB will have only one organisation
     *
     * @param clientId
     * @param storeId
     * @return
     */
    @Transactional
    @GetMapping("/{storeId}")
    public ResponseEntity<?> getStoreByStoreId(@RequestParam String clientId,
                                                                 @PathVariable String storeId) {
        DBContextHolder.setCurrentDb(clientId);
        Optional<Store> optionalStore = repository.findById(storeId);
        if (optionalStore.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(new ApiResponse<>(200, optionalStore.get()));
    }

    /**
     * Get store by organisation id. For now each client DB will have only one organisation
     *
     * @param clientId
     * @param latitude
     * @param longitude
     * @return
     */
    @Transactional
    @GetMapping("/getDeliverableStoresByLatLng")
    public ResponseEntity<?> getDeliverableStoresByLatLng(@RequestParam String clientId,
                                                                 @RequestParam double latitude,
                                                                    @RequestParam double longitude) {
        DBContextHolder.setCurrentDb(clientId);
        List<Store> stores;
        try {
            // Need to get list of deliverable stores by lat and lng
            stores = storeService.getStoreByLatLng(latitude, longitude, 10);
        } catch (NumberFormatException e) {
            // Wrong input
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok(new ApiResponse<>(200, stores));
    }
}
