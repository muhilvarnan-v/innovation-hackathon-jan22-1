package com.flytekart.web.service;

import com.flytekart.web.model.client.StoreVariant;
import com.flytekart.web.model.dto.ProductStoreProductDTO;
import com.flytekart.web.model.dto.VariantStoreVariantDTO;
import com.flytekart.web.repository.client.StoreVariantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;


@Service
public class StoreVariantService {

    @Autowired
    private StoreVariantRepository storeVariantRepository;

    public List<StoreVariant> getStoreVariantsByStoreId(String storeId) {
        List<StoreVariant> storeVariants;
        if (StringUtils.hasText(storeId)) {
            storeVariants =  storeVariantRepository.findUndeletedByStoreId(storeId);
        } else {
            storeVariants = storeVariantRepository.findAllUndeleted();
        }
        return storeVariants;
    }

    public List<StoreVariant> getStoreVariantsByStoreIdAndProductId(String storeId, String productId) {
        List<StoreVariant> storeVariants;
        if (StringUtils.hasText(storeId)) {
            storeVariants =  storeVariantRepository.findUndeletedByStoreIdAndProductId(storeId, productId);
        } else {
            storeVariants = storeVariantRepository.findAllUndeleted();
        }
        return storeVariants;
    }

    public StoreVariant getStoreVariantsByStoreIdAndProductIdAndVariantName(String storeId, String productId, String variantName) {
        StoreVariant storeVariant;
        if (StringUtils.hasText(storeId)) {
            List<StoreVariant> storeVariants =  storeVariantRepository
                    .findUndeletedByStoreIdAndProductIdAndVariantName(storeId, productId, variantName);
            storeVariant = storeVariants.get(0);
        } else {
            List<StoreVariant> storeVariants = storeVariantRepository.findAllUndeleted();
            storeVariant = storeVariants.get(0);
        }
        return storeVariant;
    }

    public List<StoreVariant> getStoreVariantsByVariantId(String variantId) {
        List<StoreVariant> storeVariants;
        if (StringUtils.hasText(variantId)) {
            storeVariants =  storeVariantRepository.findUndeletedByVariantId(variantId);
        } else {
            storeVariants = storeVariantRepository.findAllUndeleted();
        }
        return storeVariants;
    }

    public List<StoreVariant> getActiveStoreVariantByVariantId(String storeVariantId) {
        List<StoreVariant> storeVariants;
        if (StringUtils.hasText(storeVariantId)) {
            storeVariants =  storeVariantRepository.findActiveAndUndeletedByVariantId(storeVariantId);
        } else {
            storeVariants = null;
        }
        return storeVariants;
    }

    public VariantStoreVariantDTO getStoreVariantDTOByStoreVariantId(String storeVariantId) {
        VariantStoreVariantDTO dto;
        if (StringUtils.hasText(storeVariantId)) {
            dto =  storeVariantRepository.findDTOByStoreVariantId(storeVariantId);
        } else {
            dto = null;
        }
        return dto;
    }

    public StoreVariant getUndeletedStoreVariantByStoreVariantId(String storeVariantId) {
        StoreVariant storeVariant;
        if (StringUtils.hasText(storeVariantId)) {
            storeVariant =  storeVariantRepository.findUndeletedByStoreVariantId(storeVariantId);
        } else {
            storeVariant = null;
        }
        return storeVariant;
    }

    public StoreVariant getStoreVariantByStoreVariantId(String storeVariantId) {
        StoreVariant storeVariant = null;
        if (StringUtils.hasText(storeVariantId)) {
            Optional<StoreVariant> optionalStoreVariant =  storeVariantRepository.findById(storeVariantId);
            if (optionalStoreVariant.isPresent()) {
                storeVariant = optionalStoreVariant.get();
            }
        }
        return storeVariant;
    }

    public StoreVariant getAnyStoreVariantByStoreVariantId(String storeVariantId) {
        StoreVariant storeVariant;
        if (StringUtils.hasText(storeVariantId)) {
            Optional<StoreVariant> optionalStoreVariant =  storeVariantRepository.findById(storeVariantId);
            if (optionalStoreVariant.isEmpty()) {
                storeVariant = null;
            } else {
                storeVariant = optionalStoreVariant.get();
            }
        } else {
            storeVariant = null;
        }
        return storeVariant;
    }

    public List<VariantStoreVariantDTO> getAllVariantsWithStoreVariantsByStoreId(String storeId, String productId) {
        List<VariantStoreVariantDTO> storeVariants;
        if (StringUtils.hasText(storeId)) {
            storeVariants =  storeVariantRepository.findAllVariantsWithStoreVariantsByStoreId(storeId, productId);
        } else {
            storeVariants = null;
        }
        return storeVariants;
    }

    public StoreVariant save(StoreVariant storeVariant) {
        storeVariantRepository.save(storeVariant);
        return storeVariant;
    }

    public StoreVariant getStoreVariantByStoreIdAndVariantId(String storeId, String variantId) {
        StoreVariant storeVariant = null;
        if (StringUtils.hasText(storeId) && StringUtils.hasText(variantId)) {
            storeVariant =  storeVariantRepository.findByStoreIdAndVariantId(storeId, variantId);
        }
        return storeVariant;
    }
}
