package com.flytekart.web.controller;

import com.flytekart.web.repository.client.AWSS3Service;
import com.flytekart.web.model.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.access.prepost.PreAuthorize;
import java.net.URL;
import org.json.JSONObject;


@RestController
@RequestMapping(value= "/api/s3")
public class AWSS3Controller {
 
    @Autowired
    private AWSS3Service service;
 
    @PostMapping(value= "/upload")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> uploadFile(@RequestPart(value= "file") final MultipartFile multipartFile,
                                        @RequestParam(value="clientId") final String clientId) {
        URL url = service.uploadFile(multipartFile, clientId);
        return ResponseEntity.ok(new ApiResponse<>(200, url));
    }
}