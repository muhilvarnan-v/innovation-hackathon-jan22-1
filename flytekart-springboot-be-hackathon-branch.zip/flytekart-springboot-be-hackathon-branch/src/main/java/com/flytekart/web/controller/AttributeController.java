package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.AttributeValue;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.AttributeRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.service.AttributeService;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/attributes")
public class AttributeController {

    @Autowired
    private AttributeService attributeService;

    @PostMapping("/")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> save(@Valid @RequestBody Attribute attribute, @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if(principal.getUserType() != Constants.EMPLOYEE) {
            return ResponseEntity.notFound().build();
        }
        attributeService.save(attribute);
        return ResponseEntity.ok(new ApiResponse<>(200, attribute));
    }

    /**
     * Get all attributes - Done
     * Get all attributes based on starting characters
     * @param clientId
     * @return
     */
    @Transactional
    @GetMapping("/")
    public ResponseEntity<?> getAllAttributes(@RequestParam String clientId,
                                                        @RequestParam(required = false) String prefix) {
        DBContextHolder.setCurrentDb(clientId);
        List<Attribute> attributes;
        if (StringUtils.hasText(prefix)) {
            attributes =  attributeService.getAttributesByPrefix(prefix);
        } else {
            attributes =  attributeService.getAllAttributes();
        }
        return ResponseEntity.ok(new ApiResponse<>(200, attributes));
    }
}
