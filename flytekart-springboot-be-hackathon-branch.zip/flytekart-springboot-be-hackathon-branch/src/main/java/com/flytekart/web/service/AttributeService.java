package com.flytekart.web.service;

import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.AttributeValue;
import com.flytekart.web.repository.client.AttributeRepository;
import com.flytekart.web.repository.client.AttributeValueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;


@Service
public class AttributeService {

    @Autowired
    AttributeRepository attributeRepository;

    public List<Attribute> getAttributesByPrefix(String prefix) {
        List<Attribute> attributes;
        if (StringUtils.hasText(prefix)) {
            attributes = attributeRepository.findUnDeletedByNameIgnoreCaseContaining(prefix);
        } else {
            attributes = attributeRepository.findAllUndeleted();
        }
        return attributes;
    }

    public Attribute getAttributesByName(String name) {
        Attribute attribute;
        if (StringUtils.hasText(name)) {
            attribute = attributeRepository.findUnDeletedByNameIgnoreCase(name);
        } else {
            attribute = null;
        }
        return attribute;
    }

    public List<Attribute> getAllAttributes() {
        List<Attribute> attributes = attributeRepository.findAllUndeleted();
        return attributes;
    }

    public Attribute save(Attribute attribute   ) {
        attributeRepository.save(attribute);
        return attribute;
    }
}
