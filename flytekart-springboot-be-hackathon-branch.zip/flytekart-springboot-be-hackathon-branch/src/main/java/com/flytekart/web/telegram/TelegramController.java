package com.flytekart.web.telegram;

import com.flytekart.web.controller.OrderController;
import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.*;
import com.flytekart.web.model.dto.StoreCategoryDTO;
import com.flytekart.web.model.request.CreateOrderRequest;
import com.flytekart.web.repository.client.AddressRepository;
import com.flytekart.web.repository.client.EndUserRepository;
import com.flytekart.web.security.JwtAuthenticationFilter;
import com.flytekart.web.service.StoreCategoryService;
import com.flytekart.web.service.StoreProductService;
import com.flytekart.web.service.StoreService;
import com.flytekart.web.service.StoreVariantService;
import com.flytekart.web.util.Constants;
import com.flytekart.web.util.Utilities;
import com.pengrad.telegrambot.TelegramBot;
import com.pengrad.telegrambot.model.request.KeyboardButton;
import com.pengrad.telegrambot.model.request.ReplyKeyboardMarkup;
import com.pengrad.telegrambot.request.SendMessage;
import com.pengrad.telegrambot.response.BaseResponse;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.telegram.telegrambots.meta.api.objects.Update;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/telegram")
public class TelegramController {

    @Autowired
    TelegramService telegramService;

    @Autowired
    TelegramUserContextRepository telegramUserContextRepository;

    @Autowired
    TelegramSettingsRepository telegramSettingsRepository;

    @Autowired
    EndUserRepository userRepository;

    @Autowired
    StoreService storeService;

    @Autowired
    StoreCategoryService storeCategoryService;

    @Autowired
    StoreProductService storeProductService;

    @Autowired
    StoreVariantService storeVariantService;

    @Autowired
    AddressRepository addressRepository;

    @Autowired
    OrderController orderController;

    @Autowired
    JwtAuthenticationFilter jwtAuthenticationFilter;

    @PostMapping("/getUpdate/{clientId}")
    public ResponseEntity<?> getUpdate(@PathVariable("clientId") String clientId,
                                       @RequestBody Update update){
        //log.info("some update recieved {}",update.toString());
        DBContextHolder.setCurrentDb(clientId);
        // TODO To be based on user selection and the language should be from languages files
        boolean isTelugu = true;
        if (update.getMessage() != null && update.getMessage().getChat() != null) {
        //if (false) {
            Long chatId = update.getMessage().getChat().getId();
            // Check if chatId is the DB
            List<EndUser> userList = userRepository.findUnDeletedByChatId(chatId);
            TelegramSettings telegramSettings = telegramService.getTelegramSettings();
            TelegramBot bot = new TelegramBot(telegramSettings.getTokenId());
            if (userList != null && userList.size() > 0) {
                EndUser user = userList.get(0);
                jwtAuthenticationFilter.forceAuthForTelegram(clientId, user.getId());
                // Check the context and process the msg
                List<TelegramUserContext> telegramUserContexts =
                        telegramUserContextRepository.findUnDeletedByUserId(user.getId());
                TelegramUserContext telegramUserContext;
                if (telegramUserContexts != null && telegramUserContexts.size() > 0) {
                    telegramUserContext = telegramUserContexts.get(telegramUserContexts.size() - 1); // Get the last one
                } else {
                    telegramUserContext = new TelegramUserContext();
                    telegramUserContext.setUser(user);
                    telegramUserContext.setContext("order");
                }
                if (telegramUserContext.getLastMessageId() >= update.getMessage().getMessageId()) {
                    // Ignore
                    return ResponseEntity.ok().build();
                }

                telegramUserContext.setLastMessageId(update.getMessage().getMessageId());

                switch (telegramUserContext.getContext()) {
                    case "orderPlaced":
                    case "order": {
                        List<Store> stores = storeService.getAllStores();
                        KeyboardButton[] keyboardButtons = new KeyboardButton[stores.size()];
                        for (int i = 0; i < stores.size(); i++) {
                            Store store = stores.get(i);
                            KeyboardButton keyboardButton = new KeyboardButton(store.getName());
                            keyboardButtons[i] = keyboardButton;
                        }
                        ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(keyboardButtons);
                        String englishText = "Please select a store to place your order";
                        String teluguText = "దయచేసి మీ ఆర్డర్ చేయడానికి స్టోర్\u200Cను ఎంచుకోండి";
                        String text;
                        if (isTelugu) {
                            text = teluguText;
                        } else {
                            text = englishText;
                        }
                        BaseResponse response = bot.execute(
                                new SendMessage(update.getMessage().getChat().getId(), text).replyMarkup(markupRequest));
                        telegramUserContext.setContext("store");
                        telegramService.save(telegramUserContext);
                        break;
                    }

                    case "store": {
                        String storeName = update.getMessage().getText();
                        Store selectedStore = storeService.getStoreByName(storeName);

                        if (selectedStore == null) {
                            // Ignore and exit
                            return ResponseEntity.ok().build();
                        }

                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("storeId", selectedStore.getId());
                        telegramUserContext.setData(jsonObject.toString());

                        // Select category
                        List<StoreCategoryDTO> storeCategories =
                                storeCategoryService.getStoreCategoriesByStoreId(selectedStore.getId());
                        KeyboardButton[] keyboardButtons = new KeyboardButton[storeCategories.size()];
                        for (int i = 0; i < storeCategories.size(); i++) {
                            StoreCategoryDTO storeCategory = storeCategories.get(i);
                            KeyboardButton keyboardButton = new KeyboardButton(storeCategory.getName());
                            keyboardButtons[i] = keyboardButton;
                        }

                        ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(keyboardButtons);
                        String englishText = "Please select a category";
                        String teluguText = "దయచేసి ఒక వర్గాన్ని ఎంచుకోండి";
                        String text;
                        if (isTelugu) {
                            text = teluguText;
                        } else {
                            text = englishText;
                        }
                        BaseResponse response = bot.execute(
                                new SendMessage(update.getMessage().getChat().getId(), text).replyMarkup(markupRequest));
                        telegramUserContext.setContext("category");
                        telegramService.save(telegramUserContext);
                        break;
                    }

                    case "category": {
                        String categoryName = update.getMessage().getText();
                        String dataString = telegramUserContext.getData();
                        JSONObject jsonObject = new JSONObject(dataString);
                        String storeId = jsonObject.getString("storeId");
                        StoreCategory storeCategory = storeCategoryService
                                .getStoreCategoryByStoreIdAndCategoryName(storeId, categoryName);
                        if (storeCategory == null) {
                            // Ignore and exit
                            return ResponseEntity.ok().build();
                        }
                        jsonObject.put("storeCategoryId", storeCategory.getId());
                        jsonObject.put("categoryId", storeCategory.getCategory().getId());
                        telegramUserContext.setData(jsonObject.toString());

                        // select product
                        List<StoreProduct> storeProducts = storeProductService
                                .getStoreProductsByStoreIdAndCategoryId(storeId, storeCategory.getCategory().getId());
                        KeyboardButton[] keyboardButtons = new KeyboardButton[storeProducts.size()];
                        for (int i = 0; i < storeProducts.size(); i++) {
                            StoreProduct storeProduct = storeProducts.get(i);
                            KeyboardButton keyboardButton = new KeyboardButton(storeProduct.getProduct().getName());
                            keyboardButtons[i] = keyboardButton;
                        }

                        ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(keyboardButtons);
                        String englishText = "Please select a product";
                        String teluguText = "దయచేసి ఒక ఉత్పత్తిని ఎంచుకోండి";
                        String text;
                        if (isTelugu) {
                            text = teluguText;
                        } else {
                            text = englishText;
                        }
                        BaseResponse response = bot.execute(
                                new SendMessage(update.getMessage().getChat().getId(), text).replyMarkup(markupRequest));
                        telegramUserContext.setContext("product");
                        telegramService.save(telegramUserContext);
                        break;
                    }

                    case "product": {
                        String productName = update.getMessage().getText();
                        String dataString = telegramUserContext.getData();
                        JSONObject jsonObject = new JSONObject(dataString);
                        String storeId = jsonObject.getString("storeId");
                        StoreProduct storeProduct = storeProductService.getStoreProductByStoreIdAndProductName(storeId, productName);
                        jsonObject.put("storeProductId", storeProduct.getId());
                        jsonObject.put("productId", storeProduct.getProduct().getId());
                        telegramUserContext.setData(jsonObject.toString());

                        // select variant
                        List<StoreVariant> storeVariants =
                                storeVariantService.getStoreVariantsByStoreIdAndProductId(storeId, storeProduct.getProduct().getId());
                        KeyboardButton[] keyboardButtons = new KeyboardButton[storeVariants.size()];
                        for (int i = 0; i < storeVariants.size(); i++) {
                            StoreVariant storeVariant = storeVariants.get(i);
                            KeyboardButton keyboardButton = new KeyboardButton(storeVariant.getVariant().getName());
                            keyboardButtons[i] = keyboardButton;
                        }

                        ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(keyboardButtons);
                        String englishText = "Please select a variant";
                        String teluguText = "దయచేసి వేరియంట్\u200Cని ఎంచుకోండి";
                        String text;
                        if (isTelugu) {
                            text = teluguText;
                        } else {
                            text = englishText;
                        }
                        BaseResponse response = bot.execute(
                                new SendMessage(update.getMessage().getChat().getId(), text).replyMarkup(markupRequest));
                        telegramUserContext.setContext("variant");
                        telegramService.save(telegramUserContext);
                        break;
                    }

                    case "variant": {
                        String variantName = update.getMessage().getText();
                        String dataString = telegramUserContext.getData();
                        JSONObject jsonObject = new JSONObject(dataString);
                        String storeId = jsonObject.getString("storeId");
                        String productId = jsonObject.getString("productId");
                        StoreVariant storeVariant = storeVariantService.getStoreVariantsByStoreIdAndProductIdAndVariantName(storeId, productId, variantName);
                        jsonObject.put("storeVariantId", storeVariant.getId());
                        telegramUserContext.setData(jsonObject.toString());

                        // select quantity
                        int maxQuantity = 4;
                        KeyboardButton[] keyboardButtons = new KeyboardButton[maxQuantity];
                        for (int i = 1; i <= maxQuantity; i++) {
                            KeyboardButton keyboardButton = new KeyboardButton(String.valueOf(i));
                            keyboardButtons[i-1] = keyboardButton;
                        }

                        ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(keyboardButtons);
                        String englishText = "Please select a quantity";
                        String teluguText = "దయచేసి పరిమాణాన్ని ఎంచుకోండి";
                        String text;
                        if (isTelugu) {
                            text = teluguText;
                        } else {
                            text = englishText;
                        }
                        BaseResponse response = bot.execute(
                                new SendMessage(update.getMessage().getChat().getId(), text).replyMarkup(markupRequest));
                        telegramUserContext.setContext("quantity");
                        telegramService.save(telegramUserContext);
                        break;
                    }

                    case "quantity": {
                        String quantityString = update.getMessage().getText();
                        int quantity = Integer.parseInt(quantityString);
                        String dataString = telegramUserContext.getData();
                        JSONObject jsonObject = new JSONObject(dataString);
                        jsonObject.put("quantity", quantity);
                        telegramUserContext.setData(jsonObject.toString());

                        // Select delivery address

                        List<Address> addressList = addressRepository.findByUserId(user.getId());
                        KeyboardButton[] keyboardButtons = new KeyboardButton[addressList.size()];
                        for (int i = 0; i < addressList.size(); i++) {
                            Address address = addressList.get(i);
                            KeyboardButton keyboardButton = new KeyboardButton(address.toString());
                            keyboardButtons[i] = keyboardButton;
                        }

                        ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(keyboardButtons);
                        String englishText = "Please select a delivery address";
                        String teluguText = "దయచేసి డెలివరీ చిరునామాను ఎంచుకోండి";
                        String text;
                        if (isTelugu) {
                            text = teluguText;
                        } else {
                            text = englishText;
                        }
                        BaseResponse response = bot.execute(
                                new SendMessage(update.getMessage().getChat().getId(), text).replyMarkup(markupRequest));
                        telegramUserContext.setContext("address");
                        telegramService.save(telegramUserContext);
                        break;
                    }

                    case "address": {
                        String addressString = update.getMessage().getText();
                        String[] split = addressString.split(",");
                        String addressId = split[0];
                        Address address = addressRepository.findByIdAndUserId(addressId, user.getId());

                        String dataString = telegramUserContext.getData();
                        JSONObject jsonObject = new JSONObject(dataString);
                        jsonObject.put("addressId", address.getId());
                        telegramUserContext.setData(jsonObject.toString());

                        // Ask to confirm the order
                        KeyboardButton[] keyboardButtons = new KeyboardButton[1];
                        String englishButton = "Confirm order";
                        String teluguButton = "నిర్ధారించండి";
                        KeyboardButton keyboardButton = new KeyboardButton(teluguButton);
                        keyboardButtons[0] = keyboardButton;

                        ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(keyboardButtons);
                        String englishText = "Please confirm the order";
                        String teluguText = "దయచేసి ఆర్డర్\u200Cని నిర్ధారించండి";
                        String text;
                        if (isTelugu) {
                            text = teluguText;
                        } else {
                            text = englishText;
                        }
                        BaseResponse response = bot.execute(
                                new SendMessage(update.getMessage().getChat().getId(), text).replyMarkup(markupRequest));
                        telegramUserContext.setContext("placeOrder");
                        telegramService.save(telegramUserContext);
                        break;
                    }

                    case "placeOrder": {
                        String dataString = telegramUserContext.getData();
                        JSONObject jsonObject = new JSONObject(dataString);
                        String addressId = jsonObject.getString("addressId");
                        String storeId = jsonObject.getString("storeId");
                        String storeVariantId = jsonObject.getString("storeVariantId");
                        int quantity = jsonObject.getInt("quantity");

                        // Place order
                        CreateOrderRequest request = new CreateOrderRequest();
                        CreateOrderRequest.OrderDTO orderDTO = new CreateOrderRequest.OrderDTO();
                        orderDTO.orderSource = "Telegram";
                        orderDTO.deliveryAddressId = addressId;
                        orderDTO.paymentType = "COD";
                        orderDTO.storeId = storeId;
                        orderDTO.userId = user.getId();

                        request.setOrder(orderDTO);

                        CreateOrderRequest.OrderItemDTO orderItemDTO = new CreateOrderRequest.OrderItemDTO();
                        orderItemDTO.storeVariantId = storeVariantId;
                        orderItemDTO.quantity = quantity;

                        List<CreateOrderRequest.OrderItemDTO> orderItemDTOS = new ArrayList<>(1);
                        orderItemDTOS.add(orderItemDTO);
                        request.setOrderItems(orderItemDTOS);


                        String orderId = orderController.createOrderForTelegram(request, clientId, user);

                        String englishText = "Your order is placed. Order id: " + orderId;
                        String teluguText = "మీ ఆర్డర్ నిర్ధారించబడింది. ఆర్డర్ id: " + orderId;
                        String text;
                        if (isTelugu) {
                            text = teluguText;
                        } else {
                            text = englishText;
                        }

                        BaseResponse response = bot.execute(
                                new SendMessage(update.getMessage().getChat().getId(), text));

                        // Show start order button
                        String englishButton = "Start!";
                        String teluguButton = "ప్రారంభించండి";
                        String buttonText;
                        if (isTelugu) {
                            buttonText = teluguButton;
                        } else {
                            buttonText = englishButton;
                        }
                        KeyboardButton button = new KeyboardButton(buttonText);
                        ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(button);

                        String englishKeyboardText = "Start your order";
                        String teluguKeyboardText = "మీ ఆర్డర్\u200Cను ప్రారంభించండి";
                        String keyboardText;
                        if (isTelugu) {
                            keyboardText = englishKeyboardText;
                        } else {
                            keyboardText = teluguKeyboardText;
                        }

                        // Show placeNewOrder keyboard
                        response = bot.execute(
                                new SendMessage(update.getMessage().getChat().getId(), keyboardText).replyMarkup(markupRequest));
                        telegramUserContext.setContext("order");
                        telegramService.save(telegramUserContext);
                        break;
                    }
                }

            } else if (update.getMessage().hasContact() &&
                    update.getMessage().getFrom().getId().equals(update.getMessage().getContact().getUserId())) {
                // Show 'start order' option
                String phoneNumber = update.getMessage().getContact().getPhoneNumber();
                // Clean the phone number as per Flytekart
                String countryCode = phoneNumber.substring(0, 2);
                phoneNumber = phoneNumber.substring(2);
                phoneNumber = "+" + countryCode + "-" + phoneNumber;
                Optional<EndUser> endUserOptional = userRepository.findByPhoneNumber(phoneNumber);
                if (endUserOptional.isEmpty()) {
                    KeyboardButton button = new KeyboardButton("Please click here to login with your phone number");
                    button.requestContact(true);
                    ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(button);

                    BaseResponse response = bot.execute(
                            new SendMessage(update.getMessage().getChat().getId(), "Please login through app first").replyMarkup(markupRequest));
                } else {
                    EndUser endUser = endUserOptional.get();
                    endUser.setTelegramChatId(update.getMessage().getChatId());
                    userRepository.save(endUser);

                    List<TelegramUserContext> telegramUserContexts = telegramUserContextRepository.findUnDeletedByUserId(endUser.getId());
                    if (telegramUserContexts.size() > 0) {
                        TelegramUserContext telegramUserContext = telegramUserContexts.get(0);
                        telegramUserContext.setContext("order");
                        telegramUserContext.setData(null);
                        telegramService.save(telegramUserContext);
                    }

                    // Show start order button
                    String englishButton = "Start!";
                    String teluguButton = "ప్రారంభించండి";
                    String buttonText;
                    if (isTelugu) {
                        buttonText = teluguButton;
                    } else {
                        buttonText = englishButton;
                    }
                    KeyboardButton button = new KeyboardButton(buttonText);
                    ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(button);

                    String englishText = "Start your order";
                    String teluguText = "మీ ఆర్డర్\u200Cను ప్రారంభించండి";
                    String text;
                    if (isTelugu) {
                        text = teluguText;
                    } else {
                        text = englishText;
                    }
                    BaseResponse response = bot.execute(
                            new SendMessage(update.getMessage().getChat().getId(), text).replyMarkup(markupRequest));
                }
            } else {
                // Show sign in option
                String englishButton = "Click here";
                String teluguButton = "ఇక్కడ నొక్కండి";
                KeyboardButton button = new KeyboardButton(teluguButton);
                button.requestContact(true);
                ReplyKeyboardMarkup markupRequest = new ReplyKeyboardMarkup(button);
                /*InlineKeyboardButton button1 = new InlineKeyboardButton("Enter phone number");
                button1.callbackData("callBackData");
                InlineKeyboardMarkup markup = new InlineKeyboardMarkup(button1);*/
                String englishText = "Please click below to login with your phone number";
                String teluguText = "దయచేసి మీ ఫోన్ నంబర్\u200Cతో లాగిన్ చేయడానికి దిగువ క్లిక్ చేయండి";

                BaseResponse response = bot.execute(
                        new SendMessage(update.getMessage().getChat().getId(), teluguText).replyMarkup(markupRequest));

            }
        }
        System.out.println(update.toString());
        System.out.println(clientId);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/createBot")
    public ResponseEntity<?> createBot(@RequestParam String clientId){
        DBContextHolder.setCurrentDb(clientId);
        // Check Telegram settings for the tokenId
        TelegramSettings telegramSettings = telegramService.getTelegramSettings();
        if (telegramSettings != null) {
            telegramService.addTelegramBot(clientId, telegramSettings.getTokenId());// "5072095659:AAEVyFZNkOi4bf7xDjN3e6efgGyAC66byeM"
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.badRequest().build();
        }

    }
}
