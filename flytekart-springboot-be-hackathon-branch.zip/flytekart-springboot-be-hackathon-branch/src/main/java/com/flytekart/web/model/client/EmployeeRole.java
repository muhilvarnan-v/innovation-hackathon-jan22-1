package com.flytekart.web.model.client;

import com.flytekart.web.model.common.DateAudit;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

// TODO May need to implement validation error responses like here - https://www.baeldung.com/spring-boot-bean-validation

@Entity
@Table(name = "EmployeeRole", schema = "public")
public class EmployeeRole extends DateAudit {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String id;
    @NotBlank
    @Size(max = 40)
    private String employeeId;
    @NotBlank
    @Size(max = 40)
    private String roleId;

    public EmployeeRole() {
    }

    public EmployeeRole(@NotBlank @Size(max = 40) String employeeId, @NotBlank @Size(max = 40) String roleId) {
        this.employeeId = employeeId;
        this.roleId = roleId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }
}
