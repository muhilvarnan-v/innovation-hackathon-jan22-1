package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.StoreCategory;
import com.flytekart.web.model.client.StoreVariant;
import com.flytekart.web.model.dto.CategoryStoreCategoryDTO;
import com.flytekart.web.model.dto.StoreCategoryDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StoreCategoryRepository extends JpaRepository<StoreCategory, String> {
    List<StoreCategory> findByStoreId(String storeId);

    @Query("from StoreCategory where id=:id")
    StoreCategory findByStoreCategoryId(String id);

    @Query("from StoreCategory where storeId=:storeId and categoryId=:categoryId")
    StoreCategory findByStoreIdAndCategoryId(String storeId, String categoryId);

    //@Query("from StoreCategory where storeId=:storeId and categoryId=:categoryId")
    @Query(value = "select sc.* from StoreCategory sc " +
            "inner join Category c on sc.categoryId = c.Id and c.name=:categoryName where storeId=:storeId",
            nativeQuery = true)
    List<StoreCategory> findByStoreIdAndCategoryName(String storeId, String categoryName);

    @Query("from StoreCategory where deletedBy IS NULL and storeId=:storeId")
    List<StoreCategory> findUndeletedByStoreId(String storeId);

    @Query(name = "StoreCategory.findUndeletedDTOByStoreId", nativeQuery = true)
    List<StoreCategoryDTO> findUndeletedDTOByStoreId(String storeId);

    @Query("from StoreCategory where deletedBy IS NULL")
    List<StoreCategory> findAllUndeleted();

    @Query("from StoreCategory where deletedBy IS NULL and categoryId=:categoryId")
    List<StoreCategory> findUndeletedByCategoryId(String categoryId);

    List<StoreCategory> findByCategoryId(String categoryId);

    /*@Query(
            value = "select new com.flytekart.web.model.dto.CategoryStoreCategoryDTO" +
                    "(c.id, c.name, c.parentCategoryId, c.isActive, sc.id)" +
                    " from Category c left join StoreCategory sc on sc.categoryId = c.id " +
                    "and sc.storeId=:storeId where c.isActive = true and c.deletedAt is null", nativeQuery = true
    )
    List<CategoryStoreCategoryDTO> findAllCategoriesWithStoreCategoriesByStoreId(String storeId);*/

    @Query(name = "StoreCategory.findAllCategoriesWithStoreCategoriesByStoreId", nativeQuery = true)
    List<CategoryStoreCategoryDTO> findAllCategoriesWithStoreCategoriesByStoreId(String storeId);
}
