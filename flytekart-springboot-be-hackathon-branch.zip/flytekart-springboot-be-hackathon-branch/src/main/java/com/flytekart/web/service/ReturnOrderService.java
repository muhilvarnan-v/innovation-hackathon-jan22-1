package com.flytekart.web.service;

import com.flytekart.web.model.client.*;
import com.flytekart.web.repository.client.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class ReturnOrderService {

    @Autowired
    private ReturnOrderRepository returnOrderRepository;

    @Autowired
    private ReturnOrderItemRepository returnOrderItemRepository;

    public List<ReturnOrderItem> getReturnOrderItemsByReturnOrderId(String returnOrderId) {
        List<ReturnOrderItem> returnOrderItems;
        if (StringUtils.hasText(returnOrderId)) {
            returnOrderItems =  returnOrderItemRepository.findUnDeletedByReturnOrderId(returnOrderId);
        } else {
            returnOrderItems = null;
        }
        return returnOrderItems;
    }

    public ReturnOrder getReturnOrderByReturnOrderId(String returnOrderId) {
        ReturnOrder returnOrder;
        if (StringUtils.hasText(returnOrderId)) {
            returnOrder =  returnOrderRepository.findUnDeletedByReturnOrderId(returnOrderId);
        } else {
            returnOrder = null;
        }
        return returnOrder;
    }

    public ReturnOrderItem getReturnOrderItemByReturnOrderItemId(String returnOrderItemId) {
        ReturnOrderItem returnOrderItem;
        if (StringUtils.hasText(returnOrderItemId)) {
            returnOrderItem =  returnOrderItemRepository.findUnDeletedByReturnOrderItemId(returnOrderItemId);
        } else {
            returnOrderItem = null;
        }
        return returnOrderItem;
    }

    public ReturnOrder save(ReturnOrder returnOrder) {
        returnOrderRepository.save(returnOrder);
        return returnOrder;
    }
}
