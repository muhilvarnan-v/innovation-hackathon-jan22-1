package com.flytekart.web.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VariantStoreVariantDTO {

    private String id;

    private String name;

    private String productId;

    private String sku;

    private Double price;

    private Double tax;

    private Double originalPrice;

    @JsonProperty(value = "isActive")
    private boolean isActive;

    private String storeVariantId;

    @JsonProperty(value = "storeVariantIsActive")
    private boolean storeVariantIsActive;

    private Double storeVariantPrice;

    private Double storeVariantTax;

    private Double storeVariantOriginalPrice;

    private Integer storeVariantQuantity;

    private String storeVariantDeletedAt;

    private String storeVariantDeletedBy;

    /*public VariantStoreVariantDTO(String id, String name, String productId, String sku, Double price, Double originalPrice,
                                  boolean isActive, String storeVariantId,
                                  Double storeVariantPrice, Double storeVariantOriginalPrice,
                                  String storeVariantDeletedAt, String storeVariantDeletedBy) {
        this.id = id;
        this.name = name;
        this.productId = productId;
        this.sku = sku;
        this.price = price;
        this.originalPrice = originalPrice;
        this.isActive = isActive;
        this.storeVariantId = storeVariantId;
        this.storeVariantIsActive = storeVariantIsActive;
        this.storeVariantPrice = storeVariantPrice;
        this.storeVariantOriginalPrice = storeVariantOriginalPrice;
        this.storeVariantDeletedAt = storeVariantDeletedAt;
        this.storeVariantDeletedBy = storeVariantDeletedBy;
    }*/

    public VariantStoreVariantDTO(String id, String name, String productId, String sku, Double price, Double tax,
                                  Double originalPrice, boolean isActive, String storeVariantId,
                                  Boolean storeVariantIsActive, Double storeVariantPrice, Double storeVariantTax,
                                  Double storeVariantOriginalPrice, Integer storeVariantQuantity,
                                  String storeVariantDeletedAt, String storeVariantDeletedBy) {
        this.id = id;
        this.name = name;
        this.productId = productId;
        this.sku = sku;
        this.price = price;
        this.tax = tax;
        this.originalPrice = originalPrice;
        this.isActive = isActive;
        this.storeVariantId = storeVariantId;
        this.storeVariantIsActive = storeVariantIsActive != null && storeVariantIsActive;
        this.storeVariantPrice = storeVariantPrice;
        this.storeVariantTax = storeVariantTax;
        this.storeVariantOriginalPrice = storeVariantOriginalPrice;
        this.storeVariantQuantity = storeVariantQuantity;
        this.storeVariantDeletedAt = storeVariantDeletedAt;
        this.storeVariantDeletedBy = storeVariantDeletedBy;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStoreVariantQuantity() {
        return storeVariantQuantity;
    }

    public void setStoreVariantQuantity(Integer storeVariantQuantity) {
        this.storeVariantQuantity = storeVariantQuantity;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public Double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(Double originalPrice) {
        this.originalPrice = originalPrice;
    }

    @JsonProperty(value = "isActive")
    public boolean isActive() {
        return isActive;
    }

    @JsonProperty(value = "isActive")
    public void setActive(boolean active) {
        isActive = active;
    }

    public String getStoreVariantId() {
        return storeVariantId;
    }

    public void setStoreVariantId(String storeVariantId) {
        this.storeVariantId = storeVariantId;
    }

    @JsonProperty(value = "storeVariantIsActive")
    public boolean isStoreVariantIsActive() {
        return storeVariantIsActive;
    }

    @JsonProperty(value = "storeVariantIsActive")
    public void setStoreVariantIsActive(boolean storeVariantIsActive) {
        this.storeVariantIsActive = storeVariantIsActive;
    }

    public Double getStoreVariantPrice() {
        return storeVariantPrice;
    }

    public void setStoreVariantPrice(Double storeVariantPrice) {
        this.storeVariantPrice = storeVariantPrice;
    }

    public Double getStoreVariantTax() {
        return storeVariantTax;
    }

    public void setStoreVariantTax(Double storeVariantTax) {
        this.storeVariantTax = storeVariantTax;
    }

    public Double getStoreVariantOriginalPrice() {
        return storeVariantOriginalPrice;
    }

    public void setStoreVariantOriginalPrice(Double storeVariantOriginalPrice) {
        this.storeVariantOriginalPrice = storeVariantOriginalPrice;
    }

    public String getStoreVariantDeletedAt() {
        return storeVariantDeletedAt;
    }

    public void setStoreVariantDeletedAt(String storeVariantDeletedAt) {
        this.storeVariantDeletedAt = storeVariantDeletedAt;
    }

    public String getStoreVariantDeletedBy() {
        return storeVariantDeletedBy;
    }

    public void setStoreVariantDeletedBy(String storeVariantDeletedBy) {
        this.storeVariantDeletedBy = storeVariantDeletedBy;
    }
}
