package com.flytekart.web.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class OTPVerify {
    private String phoneNumber;
    private String otp;

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getOTP() {
        return otp;
    }
}
