package com.flytekart.web.service;

import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.AttributeValue;
import com.flytekart.web.model.response.AttributeResponse;
import com.flytekart.web.repository.client.AttributeValueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;


@Service
public class AttributeValueService {

    @Autowired
    AttributeValueRepository attributeValueRepository;

    public List<AttributeValue> getAttributeValuesByAttributeId(String attributeId) {
        List<AttributeValue> attributeValues;
        if (StringUtils.hasText(attributeId)) {
            attributeValues = attributeValueRepository.findUnDeletedByAttributeId(attributeId);
        } else {
            attributeValues = attributeValueRepository.findAllUndeleted();
        }
        return attributeValues;
    }

    public List<AttributeResponse> getAllAttributeValues() {
        List<AttributeValue> attributeValues = attributeValueRepository.findAllUndeleted();
        List<AttributeResponse> attributeResponses = new ArrayList<>(10);
        for (AttributeValue attributeValue : attributeValues) {
            Attribute attribute = attributeValue.getAttribute();
            boolean matchFound = false;
            for (AttributeResponse attributeResponse : attributeResponses) {
                if (attributeResponse.getAttribute().getId().equals(attribute.getId())) {
                    matchFound = true;
                    if (attributeResponse.getAttributeValues() == null) {
                        attributeResponse.setAttributeValues(new ArrayList<>(10));
                    }
                    List<AttributeValue> subAttributeValues = attributeResponse.getAttributeValues();
                    subAttributeValues.add(attributeValue);
                    break;
                }
            }
            if (!matchFound) {
                AttributeResponse attributeResponse = new AttributeResponse();
                attributeResponse.setAttribute(attributeValue.getAttribute());
                List<AttributeValue> subAttributeValues = new ArrayList<>(10);
                attributeResponse.setAttributeValues(subAttributeValues);
                subAttributeValues.add(attributeValue);
                attributeResponses.add(attributeResponse);
            }
        }
        return attributeResponses;
    }

    public AttributeValue getAttributeValuesByAttributeIdAndName(String attributeId, String name) {
        AttributeValue attributeValue;
        if (StringUtils.hasText(attributeId) && StringUtils.hasText(name)) {
            List<AttributeValue> attributeValues = attributeValueRepository.findUnDeletedByAttributeIdAndName(attributeId, name);
            if (attributeValues != null && attributeValues.size() > 0) {
                attributeValue = attributeValues.get(0);
            } else {
                attributeValue = null;
            }
        } else {
            attributeValue = null;
        }
        return attributeValue;
    }

    public List<AttributeValue> getAttributeValueByAttributeIdAndPrefix(String attributeId, String prefix) {
        List<AttributeValue> attributeValues;
        if (StringUtils.hasText(attributeId)) {
            attributeValues =  attributeValueRepository
                    .findUnDeletedByPrefixIgnoreCaseContaining(attributeId, prefix);
        } else {
            attributeValues = null;
        }
        return attributeValues;
    }

    public AttributeValue getAttributeValueByAttributeValueId(String attributeValueId) {
        AttributeValue attributeValue;
        if (StringUtils.hasText(attributeValueId)) {
            attributeValue =  attributeValueRepository
                    .findUnDeletedByAttributeValueId(attributeValueId);
        } else {
            attributeValue = null;
        }
        return attributeValue;
    }

    public AttributeValue save(AttributeValue attributeValue) {
        attributeValueRepository.save(attributeValue);
        return attributeValue;
    }
}
