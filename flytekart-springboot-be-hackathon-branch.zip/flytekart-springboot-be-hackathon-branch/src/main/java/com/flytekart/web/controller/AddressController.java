package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.model.client.Address;
import com.flytekart.web.model.request.CreateAddressRequest;
import com.flytekart.web.model.response.ApiResponse;
import com.flytekart.web.repository.client.AddressRepository;
import com.flytekart.web.security.UserPrincipal;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {

    @Autowired
    private AddressRepository repository;

    // TODO Move this to AddressService
    public Address save(Address address) {
        return repository.save(address);
    }

    @PostMapping("/saveDeliveryAddress")
    @Transactional
    @PreAuthorize("isAuthenticated()") // Use PreAuthorize with roles after we implement Roles for Employees and Users
    public ResponseEntity<?> saveDeliveryAddress(@Valid @RequestBody CreateAddressRequest request,
                                                           @RequestParam String clientId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (request.getId() != null) {
            Optional<Address> managedAddressOptional = repository.findById(request.getId());
            if (managedAddressOptional.isPresent()) {
                Address managedAddress = managedAddressOptional.get();

                // Check access. If user is updating, the same user should have created the address
                if (managedAddress.getCreatedByResourceType().equalsIgnoreCase(Constants.USER)
                && !managedAddress.getCreatedBy().equals(principal.getId())) {
                    return ResponseEntity.notFound().build();
                }

                managedAddress.setLine1(request.getLine1());
                managedAddress.setLine2(request.getLine2());
                managedAddress.setCity(request.getCity());
                managedAddress.setState(request.getState());
                managedAddress.setCountry(request.getCountry());
                managedAddress.setZip(request.getZip());
                managedAddress.setLatitude(request.getLatitude());
                managedAddress.setLongitude(request.getLongitude());
                repository.save(managedAddress);
                return ResponseEntity.ok(new ApiResponse<>(200, managedAddress));
            } else {
                return ResponseEntity.notFound().build();
            }
        } else {
            Address address = new Address();
            address.setLine1(request.getLine1());
            address.setLine2(request.getLine2());
            address.setCity(request.getCity());
            address.setState(request.getState());
            address.setCountry(request.getCountry());
            address.setZip(request.getZip());
            address.setLatitude(request.getLatitude());
            address.setLongitude(request.getLongitude());
            repository.save(address);
            return ResponseEntity.ok(new ApiResponse<>(200, address));
        }
    }

    @Transactional
    @GetMapping("/getByUserId/{userId}")
    public ResponseEntity<?> getAddressListByUserId(@RequestParam String clientId,
                                                                   @PathVariable String userId) {
        DBContextHolder.setCurrentDb(clientId);
        UserPrincipal principal = (UserPrincipal) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();

        if (Constants.USER.equals(principal.getUserType()) && !principal.getId().equals(userId)) {
            return ResponseEntity.notFound().build();
        }

        List<Address> addressList = repository.findByUserId(userId);
        return ResponseEntity.ok(new ApiResponse<>(200, addressList));
    }
}
