package com.flytekart.web.telegram;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TelegramUserContextRepository extends JpaRepository<TelegramUserContext, String> {

    @Query("from TelegramUserContext where deletedBy IS NULL and userId=:userId")
    List<TelegramUserContext> findUnDeletedByUserId(String userId);
}
