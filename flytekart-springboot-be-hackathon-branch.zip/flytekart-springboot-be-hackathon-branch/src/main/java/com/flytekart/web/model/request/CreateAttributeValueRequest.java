package com.flytekart.web.model.request;

import com.flytekart.web.model.client.Attribute;
import com.flytekart.web.model.client.AttributeValue;

import javax.validation.constraints.Size;

public class CreateAttributeValueRequest {

    @Size(min = 1, max = 40)
    private String id;

    @Size(min = 1, max = 100)
    private String name;

    @Size(min = 1, max = 40)
    private String attributeId;

    public CreateAttributeValueRequest() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAttributeId() {
        return attributeId;
    }

    public void setAttributeId(String attributeId) {
        this.attributeId = attributeId;
    }

    public static AttributeValue getAttributeValue(CreateAttributeValueRequest requestBody) {
        Attribute attribute = new Attribute();
        attribute.setId(requestBody.getAttributeId());

        AttributeValue attributeValue = new AttributeValue();
        attributeValue.setName(requestBody.getName());
        attributeValue.setAttribute(attribute);

        return attributeValue;
    }

    public static AttributeValue getAttributeValue(CreateAttributeValueRequest request,
                                                   AttributeValue managedAttributeValue) {
        Attribute attribute = new Attribute();
        attribute.setId(request.getAttributeId());

        managedAttributeValue.setName(request.getName());
        managedAttributeValue.setAttribute(attribute);

        return managedAttributeValue;
    }
}
