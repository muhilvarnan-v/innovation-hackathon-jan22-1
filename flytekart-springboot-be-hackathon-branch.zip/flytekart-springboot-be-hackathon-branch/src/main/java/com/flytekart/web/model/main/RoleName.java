package com.flytekart.web.model.main;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_TEST
}
