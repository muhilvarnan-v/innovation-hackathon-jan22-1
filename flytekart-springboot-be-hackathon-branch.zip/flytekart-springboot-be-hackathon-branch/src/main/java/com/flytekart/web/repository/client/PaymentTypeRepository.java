package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.PaymentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentTypeRepository extends JpaRepository<PaymentType, String> {
    PaymentType findByName(String name);
}
