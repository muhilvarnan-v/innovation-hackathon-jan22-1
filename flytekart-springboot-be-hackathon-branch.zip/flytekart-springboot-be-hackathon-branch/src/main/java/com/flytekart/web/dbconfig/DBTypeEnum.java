package com.flytekart.web.dbconfig;

public enum DBTypeEnum {
    MAIN, CLIENT_A;
}
