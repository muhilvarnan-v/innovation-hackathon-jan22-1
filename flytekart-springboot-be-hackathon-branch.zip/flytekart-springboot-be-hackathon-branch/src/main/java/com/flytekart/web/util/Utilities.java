package com.flytekart.web.util;

// Importing Twilio packages
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
// import com.flytekart.web.util.Constants;

import org.apache.commons.lang3.RandomStringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Utilities {
    public static String getNewRandomString(int length) {
        return RandomStringUtils.random(length, true, true);
    }

    public static Message verifyPhoneNumber(String clientName, String toPhoneNumber,
                                            String accountSid, String authToken,
                                            String twilioPhoneNumber) {
        Twilio.init(accountSid, authToken);
		Message message = Message.creator(new PhoneNumber(toPhoneNumber),
			new PhoneNumber(twilioPhoneNumber),
			"OTP to complete the registration on ${clientName}").create();
		System.out.println(message.getSid());
		return message;
    }

    public static String getFormattedMoney(double moneyDouble) {
        BigDecimal bigDecimal = new BigDecimal(moneyDouble)
                .setScale(2, RoundingMode.HALF_UP);
        StringBuilder builder = new StringBuilder();
        builder.append(Constants.CURRENCY_RUPEE_PREFIX).append(Constants.SPACE).append(bigDecimal.toString());
        return builder.toString();
    }
}
