package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Otp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import java.util.Date;
import java.util.Optional;

@Repository
public interface OtpRepository extends JpaRepository<Otp, String> {
    @Query(value = "select * from Otp where mobileNumber=:mobileno and purpose=:purpose " +
    "and userType=:userType AND expiry > :expiry order by createdAt desc LIMIT 1", nativeQuery = true)
Otp findByMobileNoAndPurposeAndUserType(String mobileno, String purpose, String userType, Date expiry);
}