package com.flytekart.web.model.dto;

import java.util.Date;

public class UserReportDTO {
 
    private Date createdAt;

    private Integer total;


    public UserReportDTO(Date createdAt, Integer total) {
        this.createdAt = createdAt;
        this.total = total;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
}
