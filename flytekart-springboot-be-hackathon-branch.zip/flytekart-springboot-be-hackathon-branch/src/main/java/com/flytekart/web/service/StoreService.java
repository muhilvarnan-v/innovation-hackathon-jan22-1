package com.flytekart.web.service;

import com.flytekart.web.model.client.Address;
import com.flytekart.web.model.client.Store;
import com.flytekart.web.repository.client.AddressRepository;
import com.flytekart.web.repository.client.StoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class StoreService {

    @Autowired
    StoreRepository repository;

    public List<Store> getStoreByLatLng(double lat, double lng, int radius) {
        //List<Store> stores = repository.findAll();
        List<Store> stores = repository.findNearestByLatLng(lat, lng, radius);
        return stores;
    }

    public List<Store> getAllStores() {
        //List<Store> stores = repository.findAll();
        List<Store> stores = repository.findAllByOrderByNameAsc();
        return stores;
    }

    public Store getStoreByName(String name) {
        //List<Store> stores = repository.findAll();
        List<Store> stores = repository.findByName(name);
        Store store = null;
        if (stores != null && stores.size() > 0) {
            store = stores.get(0);
        }
        return store;
    }
}
