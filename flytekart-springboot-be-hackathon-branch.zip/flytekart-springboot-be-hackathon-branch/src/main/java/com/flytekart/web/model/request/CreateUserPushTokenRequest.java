package com.flytekart.web.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class CreateUserPushTokenRequest {
    @Size(min = 1, max = 40)
    private String id;

    @Size(min = 1, max = 40)
    @NotBlank(message = "User is required")
    private String userId;

    @Size(min = 1, max = 200)
    @NotBlank(message = "Push token is required")
    private String token;

    @Size(min = 1, max = 40)
    @NotBlank(message = "Client type is required")
    private String clientType;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }
}
