package com.flytekart.web.model.dto;

public class ProductOrderReportDTO {
 
    private String id;

    private String productName;

    private String variantName;

    private String categoryName;

    private Integer orderedQuantity;

    private Double orderedPrice;

    private Integer deliveredQuantity;

    private Double deliveredPrice;


    public ProductOrderReportDTO(String id, String productName, String variantName, String categoryName, Integer orderedQuantity,
                                    Double orderedPrice, Integer deliveredQuantity, Double deliveredPrice) {
        this.id = id;
        this.productName = productName;
        this.variantName = variantName;
        this.categoryName = categoryName;
        this.orderedQuantity = orderedQuantity;
        this.deliveredQuantity = deliveredQuantity;
        this.orderedPrice = orderedPrice;
        this.deliveredPrice = deliveredPrice;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getVariantName() {
        return variantName;
    }

    public void setVariantName(String variantName) {
        this.variantName = variantName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Integer getOrderedQuantity() {
        return orderedQuantity;
    }

    public void setOrderedQuantity(Integer orderedQuantity) {
        this.orderedQuantity = orderedQuantity;
    }

    public Integer getDeliveredQuantity() {
        return deliveredQuantity;
    }

    public void setStoreProductId(Integer deliveredQuantity) {
        this.deliveredQuantity = deliveredQuantity;
    }

    public Double getOrderedPrice() {
        return orderedPrice;
    }

    public void setOrderedPrice(Double orderedPrice) {
        this.orderedPrice = orderedPrice;
    }

    public Double getDeliveredPrice() {
        return deliveredPrice;
    }

    public void setDeliveredPrice(Double deliveredPrice) {
        this.deliveredPrice = deliveredPrice;
    }
}
