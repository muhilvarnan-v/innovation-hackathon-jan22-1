package com.flytekart.web.service;

import com.flytekart.web.model.client.Product;
import com.flytekart.web.model.client.StoreVariant;
import com.flytekart.web.repository.client.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;


@Service
public class ProductService {

    @Autowired
    ProductRepository productRepository;

    public Product getProductByProductId(String productId) {
        Product product;
        if (StringUtils.hasText(productId)) {
            product =  productRepository.findUnDeletedByProductId(productId);
        } else {
            product = null;
        }
        return product;
    }

    public Product getProductByCategoryIdAndProductName(String categoryId, String productName) {
        Product product;
        if (StringUtils.hasText(categoryId) && StringUtils.hasText(productName)) {
            product =  productRepository.findUnDeletedByCategoryIdAndProductName(categoryId, productName);
        } else {
            product = null;
        }
        return product;
    }

    public List<Product> getProductsByCategoryId(String categoryId) {
        List<Product> products;
        if (StringUtils.hasText(categoryId)) {
            products =  productRepository.findUnDeletedByCategoryId(categoryId);
        } else {
            products = productRepository.findAll();
        }
        return products;
    }

    public List<Product> getAllProducts() {
        List<Product> products = productRepository.findAll();
        return products;
    }

    public Product save(Product product) {
        productRepository.save(product);
        return product;
    }
}
