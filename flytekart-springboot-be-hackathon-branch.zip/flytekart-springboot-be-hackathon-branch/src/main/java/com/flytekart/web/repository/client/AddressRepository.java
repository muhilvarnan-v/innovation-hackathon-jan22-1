package com.flytekart.web.repository.client;

import com.flytekart.web.model.client.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AddressRepository extends JpaRepository<Address, String> {
    @Query("from Address where createdBy=:userId and createdByResourceType='User' order by createdAt desc")
    List<Address> findByUserId(String userId);

    @Query("from Address where id=:id and createdBy=:userId and createdByResourceType='User' order by createdAt desc")
    Address findByIdAndUserId(String id, String userId);
}
