package com.flytekart.web.controller;

import com.flytekart.web.dbconfig.DBContextHolder;
import com.flytekart.web.exception.ResourceNotFoundException;
import com.flytekart.web.model.client.Employee;
import com.flytekart.web.model.main.User;
import com.flytekart.web.model.main.UserProfile;
import com.flytekart.web.repository.client.EmployeeRepository;
import com.flytekart.web.repository.main.UserRepository;
import com.flytekart.web.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/employees/{username}")
    //@PreAuthorize("hasRole('USER')")
    //@PreAuthorize("hasRole('USER') && #username == authentication.name")
    public UserProfile getCurrentUser(@PathVariable("username") String username) {
        DBContextHolder.setCurrentDb(Constants.MAIN);
        Employee employee = employeeRepository.findByUsername(username).orElseThrow(() -> new ResourceNotFoundException("User", "username", username));
        return new UserProfile(employee.getId(), employee.getUsername(), employee.getName());
    }
}
