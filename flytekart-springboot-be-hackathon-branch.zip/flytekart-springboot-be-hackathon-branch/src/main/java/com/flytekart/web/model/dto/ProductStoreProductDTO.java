package com.flytekart.web.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductStoreProductDTO {

    private String id;

    private String name;

    private String categoryId;

    @JsonProperty(value = "isActive")
    private boolean isActive;

    private String storeProductId;

    private String storeProductDeletedAt;

    private String storeProductDeletedBy;

    public ProductStoreProductDTO(String id, String name, String categoryId, boolean isActive,
                                  String storeProductId, String storeProductDeletedAt, String storeProductDeletedBy) {
        this.id = id;
        this.name = name;
        this.categoryId = categoryId;
        this.isActive = isActive;
        this.storeProductId = storeProductId;
        this.storeProductDeletedAt = storeProductDeletedAt;
        this.storeProductDeletedBy = storeProductDeletedBy;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    @JsonProperty(value = "isActive")
    public boolean isActive() {
        return isActive;
    }

    @JsonProperty(value = "isActive")
    public void setActive(boolean active) {
        isActive = active;
    }

    public String getStoreProductId() {
        return storeProductId;
    }

    public void setStoreProductId(String storeProductId) {
        this.storeProductId = storeProductId;
    }

    public String getStoreProductDeletedAt() {
        return storeProductDeletedAt;
    }

    public void setStoreProductDeletedAt(String storeProductDeletedAt) {
        this.storeProductDeletedAt = storeProductDeletedAt;
    }

    public String getStoreProductDeletedBy() {
        return storeProductDeletedBy;
    }

    public void setStoreProductDeletedBy(String storeProductDeletedBy) {
        this.storeProductDeletedBy = storeProductDeletedBy;
    }
}
