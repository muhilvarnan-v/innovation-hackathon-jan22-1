let {
    languageMsg,
    welcomeMsg,
    electronicsCatalogue,
    mobileCatalogue,
    productById,
    multipleProductById,
    confirmationMsg,
    thanksMsg
} = require('./message');
let {
    generatePaymentLink,
    getProductByCatalogueId,
    nlpApi
} = require('./api');

let getProductInfo = async (orderDetails, productByCatalogueId) => {
    let productInfo = "";
    let totalAmt = 0;
    // console.log("productByCatalogueId", productByCatalogueId);
    for (let i = 0; i < orderDetails.productDetails.length; i++) {
        if (orderDetails.productDetails.length > 1) productInfo += `\n${i + 1}.`;
        let productDeatils = productByCatalogueId.filter((dataEach) => dataEach.retailer_id == orderDetails.productDetails[i].productId);
        productInfo += `*${(productDeatils && productDeatils[0] && productDeatils[0].name) ? productDeatils[0].name : orderDetails.productDetails[i].productId}*\n    Quantity: ${orderDetails.productDetails[i].quantity}\n    Price: ${orderDetails.productDetails[i].currency == "INR" ? "₹" : orderDetails.productDetails[i].currency} ${orderDetails.productDetails[i].price}`;
        totalAmt += parseFloat(orderDetails.productDetails[i].price);
    };
    if (orderDetails.productDetails.length > 1) productInfo += `\n\nTotal: ${totalAmt}`;
    return productInfo;
};

let getIntents = async (products) => {
    let intendsData = [
        {
            "intent": "hi",
            "variations": [
                {
                    "variation": "Hello"
                },
                {
                    "variation": "Hey"
                },
                {
                    "variation": "Hi"
                },
                {
                    "variation": "नमस्ते"
                }
            ]
        },
        {
            "intent": "main menu",
            "variations": [
                {
                    "variation": "मुख्य मेनू"
                },
                {
                    "variation": "Main menu"
                },
                {
                    "variation": "Main"
                },
                {
                    "variation": "Menu"
                },
                {
                    "variation": "मुख्य"
                },
                {
                    "variation": "मेनू"
                }
            ]
        },
        {
            "intent": "Change Language",
            "variations": [
                {
                    "variation": "Language Change"
                },
                {
                    "variation": "Language"
                },
                {
                    "variation": "भाषा बदलो"
                },
                {
                    "variation": "भाषा"
                },
                {
                    "variation": "बदलो भाषा"
                }
            ]
        },
        {
            "intent": "Laptop",
            "variations": [
                {
                    "variation": "Laptop"
                },
                {
                    "variation": "Laptops"
                },
                {
                    "variation": "लैपटॉप"
                }
            ]
        },
        {
            "intent": "Watch",
            "variations": [
                {
                    "variation": "Watch"
                },
                {
                    "variation": "Watches"
                },
                {
                    "variation": "घड़ियाँ"
                }
            ]
        },
        {
            "intent": "Mobile",
            "variations": [
                {
                    "variation": "Mobile"
                },
                {
                    "variation": "Mobiles"
                },
                {
                    "variation": "मोबाइल"
                }
            ]
        },
        {
            "intent": "Headphone",
            "variations": [
                {
                    "variation": "Headphone"
                },
                {
                    "variation": "Headphones"
                },
                {
                    "variation": "हेडफोन"
                }
            ]
        }
    ];
    for (let i = 0; i < products.length; i++) {
        intendsData.push({
            "intent": products[i].name,
            "variations": [
                {
                    "variation": products[i].name
                }
            ]
        });
    }
    // console.log("intendsData", intendsData)
    return intendsData;
};

let newMsgResponse = async (msg, products, language, sender) => {
    let repMsg = "";
    let product = products.filter((dataEach) => dataEach.name == msg);
    if (product && product.length && product[0] && product[0].retailer_id && language && sender) {
        repMsg = productById(language, sender, product[0].retailer_id);
    } else if (msg == "Change Language") {
        repMsg = languageMsg;
    } else if (msg == "Laptop") {
        repMsg = language == "english" ? await multipleProductById(language, sender, "Laptops", ["LAPTOP001", "LAPTOP002"]) : await multipleProductById(language, sender, "लैपटॉप", ["LAPTOP001_H", "LAPTOP002_H"]);
    } else if (msg == "Watch") {
        repMsg = language == "english" ? await multipleProductById(language, sender, "Watches", ["WATCH001", "WATCH002"]) : await multipleProductById(language, sender, "घड़ियाँ", ["WATCH001_H", "WATCH002_H"]);
    } else if (msg == "Mobile") {
        repMsg = language == "english" ? await multipleProductById(language, sender, "Mobiles", ["MOBILE0001"]) : await multipleProductById(language, sender, "मोबाइल", ["MOBILE0001_H"]);
    } else if (msg == "Headphone") {
        repMsg = language == "english" ? await multipleProductById(language, sender, "Headphones", ["HEADPHONE001", "HEADPHONE002"]) : await multipleProductById(language, sender, "हेडफोन", ["HEADPHONE001_H", "HEADPHONE002_H"]);
    } else {
        repMsg = language ? welcomeMsg[language] : languageMsg;
    }
    return repMsg;
};

module.exports = {
    getProductInfo,
    getIntents,
    newMsgResponse
};