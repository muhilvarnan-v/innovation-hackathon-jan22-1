let CATALOGUEID = "";

let languageMsg = {
    "type": "quick_reply",
    "msgid": "languageMsg",
    "content": {
        "type": "text",
        "header": "",
        "text": "Please select your language preference 👇\nकृपया अपनी भाषा वरीयता चुनें 👇",
        "caption": ""
    },
    "options": [
        {
            "type": "text",
            "title": "English"
        },
        {
            "type": "text",
            "title": "हिन्दी"
        }
    ]
};

let welcomeMsg = {
    "english": {
        "type": "quick_reply",
        "msgid": "welcomeMsg",
        "content": {
            "type": "text",
            "header": "Flash Sale 💥 💥 !!",
            "text": "We have exciting deals and discounts. Don't miss it out.😱🤯.\n\nShop for your family and friends and bring a smile on their face 🛍️🤩",
            "caption": "💡 If you ever want to start over, send us a 'hi' message"
        },
        "options": [
            {
                "type": "text",
                "title": "Electronics"
            },
            {
                "type": "text",
                "title": "Mobile"
            },
            {
                "type": "text",
                "title": "Change Language"
            }
        ]
    },
    "hindi": {
        "type": "quick_reply",
        "msgid": "welcomeMsg",
        "content": {
            "type": "text",
            "header": "फ्लैश सेल 💥 💥 !!",
            "text": "हमारे पास रोमांचक सौदे और छूट हैं। इसे मिस न करें।😱🤯.\n\nअपने परिवार और दोस्तों के लिए खरीदारी करें और उनके चेहरे पर मुस्कान लाएं 🛍️🤩\n\n_💡 यदि आप कभी भी शुरुआत करना चाहते हैं, तो हमें एक 'नमस्ते' संदेश भेजें_",
            "caption": ""
        },
        "options": [
            {
                "type": "text",
                "title": "इलेक्ट्रानिक्स"
            },
            {
                "type": "text",
                "title": "मोबाइल"
            },
            {
                "type": "text",
                "title": "भाषा बदलो"
            }
        ]
    }
};

let electronicsCatalogue = (language, sender) => {
    let repMsg = {
        "english": {
            "type": "product_details",
            "subType": "product_list",
            "catalogId": CATALOGUEID,
            "productId": "",
            "destination": sender,
            "body": {
                "text": "Spread happiness this Flash Sale 🎉​🧨​🎆​ Shop Now !!"
            },
            "header": {
                "type": "text",
                "text": "Great saving opportunity"
            },
            "footer": {
                "text": "Buy Now"
            },
            "sections": [
                {
                    "title": "Laptops",
                    "productList": [
                        {
                            "productId": "LAPTOP001"
                        },
                        {
                            "productId": "LAPTOP002"
                        }
                    ]
                },
                {
                    "title": "Headphones",
                    "productList": [
                        {
                            "productId": "HEADPHONE001"
                        },
                        {
                            "productId": "HEADPHONE002"
                        }
                    ]
                },
                {
                    "title": "Watches",
                    "productList": [
                        {
                            "productId": "WATCH001"
                        },
                        {
                            "productId": "WATCH002"
                        }
                    ]
                }
            ]
        },
        "hindi": {
            "type": "product_details",
            "subType": "product_list",
            "catalogId": CATALOGUEID,
            "productId": "",
            "destination": sender,
            "body": {
                "text": "इस फ्लैश सेल में खुशियां फैलाएं 🎉​🧨​🎆​ अभी खरीदारी करें !!"
            },
            "header": {
                "type": "text",
                "text": "बचत का बढ़िया मौका"
            },
            "footer": {
                "text": "अभी खरीदें"
            },
            "sections": [
                {
                    "title": "लैपटॉप",
                    "productList": [
                        {
                            "productId": "LAPTOP001_H"
                        },
                        {
                            "productId": "LAPTOP002_H"
                        }
                    ]
                },
                {
                    "title": "हेडफोन",
                    "productList": [
                        {
                            "productId": "HEADPHONE001_H"
                        },
                        {
                            "productId": "HEADPHONE002_H"
                        }
                    ]
                },
                {
                    "title": "घड़ियाँ",
                    "productList": [
                        {
                            "productId": "WATCH001_H"
                        },
                        {
                            "productId": "WATCH002_H"
                        }
                    ]
                }
            ]
        }
    };
    return repMsg[language];
};

let mobileCatalogue = (language, sender) => {
    let repMsg = {
        "english": {
            "type": "product_details",
            "subType": "product",
            "catalogId": CATALOGUEID,
            "destination": sender,
            "productId": "MOBILE0001",
            "body": {
                "text": "We have exciting deals and discounts this Flash Sale.😱🤯"
            },
            "footer": {
                "text": "Don't miss it out."
            }
        },
        "hindi": {
            "type": "product_details",
            "subType": "product",
            "catalogId": CATALOGUEID,
            "destination": sender,
            "productId": "MOBILE0001_H",

            "body": {
                "text": "इस फ्लैश सेल में हमारे पास रोमांचक सौदे और छूट हैं।😱🤯"
            },
            "footer": {
                "text": "इसे मिस न करें।"
            }
        }
    };
    return repMsg[language];
};

let productById = (language, sender, productId) => {
    let repMsg = {
        "english": {
            "type": "product_details",
            "subType": "product",
            "catalogId": CATALOGUEID,
            "destination": sender,
            "productId": productId,
            "body": {
                "text": "Please click below to know more about the product 👇"
            },
            "footer": {
                "text": ""
            }
        },
        "hindi": {
            "type": "product_details",
            "subType": "product",
            "catalogId": CATALOGUEID,
            "destination": sender,
            "productId": productId,

            "body": {
                "text": "उत्पाद के बारे में अधिक जानने के लिए कृपया नीचे क्लिक करें 👇"
            },
            "footer": {
                "text": ""
            }
        }
    };
    return repMsg[language];
};

let multipleProductById = (language, sender, title, productIds) => {
    let repMsg = {
        "english": {
            "type": "product_details",
            "subType": "product_list",
            "catalogId": CATALOGUEID,
            "productId": "",
            "destination": sender,
            "body": {
                "text": "Please click below to know more about the product 👇"
            },
            "header": {
                "type": "text",
                "text": "Great saving opportunity"
            },
            "footer": {
                "text": "Buy Now"
            },
            "sections": [
                {
                    "title": title,
                    "productList": [
                    ]
                }
            ]
        },
        "hindi": {
            "type": "product_details",
            "subType": "product_list",
            "catalogId": CATALOGUEID,
            "productId": "",
            "destination": sender,
            "body": {
                "text": "उत्पाद के बारे में अधिक जानने के लिए कृपया नीचे क्लिक करें 👇"
            },

            "header": {
                "type": "text",
                "text": "बचत का बढ़िया मौका"
            },
            "footer": {
                "text": "अभी खरीदें"
            },
            "sections": [
                {
                    "title": title,
                    "productList": [
                    ]
                }
            ]
        }
    };
    for (let i = 0; i < productIds.length; i++) {
        repMsg[language].sections[0].productList.push({
            "productId": productIds[i]
        });
    }
    return repMsg[language];
};

let confirmationMsg = (language, productInfo) => {
    let repMsg = {
        "english": {
            "type": "quick_reply",
            "msgid": "confirmationMsg",
            "content": {
                "type": "text",
                "header": "You are almost there!!",
                "text": `Product Details:\n${productInfo}\n\nPlease *confirm* if you would like to buy 🤩🤩?`,
                "caption": ""
            },
            "options": [
                {
                    "type": "text",
                    "title": "Confirm"
                },
                {
                    "type": "text",
                    "title": "Main menu"
                }
            ]
        },
        "hindi": {
            "type": "quick_reply",
            "msgid": "confirmationMsg",
            "content": {
                "type": "text",
                "header": "आप लगभग वहाँ हैं!!",
                "text": `उत्पाद विवरण:\n${productInfo}\n\nकृपया *पुष्टि करें* यदि आप खरीदना चाहते हैं 🤩🤩?`,
                "caption": ""
            },
            "options": [
                {
                    "type": "text",
                    "title": "पुष्टि"
                },
                {
                    "type": "text",
                    "title": "मुख्य मेनू"
                }
            ]
        }
    };
    return repMsg[language];
};

let thanksMsg = (language, link) => {
    let repMsg = {
        "english": {
            "type": "quick_reply",
            "msgid": "thanksMsg",
            "content": {
                "type": "text",
                "header": "",
                "text": `Please click on the below link to buy 👇🏻 !!\n\n${link}`,
                "caption": ""
            },
            "options": [
                {
                    "type": "text",
                    "title": "Main menu"
                }
            ]
        },
        "hindi": {
            "type": "quick_reply",
            "msgid": "thanksMsg",
            "content": {
                "type": "text",
                "header": "",
                "text": `खरीदने के लिए कृपया नीचे दिए गए लिंक पर क्लिक करें 👇🏻 !!\n\n${link}`,
                "caption": ""
            },
            "options": [
                {
                    "type": "text",
                    "title": "मुख्य मेनू"
                }
            ]
        }
    };
    return repMsg[language];
};


module.exports = {
    languageMsg,
    welcomeMsg,
    electronicsCatalogue,
    mobileCatalogue,
    productById,
    multipleProductById,
    confirmationMsg,
    thanksMsg
};