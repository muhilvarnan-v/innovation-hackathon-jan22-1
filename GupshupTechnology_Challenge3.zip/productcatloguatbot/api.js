var axios = require('axios');
let ACESSTOKEN = "";
let PAYEEACCOUNT = "";
let CLIENTID = "";
let CLIENTSECRET = "";
let MODULESECRET = "";
let PROVIDERSECRET = "";
let APIKEY = ""

let getProductByCatalogueId = async (catalogueId) => {
    var config = {
        method: 'get',
        url: `https://graph.facebook.com/v12.0/${catalogueId}/products?access_token=${ACESSTOKEN}`,
        headers: {}
    };

    return await axios(config)
        .then(function (response) {
            console.log("Catalogue API response: ", JSON.stringify(response.data));
            if (response.data && response.data.data && response.data.data.length) {
                return response.data.data;
            } else {
                return "";
            }
        })
        .catch(function (error) {
            console.log("Catalogue API response: ", error);
            return "";
        });
};

let generatePaymentLink = async (amount) => {
    var data = JSON.stringify({
        "reference_id": new Date().getTime().toString(),
        "payee_account": PAYEEACCOUNT,
        "amount": amount,
        "purpose_message": "Payment",
        "generate_qr": 0,
        "expiry_time": 30,
        "customized_qr_with_logo": 1
    });

    var config = {
        method: 'post',
        url: 'https://in.decentro.tech/v2/payments/upi/link',
        headers: {
            'client_id': CLIENTID,
            'client_secret': CLIENTSECRET,
            'module_secret': MODULESECRET,
            'provider_secret': PROVIDERSECRET,
            'Content-Type': ' application/json'
        },
        data: data
    };

    return await axios(config)
        .then(function (response) {
            console.log("payment API response: ", JSON.stringify(response.data));
            if (response.data && response.data.data && response.data.data.generatedLink) {
                return response.data.data.generatedLink;
            } else {
                return "";
            }
        })
        .catch(function (error) {
            console.log("payment API response: ", error);
            return "";
        });
};

let nlpApi = async (data) => {
    var config = {
        method: 'post',
        url: 'https://api.gupshup.io/sm/api/v1/nlp/nlponthefly',
        headers: {
            'apikey': APIKEY,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: data
    };

    return await axios(config)
        .then(function (response) {
            console.log("nlpApi API response: ", JSON.stringify(response.data));
            if (response.data && response.data[0] && response.data[0].topIntents && response.data[0].topIntents[0] && response.data[0].topIntents[0].intent) {
                return response.data[0].topIntents[0].intent;
            } else {
                return "";
            }
        })
        .catch(function (error) {
            console.log("nlpApi API response: ", error);
            return "";
        });
};

module.exports = {
    generatePaymentLink,
    getProductByCatalogueId,
    nlpApi
};