const botScriptExecutor = require('bot-script').executor;
const scr_config = require('./scr_config.json');
let CATALOGUEID = "";
let {
    languageMsg,
    welcomeMsg,
    electronicsCatalogue,
    mobileCatalogue,
    productById,
    multipleProductById,
    confirmationMsg,
    thanksMsg
} = require('./message');
let {
    getProductInfo,
    newMsgResponse,
    getIntents
} = require('./utilities');
let {
    generatePaymentLink,
    getProductByCatalogueId,
    nlpApi
} = require('./api');

async function MessageHandler(context, event) {
    let msg = event.message;
    let msgId = event.messageobj.refmsgid;
    let repMsg = "";
    if (event.messageobj.type == "event" || typeof (msg) == "string" && (msg == "नमस्ते" || msg.toLowerCase() == "hi" || msg.toLowerCase() == "restart")) {
        repMsg = languageMsg;
        context.sendResponse(JSON.stringify(repMsg));
    }
    else if (msgId == "languageMsg") {
        let language = msg && msg.includes("English") ? "english" : (msg.includes("हिन्दी") ? "hindi" : null);
        repMsg = welcomeMsg[language];
        context.simpledb.roomleveldata.language = language;
        context.sendResponse(JSON.stringify(repMsg));
    }
    else if (msg && typeof (msg) == "string" && (msg.startsWith("मुख्य मेनू") || msg.toLowerCase().startsWith("main menu"))) {
        repMsg = welcomeMsg[context.simpledb.roomleveldata.language];
        context.sendResponse(JSON.stringify(repMsg));
    }
    else if (msgId == "welcomeMsg") {
        if (msg.startsWith("Electronics") || msg.startsWith("इलेक्ट्रानिक्स")) repMsg = electronicsCatalogue(context.simpledb.roomleveldata.language, event.sender.split(":")[1]);
        else if (msg.startsWith("Mobile") || msg.startsWith("मोबाइल")) repMsg = mobileCatalogue(context.simpledb.roomleveldata.language, event.sender.split(":")[1]);
        else if (msg.startsWith("Change Language") || msg.startsWith("भाषा बदलो")) repMsg = languageMsg;
        context.sendResponse(JSON.stringify(repMsg));
    } else if (msgId == "confirmationMsg") {
        if (msg.startsWith("Confirm") || msg.startsWith("पुष्टि")) {
            let amount = 1;
            let link = await generatePaymentLink(amount);
            repMsg = thanksMsg(context.simpledb.roomleveldata.language, link);
        } else {
            repMsg = welcomeMsg[context.simpledb.roomleveldata.language];
        }
        context.sendResponse(JSON.stringify(repMsg));
    } else {
        if (event.messageobj.orderDetails) {
            // console.log("orderDetails : "+JSON.stringify(event.messageobj));
            let productByCatalogueId = await getProductByCatalogueId(event.messageobj.orderDetails.catalogId);
            let productInfo = await getProductInfo(event.messageobj.orderDetails, productByCatalogueId);
            repMsg = confirmationMsg(context.simpledb.roomleveldata.language, productInfo);
            context.simpledb.roomleveldata.products = productByCatalogueId;
            context.sendResponse(JSON.stringify(repMsg));
        } else if (event.messageobj.productInformation) {
            // console.log("productInformation : "+JSON.stringify(event.messageobj));
            repMsg = productById(context.simpledb.roomleveldata.language, event.sender.split(":")[1], event.messageobj.productInformation.productId);
            context.sendResponse(JSON.stringify(repMsg));
        } else {
            let products = context.simpledb.roomleveldata.products ? context.simpledb.roomleveldata.products : await getProductByCatalogueId(CATALOGUEID);
            let param = {
                "queries": [msg.toLocaleString()],
                "intents": await getIntents(products)
            }
            let data = ('data=' + encodeURIComponent(JSON.stringify(param))).toLocaleString();
            let newMsg = await nlpApi(data);
            if (newMsg) {
                repMsg = await newMsgResponse(newMsg, products, context.simpledb.roomleveldata.language, event.sender.split(":")[1]);
            } else if (context.simpledb.roomleveldata.language) {
                repMsg = welcomeMsg[context.simpledb.roomleveldata.language];
            } else {
                repMsg = languageMsg;
            }
            context.sendResponse(JSON.stringify(repMsg));
        }
    }
}

function EventHandler(context, event) {
    context.simpledb.roomleveldata = {};
    MessageHandler(context, event);
}

function ScriptHandler(context, event) {
    let options = Object.assign({}, scr_config);
    options.current_dir = __dirname;
    options.default_message = "Sorry I am young and still learning. I am unable to understand your query.";
    // You can add any start point by just mentioning the <script_file_name>.<section_name>
    options.start_section = "script.main";
    options.success = function (opm) {
        //context.sendResponse(a);
        context.sendResponse(JSON.stringify(opm));
    };
    options.error = function (err) {
        context.console.log(err.stack);
        context.sendResponse("Sorry Some error occurred.");
    };
    botScriptExecutor.execute(options, event, context);
}

function HttpResponseHandler(context, event) {
    if (event.geturl === "http://ip-api.com/json")
        context.sendResponse('This is response from http \n' + JSON.stringify(event.getresp, null, '\t'));
}

function DbGetHandler(context, event) {
    context.sendResponse("testdbput keyword was last sent by:" + JSON.stringify(event.dbval));
}

function DbPutHandler(context, event) {
    context.sendResponse("testdbput keyword was last sent by:" + JSON.stringify(event.dbval));
}

function HttpEndpointHandler(context, event) {
    context.sendResponse('This is response from http \n' + JSON.stringify(event, null, '\t'));
}

function LocationHandler(context, event) {
    context.sendResponse("Got location");
}

exports.onMessage = MessageHandler;
exports.onEvent = EventHandler;
exports.onHttpResponse = HttpResponseHandler;
exports.onDbGet = DbGetHandler;
exports.onDbPut = DbPutHandler;
if (typeof LocationHandler == 'function') {
    exports.onLocation = LocationHandler;
}
if (typeof HttpEndpointHandler == 'function') {
    exports.onHttpEndpoint = HttpEndpointHandler;
}
