package com.flytekart.customer.ui.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.Address;
import com.flytekart.customer.models.OrderItem;
import com.flytekart.customer.models.Payment;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.models.response.OrderResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;

import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

public class OrderDetailsActivity extends AppCompatActivity implements View.OnClickListener {

    private OrderResponse orderResponse;
    private String accessToken;

    private TextView tvStoreName;
    private TextView tvStoreAddress;
    private TextView tvDeliveryAddress;
    private LinearLayout llItems;
    private TextView tvSubTotal;
    private TextView tvTax;
    private TextView tvTotal;
    private TextView tvOrderStatus;
    private TextView tvPaymentType;
    private TextView tvPaid;
    private TextView tvBalance;
    private LinearLayout llCustomerDetails;
    private LayoutInflater layoutInflater;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);

        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(R.string.order_details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        tvStoreName = findViewById(R.id.tv_store_name);
        tvStoreAddress = findViewById(R.id.tv_store_address);
        tvDeliveryAddress = findViewById(R.id.tv_delivery_address);
        llItems = findViewById(R.id.ll_items);
        tvSubTotal = findViewById(R.id.tv_sub_total);
        tvTax = findViewById(R.id.tv_tax);
        tvTotal = findViewById(R.id.tv_total);
        tvOrderStatus = findViewById(R.id.tv_order_status);
        tvPaymentType = findViewById(R.id.tv_payment_type);
        tvPaid = findViewById(R.id.tv_paid);
        tvBalance = findViewById(R.id.tv_balance);
        llCustomerDetails = findViewById(R.id.ll_customer_details);
        layoutInflater = LayoutInflater.from(this);

        orderResponse = getIntent().getParcelableExtra(Constants.ORDER);

        SharedPreferences sharedPreferences = Utilities.getSharedPreferences();
        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, Constants.EMPTY);

        getData();
    }

    private void setDeliveryAddressToUI() {
        Address deliveryAddress = orderResponse.getOrder().getDeliveryAddress();
        StringBuilder builder = new StringBuilder();
        builder.append(deliveryAddress.getLine1()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getLine2()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getCity()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getState()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getCountry()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getZip());
        tvDeliveryAddress.setText(builder.toString());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setPaidAndBalanceToUI() {
        double paid = 0;
        if (orderResponse.getPayments() != null) {
            for (Payment payment : orderResponse.getPayments()) {
                if (payment.getPaymentStatus().getName().equalsIgnoreCase(Constants.PaymentStatus.PAID)) {
                    paid = paid + payment.getAmount();
                }
            }
        }
        double balance = orderResponse.getOrderTotal().getTotal() - paid;
        tvPaid.setText(String.valueOf(paid));
        tvBalance.setText(String.valueOf(balance));
        if (orderResponse.getPayments().size() == 0) {
            tvPaymentType.setText(Constants.EMPTY);
        } else if (orderResponse.getPayments().size() == 1) {
            tvPaymentType.setText(orderResponse.getPayments().get(0).getPaymentType().getName());
        } else {
            tvPaymentType.setText(Constants.MULTIPLE);
        }
    }

    private void getData() {
        showProgress(true);
        Call<BaseResponse<OrderResponse>> getOrderByIdCall = Flytekart.getApiService().getOrderById(accessToken, orderResponse.getOrder().getId(), BuildConfig.CLIENT_ID);
        getOrderByIdCall.enqueue(new CustomCallback<BaseResponse<OrderResponse>>() {
            @Override
            public void onFlytekartGenericErrorResponse(Call<BaseResponse<OrderResponse>> call) {
                Logger.e("Order List API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<OrderResponse>> call, Response<BaseResponse<OrderResponse>> response) {
                Logger.e("Order API success");
                showProgress(false);
                orderResponse = response.body().getBody();
                setOrderDetails();
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<OrderResponse>> call, APIError responseBody) {
                Logger.e("Order API call  response status code : " + responseBody.getStatus());
                showProgress(false);
                Toast.makeText(getApplicationContext(), responseBody.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setOrderDetails() {
        if (this.orderResponse != null) {
            tvStoreName.setText(orderResponse.getOrder().getStore().getName());

            Address storeAddress = orderResponse.getOrder().getStore().getAddress();
            StringBuilder builder = new StringBuilder();
            builder.append(storeAddress.getLine1()).append(Constants.COMMA_SPACE);
            builder.append(storeAddress.getLine2()).append(Constants.COMMA_SPACE);
            builder.append(storeAddress.getCity()).append(Constants.COMMA_SPACE);
            builder.append(storeAddress.getState()).append(Constants.COMMA_SPACE);
            builder.append(storeAddress.getCountry()).append(Constants.COMMA_SPACE);
            builder.append(storeAddress.getZip());
            tvStoreAddress.setText(builder.toString());

            // TODO Run a loop to fill llItems
            setItemsData();

            tvSubTotal.setText(Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotalPrice()));
            tvTax.setText(Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotalTax()));
            tvTotal.setText(Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal()));

            tvOrderStatus.setText(Utilities.getFormattedOrderStatus(orderResponse.getOrder().getOrderStatus().getName()));
            // TODO How to handle order cancellations from user side?
            /*if (orderResponse.getOrder().getOrderStatus().getName().equalsIgnoreCase("DELIVERED") ||
                    orderResponse.getOrder().getOrderStatus().getName().equalsIgnoreCase("IN_PROGRESS") ||
                    orderResponse.getOrder().getOrderStatus().getName().equalsIgnoreCase("CANCELED")) {
                tvUpdateOrderStatus.setVisibility(View.GONE);
            } else {
                tvUpdateOrderStatus.setVisibility(View.VISIBLE);
                tvUpdateOrderStatus.setOnClickListener(this);
            }*/
            llCustomerDetails.setOnClickListener(this);

            setDeliveryAddressToUI();
            setPaidAndBalanceToUI();
        }
    }

    private void setItemsData() {
        List<OrderItem> orderItems = orderResponse.getOrderItems();
        for (OrderItem orderItem : orderItems) {
            View v = layoutInflater.inflate(R.layout.list_item_order_item, null);

            TextView tvItemName = v.findViewById(R.id.tv_item_name);
            TextView tvVariantName = v.findViewById(R.id.tv_variant_name);
            TextView tvQuantity = v.findViewById(R.id.tv_quantity);
            TextView tvItemPrice = v.findViewById(R.id.tv_item_price);
            TextView tvCategoryName = v.findViewById(R.id.tv_category_name);

            tvItemName.setText(orderItem.getStoreVariant().getVariant().getProduct().getName());
            tvVariantName.setText(orderItem.getStoreVariant().getVariant().getName());
            tvQuantity.setText(String.valueOf(orderItem.getQuantity()));
            tvItemPrice.setText(Utilities.getFormattedMoney(orderItem.getTotalPrice()));
            tvCategoryName.setText(orderItem.getStoreVariant().getVariant().getProduct().getCategory().name);

            llItems.addView(v);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}