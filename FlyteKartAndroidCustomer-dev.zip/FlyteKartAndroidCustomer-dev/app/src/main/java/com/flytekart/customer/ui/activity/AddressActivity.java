package com.flytekart.customer.ui.activity;

import android.os.Bundle;

import androidx.annotation.Nullable;

import com.flytekart.customer.R;

public class AddressActivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
    }
}
