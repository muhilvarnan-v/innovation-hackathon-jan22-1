package com.flytekart.customer.ui.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.UserDetails;
import com.flytekart.customer.models.UserPushToken;
import com.flytekart.customer.models.request.CreateUserPushTokenRequest;
import com.flytekart.customer.models.request.VerifyOTPRequest;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.models.response.LoginResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.SmsBroadcastReceiver;
import com.flytekart.customer.utils.Utilities;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Response;

// TODO Learn about feature on feature dependencies
public class OTPVerificationActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etPhoneNumber;
    private EditText etPassword;
    private TextView tvForgotPassword;
    private ProgressDialog progressDialog;
    private SharedPreferences sharedPreferences;
    private SmsBroadcastReceiver smsBroadcastReceiver;
    private final int REQ_USER_CONSENT = 1000;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);
        setStatusBackgroundColor();
        hideActionBar();

        findViewById(R.id.tv_login).setOnClickListener(this);
        findViewById(R.id.tv_sign_up).setOnClickListener(this);
        etPhoneNumber = findViewById(R.id.et_phone_number);
        etPassword = findViewById(R.id.et_password);
        tvForgotPassword = findViewById(R.id.tv_forgot_password);
        tvForgotPassword.setPaintFlags(tvForgotPassword.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        String usernameExtra = getIntent().getStringExtra(Constants.USERNAME);
        etPhoneNumber.setText(usernameExtra);
        sharedPreferences = Utilities.getSharedPreferences();

        etPassword.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(etPassword.getWindowToken(), 0);
                checkInputAndVerifyOTP();
            }
            return true;
        });

        startSmsUserConsent();
    }

    private void setStatusBackgroundColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black_transparent));
        }
    }

    private void hideActionBar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_login: {
                checkInputAndVerifyOTP();
                break;
            }
            case R.id.tv_sign_up: {
                Intent signUpIntent = new Intent(OTPVerificationActivity.this, SignUpActivity.class);
                startActivity(signUpIntent);
                finish();
                break;
            }

        }
    }

    private void checkInputAndVerifyOTP() {
        String email = etPhoneNumber.getText().toString().trim();
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
            return;
        }
        String password = etPassword.getText().toString().trim();
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter a valid OTP", Toast.LENGTH_SHORT).show();
            return;
        }

        // Need to make API call to login
        clientLogin(email, password);
    }

    private void clientLogin(String usernameOrEmail, String password) {
        VerifyOTPRequest request = new VerifyOTPRequest();
        request.setPhoneNumber(usernameOrEmail);
        request.setOtp(password);
        showProgress(true);
        Call<BaseResponse<LoginResponse>> loginCall = Flytekart.getApiService().verifyOTP(BuildConfig.CLIENT_ID, request);
        loginCall.enqueue(new CustomCallback<BaseResponse<LoginResponse>>() {
            @Override
            public void onFlytekartSuccessResponse(@NotNull Call<BaseResponse<LoginResponse>> call, @NotNull Response<BaseResponse<LoginResponse>> response) {
                Logger.i("Client Login API call response received.");
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse loginResponse = response.body().getBody();
                    getFCMToken(BuildConfig.CLIENT_ID, loginResponse);
                } else {
                    showProgress(false);
                }
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<LoginResponse>> call, APIError responseBody) {
                /*if (response.errorBody() != null) {
                    try {
                        ApiCallResponse apiCallResponse = new Gson().fromJson(
                                response.errorBody().string(), ApiCallResponse.class);
                        Toast.makeText(getApplicationContext(), apiCallResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }*/
                Logger.e("Client Login API response failed");
                showProgress(false);
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<LoginResponse>> call) {
                Logger.i("Client Login API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getFCMToken(String clientId, LoginResponse loginResponse) {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                if (task.isSuccessful()) {
                    String token = task.getResult();
                    saveFCMToken(clientId, loginResponse, token);
                } else {
                    // Fail login
                    Logger.i("Get FCM token failure.");
                    showProgress(false);
                    Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void saveFCMToken(String clientId, LoginResponse loginResponse, String token) {
        CreateUserPushTokenRequest request = new CreateUserPushTokenRequest();
        request.setUserId(loginResponse.getUserDetails().getId());
        request.setToken(token);
        request.setClientType("android");
        Call<BaseResponse<UserPushToken>> saveFCMTokenCall = Flytekart.getApiService().saveFCMToken(
                loginResponse.getTokenType() + Constants.SPACE + loginResponse.getAccessToken(), clientId, request);
        saveFCMTokenCall.enqueue(new CustomCallback<BaseResponse<UserPushToken>>() {
            @Override
            public void onFlytekartSuccessResponse(@NotNull Call<BaseResponse<UserPushToken>> call, @NotNull Response<BaseResponse<UserPushToken>> response) {
                Logger.i("User push token save API call response received.");
                showProgress(false);
                if (response.isSuccessful() && response.body() != null) {
                    UserPushToken userPushToken = response.body().getBody();
                    // Get dropdown data and go to next screen.
                    Toast.makeText(getApplicationContext(), "Login successful.", Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, loginResponse.getTokenType() + " " + loginResponse.getAccessToken());
                    editor.putString(Constants.SHARED_PREF_USER_PUSH_TOKEN_ID, userPushToken.getId());
                    editor.apply();
                    saveUserDetails(loginResponse.getUserDetails());
                    Logger.i("User push token save API call success.");
                    setResult(RESULT_OK);
                    finish();
                }
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<UserPushToken>> call, APIError responseBody) {
                Logger.e("User push token save API response failed");
                showProgress(false);
                if (responseBody != null && responseBody.getMessage() != null) {
                    Toast.makeText(getApplicationContext(), responseBody.getMessage(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<UserPushToken>> call) {
                Logger.i("User push token save API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveUserDetails(UserDetails userDetails) {
        Gson gson = new Gson();
        String json = gson.toJson(userDetails);
        sharedPreferences.edit().putString(Constants.SHARED_PREF_KEY_USER_DETAILS, json).apply();
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    private void startSmsUserConsent() {
        SmsRetrieverClient client = SmsRetriever.getClient(this);
        client.startSmsUserConsent(null).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Logger.d("SmsRetrieverClient on Success");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Logger.d("SmsRetrieverClient on Failure");
                e.printStackTrace();
            }
        });
    }

    private void registerBroadcastReceiver() {
        smsBroadcastReceiver = new SmsBroadcastReceiver();
        smsBroadcastReceiver.smsBroadcastReceiverListener =
                new SmsBroadcastReceiver.SmsBroadcastReceiverListener() {
                    @Override
                    public void onSuccess(Intent intent) {
                        startActivityForResult(intent, REQ_USER_CONSENT);
                    }

                    @Override
                    public void onFailure() {
                        Logger.d("SmsBroadcastReceiver on Failure");
                    }
                };
        IntentFilter intentFilter = new IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION);
        registerReceiver(smsBroadcastReceiver, intentFilter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerBroadcastReceiver();
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(smsBroadcastReceiver);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_USER_CONSENT) {
            if ((resultCode == RESULT_OK) && (data != null)) {
                String message = data.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE);
                getOtpFromMessage(message);
            }
        }
    }

    private void getOtpFromMessage(String message) {
        // This will match any 6 digit number in the message
        Pattern pattern = Pattern.compile("(|^)\\d{6}");
        Matcher matcher = pattern.matcher(message);
        if (matcher.find()) {
            etPassword.setText(matcher.group(0));
            checkInputAndVerifyOTP();
        }
    }
}
