package com.flytekart.customer.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.flytekart.customer.R;
import com.flytekart.customer.models.Address;
import com.flytekart.customer.utils.Constants;

import java.util.List;

public class AddressListAdapter extends RecyclerView.Adapter<AddressListAdapter.AddressViewHolder> {

    private AddressClickListener addressClickListener;
    private List<Address> addressList;
    private Address deliveryAddress;
    private int mode;
    private int selectedColor;
    private int unSelectedColor;
    public static final String MODE = "MODE";
    public static final int MODE_SELECT_DELIVERY_ADDRESS = 1001;
    public static final int MODE_EDIT_DELIVERY_ADDRESS = 1002;

    public AddressListAdapter(Context context, AddressClickListener addressClickListener,
                              int mode, List<Address> addressList, Address deliveryAddress) {
        selectedColor = ContextCompat.getColor(context, R.color.phone_green);
        unSelectedColor = ContextCompat.getColor(context, R.color.dark_grey);
        this.addressClickListener = addressClickListener;
        this.mode = mode;
        this.addressList = addressList;
        this.deliveryAddress = deliveryAddress;
    }

    @NonNull
    @Override
    public AddressViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item_address, parent, false);
        return new AddressViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AddressViewHolder holder, int position) {
        Address address = addressList.get(position);
        holder.tvLine1.setText(address.getLine1());
        if (address.getLine2() != null && !address.getLine2().isEmpty()) {
            holder.tvLine2.setText(address.getLine2());
        } else {
            holder.tvLine2.setVisibility(View.GONE);
        }

        StringBuilder cityBuilder = new StringBuilder();
        cityBuilder.append(address.getCity()).append(Constants.COMMA_SPACE);
        cityBuilder.append(address.getState());
        holder.tvCityState.setText(cityBuilder.toString());

        StringBuilder countryBuilder = new StringBuilder();
        countryBuilder.append(address.getCountry()).append(Constants.COMMA_SPACE);
        countryBuilder.append(address.getZip());
        holder.tvCountryZip.setText(countryBuilder.toString());
        holder.itemView.setTag(address);

        if (mode == MODE_SELECT_DELIVERY_ADDRESS) {
            // Show tick icon and hide edit icon
            // Add address click listener
            holder.ivSelectedAddress.setImageResource(R.drawable.ic_baseline_check_circle_24);
            if (deliveryAddress != null && deliveryAddress.getId() != null
                    && deliveryAddress.getId().equals(address.getId())) {
                holder.ivSelectedAddress.setColorFilter(selectedColor);
            } else {
                holder.ivSelectedAddress.setColorFilter(unSelectedColor);
            }
            holder.itemView.setOnClickListener(new SelectClickListener(position));
        } else if (mode == MODE_EDIT_DELIVERY_ADDRESS) {
            // Hide tick icon and show edit icon
            // Add address click listener
            holder.ivSelectedAddress.setImageResource(R.drawable.ic_edit);
            holder.ivSelectedAddress.setColorFilter(unSelectedColor);
            holder.itemView.setOnClickListener(new EditClickListener(position));
        }
    }

    @Override
    public int getItemCount() {
        return addressList.size();
    }

    private class EditClickListener implements View.OnClickListener {
        private int position;

        public EditClickListener(int position) {
            this.position = position;
        }

        @Override
        public void onClick(View v) {
            addressClickListener.onEdit(position);
        }
    }

    private class SelectClickListener implements View.OnClickListener {
        private int position;

        public SelectClickListener(int position) {
            this.position = position;
        }

        @Override
        public void onClick(View v) {
            addressClickListener.onSelect(position);
        }
    }

    public interface AddressClickListener {
        void onEdit(int position);
        void onSelect(int position);
    }

    public static class AddressViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivSelectedAddress;
        private ImageView ivEditAddress;
        private TextView tvLine1;
        private TextView tvLine2;
        private TextView tvCityState;
        private TextView tvCountryZip;

        public AddressViewHolder(View view) {
            super(view);
            ivSelectedAddress = view.findViewById(R.id.iv_selected_address);
            tvLine1 = view.findViewById(R.id.tv_line_1);
            tvLine2 = view.findViewById(R.id.tv_line_2);
            tvCityState = view.findViewById(R.id.tv_city_state);
            tvCountryZip = view.findViewById(R.id.tv_country_zip);
        }
    }
}
