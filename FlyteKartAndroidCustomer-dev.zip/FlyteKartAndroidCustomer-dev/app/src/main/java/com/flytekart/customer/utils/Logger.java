package com.flytekart.customer.utils;

import android.util.Log;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;


/**
 * Custom logging to print logs only in debug builds.
 * Created by narendranathp on 04/05/17.
 */
public class Logger {
    public static void v(String message) {
        if (BuildConfig.DEBUG) {
            Log.v(Flytekart.class.getSimpleName(), message);
        }
    }

    public static void d(String message) {
        if (BuildConfig.DEBUG) {
            Log.e(Flytekart.class.getSimpleName(), message);
        }
    }

    public static void i(String message) {
        if (BuildConfig.DEBUG) {
            Log.i(Flytekart.class.getSimpleName(), message);
        }
    }

    public static void w(String message) {
        if (BuildConfig.DEBUG) {
            Log.w(Flytekart.class.getSimpleName(), message);
        }
    }

    public static void e(String message) {
        if (BuildConfig.DEBUG) {
            Log.e(Flytekart.class.getSimpleName(), message);
        }
    }
}
