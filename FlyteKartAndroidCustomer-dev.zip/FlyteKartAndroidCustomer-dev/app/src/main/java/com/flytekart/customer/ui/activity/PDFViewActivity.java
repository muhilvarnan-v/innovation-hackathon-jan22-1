package com.flytekart.customer.ui.activity;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;

import com.flytekart.customer.R;
import com.flytekart.customer.utils.Constants;
import com.pdfview.PDFView;

public class PDFViewActivity extends BaseActivity {

    private PDFView pdfView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_view);

        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        String title = getIntent().getStringExtra(Constants.TITLE);
        String pdfFileName = getIntent().getStringExtra(Constants.PDF_FILE_NAME);
        setTitle(title);

        pdfView = findViewById(R.id.pdf_view);
        pdfView.fromAsset(pdfFileName).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
