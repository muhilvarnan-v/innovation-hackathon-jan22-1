package com.flytekart.customer.ui.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.Address;
import com.flytekart.customer.models.UserDetails;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.ui.adapter.AddressListAdapter;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

public class MyAddressesActivity extends BaseActivity implements View.OnClickListener, AddressListAdapter.AddressClickListener {

    private View rlNotLoggedIn;
    private View rlNoAddresses;
    private String accessToken;
    private View tvAddAddress;
    private View vAddAddressDivider;
    private RecyclerView rvAddressList;
    private List<Address> addresses;
    private Address deliveryAddress;
    private UserDetails userDetails;
    private AddressListAdapter adapter;
    private LinearLayoutManager addressListLayoutManager;
    protected SharedPreferences sharedPreferences;
    private ProgressDialog progressDialog;
    private int mode = -1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_addresses);

        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle("My Addresses");

        rlNotLoggedIn = findViewById(R.id.rl_not_logged_in);
        rlNoAddresses = findViewById(R.id.rl_no_addresses);
        rvAddressList = findViewById(R.id.rv_address_list);
        tvAddAddress = findViewById(R.id.tv_add_new_address);
        vAddAddressDivider = findViewById(R.id.v_add_address_divider);
        addressListLayoutManager = new LinearLayoutManager(this);
        rvAddressList.setLayoutManager(addressListLayoutManager);
        rvAddressList.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        sharedPreferences = Utilities.getSharedPreferences();
        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, null);
        mode = getIntent().getIntExtra(AddressListAdapter.MODE, -1);
        deliveryAddress = getIntent().getParcelableExtra(Constants.ADDRESS);
        getUserDetails();

        if (accessToken == null) {
            rlNotLoggedIn.setVisibility(View.VISIBLE);
        } else {
            rlNotLoggedIn.setVisibility(View.GONE);
        }
        tvAddAddress.setOnClickListener(this);

        getData();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_add_new_address:
                openAddressCreation(null, -1);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            Address deliveryAddress = data.getParcelableExtra(Constants.ADDRESS);
            int position = data.getIntExtra(Constants.SELECTED_POSITION, -1);
            if (addresses != null && deliveryAddress != null) {
                if (position == -1) {
                    // Add to the first of the list
                    addresses.add(0, deliveryAddress);
                    //adapter.notifyItemInserted(0);
                    if (adapter == null) {
                        setAddressesData();
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                } else {
                    // Modify in the selected position
                    addresses.remove(position);
                    addresses.add(position, deliveryAddress);
                    adapter.notifyItemChanged(position);
                }
            }
        }
    }

    @Override
    protected void onCartClicked() {
        super.onCartClicked();
        finish();
    }

    private void openAddressCreation(Address selectedAddress, int position) {
        Intent addressIntent = new Intent(this, MapsActivity.class);
        addressIntent.putExtra(Constants.MAPS_MODE, MapsActivity.MODE_SAVE_DELIVERY_ADDRESS);
        addressIntent.putExtra(Constants.ADDRESS, selectedAddress);
        addressIntent.putExtra(Constants.SELECTED_POSITION, position);
        startActivityForResult(addressIntent, 1001);
    }

    private void getUserDetails() {
        Gson gson = new Gson();
        String userDetailsString = sharedPreferences.getString(Constants.SHARED_PREF_KEY_USER_DETAILS, null);
        if (userDetailsString != null) {
            this.userDetails = gson.fromJson(userDetailsString, UserDetails.class);
        }
    }

    private void getData() {
        showProgress(true);
        Call<BaseResponse<List<Address>>> getCategoriesCall = Flytekart.getApiService()
                .getDeliveryAddressesOfUser(accessToken, userDetails.getId(), BuildConfig.CLIENT_ID);
        getCategoriesCall.enqueue(new CustomCallback<BaseResponse<List<Address>>>() {
            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<List<Address>>> call, Response<BaseResponse<List<Address>>> response) {
                Logger.i("Addresses list response received.");
                showProgress(false);
                if (response.isSuccessful() && response.body() != null) {
                    addresses = response.body().getBody();
                    tvAddAddress.setVisibility(View.VISIBLE);
                    vAddAddressDivider.setVisibility(View.VISIBLE);
                    setAddressesData();
                }
                Logger.e("Address List API call response status code : " + response.code());
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<List<Address>>> call, APIError responseBody) {
                Logger.i("Addresses list API call failed.");
                showProgress(false);
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<List<Address>>> call) {
                Logger.i("Addresses List API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setAddressesData() {
        if (addresses == null || addresses.isEmpty()) {
            rvAddressList.setVisibility(View.GONE);
            rlNoAddresses.setVisibility(View.VISIBLE);
            rlNoAddresses.setOnClickListener(v -> {
                openAddressCreation(null, -1);
            });

        } else {
            rlNoAddresses.setVisibility(View.GONE);
            rvAddressList.setVisibility(View.VISIBLE);

            adapter = new AddressListAdapter(this, this, mode, addresses, deliveryAddress);
            rvAddressList.setAdapter(adapter);
        }
    }

    @Override
    public void onEdit(int position) {
        openAddressCreation(addresses.get(position), position);
    }

    @Override
    public void onSelect(int position) {
        deliveryAddress = addresses.get(position);
        adapter.notifyItemChanged(position);

        Intent intent = new Intent();
        intent.putExtra(Constants.ADDRESS, deliveryAddress);
        setResult(RESULT_OK, intent);
        finish();
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}
