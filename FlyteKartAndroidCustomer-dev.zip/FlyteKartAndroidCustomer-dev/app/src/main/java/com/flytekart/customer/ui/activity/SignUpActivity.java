package com.flytekart.customer.ui.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.flytekart.customer.R;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Utilities;

// TODO Learn about feature on feature dependencies
public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etName;
    private EditText etPassword;
    private EditText etCnfPassword;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        setStatusBackgroundColor();
        hideActionBar();

        findViewById(R.id.tv_sign_up).setOnClickListener(this);
        findViewById(R.id.tv_login).setOnClickListener(this);
        etName = findViewById(R.id.et_phone_number);
        etPassword = findViewById(R.id.et_password);
        etCnfPassword = findViewById(R.id.et_cnf_password);
    }

    private void setStatusBackgroundColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black_transparent));
        }
    }

    private void hideActionBar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_sign_up: {
                String username = etName.getText().toString().trim();
                if (TextUtils.isEmpty(username)) {
                    Toast.makeText(this, "Please enter a valid username", Toast.LENGTH_SHORT).show();
                    return;
                }

                String password = etPassword.getText().toString().trim();
                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(this, "Please enter a valid password", Toast.LENGTH_SHORT).show();
                    return;
                }

                String cnfPassword = etCnfPassword.getText().toString().trim();
                if (TextUtils.isEmpty(cnfPassword) || !password.equals(cnfPassword)) {
                    Toast.makeText(this, "Password and confirm password do not match.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Need to make API call to login
                SharedPreferences sharedPreferences = Utilities.getSharedPreferences();
                sharedPreferences.edit().putString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, "dummy").commit();
                Intent homeIntent = new Intent(SignUpActivity.this, HomeActivity.class);
                homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(homeIntent);
                finish();
                break;
            }
            case R.id.tv_login: {
                // Need to make API call to login
                Intent loginIntent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(loginIntent);
                finish();
            }
        }
    }
}
