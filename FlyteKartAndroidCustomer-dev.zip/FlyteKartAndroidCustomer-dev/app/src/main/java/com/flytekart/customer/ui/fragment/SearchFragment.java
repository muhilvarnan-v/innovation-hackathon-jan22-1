package com.flytekart.customer.ui.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.flytekart.customer.R;
import com.flytekart.customer.models.Cart;
import com.flytekart.customer.models.Category;
import com.flytekart.customer.models.FoodCode;
import com.flytekart.customer.models.Item;
import com.flytekart.customer.models.StoreProductDTO;
import com.flytekart.customer.models.StoreVariantDTO;
import com.flytekart.customer.ui.activity.CartActivity;
import com.flytekart.customer.ui.activity.CategoryItemsActivity;
import com.flytekart.customer.ui.activity.ItemDetailsActivity;
import com.flytekart.customer.ui.adapter.SearchItemsAdapter;
import com.flytekart.customer.utils.Constants;

import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends Fragment implements SearchView.OnQueryTextListener, SearchItemsAdapter.SearchItemListener {

    private SearchView svSearch;
    private RecyclerView rvSearch;
    private View rlNoSearchResults;
    private LinearLayoutManager layoutManager;
    private List<Category> categories;
    private List<Item> items;
    private SearchItemsAdapter searchItemsAdapter;
    private FragmentInteractionListener fragmentInteractionListener;

    @Override
    public void onAttach(@NonNull Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            fragmentInteractionListener = (FragmentInteractionListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString()
                    + " must implement OnHeadlineSelectedListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        svSearch = view.findViewById(R.id.sv_search);
        rlNoSearchResults = view.findViewById(R.id.rl_no_search_results);
        rvSearch = view.findViewById(R.id.rv_search);
        rvSearch.setHasFixedSize(true);
        if (getActivity() != null && isAdded()) {
            layoutManager = new LinearLayoutManager(getActivity());
            layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            rvSearch.setLayoutManager(layoutManager);
        }
        svSearch.setOnQueryTextListener(this);
        //setListeners();
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        // TODO Make search API call
        if (!TextUtils.isEmpty(query)) {
            if (query.equals("snacks")) {
                rlNoSearchResults.setVisibility(View.GONE);
                categories = getCategories();
                items = getItems();
                searchItemsAdapter = new SearchItemsAdapter(categories, items, fragmentInteractionListener.onGetCart(), this);
                rvSearch.setAdapter(searchItemsAdapter);
                rvSearch.setVisibility(View.VISIBLE);
            } else {
                // Show no results graphical view
                categories = null;
                items = null;
                rvSearch.setVisibility(View.GONE);
                rlNoSearchResults.setVisibility(View.VISIBLE);
            }
        }
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        return false;
    }

    private List<Category> getCategories() {
        // TODO Make categories list API call
        Category category1 = new Category();
        category1.colorCode = R.color.randomColor1;
        category1.name = "Snacks";

        Category category8 = new Category();
        category8.colorCode = R.color.randomColor4;
        category8.name = "European";

        List<Category> categories = new ArrayList<>(5);
        categories.add(category1);
        categories.add(category8);

        return categories;
    }

    private List<Item> getItems() {
        Item item1 = new Item();
        item1.colorCode = R.color.randomColor1;
        item1.id = 1;
        item1.currencyCode = "Rs";
        item1.foodCode = FoodCode.NONE;
        item1.itemName = "Stuffed Garlic Breadsticks";
        item1.oldPrice = 350;
        item1.price = 300;
        item1.quantity = "1 box";

        Item item2 = new Item();
        item2.id = 2;
        item2.colorCode = R.color.randomColor2;
        item2.currencyCode = "Rs";
        item2.foodCode = FoodCode.VEG;
        item2.itemName = "Chips";
        item2.oldPrice = 80;
        item2.price = 60;
        item2.quantity = "100 gms";

        Item item3 = new Item();
        item3.id = 3;
        item3.colorCode = R.color.randomColor3;
        item3.currencyCode = "Rs";
        item3.foodCode = FoodCode.NONVEG;
        item3.itemName = "Pickle";
        item3.oldPrice = 250;
        item3.price = 200;
        item3.quantity = "250 gms";

        Item item4 = new Item();
        item4.id = 4;
        item4.colorCode = R.color.randomColor4;
        item4.currencyCode = "Rs";
        item4.foodCode = FoodCode.VEG;
        item4.itemName = "Mango juice";
        item4.oldPrice = -1;
        item4.price = 60;
        item4.quantity = "100 mL";

        Item item5 = new Item();
        item5.id = 5;
        item5.colorCode = R.color.randomColor5;
        item5.currencyCode = "Rs";
        item5.foodCode = FoodCode.NONVEG;
        item5.itemName = "Curry cut";
        item5.oldPrice = -1;
        item5.price = 250;
        item5.quantity = "1 kg";

        Item item6 = new Item();
        item6.id = 6;
        item6.colorCode = R.color.randomColor1;
        item6.currencyCode = "Rs";
        item6.foodCode = FoodCode.NONE;
        item6.itemName = "Stuffed Garlic Breadsticks";
        item6.oldPrice = 350;
        item6.price = 300;
        item6.quantity = "1 box";

        Item item7 = new Item();
        item7.id = 7;
        item7.colorCode = R.color.randomColor2;
        item7.currencyCode = "Rs";
        item7.foodCode = FoodCode.VEG;
        item7.itemName = "Chips";
        item7.oldPrice = 80;
        item7.price = 60;
        item7.quantity = "100 gms";

        Item item8 = new Item();
        item8.id = 8;
        item8.colorCode = R.color.randomColor3;
        item8.currencyCode = "Rs";
        item8.foodCode = FoodCode.NONVEG;
        item8.itemName = "Pickle";
        item8.oldPrice = 250;
        item8.price = 200;
        item8.quantity = "250 gms";

        Item item9 = new Item();
        item9.id = 9;
        item9.colorCode = R.color.randomColor4;
        item9.currencyCode = "Rs";
        item9.foodCode = FoodCode.VEG;
        item9.itemName = "Mango juice";
        item9.oldPrice = -1;
        item9.price = 60;
        item9.quantity = "100 mL";

        List<Item> items = new ArrayList<>(20);
        items.add(item1);
        items.add(item2);
        items.add(item3);
        items.add(item4);
        items.add(item5);
        items.add(item6);
        items.add(item7);
        items.add(item8);
        items.add(item9);

        return items;
    }

    /*private void setListeners() {
        final GestureDetector gestureDetector = new GestureDetector(getActivity(), new GestureDetector.SimpleOnGestureListener() {

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                return true;
            }

        });

        rvSearch.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
                View child = rv.findChildViewUnder(e.getX(), e.getY());
                if (child != null && gestureDetector.onTouchEvent(e)) {
                    int position = rv.getChildAdapterPosition(child);
                    onSearchItemClicked(position);
                }
                return false;
            }

            @Override
            public void onTouchEvent(RecyclerView rv, MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
    }

    private void onSearchItemClicked(int position) {
        if (categories != null && position < categories.size()) {
            Category category = categories.get(position);
            onCategoryClicked(category);
        } else {
            int itemPosition = -1;
            if (categories == null) {
                itemPosition = position;
            } else {
                itemPosition = position - categories.size();
            }
            Item item = items.get(itemPosition);
            onItemClicked(item);
        }
    }*/

    @Override
    public void onCategoryClicked(int position, Category category) {
        if (getActivity() != null && isAdded()) {
            Intent categoryItemsIntent = new Intent(getActivity(), CategoryItemsActivity.class);
            categoryItemsIntent.putExtra(Constants.CATEGORY, category);
            startActivityForResult(categoryItemsIntent, CategoryItemsActivity.REQUEST_CODE_CATEGORY_ITEMS_ACTIVITY);
        }
    }

    @Override
    public void onItemClicked(int position, Item item) {
        if (getActivity() != null && isAdded()) {
            Intent itemIntent = new Intent(getActivity(), ItemDetailsActivity.class);
            itemIntent.putExtra(Constants.ITEM, item);
            itemIntent.putExtra(Constants.SELECTED_POSITION, position);
            startActivityForResult(itemIntent, ItemDetailsActivity.REQUEST_CODE_ITEM_DETAILS_ACTIVITY);
        }
    }

    @Override
    public void onAddClick(int position, StoreProductDTO storeProduct) {
        if (getActivity() != null && isAdded()) {
            if (storeProduct.variants.size() == 1) {
                Cart cart = fragmentInteractionListener.onAddFirstItemToCart(storeProduct.variants.get(0));

                searchItemsAdapter.setCart(cart);
                searchItemsAdapter.notifyItemChanged(position);
                fragmentInteractionListener.onSetupBadge();
            } else {
                // TODO
            }
        }
    }

    @Override
    public void onItemIncrement(int position, StoreProductDTO storeProduct) {
        if (getActivity() != null && isAdded()) {
            if (storeProduct.variants.size() == 1) {
                Cart cart = fragmentInteractionListener
                        .onIncrementItemInCart(storeProduct.variants.get(0));

                searchItemsAdapter.setCart(cart);
                searchItemsAdapter.notifyItemChanged(position);
                fragmentInteractionListener.onSetupBadge();
            } else {
                // TODO
            }
        }
    }

    @Override
    public void onItemDecrement(int position, StoreProductDTO storeProduct) {
        if (getActivity() != null && isAdded()) {
            if (storeProduct.variants.size() == 1) {
                Cart cart = fragmentInteractionListener
                        .onDecrementItemInCart(storeProduct.variants.get(0));

                searchItemsAdapter.setCart(cart);
                searchItemsAdapter.notifyItemChanged(position);
                fragmentInteractionListener.onSetupBadge();
            } else {
                // TODO
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ItemDetailsActivity.REQUEST_CODE_ITEM_DETAILS_ACTIVITY && data != null) {
            int position = data.getIntExtra(Constants.SELECTED_POSITION, -1);
            if (position != -1) {
                searchItemsAdapter.setCart(fragmentInteractionListener.onGetCart());
                searchItemsAdapter.notifyItemChanged(position);
            }
        } else if (requestCode == CategoryItemsActivity.REQUEST_CODE_CATEGORY_ITEMS_ACTIVITY ||
                requestCode == CartActivity.REQUEST_CODE_CART_ACTIVITY) {
            searchItemsAdapter.setCart(fragmentInteractionListener.onGetCart());
            searchItemsAdapter.notifyDataSetChanged();
        }
    }

    public void refreshCartItems() {
        if (searchItemsAdapter != null && rvSearch.getVisibility() == View.VISIBLE) {
            searchItemsAdapter.setCart(fragmentInteractionListener.onGetCart());
            searchItemsAdapter.notifyDataSetChanged();
        }
    }

    public interface FragmentInteractionListener {
        Cart onAddFirstItemToCart(StoreVariantDTO storeVariant);
        Cart onIncrementItemInCart(StoreVariantDTO storeVariant);
        Cart onDecrementItemInCart(StoreVariantDTO storeVariant);
        void onSetupBadge();
        Cart onGetCart();
    }
}
