package com.flytekart.customer.network;

import com.flytekart.customer.models.Address;
import com.flytekart.customer.models.Cart;
import com.flytekart.customer.models.Store;
import com.flytekart.customer.models.StoreProductDTO;
import com.flytekart.customer.models.UserPushToken;
import com.flytekart.customer.models.dto.StoreCategoryDTO;
import com.flytekart.customer.models.request.CreateAddressRequest;
import com.flytekart.customer.models.request.CreateRazorpayOrderRequest;
import com.flytekart.customer.models.request.CreateUserPushTokenRequest;
import com.flytekart.customer.models.request.DeleteUserPushTokenRequest;
import com.flytekart.customer.models.request.LoginRequest;
import com.flytekart.customer.models.request.SendOTPRequest;
import com.flytekart.customer.models.request.VerifyOTPRequest;
import com.flytekart.customer.models.request.VerifyRazorpayPaymentRequest;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.models.response.CreateRazorpayOrderResponse;
import com.flytekart.customer.models.response.LoginResponse;
import com.flytekart.customer.models.response.OrderResponse;
import com.flytekart.customer.utils.Constants;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    @GET("/api/stores/getDeliverableStoresByLatLng")
    Call<BaseResponse<List<Store>>> getDeliverableStoresByLatLng(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Query("latitude") double latitude,
            @Query("longitude") double longitude,
            @Query("clientId") String clientId);

    @GET("/api/storeCategories/store/{storeId}")
    Call<BaseResponse<List<StoreCategoryDTO>>> getStoreCategoriesByStoreId(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Path("storeId") String storeId,
            @Query("clientId") String clientId);

    @GET("/api/storeProducts/withVariants/store/{storeId}")
    Call<BaseResponse<List<StoreProductDTO>>> getStoreProductsWithVariantsByStoreId(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Path("storeId") String storeId,
            @Query("clientId") String clientId,
            @Query("categoryId") String categoryId,
            @Query("pageSize") int pageSize,
            @Query("pageNumber") int pageNumber);

    @POST("/api/auth/signin")
    Call<BaseResponse<LoginResponse>> login(
            @Query("clientId") String clientId,
            @Body LoginRequest loginRequest);

    @POST("/api/auth/otplogin")
    Call<BaseResponse<String>> sendOTP(
            @Query("clientId") String clientId,
            @Body SendOTPRequest request);

    @POST("/api/auth/otpverify")
    Call<BaseResponse<LoginResponse>> verifyOTP(
            @Query("clientId") String clientId,
            @Body VerifyOTPRequest request);

    @POST("/api/notifications/saveUserPushToken")
    Call<BaseResponse<UserPushToken>> saveFCMToken(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Query("clientId") String clientId,
            @Body CreateUserPushTokenRequest request);

    @POST("/api/notifications/deleteUserPushToken")
    Call<BaseResponse<UserPushToken>> deleteFCMToken(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Query("clientId") String clientId,
            @Body DeleteUserPushTokenRequest request);

    @POST("/api/addresses/saveDeliveryAddress")
    Call<BaseResponse<Address>> saveDeliveryAddress(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Query("clientId") String clientId,
            @Body CreateAddressRequest addressRequest);

    @POST("/api/orders/createOrder")
    Call<BaseResponse<OrderResponse>> createOrder(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Query("clientId") String clientId,
            @Body Cart request);

    @POST("/api/payments/createRazorpayOrder")
    Call<BaseResponse<CreateRazorpayOrderResponse>> createRazorpayOrder(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Query("clientId") String clientId,
            @Body CreateRazorpayOrderRequest request);

    @POST("/api/payments/validateRazorpayPayment")
    Call<BaseResponse<OrderResponse>> validateRazorpayPayment(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Query("clientId") String clientId,
            @Body VerifyRazorpayPaymentRequest request);

    @GET("/api/addresses/getByUserId/{userId}")
    Call<BaseResponse<List<Address>>> getDeliveryAddressesOfUser(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Path("userId") String userId,
            @Query("clientId") String clientId);

    @GET("/api/orders/getByUserId/{userId}")
    Call<BaseResponse<List<OrderResponse>>> getOrdersByUserId(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Path("userId") String userId,
            @Query("clientId") String clientId,
            @Query("pageNumber") int pageNumber,
            @Query("pageSize") int pageSize);

    @GET("/api/orders/get/{orderId}")
    Call<BaseResponse<OrderResponse>> getOrderById(
            @Header(Constants.API_TOKEN_TAG) String apiToken,
            @Path("orderId") String orderId,
            @Query("clientId") String clientId);
}
