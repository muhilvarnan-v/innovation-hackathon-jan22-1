package com.flytekart.customer.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.flytekart.customer.R;
import com.flytekart.customer.models.Address;
import com.flytekart.customer.models.Store;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Utilities;

import java.util.List;

public class StoreListAdapter extends BaseAdapter {

    private Context context;
    private List<Store> stores;

    public StoreListAdapter(Context context, List<Store> stores) {
        this.context = context;
        this.stores = stores;
    }

    @Override
    public int getCount() {
        return stores.size();
    }

    @Override
    public Object getItem(int position) {
        return stores.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            rowView = inflater.inflate(R.layout.list_item_store, parent, false);
        } else {
            rowView = convertView;
        }

        TextView tvStoreName = rowView.findViewById(R.id.tv_store_name);
        TextView tvStoreAddress = rowView.findViewById(R.id.tv_store_address);

        tvStoreName.setText(stores.get(position).getName());
        Address storeAddress = stores.get(position).getAddress();
        tvStoreAddress.setText(Utilities.getAddressString(storeAddress));

        return rowView;
    }
}
