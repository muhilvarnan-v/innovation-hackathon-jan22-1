package com.flytekart.customer.ui.activity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.flytekart.customer.R;
import com.flytekart.customer.models.CartItem;
import com.flytekart.customer.models.ItemDetails;
import com.flytekart.customer.models.StoreProductDTO;
import com.flytekart.customer.models.StoreVariantDTO;
import com.flytekart.customer.ui.adapter.ItemImagePagerAdapter;
import com.flytekart.customer.ui.custom.ViewPagerIndicator;
import com.flytekart.customer.utils.Constants;

import java.util.ArrayList;

/**
 * It should always come from startActivityForResult
 * TODO This screen will be disabled for v0.5
 */
public class ItemDetailsActivity extends BaseActivity implements ItemImagePagerAdapter.OnPagerClickListener, View.OnClickListener {

    private ViewPager vpItem;
    private ViewPagerIndicator vpiItem;
    private TextView tvItemName;
    private TextView tvItemQuantity;
    private TextView tvItemPrice;
    private TextView tvItemOldPrice;
    private TextView tvDescription;
    private TextView tvItemCartTotal;
    private TextView tvAdd;
    private TextView tvCounter;
    private TextView tvDecrement;
    private TextView tvIncrement;
    private LinearLayout llItemCounter;
    private int viewPagerWidth;
    private int viewPagerHeight;
    private StoreProductDTO storeProduct;
    private ItemDetails itemDetails;
    public static final int REQUEST_CODE_ITEM_DETAILS_ACTIVITY = 100;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_details);

        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        storeProduct = getIntent().getParcelableExtra(Constants.ITEM);
        setTitle(storeProduct.productName);

        vpItem = findViewById(R.id.vp_item);
        vpiItem = findViewById(R.id.vpi_item);
        tvItemName = findViewById(R.id.tv_item_name);
        tvItemQuantity = findViewById(R.id.tv_item_quantity);
        tvItemPrice = findViewById(R.id.tv_item_price);
        tvItemOldPrice = findViewById(R.id.tv_item_old_price);
        tvDescription = findViewById(R.id.tv_description);
        tvItemCartTotal = findViewById(R.id.tv_item_cart_total);
        tvAdd = findViewById(R.id.tv_add);
        tvCounter = findViewById(R.id.tv_counter);
        tvDecrement = findViewById(R.id.tv_decrement);
        tvIncrement = findViewById(R.id.tv_increment);
        llItemCounter = findViewById(R.id.ll_item_counter);

        setViewPagerLayout();

        cart = getCart();
        setItemUi();
        itemDetails = getItemDetails();
        setViewPager();
        setItemDetailsUi();
        tvAdd.setOnClickListener(this);
        tvDecrement.setOnClickListener(this);
        tvIncrement.setOnClickListener(this);
    }

    private void setItemDetailsUi() {
        tvDescription.setText(itemDetails.description);
        setItemCart();
    }

    private void setItemCart() {
        // Need to check it with cart
        /*int quantity = 0;
        int itemCartTotal = 0;
        if (cart != null && cart.cartItems != null) {
            for (CartItem cartItem : cart.cartItems) {
                if (storeProduct.variants.get(0).storeVariantId == cartItem.storeVariant.storeVariantId) {
                    quantity = cartItem.quantity;
                    itemCartTotal = (int) (cartItem.quantity * storeProduct.variants.get(0).price);
                    break;
                }
            }
        }
        if (quantity == 0) {
            tvItemCartTotal.setText("Rs." + storeProduct.variants.get(0).price);
            tvAdd.setVisibility(View.VISIBLE);
            llItemCounter.setVisibility(View.GONE);
        } else {
            tvItemCartTotal.setText("Rs." + itemCartTotal);
            tvAdd.setVisibility(View.GONE);
            llItemCounter.setVisibility(View.VISIBLE);
        }
        tvCounter.setText(String.valueOf(quantity));
        // Need to update cart counter also
        setupBadge();*/
    }

    private void setItemUi() {
        StoreVariantDTO storeVariant = storeProduct.variants.get(0);
        tvItemName.setText(storeProduct.productName);
        tvItemQuantity.setText(storeVariant.variantName);
        tvItemPrice.setText("Rs." + storeVariant.price);
        if (storeVariant.originalPrice != -1) {
            tvItemOldPrice.setText("Rs." + storeVariant.originalPrice);
            tvItemOldPrice.setVisibility(View.VISIBLE);
            tvItemOldPrice.setPaintFlags(tvItemOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            tvItemOldPrice.setVisibility(View.GONE);
        }
    }

    private void setViewPagerLayout() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        viewPagerWidth = displayMetrics.widthPixels;
        viewPagerHeight = (int) (viewPagerWidth * 0.6f);
        vpItem.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, viewPagerHeight));
    }

    private void setViewPager() {
        ItemImagePagerAdapter heroPagerAdapter = new ItemImagePagerAdapter(this,
                itemDetails, viewPagerWidth, viewPagerHeight);
        vpItem.setAdapter(heroPagerAdapter);
        vpiItem.setViewPager(vpItem);
    }

    private ItemDetails getItemDetails() {
        ItemDetails itemDetails = new ItemDetails();

        ArrayList<Integer> colorCodes = new ArrayList<>();
        colorCodes.add(R.color.randomColor1);
        colorCodes.add(R.color.randomColor2);
        colorCodes.add(R.color.randomColor3);
        colorCodes.add(R.color.randomColor4);
        colorCodes.add(R.color.randomColor5);

        String description = getString(R.string.sample_description);

        itemDetails.colorCodes = colorCodes;
        itemDetails.description = description;
        return itemDetails;
    }

    @Override
    public void onPagerClick(int color, int position) {
        // TODO Need to implement full screen ImageView activity here. - From Film Exotica
        Intent photoIntent = new Intent(this, PhotoActivity.class);
        photoIntent.putExtra(Constants.ITEM_PHOTO_LIST, itemDetails.colorCodes);
        photoIntent.putExtra(Constants.SELECTED_PAGE, vpItem.getCurrentItem());
        startActivity(photoIntent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_add: {
                tvAdd.setVisibility(View.GONE);
                llItemCounter.setVisibility(View.VISIBLE);
                addFirstItemToCart(storeProduct.variants.get(0));
                setItemCart();
                break;
            }
            case R.id.tv_decrement: {
                decrementItemInCart(storeProduct.variants.get(0));
                setItemCart();
                break;
            }
            case R.id.tv_increment: {
                incrementItemInCart(storeProduct.variants.get(0));
                setItemCart();
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        super.onBackPressed();
    }

    @Override
    protected void refreshCartItems() {
        super.refreshCartItems();
        cart = getCart();
        setItemCart();
    }
}
