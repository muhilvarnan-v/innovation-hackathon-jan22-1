package com.flytekart.customer.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.flytekart.customer.R;
import com.flytekart.customer.models.OrderItem;
import com.flytekart.customer.models.response.OrderResponse;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Utilities;

import java.util.List;

public class OrdersAdapter extends RecyclerView.Adapter<OrdersAdapter.OrderViewHolder> {

    private List<OrderResponse> orderResponses;

    public OrdersAdapter(List<OrderResponse> orderResponses) {
        this.orderResponses = orderResponses;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        OrderResponse orderResponse = orderResponses.get(position);
        String orderItemsNames = getOrderItemsNames(orderResponse.getOrderItems());
        holder.tvOrderItemsNames.setText(orderItemsNames);
        holder.tvOrderTime.setText(Utilities.getFormattedCalendarString(orderResponse.getOrder().getOrderPlacedAt()));
        holder.tvOrderSource.setText(orderResponse.getOrder().getOrderSource().getName());
        holder.tvOrderStatus.setText(Utilities.getFormattedOrderStatus(orderResponse.getOrder().getOrderStatus().getName()));
        holder.tvOrderTotal.setText(Utilities.getFormattedMoney(orderResponse.getOrderTotal().getTotal()));
    }

    private String getOrderItemsNames(List<OrderItem> orderItems) {
        StringBuilder builder = new StringBuilder();
        for (OrderItem orderItem : orderItems) {
            if (builder.length() >= 50) {
                break;
            }
            if (builder.length() > 0) {
                builder.append(Constants.COMMA_SPACE);
            }
            builder.append(orderItem.getStoreVariant().getVariant().getProduct().getName());
        }
        return builder.toString();
    }

    @Override
    public int getItemCount() {
        return orderResponses.size();
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        private TextView tvOrderItemsNames;
        private TextView tvOrderTime;
        private TextView tvOrderSource;
        private TextView tvOrderStatus;
        private TextView tvOrderTotal;

        public OrderViewHolder(View view) {
            super(view);
            tvOrderItemsNames = view.findViewById(R.id.tv_order_items_names);
            tvOrderTime = view.findViewById(R.id.tv_order_time);
            tvOrderSource = view.findViewById(R.id.tv_order_source);
            tvOrderStatus = view.findViewById(R.id.tv_order_status);
            tvOrderTotal = view.findViewById(R.id.tv_order_total);
        }
    }
}
