package com.flytekart.customer.models;

import java.util.ArrayList;

public class ItemDetails {
    public ArrayList<Integer> colorCodes;
    public String description;
}
