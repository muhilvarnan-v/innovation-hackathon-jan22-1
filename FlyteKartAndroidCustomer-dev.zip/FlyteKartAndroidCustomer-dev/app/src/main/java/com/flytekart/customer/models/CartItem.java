package com.flytekart.customer.models;

import android.os.Parcel;
import android.os.Parcelable;

public class CartItem implements Parcelable {
    public StoreVariantDTO storeVariant;
    public int quantity;
    public boolean isDeliverable;
    public boolean isAvailable;
    public double itemTotal;
    public double taxTotal;
    public double total;


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.storeVariant, flags);
        dest.writeInt(this.quantity);
        dest.writeByte(this.isDeliverable ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isAvailable ? (byte) 1 : (byte) 0);
        dest.writeDouble(this.itemTotal);
        dest.writeDouble(this.taxTotal);
        dest.writeDouble(this.total);
    }

    public void readFromParcel(Parcel source) {
        this.storeVariant = source.readParcelable(StoreVariantDTO.class.getClassLoader());
        this.quantity = source.readInt();
        this.isDeliverable = source.readByte() != 0;
        this.isAvailable = source.readByte() != 0;
        this.itemTotal = source.readDouble();
        this.taxTotal = source.readDouble();
        this.total = source.readDouble();
    }

    public CartItem() {
    }

    protected CartItem(Parcel in) {
        this.storeVariant = in.readParcelable(StoreVariantDTO.class.getClassLoader());
        this.quantity = in.readInt();
        this.isDeliverable = in.readByte() != 0;
        this.isAvailable = in.readByte() != 0;
        this.itemTotal = in.readDouble();
        this.taxTotal = in.readDouble();
        this.total = in.readDouble();
    }

    public static final Parcelable.Creator<CartItem> CREATOR = new Parcelable.Creator<CartItem>() {
        @Override
        public CartItem createFromParcel(Parcel source) {
            return new CartItem(source);
        }

        @Override
        public CartItem[] newArray(int size) {
            return new CartItem[size];
        }
    };
}
