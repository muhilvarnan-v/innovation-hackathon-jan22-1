package com.flytekart.customer.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.flytekart.customer.R;
import com.flytekart.customer.models.Address;
import com.flytekart.customer.models.Store;
import com.flytekart.customer.utils.Utilities;

import java.util.List;

public class LocationChooserOptionsAdapter extends BaseAdapter {

    private Context context;
    private String[] options;

    public LocationChooserOptionsAdapter(Context context, boolean isLoggedIn) {
        this.context = context;
        if (isLoggedIn) {
            this.options = new String[]{"Choose from map", "Choose from saved addresses"};
        } else {
            this.options = new String[]{"Choose from map"};
        }
    }

    @Override
    public int getCount() {
        return options.length;
    }

    @Override
    public Object getItem(int position) {
        return options[position];
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            rowView = inflater.inflate(android.R.layout.simple_list_item_1, parent, false);
        } else {
            rowView = convertView;
        }

        TextView tvOptionName = rowView.findViewById(android.R.id.text1);

        tvOptionName.setText(options[position]);

        return rowView;
    }
}
