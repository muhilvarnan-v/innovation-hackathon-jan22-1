package com.flytekart.customer.ui.activity;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.request.CreateAddressRequest;
import com.flytekart.customer.models.response.ApiCallResponse;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Response;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap googleMap;
    private ImageView ivCurrentLocation;
    private TextView tvLocationDesc;
    private Button btnAddress;
    private Button btnSelectLocation;
    private View svAddAddress;
    private TextInputEditText etLine1;
    private TextInputEditText etLine2;
    private com.flytekart.customer.models.Address address;
    private boolean cameraMoveStarted = false;
    private int mapsMode;
    private SharedPreferences sharedPreferences;
    private String accessToken;
    private int position;
    private ProgressDialog progressDialog;

    public static final int MODE_ADDRESS = 1001;
    public static final int MODE_LAT_LNG_LOCATION = 1002;
    public static final int MODE_SAVE_DELIVERY_ADDRESS = 1003;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        address = getIntent().getParcelableExtra(Constants.ADDRESS);
        position = getIntent().getIntExtra(Constants.SELECTED_POSITION, -1);
        mapsMode = getIntent().getIntExtra(Constants.MAPS_MODE, -1);
        mapFragment.getMapAsync(this);

        ivCurrentLocation = findViewById(R.id.iv_current_location);
        tvLocationDesc = findViewById(R.id.tv_location_desc);
        btnAddress = findViewById(R.id.btn_add_address);
        etLine1 = findViewById(R.id.et_line_1);
        etLine2 = findViewById(R.id.et_line_2);
        svAddAddress = findViewById(R.id.sv_add_address);
        btnSelectLocation = findViewById(R.id.btn_select_location);

        /*etLine1.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        etLine2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        etLandmark.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);*/

        ivCurrentLocation.setOnClickListener(view -> {
            showLocationServicesPopup();
        });

        if (mapsMode == MODE_SAVE_DELIVERY_ADDRESS) {
            svAddAddress.setVisibility(View.VISIBLE);
            btnSelectLocation.setVisibility(View.GONE);
        } else {
            svAddAddress.setVisibility(View.GONE);
            btnSelectLocation.setVisibility(View.VISIBLE);
        }

        btnAddress.setOnClickListener(view -> {
            selectAddress();
        });
        btnSelectLocation.setOnClickListener(view -> {
            selectAddress();
        });
        sharedPreferences = Utilities.getSharedPreferences();
        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, null);
        setAddressToFields();
        if (mapsMode == MODE_SAVE_DELIVERY_ADDRESS) {
            btnAddress.setText(R.string.save_address);
        }
    }

    private void selectAddress() {
        String line1 = etLine1.getText().toString().trim();
        if (line1.endsWith(Constants.COMMA)) {
            line1 = line1.substring(0, line1.length() - 1);
        }
        // Only while saving, we need the delivery address fully.
        if (mapsMode == MODE_SAVE_DELIVERY_ADDRESS && line1.isEmpty()) {
            Toast.makeText(MapsActivity.this, "Address line 1 cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }
        String line2 = etLine2.getText().toString().trim();
        if (line2.endsWith(Constants.COMMA)) {
            line2 = line2.substring(0, line1.length() - 1);
        }
            /*if (line2.isEmpty()) {
                Toast.makeText(MapsActivity.this, "Address line cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }*/
        if (address == null) {
            Toast.makeText(getApplicationContext(), R.string.err_add_address, Toast.LENGTH_SHORT).show();
            //Toast.makeText(MapsActivity.this, "Address did not fetched. Please try again later.", Toast.LENGTH_SHORT).show();
            return;
        }
        address.setLine1(line1);
        address.setLine2(line2);
        if (mapsMode == MODE_SAVE_DELIVERY_ADDRESS) {
            saveDeliveryAddress();
        } else {
            closeMaps();
        }
    }

    private void closeMaps() {
        Intent intent = new Intent();
        intent.putExtra(Constants.ADDRESS, address);
        intent.putExtra(Constants.SELECTED_POSITION, position);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }

    private void setAddressToFields() {
        if (address != null) {
            etLine1.setText(address.getLine1());
            etLine2.setText(address.getLine2());

            StringBuilder builder = new StringBuilder();
            builder.append(address.getCity()).append(Constants.COMMA_SPACE);
            builder.append(address.getState()).append(Constants.COMMA_SPACE);
            builder.append(address.getCountry()).append(Constants.COMMA_SPACE);
            builder.append(address.getZip());
            tvLocationDesc.setText(builder.toString());
        }
    }

    private void showCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ArrayList<String> permissionsList = new ArrayList<>();
            if (ContextCompat.checkSelfPermission(MapsActivity.this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(Manifest.permission.ACCESS_FINE_LOCATION);
            }
            if (ContextCompat.checkSelfPermission(MapsActivity.this,
                    Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            }

            if (permissionsList.size() > 0) {
                ActivityCompat.requestPermissions(MapsActivity.this,
                        permissionsList.toArray(new String[permissionsList.size()]),
                        1001);
            }
            return;
        }

        // TODO Check if location service is ON
        FusedLocationProviderClient mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mFusedLocationClient.getLastLocation()
                .addOnSuccessListener(new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // GPS location can be null if GPS is switched off
                        if (location != null) {
                            loadMapFromLatLng(location.getLatitude(), location.getLongitude());
                            getAddress(location.getLatitude(), location.getLongitude());
                        } else {
                            sendLocationRequest();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Logger.e("Error trying to get last GPS location");
                        e.printStackTrace();
                    }
                });
    }

    private SettingsClient mSettingsClient;
    private LocationSettingsRequest mLocationSettingsRequest;
    private LocationCallback mLocationCallback;
    private static final int REQUEST_CHECK_SETTINGS = 214;
    private static final int REQUEST_ENABLE_GPS = 516;

    private void showLocationServicesPopup() {
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(LocationRequest.create().setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY));
        builder.setAlwaysShow(true);
        mLocationSettingsRequest = builder.build();

        mSettingsClient = LocationServices.getSettingsClient(MapsActivity.this);

        mSettingsClient
                .checkLocationSettings(mLocationSettingsRequest)
                .addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
                    @Override
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        //Success Perform Task Here
                        showCurrentLocation();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        int statusCode = ((ApiException) e).getStatusCode();
                        switch (statusCode) {
                            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                try {
                                    ResolvableApiException rae = (ResolvableApiException) e;
                                    rae.startResolutionForResult(MapsActivity.this, REQUEST_CHECK_SETTINGS);
                                } catch (IntentSender.SendIntentException sie) {
                                    Log.e("GPS","Unable to execute request.");
                                }
                                break;
                            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                Log.e("GPS","Location settings are inadequate, and cannot be fixed here. Fix in Settings.");
                        }
                    }
                })
                .addOnCanceledListener(new OnCanceledListener() {
                    @Override
                    public void onCanceled() {
                        Log.e("GPS","checkLocationSettings -> onCanceled");
                    }
                });
    }

    private void sendLocationRequest() {
        LocationRequest mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(60000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationCallback mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null || locationResult.getLocations().size() == 0) {
                    return;
                }
                Location location = locationResult.getLocations().get(0);
                removeLocationUpdates();
                loadMapFromLatLng(location.getLatitude(), location.getLongitude());
                getAddress(location.getLatitude(), location.getLongitude());
            }
        };
        LocationServices.getFusedLocationProviderClient(MapsActivity.this)
                .requestLocationUpdates(mLocationRequest, mLocationCallback, null);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CHECK_SETTINGS) {
            switch (resultCode) {
                case Activity.RESULT_OK:
                    //Success Perform Task Here
                    showCurrentLocation();
                    break;
                case Activity.RESULT_CANCELED:
                    Log.e("GPS","User denied to access location");
                    openGpsEnableSetting();
                    break;
            }
        } else if (requestCode == REQUEST_ENABLE_GPS) {
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            boolean isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

            if (!isGpsEnabled) {
                //openGpsEnableSetting(); Do nothing for now
            } else {
                showCurrentLocation();
            }
        }
    }

    private void openGpsEnableSetting() {
        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivityForResult(intent, REQUEST_ENABLE_GPS);
    }

    private void loadMapFromLatLng(double latitude, double longitude) {
        LatLng latLng = new LatLng(latitude, longitude);
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title(latLng.latitude + " : " + latLng.longitude);
        googleMap.clear();
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));
        googleMap.addMarker(markerOptions);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;
        if (address == null) {
            showLocationServicesPopup();
        } else {
            loadMapFromLatLng(address.getLatitude(), address.getLongitude());
        }

        this.googleMap.setOnCameraMoveStartedListener(new GoogleMap.OnCameraMoveStartedListener() {
            @Override
            public void onCameraMoveStarted(int reason) {
                if (reason == REASON_GESTURE) {
                    Logger.d("Gesture");
                    cameraMoveStarted = true;
                } else if (reason == REASON_API_ANIMATION) {
                    Logger.d("API animation");
                } else if (reason == REASON_DEVELOPER_ANIMATION) {
                    Logger.d("Dev animation");
                }
            }
        });
        this.googleMap.setOnCameraIdleListener(new GoogleMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {
                if (cameraMoveStarted) {
                    LatLng latLng = MapsActivity.this.googleMap.getCameraPosition().target;
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(latLng);
                    markerOptions.title(latLng.latitude + " : " + latLng.longitude);
                    googleMap.clear();
                    googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                    googleMap.addMarker(markerOptions);
                    MapsActivity.this.getAddress(latLng.latitude, latLng.longitude);
                    cameraMoveStarted = false;
                }
            }
        });

    }

    public void getAddress(double lat, double lng) {
        Geocoder geocoder = new Geocoder(MapsActivity.this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            if (addresses.size() > 0) {
                Address obj = addresses.get(0);
                if (address == null) {
                    address = new com.flytekart.customer.models.Address();
                }
                address.setCity(obj.getSubAdminArea());
                address.setState(obj.getAdminArea());
                address.setCountry(obj.getCountryName());
                address.setZip(obj.getPostalCode());
                address.setLatitude(lat);
                address.setLongitude(lng);
                setAddressToFields();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == Constants.LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0) {
                showLocationServicesPopup();
            }
        }
    }

    private void saveDeliveryAddress() {
        CreateAddressRequest request = new CreateAddressRequest();
        request.setId(address.getId());
        request.setLine1(address.getLine1());
        request.setLine2(address.getLine2());
        request.setCity(address.getCity());
        request.setState(address.getState());
        request.setCountry(address.getCountry());
        request.setZip(address.getZip());
        request.setLatitude(String.valueOf(address.getLatitude()));
        request.setLongitude(String.valueOf(address.getLongitude()));
        showProgress(true);
        Call<BaseResponse<com.flytekart.customer.models.Address>> saveAddressCall = Flytekart.getApiService().saveDeliveryAddress(
                accessToken, BuildConfig.CLIENT_ID, request);
        saveAddressCall.enqueue(new CustomCallback<BaseResponse<com.flytekart.customer.models.Address>>() {
            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<com.flytekart.customer.models.Address>> call, Response<BaseResponse<com.flytekart.customer.models.Address>> response) {
                Logger.i("Save address API call response received.");
                showProgress(false);
                if (response.isSuccessful() && response.body() != null) {
                    address = response.body().getBody();
                    // Get dropdown data and go to next screen.
                    Toast.makeText(getApplicationContext(), "Address saved successfully.", Toast.LENGTH_SHORT).show();
                    closeMaps();
                } else if (response.errorBody() != null) {
                    try {
                        ApiCallResponse apiCallResponse = new Gson().fromJson(
                                response.errorBody().string(), ApiCallResponse.class);
                        Toast.makeText(getApplicationContext(), apiCallResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Logger.e("Save address API response status code : " + response.code());
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<com.flytekart.customer.models.Address>> call, APIError responseBody) {
                Logger.i("Save address API call failed.");
                showProgress(false);
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<com.flytekart.customer.models.Address>> call) {
                Logger.i("Save address API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    private void removeLocationUpdates() {
        if (mLocationCallback != null) {
            LocationServices.getFusedLocationProviderClient(MapsActivity.this)
                    .removeLocationUpdates(mLocationCallback);
        }
    }

    @Override
    protected void onDestroy() {
        removeLocationUpdates();
        super.onDestroy();
    }
}