package com.flytekart.customer.ui.adapter;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.flytekart.customer.R;
import com.flytekart.customer.models.Cart;
import com.flytekart.customer.models.Category;
import com.flytekart.customer.models.FoodCode;
import com.flytekart.customer.models.Item;
import com.flytekart.customer.models.StoreProductDTO;

import java.util.List;

public class SearchItemsAdapter extends RecyclerView.Adapter<SearchItemsAdapter.SearchItemViewHolder> implements View.OnClickListener {

    private static final int VIEW_TYPE_CATEGORY = 0;
    private static final int VIEW_TYPE_ITEM = 1;
    private Cart cart;
    private List<Category> categories;
    private List<Item> items;
    private SearchItemListener searchItemListener;

    public SearchItemsAdapter(List<Category> categories, List<Item> items, Cart cart, SearchItemListener searchItemListener) {
        this.categories = categories;
        this.items = items;
        this.cart = cart;
        this.searchItemListener = searchItemListener;
    }

    @NonNull
    @Override
    public SearchItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_CATEGORY) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_search_category_item, parent, false);
            return new SearchItemViewHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_search_item, parent, false);
            return new SearchItemViewHolder(v);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull SearchItemViewHolder holder, int position) {

        if (categories != null && position < categories.size()) {
            Category category = categories.get(position);
            holder.ivItem.setImageResource(category.colorCode);
            holder.tvCategoryName.setText(category.name);

            holder.itemView.setTag(category);
            holder.itemView.setTag(R.id.rl_item, position);
            holder.itemView.setOnClickListener(this);
        } else {
            int itemPosition = -1;
            if (categories == null) {
                itemPosition = position;
            } else {
                itemPosition = position - categories.size();
            }
            Item item = items.get(itemPosition);

            holder.ivItem.setImageResource(item.colorCode);
            holder.tvItemName.setText(item.itemName);
            holder.tvPrice.setText(item.currencyCode + item.price);
            if (item.oldPrice == -1) {
                holder.tvOldPrice.setVisibility(View.INVISIBLE);
            } else {
                holder.tvOldPrice.setVisibility(View.VISIBLE);
                holder.tvOldPrice.setText(item.currencyCode + item.oldPrice);
                holder.tvOldPrice.setPaintFlags(holder.tvOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            }
            holder.tvQuantity.setText(item.quantity);
            if (item.foodCode == FoodCode.NONE) {
                holder.ivVegSymbol.setVisibility(View.GONE);
            } else if (item.foodCode == FoodCode.VEG) {
                holder.ivVegSymbol.setVisibility(View.VISIBLE);
                holder.ivVegSymbol.setImageResource(R.drawable.ic_veg);
            } else if (item.foodCode == FoodCode.NONVEG) {
                holder.ivVegSymbol.setVisibility(View.VISIBLE);
                holder.ivVegSymbol.setImageResource(R.drawable.ic_non_veg);
            }

            holder.itemView.setTag(item);
            holder.itemView.setTag(R.id.rl_item, position);
            holder.tvAdd.setTag(item);
            holder.tvAdd.setTag(R.id.rl_item, position);
            holder.tvIncrement.setTag(item);
            holder.tvIncrement.setTag(R.id.rl_item, position);
            holder.tvDecrement.setTag(item);
            holder.tvDecrement.setTag(R.id.rl_item, position);
            holder.itemView.setOnClickListener(this);
            holder.tvAdd.setOnClickListener(this);
            holder.tvIncrement.setOnClickListener(this);
            holder.tvDecrement.setOnClickListener(this);

            // Check cart presence
            checkCartPresence(item, holder);
        }
    }

    private void checkCartPresence(Item item, SearchItemViewHolder holder) {
        boolean foundMatch = false;
        if (cart != null) {
            /*for (OrderItemDTO dto : cart.getOrderItems()) {
                if (item.id == dto.getStoreVariantId()) {// TODO Wrong comparison
                    holder.tvAdd.setVisibility(View.GONE);
                    holder.llItemCounter.setVisibility(View.VISIBLE);
                    holder.tvCounter.setText(String.valueOf(cartItem.quantity));
                    foundMatch = true;
                    break;
                }
            }*/
        }
        if (!foundMatch) {
            holder.tvAdd.setVisibility(View.VISIBLE);
            holder.llItemCounter.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        int length = 0;
        if (categories != null) {
            length = length + categories.size();
        }
        if (items != null) {
            length = length + items.size();
        }
        return length;
    }

    @Override
    public int getItemViewType(int position) {
        if (categories != null && position < categories.size()) {
            return VIEW_TYPE_CATEGORY;
        } else {
            return VIEW_TYPE_ITEM;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_item: {
                Object tag = v.getTag();
                if (tag instanceof Item) {
                    Item item = (Item) tag;
                    int position = (int) v.getTag(R.id.rl_item);
                    searchItemListener.onItemClicked(position, item);
                } else {
                    Category category = (Category) tag;
                    int position = (int) v.getTag(R.id.rl_item);
                    searchItemListener.onCategoryClicked(position, category);
                }
                break;
            }case R.id.tv_add: {
                StoreProductDTO storeProduct = (StoreProductDTO) v.getTag();
                int position = (int) v.getTag(R.id.rl_item);
                searchItemListener.onAddClick(position, storeProduct);
                break;
            }
            case R.id.tv_increment: {
                StoreProductDTO storeProduct = (StoreProductDTO) v.getTag();
                int position = (int) v.getTag(R.id.rl_item);
                searchItemListener.onItemIncrement(position, storeProduct);
                break;
            }
            case R.id.tv_decrement: {
                StoreProductDTO storeProduct = (StoreProductDTO) v.getTag();
                int position = (int) v.getTag(R.id.rl_item);
                searchItemListener.onItemDecrement(position, storeProduct);
                break;
            }
        }
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public static class SearchItemViewHolder extends RecyclerView.ViewHolder {

        // Item view type
        ImageView ivItem;
        TextView tvItemName;
        TextView tvPrice;
        TextView tvOldPrice;
        TextView tvQuantity;
        ImageView ivVegSymbol;
        TextView tvAdd;
        TextView tvCounter;
        TextView tvIncrement;
        TextView tvDecrement;
        View llItemCounter;

        // Category view type
        TextView tvCategoryName;

        public SearchItemViewHolder(@NonNull View itemView) {
            super(itemView);

            ivItem = itemView.findViewById(R.id.iv_item);
            tvItemName = itemView.findViewById(R.id.tv_item_name);
            tvPrice = itemView.findViewById(R.id.tv_item_price);
            tvOldPrice = itemView.findViewById(R.id.tv_item_old_price);
            tvQuantity = itemView.findViewById(R.id.tv_item_quantity);
            ivVegSymbol = itemView.findViewById(R.id.iv_veg_symbol);
            tvAdd = itemView.findViewById(R.id.tv_add);
            tvAdd = itemView.findViewById(R.id.tv_add);
            tvCounter = itemView.findViewById(R.id.tv_counter);
            tvIncrement = itemView.findViewById(R.id.tv_increment);
            tvDecrement = itemView.findViewById(R.id.tv_decrement);
            llItemCounter = itemView.findViewById(R.id.ll_item_counter);


            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
        }
    }

    public interface SearchItemListener {
        void onItemClicked(int position, Item item);
        void onAddClick(int position, StoreProductDTO storeProduct);
        void onItemIncrement(int position, StoreProductDTO storeProduct);
        void onItemDecrement(int position, StoreProductDTO storeProduct);
        void onCategoryClicked(int position, Category category);
    }
}
