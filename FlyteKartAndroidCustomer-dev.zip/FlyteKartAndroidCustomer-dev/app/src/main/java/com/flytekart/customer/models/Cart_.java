package com.flytekart.customer.models;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Cart_ implements Parcelable {
    public ArrayList<CartItem> cartItems;
    public double itemsTotal;
    public double taxTotal;
    public double total;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(this.cartItems);
        dest.writeDouble(this.itemsTotal);
        dest.writeDouble(this.taxTotal);
        dest.writeDouble(this.total);
    }

    public Cart_() {
    }

    protected Cart_(Parcel in) {
        this.cartItems = in.createTypedArrayList(CartItem.CREATOR);
        this.itemsTotal = in.readDouble();
        this.taxTotal = in.readDouble();
        this.total = in.readDouble();
    }

    public static final Creator<Cart_> CREATOR = new Creator<Cart_>() {
        @Override
        public Cart_ createFromParcel(Parcel source) {
            return new Cart_(source);
        }

        @Override
        public Cart_[] newArray(int size) {
            return new Cart_[size];
        }
    };
}
