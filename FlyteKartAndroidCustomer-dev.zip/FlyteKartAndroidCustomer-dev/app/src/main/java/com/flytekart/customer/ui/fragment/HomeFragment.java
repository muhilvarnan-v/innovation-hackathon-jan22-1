package com.flytekart.customer.ui.fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.HeroPagerItem;
import com.flytekart.customer.models.dto.StoreCategoryDTO;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.ui.activity.CategoryItemsActivity;
import com.flytekart.customer.ui.adapter.HeroPagerAdapter;
import com.flytekart.customer.ui.custom.ViewPagerIndicator;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

public class HomeFragment extends Fragment implements HeroPagerAdapter.OnPagerClickListener, View.OnClickListener {

    private ViewPager vpLatest;
    private ViewPagerIndicator vpiLatest;
    private GridLayout glCategories;
    private int viewPagerWidth;
    private int viewPagerHeight;
    private int categoriesLayoutItemWidth;
    private List<StoreCategoryDTO> storeCategories;
    private String accessToken;
    private ProgressDialog progressDialog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        vpLatest = view.findViewById(R.id.vp_latest);
        vpiLatest = view.findViewById(R.id.vpi_latest);
        glCategories = view.findViewById(R.id.gl_categories);
        setViewPagerLayout();
        setCategoriesLayout();

        SharedPreferences sharedPreferences = Utilities.getSharedPreferences();
        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, Constants.EMPTY);

        setViewPager();
    }

    /**
     * Hiding the view pager for now.
     * We'll show it after we implement the banner adding functionality.
     */
    private void setViewPagerLayout() {
        if (getActivity() != null && isAdded()) {
            /*DisplayMetrics displayMetrics = new DisplayMetrics();
            getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            viewPagerWidth = displayMetrics.widthPixels;
            viewPagerHeight = (int) (viewPagerWidth * 0.6f);
            vpLatest.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, viewPagerHeight));*/
            vpLatest.setVisibility(View.GONE);
        }
    }

    private void setCategoriesLayout() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if (getActivity() != null && isAdded()) {
            getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int totalWidth = displayMetrics.widthPixels;
            int categoriesLayoutWidth = totalWidth - 2 * (getActivity().getResources().getDimensionPixelSize(R.dimen.padding_15));
            categoriesLayoutItemWidth = categoriesLayoutWidth / 3;
        }
    }

    public void getCategories(String storeId) {
        showProgress(true);
        Call<BaseResponse<List<StoreCategoryDTO>>> getCategoriesCall = Flytekart.getApiService().getStoreCategoriesByStoreId(accessToken, storeId, BuildConfig.CLIENT_ID);
        getCategoriesCall.enqueue(new CustomCallback<BaseResponse<List<StoreCategoryDTO>>>() {

            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<List<StoreCategoryDTO>>> call, Response<BaseResponse<List<StoreCategoryDTO>>> response) {
                Logger.e("Categories list response received.");
                showProgress(false);
                if (response.isSuccessful() && response.body() != null) {
                    storeCategories = response.body().getBody();
                    setCategories();
                }
                Logger.e("Categories List API call response status code : " + response.code());
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<List<StoreCategoryDTO>>> call, APIError responseBody) {
                Logger.e("Categories List API call failed");
                showProgress(false);
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<List<StoreCategoryDTO>>> call) {
                Logger.e("Categories List API call failure.");
                showProgress(false);
                Toast.makeText(getContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /*private void getCategories2() {
        // TODO Make categories list API call
        Category category1 = new Category();
        category1.colorCode = R.color.randomColor1;
        category1.categoryName = "Snacks";

        Category category2 = new Category();
        category2.colorCode = R.color.randomColor2;
        category2.categoryName = "Continental";

        Category category3 = new Category();
        category3.colorCode = R.color.randomColor3;
        category3.categoryName = "Tandoori";

        Category category4 = new Category();
        category4.colorCode = R.color.randomColor4;
        category4.categoryName = "European";

        Category category5 = new Category();
        category5.colorCode = R.color.randomColor5;
        category5.categoryName = "Chef special";

        Category category6 = new Category();
        category6.colorCode = R.color.randomColor2;
        category6.categoryName = "Continental";

        Category category7 = new Category();
        category7.colorCode = R.color.randomColor3;
        category7.categoryName = "Tandoori";

        Category category8 = new Category();
        category8.colorCode = R.color.randomColor4;
        category8.categoryName = "European";

        Category category9 = new Category();
        category9.colorCode = R.color.randomColor5;
        category9.categoryName = "Chef special";

        categories = new ArrayList<>(5);
        categories.add(category1);
        categories.add(category2);
        categories.add(category3);
        categories.add(category4);
        categories.add(category5);
        categories.add(category6);
        categories.add(category7);
        categories.add(category8);
        //categories.add(category9);
    }*/

    private void setCategories() {
        glCategories.removeAllViews();
        glCategories.setColumnCount(3);
        int rowCount = 0;
        if (storeCategories.size() % 3 > 0) {
            rowCount = (storeCategories.size() / 3) + 1;
        } else {
            rowCount = storeCategories.size() / 3;
        }
        glCategories.setRowCount(rowCount);

        // TODO Add to gridlayout
        for (int i = 0; i < storeCategories.size(); i++) {
            View categoryView = getLayoutInflater().inflate(R.layout.grid_item_category, null, false);

            GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
            //noinspection SuspiciousNameCombination
            layoutParams.height = categoriesLayoutItemWidth;
            layoutParams.width = categoriesLayoutItemWidth;
            categoryView.setLayoutParams(layoutParams);

            ImageView ivCategory = categoryView.findViewById(R.id.iv_category);
            TextView tvCategoryName = categoryView.findViewById(R.id.tv_category_name);

            //ivCategory.setImageResource(categories.get(i).colorCode);
            tvCategoryName.setText(storeCategories.get(i).getName());

            categoryView.setId(View.generateViewId());
            categoryView.setTag(storeCategories.get(i));
            categoryView.setOnClickListener(this);
            glCategories.addView(categoryView);
        }
    }

    private void setViewPager() {
        HeroPagerItem heroPagerItem1 = new HeroPagerItem();
        heroPagerItem1.colorCode = R.color.randomColor1;
        heroPagerItem1.title = "10% off on all deliveries today";

        HeroPagerItem heroPagerItem2 = new HeroPagerItem();
        heroPagerItem2.colorCode = R.color.randomColor2;
        heroPagerItem2.title = "5% off on special items";

        HeroPagerItem heroPagerItem3 = new HeroPagerItem();
        heroPagerItem3.colorCode = R.color.randomColor3;
        heroPagerItem3.title = "New items added";

        HeroPagerItem heroPagerItem4 = new HeroPagerItem();
        heroPagerItem4.colorCode = R.color.randomColor4;
        heroPagerItem4.title = "Exclusive content";

        HeroPagerItem heroPagerItem5 = new HeroPagerItem();
        heroPagerItem5.colorCode = R.color.randomColor5;
        heroPagerItem5.title = "Special offer just for you!";

        List<HeroPagerItem> heroPagerItems = new ArrayList<>(5);
        heroPagerItems.add(heroPagerItem1);
        heroPagerItems.add(heroPagerItem2);
        heroPagerItems.add(heroPagerItem3);
        heroPagerItems.add(heroPagerItem4);
        heroPagerItems.add(heroPagerItem5);

        HeroPagerAdapter heroPagerAdapter = new HeroPagerAdapter(this,
                heroPagerItems, viewPagerWidth, viewPagerHeight);
        vpLatest.setAdapter(heroPagerAdapter);
        vpiLatest.setViewPager(vpLatest);
    }

    @Override
    public void onPagerClick(HeroPagerItem heroPagerItem, int position) {
        if (getActivity() != null && isAdded()) {
            //Toast.makeText(getActivity(), "Item position clicked: " + position, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View v) {
        for (int i = 0; i < glCategories.getChildCount(); i++) {
            View categoryView = glCategories.getChildAt(i);
            if (v.getId() == categoryView.getId() && getActivity() != null && isAdded()) {
                StoreCategoryDTO category = (StoreCategoryDTO) categoryView.getTag();
                //Toast.makeText(getActivity(), "Category clicked: " + category.categoryName, Toast.LENGTH_SHORT).show();
                Intent categoryIntent = new Intent(getActivity(), CategoryItemsActivity.class);
                categoryIntent.putExtra(Constants.CATEGORY, category);
                startActivity(categoryIntent);
                break;
            }
        }
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(getActivity());
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}
