package com.flytekart.customer.ui.activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.Address;
import com.flytekart.customer.models.Cart;
import com.flytekart.customer.models.Store;
import com.flytekart.customer.models.StoreVariantDTO;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.ui.adapter.AddressListAdapter;
import com.flytekart.customer.ui.adapter.HomePagerAdapter;
import com.flytekart.customer.ui.adapter.LocationChooserOptionsAdapter;
import com.flytekart.customer.ui.adapter.StoreListAdapter;
import com.flytekart.customer.ui.fragment.HomeFragment;
import com.flytekart.customer.ui.fragment.MyAccountFragment;
import com.flytekart.customer.ui.fragment.SearchFragment;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;
import com.google.gson.Gson;
import com.skydoves.androidbottombar.AndroidBottomBarView;
import com.skydoves.androidbottombar.BottomMenuItem;
import com.skydoves.androidbottombar.OnMenuItemSelectedListener;
import com.skydoves.androidbottombar.animations.BadgeAnimation;
import com.skydoves.androidbottombar.forms.BadgeForm;
import com.skydoves.androidbottombar.forms.IconForm;
import com.skydoves.androidbottombar.forms.TitleForm;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

// Color combo: https://www.color-hex.com/color-palette/24587
public class HomeActivity extends BaseActivity implements OnMenuItemSelectedListener, SearchFragment.FragmentInteractionListener {

    private AndroidBottomBarView androidBottomBarView;
    private ViewPager vpFragments;
    private HomePagerAdapter homePagerAdapter;
    private SharedPreferences sharedPreferences;
    private Address deliveryAddress;
    //private String storeId = "cf86a1b0-9230-4425-8971-9b924cddeeac";
    private String accessToken;
    private ProgressDialog progressDialog;
    private AlertDialog storesListDialog;
    private AlertDialog locationChooserOptionsDialog;
    private AlertDialog noStoresDialog;
    private Toolbar toolbar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        setTitle(R.string.app_name);

        TitleForm titleForm = new TitleForm();
        titleForm.setTitleColor(Color.WHITE);
        titleForm.setTitleActiveColor(Color.WHITE);

        IconForm iconForm = new IconForm();
        iconForm.setIconSize(84);

        BadgeForm badgeForm = new BadgeForm();
        badgeForm.setBadgeTextSize(9f);
        badgeForm.setBadgePaddingLeft(2);
        badgeForm.setBadgePaddingRight(2);
        badgeForm.setBadgeDuration(550);

        BottomMenuItem homeBottomMenuItem = new BottomMenuItem(this);
        homeBottomMenuItem.setTitleForm(titleForm)
                .setIconForm(iconForm)
                .setBadgeForm(badgeForm)
                .setTitle("Home")
                .setTitleActiveColorRes(android.R.color.white)
                .setBadgeColorRes(R.color.white)
                .setBadgeAnimation(BadgeAnimation.FADE)
                .setIcon(R.drawable.ic_baseline_home_24).build();
        BottomMenuItem searchBottomMenuItem = new BottomMenuItem(this);
        searchBottomMenuItem.setTitleForm(titleForm)
                .setIconForm(iconForm)
                .setBadgeForm(badgeForm)
                .setTitle("Search")
                .setTitleActiveColorRes(android.R.color.white)
                .setBadgeColorRes(R.color.white)
                .setBadgeAnimation(BadgeAnimation.FADE)
                .setIcon(R.drawable.ic_baseline_search_24).build();
        BottomMenuItem accountBottomMenuItem = new BottomMenuItem(this);
        accountBottomMenuItem.setTitleForm(titleForm)
                .setIconForm(iconForm)
                .setBadgeForm(badgeForm)
                .setTitle("My Account")
                .setTitleActiveColorRes(android.R.color.white)
                .setBadgeColorRes(R.color.white)
                .setBadgeAnimation(BadgeAnimation.FADE)
                .setIcon(R.drawable.ic_baseline_account_circle_24).build();
        List<BottomMenuItem> bottomMenuItems = new ArrayList<>(3);
        bottomMenuItems.add(homeBottomMenuItem);
        bottomMenuItems.add(searchBottomMenuItem);
        bottomMenuItems.add(accountBottomMenuItem);

        androidBottomBarView = findViewById(R.id.android_bottom_bar);
        androidBottomBarView.addBottomMenuItems(bottomMenuItems);

        vpFragments = findViewById(R.id.vp_fragments);
        homePagerAdapter = new HomePagerAdapter(getSupportFragmentManager());
        vpFragments.setAdapter(homePagerAdapter);
        vpFragments.setOffscreenPageLimit(3);

        androidBottomBarView.bindViewPager(vpFragments);
        androidBottomBarView.setOnMenuItemSelectedListener(this);

        sharedPreferences = Utilities.getSharedPreferences();
        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, null);
        String addressString = sharedPreferences.getString(Constants.USED_ADDRESS, null);

        if (addressString != null) {
            getDeliveryAddress(addressString);
            getStore();
            // Load stores for the selected address
            getStoresByLatLng(deliveryAddress);
        } else {
            // Show popup to enable location? Or just take to Maps
            openLocationChooserOptions(false);
        }

        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Open maps with the selected address or open store selection if there are multiple stores
                /*Intent locationIntent = new Intent(HomeActivity.this, MapsActivity.class);
                startActivityForResult(locationIntent, MapsActivity.MODE_LAT_LNG_LOCATION);*/
                openLocationChooserOptions(true);
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, null);
    }

    private void openLocationChooserOptions(boolean isCancelable) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select location");

        builder.setSingleChoiceItems(new LocationChooserOptionsAdapter(HomeActivity.this, accessToken != null), -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: {
                        // Choose from map
                        Toast.makeText(HomeActivity.this, "Opening map", Toast.LENGTH_SHORT).show();
                        openMap();
                        break;
                    }
                    case 1: {
                        // Choose from saved addresses
                        Toast.makeText(HomeActivity.this, "Choose from saved addresses", Toast.LENGTH_SHORT).show();
                        selectSavedAddress();
                        break;
                    }
                }
            }
        });
        builder.setCancelable(isCancelable);

        // create and show the alert dialog
        locationChooserOptionsDialog = builder.create();
        locationChooserOptionsDialog.show();
    }

    private void openMap() {
        Intent locationIntent = new Intent(this, MapsActivity.class);
        startActivityForResult(locationIntent, MapsActivity.MODE_LAT_LNG_LOCATION);
    }

    private void selectSavedAddress() {
        Intent addressIntent = new Intent(this, MyAddressesActivity.class);
        addressIntent.putExtra(AddressListAdapter.MODE, AddressListAdapter.MODE_SELECT_DELIVERY_ADDRESS);
        addressIntent.putExtra(Constants.ADDRESS, deliveryAddress);
        startActivityForResult(addressIntent, 1001);
    }

    private void openStoreSelector(List<Store> stores) {
        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select store");

        builder.setSingleChoiceItems(new StoreListAdapter(this, stores), -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // user checked an item
                //Toast.makeText(HomeActivity.this, "Clicked: " + which, Toast.LENGTH_SHORT).show();
                onStoreSelected(stores.get(which));
            }
        });

        /*builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // user clicked OK
            }
        });
        builder.setNegativeButton("Cancel", null);*/
        builder.setNeutralButton("Change location", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                openLocationChooserOptions(false);
            }
        });
        builder.setCancelable(false);

        storesListDialog = builder.create();
        storesListDialog.show();
    }

    private void onNoNearestStores() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Sorry! There are no stores near by.");
        builder.setNeutralButton("Change location", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                openLocationChooserOptions(false);
            }
        });
        builder.setCancelable(false);

        noStoresDialog = builder.create();
        noStoresDialog.show();
    }

    private void onStoreSelected(Store selectedStore) {
        if (HomeActivity.this.store != null
                && !HomeActivity.this.store.getId().equals(selectedStore.getId())) {
            // When current store is different than previous store, clear cart
            cart = new Cart();
            saveCart();
            setupBadge();
        }
        HomeActivity.this.store = selectedStore;
        saveStore(HomeActivity.this.store);

        // Update tool bar with store name and location
        toolbar.setTitle(HomeActivity.this.store.getName());
        toolbar.setSubtitle(Utilities.getAddressString(HomeActivity.this.store.getAddress()));

        // Make an API call to get categories from this store. Connect to fragment method.
        getCategories();

        if (storesListDialog != null && storesListDialog.isShowing()) {
            storesListDialog.dismiss();
        }
    }

    private void getCategories() {
        HomeFragment homeFragment = (HomeFragment) homePagerAdapter.getItem(0);
        homeFragment.getCategories(store.getId());
    }

    protected void getDeliveryAddress(String addressString) {
        Gson gson = new Gson();
        if (addressString != null) {
            deliveryAddress = gson.fromJson(addressString, Address.class);
            setDeliveryAddressToUI(deliveryAddress);
        }
    }

    private void setStoreToUI(Store store) {
        getSupportActionBar().setTitle(store.getName());
        getSupportActionBar().setSubtitle(Utilities.getAddressString(store.getAddress()));
    }

    private void setDeliveryAddressToUI(Address deliveryAddress) {
        String addressString = Utilities.getAddressString(deliveryAddress);
        getSupportActionBar().setTitle(addressString);
        getSupportActionBar().setSubtitle(null);
    }

    @Override
    public void onMenuItemSelected(int i, BottomMenuItem bottomMenuItem, boolean b) {
        vpFragments.setCurrentItem(i);
        androidBottomBarView.dismissBadge(i);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        MyAccountFragment myAccountFragment = (MyAccountFragment) getSupportFragmentManager().getFragments().get(2);
        myAccountFragment.getLoginToken();
        myAccountFragment.enableUIBasedOnLogin();
        myAccountFragment.getUserDetails();
        myAccountFragment.setUserDetailsToUi();
    }

    @Override
    protected void refreshCartItems() {
        super.refreshCartItems();
        SearchFragment searchFragment = (SearchFragment) getSupportFragmentManager().getFragments().get(1);
        if (searchFragment.isAdded()) {
            searchFragment.refreshCartItems();
        }
    }

    @Override
    public Cart onAddFirstItemToCart(StoreVariantDTO storeVariant) {
        super.addFirstItemToCart(storeVariant);
        return cart;
    }

    @Override
    public Cart onIncrementItemInCart(StoreVariantDTO storeVariant) {
        super.incrementItemInCart(storeVariant);
        return cart;
    }

    @Override
    public Cart onDecrementItemInCart(StoreVariantDTO storeVariant) {
        super.decrementItemInCart(storeVariant);
        return cart;
    }

    @Override
    public void onSetupBadge() {
        super.setupBadge();
    }

    @Override
    public Cart onGetCart() {
        return getCart();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == MapsActivity.MODE_LAT_LNG_LOCATION
                || requestCode == 1001)
                && resultCode == RESULT_OK) {
            if (locationChooserOptionsDialog != null && locationChooserOptionsDialog.isShowing()) {
                locationChooserOptionsDialog.dismiss();
            }
            deliveryAddress = data.getParcelableExtra(Constants.ADDRESS);
            saveDeliveryAddress(deliveryAddress);
            toolbar.setTitle(Utilities.getAddressString(deliveryAddress));
            toolbar.setSubtitle(null);
            getStoresByLatLng(deliveryAddress);
        }
    }

    private void saveDeliveryAddress(Address address) {
        Gson gson = new Gson();
        String json = gson.toJson(address);
        sharedPreferences.edit().putString(Constants.USED_ADDRESS, json).apply();
    }

    private void saveStore(Store store) {
        Gson gson = new Gson();
        String json = gson.toJson(store);
        sharedPreferences.edit().putString(Constants.USED_STORE, json).apply();
    }

    private void getStoresByLatLng(Address address) {
        showProgress(true);
        Call<BaseResponse<List<Store>>> getStoreByLatLngCall = Flytekart.getApiService().getDeliverableStoresByLatLng(accessToken, address.getLatitude(), address.getLongitude(), BuildConfig.CLIENT_ID);
        getStoreByLatLngCall.enqueue(new CustomCallback<BaseResponse<List<Store>>>() {
            @Override
            public void onFlytekartGenericErrorResponse(Call<BaseResponse<List<Store>>> call) {
                Logger.e("Stores List API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<List<Store>>> call, Response<BaseResponse<List<Store>>> response) {
                Logger.e("Stores API success");
                showProgress(false);
                List<Store> stores = response.body().getBody();
                //Toast.makeText(getApplicationContext(), "Stores API success: " + stores.size(), Toast.LENGTH_SHORT).show();
                // Show the list of stores in a pop up and let the user choose one
                if (stores.size() > 1) {
                    openStoreSelector(stores);
                } else if (stores.size() == 1){
                    // Select the only store directly
                    onStoreSelected(stores.get(0));
                } else {
                    onNoNearestStores();
                }
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<List<Store>>> call, APIError responseBody) {
                Logger.e("Stores API call response status code");
                showProgress(false);
                Toast.makeText(getApplicationContext(), responseBody.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //Toast.makeText(this, "OnBackPressed", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        if (locationChooserOptionsDialog != null && locationChooserOptionsDialog.isShowing()) {
            locationChooserOptionsDialog.dismiss();
        }
        if (storesListDialog != null && storesListDialog.isShowing()) {
            storesListDialog.dismiss();
        }
        if (noStoresDialog != null && noStoresDialog.isShowing()) {
            noStoresDialog.dismiss();
        }
        super.onDestroy();
    }
}
