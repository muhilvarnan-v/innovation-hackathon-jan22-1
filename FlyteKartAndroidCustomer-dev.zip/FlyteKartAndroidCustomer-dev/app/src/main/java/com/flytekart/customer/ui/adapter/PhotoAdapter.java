package com.flytekart.customer.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.viewpager.widget.PagerAdapter;

import com.github.chrisbanes.photoview.PhotoView;
import com.flytekart.customer.R;

import java.util.List;

public class PhotoAdapter extends PagerAdapter {
    private List<Integer> album;

    public PhotoAdapter(List<Integer> album) {
        this.album = album;
    }

    @Override
    public int getCount() {
        if (album != null) {
            //return (blogPostSummaryList.size() * 100);
            return album.size();
        } else {
            return 0;
        }
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.photo_album_pager_item, container, false);
        int pos = position % album.size();

        PhotoView imageView = (PhotoView) view.findViewById(R.id.iv_album_photo);
        int heroImageUrl = album.get(position);

        /*Picasso.get().load(heroImageUrl)
                .into(imageView);*/
        imageView.setImageResource(heroImageUrl);

        view.setTag(R.layout.pager_item_latest, pos);
        view.setTag(album.get(pos));
        container.addView(view);
        try {
            container.removeViewAt(position - album.size());
        } catch (Exception e) {
            // Ignore
        }
        try {
            container.removeViewAt(position + album.size());
        } catch (Exception e) {
            // Ignore
        }
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        View view = (View) object;
        container.removeView(view);
    }
}
