package com.flytekart.customer.models;

import android.os.Parcel;
import android.os.Parcelable;

public class StoreVariantDTO implements Parcelable {
    public String productId;
    public String productName;
    public String storeVariantId;
    public String variantName;
    public String categoryName;
    public Double price;
    public Double tax;
    public Double originalPrice;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getStoreVariantId() {
        return storeVariantId;
    }

    public void setStoreVariantId(String storeVariantId) {
        this.storeVariantId = storeVariantId;
    }

    public String getVariantName() {
        return variantName;
    }

    public void setVariantName(String variantName) {
        this.variantName = variantName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public Double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(Double originalPrice) {
        this.originalPrice = originalPrice;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.productId);
        dest.writeString(this.productName);
        dest.writeString(this.storeVariantId);
        dest.writeString(this.variantName);
        dest.writeString(this.categoryName);
        dest.writeValue(this.price);
        dest.writeValue(this.tax);
        dest.writeValue(this.originalPrice);
    }

    public void readFromParcel(Parcel source) {
        this.productId = source.readString();
        this.productName = source.readString();
        this.storeVariantId = source.readString();
        this.variantName = source.readString();
        this.categoryName = source.readString();
        this.price = (Double) source.readValue(Double.class.getClassLoader());
        this.tax = (Double) source.readValue(Double.class.getClassLoader());
        this.originalPrice = (Double) source.readValue(Double.class.getClassLoader());
    }

    public StoreVariantDTO() {
    }

    protected StoreVariantDTO(Parcel in) {
        this.productId = in.readString();
        this.productName = in.readString();
        this.storeVariantId = in.readString();
        this.variantName = in.readString();
        this.categoryName = in.readString();
        this.price = (Double) in.readValue(Double.class.getClassLoader());
        this.tax = (Double) in.readValue(Double.class.getClassLoader());
        this.originalPrice = (Double) in.readValue(Double.class.getClassLoader());
    }

    public static final Parcelable.Creator<StoreVariantDTO> CREATOR = new Parcelable.Creator<StoreVariantDTO>() {
        @Override
        public StoreVariantDTO createFromParcel(Parcel source) {
            return new StoreVariantDTO(source);
        }

        @Override
        public StoreVariantDTO[] newArray(int size) {
            return new StoreVariantDTO[size];
        }
    };
}
