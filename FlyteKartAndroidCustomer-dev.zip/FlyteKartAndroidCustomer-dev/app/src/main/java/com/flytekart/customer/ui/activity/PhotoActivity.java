package com.flytekart.customer.ui.activity;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.flytekart.customer.R;
import com.flytekart.customer.ui.adapter.PhotoAdapter;
import com.flytekart.customer.ui.custom.ViewPagerIndicator;
import com.flytekart.customer.utils.Constants;

import java.util.List;

public class PhotoActivity extends AppCompatActivity {

    private ViewPager vpPhotoAlbum;
    private ViewPagerIndicator vpiPhotoAlbum;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);

        vpPhotoAlbum = (ViewPager) findViewById(R.id.vp_photo_album);
        vpiPhotoAlbum = (ViewPagerIndicator) findViewById(R.id.vpi_photo_album);

       /* DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = (int) (width * 0.75f);*/

        List<Integer> album = getIntent().getIntegerArrayListExtra(Constants.ITEM_PHOTO_LIST);
        vpPhotoAlbum.setAdapter(new PhotoAdapter(album));

        if (album.size() > 1) {
            vpiPhotoAlbum.setVisibility(View.VISIBLE);
            vpiPhotoAlbum.setViewPager(vpPhotoAlbum);
        } else {
            vpiPhotoAlbum.setVisibility(View.GONE);
        }

        int selectedPage = getIntent().getIntExtra(Constants.SELECTED_PAGE, 0);
        vpPhotoAlbum.setCurrentItem(selectedPage);
    }
}
