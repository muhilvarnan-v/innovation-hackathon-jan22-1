package com.flytekart.customer.ui.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.flytekart.customer.R;
import com.flytekart.customer.models.Cart;
import com.flytekart.customer.models.OrderDTO;
import com.flytekart.customer.models.OrderItemDTO;
import com.flytekart.customer.models.OrderTotal;
import com.flytekart.customer.models.Store;
import com.flytekart.customer.models.StoreVariantDTO;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Utilities;
import com.google.gson.Gson;

import java.util.ArrayList;

public class BaseActivity extends AppCompatActivity {

    protected SharedPreferences sharedPreferences;
    protected TextView textCartItemCount;
    protected Cart cart;
    protected Store store;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = Utilities.getSharedPreferences();
    }

    protected void setupBadge() {
        if (textCartItemCount != null) {
            cart = getCart();

            int cartItemCount = 0;
            if (cart != null && cart.getOrderItems() != null) {
                for (OrderItemDTO orderItem : cart.getOrderItems()) {
                    cartItemCount = cartItemCount + orderItem.getQuantity();
                }
            }

            if (cartItemCount == 0) {
                if (textCartItemCount.getVisibility() != View.GONE) {
                    textCartItemCount.setVisibility(View.GONE);
                }
            } else {
                textCartItemCount.setText(String.valueOf(Math.min(cartItemCount, 99)));
                if (textCartItemCount.getVisibility() != View.VISIBLE) {
                    textCartItemCount.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupBadge();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        FrameLayout actionView =
                (FrameLayout) menu.findItem(R.id.action_cart).getActionView();
        textCartItemCount = actionView.findViewById(R.id.cart_badge);
        setupBadge();
        actionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCartClicked();
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_cart: {
                onCartClicked();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    protected void onCartClicked() {
        // If we are in Cart screen already, we need not go in screen
        if (!this.getClass().getSimpleName().equals(CartActivity.class.getSimpleName())) {
            Intent cartIntent = new Intent(this, CartActivity.class);
            startActivityForResult(cartIntent, CartActivity.REQUEST_CODE_CART_ACTIVITY);
        }
    }

    protected Cart getCart() {
        Gson gson = new Gson();
        String cartString = sharedPreferences.getString(Constants.CART, null);
        Cart cart = gson.fromJson(cartString, Cart.class);
        return cart;
    }

    protected void saveCart() {
        Gson gson = new Gson();
        String json = gson.toJson(cart);
        sharedPreferences.edit().putString(Constants.CART, json).apply();
    }

    protected void addFirstItemToCart(StoreVariantDTO storeVariant) {
        if (cart == null || cart.getOrderItems() == null) {
            cart = new Cart();

            OrderDTO orderDTO = new OrderDTO();
            orderDTO.setUserId(null); // TODO Give correct userId
            orderDTO.setStoreId(store.getId());
            orderDTO.setOrderSource("Android"); // TODO Give correct orderSource
            orderDTO.setOrderStatus("IN_PROGRESS"); // TODO Give correct orderStatus
            cart.setOrder(orderDTO);

            cart.setOrderItems(new ArrayList<>());

            OrderTotal orderTotal = new OrderTotal();
            cart.setOrderTotal(orderTotal);
        }
        OrderItemDTO orderItemDTO = new OrderItemDTO();
        orderItemDTO.setQuantity(1);
        orderItemDTO.setProductId(storeVariant.productId);
        orderItemDTO.setProductName(storeVariant.productName);
        orderItemDTO.setCategoryName(storeVariant.categoryName);
        orderItemDTO.setStoreVariantId(storeVariant.storeVariantId);
        orderItemDTO.setVariantName(storeVariant.variantName);
        orderItemDTO.setUnitPrice(storeVariant.price);
        if (storeVariant.tax != null) {
            orderItemDTO.setUnitTax(storeVariant.tax);
        }
        orderItemDTO.setTotalPrice(orderItemDTO.getQuantity() * storeVariant.price);
        if (storeVariant.tax != null) {
            orderItemDTO.setTotalTax(orderItemDTO.getQuantity() * storeVariant.tax);
        }
        cart.getOrderItems().add(orderItemDTO);
        double priceTotal = 0;
        double taxTotal = 0;
        for (OrderItemDTO dto : cart.getOrderItems()) {
            priceTotal = priceTotal + dto.getTotalPrice();
            taxTotal = taxTotal + dto.getTotalTax();
        }

        OrderTotal orderTotal = cart.getOrderTotal();
        orderTotal.setTotalPrice(priceTotal);
        orderTotal.setTotalTax(taxTotal);
        double total = priceTotal + taxTotal;
        orderTotal.setTotal(total);
        saveCart();
    }

    protected void incrementItemInCart(StoreVariantDTO storeVariant) {
        for (OrderItemDTO dto : cart.getOrderItems()) {
            if (storeVariant.storeVariantId.equals(dto.getStoreVariantId())) {
                dto.setQuantity(dto.getQuantity() + 1);
                dto.setUnitPrice(storeVariant.price);
                dto.setTotalPrice(dto.getQuantity() * storeVariant.price);
                if (storeVariant.tax != null) {
                    dto.setUnitTax(storeVariant.tax);
                    dto.setTotalTax(dto.getQuantity() * storeVariant.tax);
                }
                break;
            }
        }
        double priceTotal = 0;
        double taxTotal = 0;
        for (OrderItemDTO dto : cart.getOrderItems()) {
            priceTotal = priceTotal + dto.getTotalPrice();
            taxTotal = taxTotal + dto.getTotalTax();
        }

        OrderTotal orderTotal = cart.getOrderTotal();
        orderTotal.setTotalPrice(priceTotal);
        orderTotal.setTotalTax(taxTotal);
        double total = priceTotal + taxTotal;
        orderTotal.setTotal(total);
        saveCart();
    }

    protected void decrementItemInCart(StoreVariantDTO storeVariant) {
        for (OrderItemDTO dto : cart.getOrderItems()) {
            if (storeVariant.storeVariantId.equals(dto.getStoreVariantId())) {
                dto.setQuantity(dto.getQuantity() - 1);
                if (dto.getQuantity() <= 0) {
                    cart.getOrderItems().remove(dto);
                } else {
                    dto.setUnitPrice(storeVariant.price);
                    dto.setTotalPrice(dto.getQuantity() * storeVariant.price);
                    if (storeVariant.tax != null) {
                        dto.setUnitTax(storeVariant.tax);
                        dto.setTotalTax(dto.getQuantity() * storeVariant.tax);
                    }
                }
                break;
            }
        }
        double priceTotal = 0;
        double taxTotal = 0;
        for (OrderItemDTO dto : cart.getOrderItems()) {
            priceTotal = priceTotal + dto.getTotalPrice();
            taxTotal = taxTotal + dto.getTotalTax();
        }

        OrderTotal orderTotal = cart.getOrderTotal();
        orderTotal.setTotalPrice(priceTotal);
        orderTotal.setTotalTax(taxTotal);
        double total = priceTotal + taxTotal;
        orderTotal.setTotal(total);
        saveCart();
    }

    protected void incrementItemInCart(OrderItemDTO orderItemDTO) {
        for (OrderItemDTO dto : cart.getOrderItems()) {
            if (orderItemDTO.getStoreVariantId().equals(dto.getStoreVariantId())) {
                dto.setQuantity(dto.getQuantity() + 1);
                dto.setUnitPrice(orderItemDTO.getUnitPrice());
                dto.setTotalPrice(dto.getQuantity() * orderItemDTO.getUnitPrice());
                dto.setUnitTax(orderItemDTO.getUnitTax());
                dto.setTotalTax(dto.getQuantity() * orderItemDTO.getUnitTax());
                break;
            }
        }
        double priceTotal = 0;
        double taxTotal = 0;
        for (OrderItemDTO dto : cart.getOrderItems()) {
            priceTotal = priceTotal + dto.getTotalPrice();
            taxTotal = taxTotal + dto.getTotalTax();
        }

        OrderTotal orderTotal = cart.getOrderTotal();
        orderTotal.setTotalPrice(priceTotal);
        orderTotal.setTotalTax(taxTotal);
        double total = priceTotal + taxTotal;
        orderTotal.setTotal(total);
        saveCart();
    }

    protected void decrementItemInCart(OrderItemDTO orderItemDTO) {
        for (OrderItemDTO dto : cart.getOrderItems()) {
            if (orderItemDTO.getStoreVariantId().equals(dto.getStoreVariantId())) {
                dto.setQuantity(dto.getQuantity() - 1);
                if (dto.getQuantity() <= 0) {
                    cart.getOrderItems().remove(dto);
                } else {
                    dto.setUnitPrice(orderItemDTO.getUnitPrice());
                    dto.setTotalPrice(dto.getQuantity() * orderItemDTO.getUnitPrice());
                    dto.setUnitTax(orderItemDTO.getUnitTax());
                    dto.setTotalTax(dto.getQuantity() * orderItemDTO.getUnitTax());
                }
                break;
            }
        }
        double priceTotal = 0;
        double taxTotal = 0;
        for (OrderItemDTO dto : cart.getOrderItems()) {
            priceTotal = priceTotal + dto.getTotalPrice();
            taxTotal = taxTotal + dto.getTotalTax();
        }

        OrderTotal orderTotal = cart.getOrderTotal();
        orderTotal.setTotalPrice(priceTotal);
        orderTotal.setTotalTax(taxTotal);
        double total = priceTotal + taxTotal;
        orderTotal.setTotal(total);
        saveCart();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CartActivity.REQUEST_CODE_CART_ACTIVITY) {
            refreshCartItems();
        }
    }

    protected void refreshCartItems() {

    }

    protected void getStore() {
        String storeString = sharedPreferences.getString(Constants.USED_STORE, null);
        if (storeString != null) {
            Gson gson = new Gson();
            store = gson.fromJson(storeString, Store.class);
        }
    }
}
