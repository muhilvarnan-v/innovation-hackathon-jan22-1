package com.flytekart.customer.utils;

public class Constants {

    public static final String CATEGORY = "category";
    public static final String ITEM = "item";
    public static final String IS_FIRST_LAUNCH_DONE = "isFirstLaunchDone";
    public static final String CART = "cart";
    public static final String ITEM_PHOTO_LIST = "itemPhotoList";
    public static final String SELECTED_PAGE = "selectedPage";
    public static final String SELECTED_POSITION = "selectedPosition";
    public static final String TITLE = "title";
    public static final String PDF_FILE_NAME = "pdfFileName";
    public static final String URL = "url";
    public static final String USED_STORE = "usedStore";
    public static final String USED_ADDRESS = "usedAddress";
    public static final String ADDRESS = "address";
    public static final String MAPS_MODE = "mapsMode";
    public static final String API_TOKEN_TAG = "Authorization";
    public static final String SHARED_PREF_KEY_ACCESS_TOKEN = "accessToken";
    public static final String SHARED_PREF_KEY_USER_DETAILS = "userDetails";
    public static final String SALES_CHANNEL_ANDROID = "Android";
    public static final String CURRENCY_RUPEE_PREFIX = "Rs";
    public static final String ORDER = "order";
    public static final String USERNAME = "username";
    public static final String MULTIPLE = "Multiple";
    public static final String SHARED_PREF_USER_PUSH_TOKEN_ID = "USER_PUSH_TOKEN_ID";

    public static final int TIMEOUT = 60;
    public static final int DEFAULT_PAGE_SIZE = 10;

    public static final int LOCATION_PERMISSION_REQUEST_CODE = 1000;
    public static final int ADDRESS_REQUEST_CODE = 1000;

    public static final String EMPTY = "";
    public static final String SPACE = " ";
    public static final String COMMA_SPACE = ", ";
    public static final String COMMA = ",";

    public static final class OrderStatus {
        public static final String IN_PROGRESS = "IN_PROGRESS";
        public static final String PLACED = "PLACED";
        public static final String CANCELED = "CANCELED";
        public static final String ACCEPTED = "ACCEPTED";
        public static final String PROCESSING = "PROCESSING";
        public static final String PROCESSED = "PROCESSED";
        public static final String OUT_FOR_DELIVERY = "OUT_FOR_DELIVERY";
        public static final String DELIVERED = "DELIVERED";
    }

    public static final class OrderItemStatus {
        public static final String IN_PROGRESS = "IN_PROGRESS";
        public static final String DELETED = "DELETED";
        public static final String PLACED = "PLACED";
        public static final String CANCELED = "CANCELED";
        public static final String ACCEPTED = "ACCEPTED";
        public static final String PROCESSING = "PROCESSING";
        public static final String PROCESSED = "PROCESSED";
        public static final String OUT_FOR_DELIVERY = "OUT_FOR_DELIVERY";
        public static final String DELIVERED = "DELIVERED";
        public static final String REMOVED = "REMOVED";
    }

    public static final class ReturnOrderStatus {
        public static final String RETURN_IN_PROGRESS = "RETURN_IN_PROGRESS";
        public static final String RETURN_PLACED = "RETURN_PLACED";
        public static final String RETURN_CANCELED = "RETURN_CANCELED";
        public static final String RETURN_REQUEST_ACCEPTED = "RETURN_REQUEST_ACCEPTED";
        public static final String RETURN_REQUEST_REJECTED = "RETURN_REQUEST_REJECTED";
        public static final String RETURN_PICKED = "RETURN_PICKED";
        public static final String RETURN_RECEIVED = "RETURN_RECEIVED";
        public static final String RETURN_ACCEPTED = "RETURN_ACCEPTED";
        public static final String RETURN_REJECTED = "RETURN_REJECTED";
    }

    public static final class ReturnOrderItemStatus {
        public static final String RETURN_IN_PROGRESS = "RETURN_IN_PROGRESS";
        public static final String RETURN_ITEM_DELETED = "RETURN_ITEM_DELETED";
        public static final String RETURN_PLACED = "RETURN_PLACED";
        public static final String RETURN_CANCELED = "RETURN_CANCELED";
        public static final String RETURN_REQUEST_ACCEPTED = "RETURN_REQUEST_ACCEPTED";
        public static final String RETURN_REQUEST_REJECTED = "RETURN_REQUEST_REJECTED";
        public static final String RETURN_PICKED = "RETURN_PICKED";
        public static final String RETURN_RECEIVED = "RETURN_RECEIVED";
        public static final String RETURN_ACCEPTED = "RETURN_ACCEPTED";
        public static final String RETURN_REJECTED = "RETURN_REJECTED";
    }

    public static final class PaymentStatus {
        public static final String UNPAID = "UNPAID";
        public static final String PAID = "PAID";
    }

    public static final class PaymentType {
        public static final String COD = "COD"; // Covers both cash on delivery and pay on delivery
        public static final String RAZORPAY = "RAZORPAY"; // Covers both cash on delivery and pay on delivery
    }
}
