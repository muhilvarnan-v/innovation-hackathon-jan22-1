package com.flytekart.customer.models;

import android.os.Parcel;
import android.os.Parcelable;

public class Item implements Parcelable {
    public long id;
    public int colorCode;
    public String itemName;
    public String currencyCode;
    public int oldPrice;
    public int price;
    public String quantity;
    public int foodCode;

    public Item() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.id);
        dest.writeInt(this.colorCode);
        dest.writeString(this.itemName);
        dest.writeString(this.currencyCode);
        dest.writeInt(this.oldPrice);
        dest.writeInt(this.price);
        dest.writeString(this.quantity);
        dest.writeInt(this.foodCode);
    }

    protected Item(Parcel in) {
        this.id = in.readLong();
        this.colorCode = in.readInt();
        this.itemName = in.readString();
        this.currencyCode = in.readString();
        this.oldPrice = in.readInt();
        this.price = in.readInt();
        this.quantity = in.readString();
        this.foodCode = in.readInt();
    }

    public static final Creator<Item> CREATOR = new Creator<Item>() {
        @Override
        public Item createFromParcel(Parcel source) {
            return new Item(source);
        }

        @Override
        public Item[] newArray(int size) {
            return new Item[size];
        }
    };
}
