package com.flytekart.customer.models;

public class FoodCode {
    public static final int NONE = -1;
    public static final int VEG = 0;
    public static final int NONVEG = 1;
}
