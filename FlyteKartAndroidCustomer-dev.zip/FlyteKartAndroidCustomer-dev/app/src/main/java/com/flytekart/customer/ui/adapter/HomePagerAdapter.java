package com.flytekart.customer.ui.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.flytekart.customer.ui.fragment.HomeFragment;
import com.flytekart.customer.ui.fragment.MyAccountFragment;
import com.flytekart.customer.ui.fragment.SearchFragment;

public class HomePagerAdapter extends FragmentPagerAdapter {

    private HomeFragment homeFragment;
    private SearchFragment searchFragment;
    private MyAccountFragment myAccountFragment;

    public HomePagerAdapter(@NonNull FragmentManager fm) {
        super(fm, FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 2: {
                if (myAccountFragment == null) {
                    myAccountFragment = new MyAccountFragment();
                }
                return myAccountFragment;
            }
            case 1: {
                if (searchFragment == null) {
                    searchFragment = new SearchFragment();
                }
                return searchFragment;
            }
            default: {
                if (homeFragment == null) {
                    homeFragment = new HomeFragment();
                }
                return homeFragment;
            }
        }
    }

    @Override
    public int getCount() {
        return 3;
    }
}
