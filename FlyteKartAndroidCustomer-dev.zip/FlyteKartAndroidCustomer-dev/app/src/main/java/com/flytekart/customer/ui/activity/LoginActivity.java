package com.flytekart.customer.ui.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.request.SendOTPRequest;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Response;

// TODO Learn about feature on feature dependencies
public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etEmail;
    private EditText etPassword;
    private TextView tvForgotPassword;
    private ProgressDialog progressDialog;
    private static final int REQUEST_CODE_OTP_VERIFICATION = 1000;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setStatusBackgroundColor();
        hideActionBar();

        findViewById(R.id.tv_login).setOnClickListener(this);
        findViewById(R.id.tv_sign_up).setOnClickListener(this);
        etEmail = findViewById(R.id.et_phone_number);
        etPassword = findViewById(R.id.et_password);
        tvForgotPassword = findViewById(R.id.tv_forgot_password);
        tvForgotPassword.setPaintFlags(tvForgotPassword.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        etEmail.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(etPassword.getWindowToken(), 0);
                checkInputAndRequestOTP();
            }
            return true;
        });
    }

    private void setStatusBackgroundColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.black_transparent));
        }
    }

    private void hideActionBar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_login: {
                checkInputAndRequestOTP();
                break;
            }
            case R.id.tv_sign_up: {
                Intent signUpIntent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(signUpIntent);
                finish();
                break;
            }

        }
    }

    private void checkInputAndRequestOTP() {
        String email = etEmail.getText().toString().trim();
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Need to make API call to login
        clientLogin(email);
    }

    private void clientLogin(String usernameOrEmail) {
        SendOTPRequest request = new SendOTPRequest();
        request.setPhoneNumber(usernameOrEmail);
        showProgress(true);
        Call<BaseResponse<String>> loginCall = Flytekart.getApiService().sendOTP(BuildConfig.CLIENT_ID, request);
        loginCall.enqueue(new CustomCallback<BaseResponse<String>>() {
            @Override
            public void onFlytekartSuccessResponse(@NotNull Call<BaseResponse<String>> call, @NotNull Response<BaseResponse<String>> response) {
                Logger.i("Client Login API call response received.");
                if (response.isSuccessful() && response.body() != null) {
                    showProgress(false);

                    SharedPreferences sharedPreferences = Utilities.getSharedPreferences();
                    String responseString = response.body().getBody();
                    // Get dropdown data and go to next screen.
                    Toast.makeText(getApplicationContext(), responseString, Toast.LENGTH_SHORT).show();
                    sharedPreferences.edit().putString(Constants.USERNAME, usernameOrEmail).apply();
                    Logger.i("Send OTP API call success.");
                    Intent otpVerificationIntent = new Intent(LoginActivity.this,
                            OTPVerificationActivity.class);
                    otpVerificationIntent.putExtra(Constants.USERNAME, usernameOrEmail);
                    startActivityForResult(otpVerificationIntent, REQUEST_CODE_OTP_VERIFICATION);
                }
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<String>> call, APIError responseBody) {
                /*if (response.errorBody() != null) {
                    try {
                        ApiCallResponse apiCallResponse = new Gson().fromJson(
                                response.errorBody().string(), ApiCallResponse.class);
                        Toast.makeText(getApplicationContext(), apiCallResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }*/
                Logger.e("Client Login API response failed");
                showProgress(false);
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<String>> call) {
                Logger.i("Client Login API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_OTP_VERIFICATION && resultCode == RESULT_OK) {
            Intent homeIntent = new Intent(LoginActivity.this, HomeActivity.class);
            homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(homeIntent);
            finish();
        }
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}
