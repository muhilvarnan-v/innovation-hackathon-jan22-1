package com.flytekart.customer.ui.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.UserDetails;
import com.flytekart.customer.models.UserPushToken;
import com.flytekart.customer.models.request.DeleteUserPushTokenRequest;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.ui.activity.LoginActivity;
import com.flytekart.customer.ui.activity.MyAddressesActivity;
import com.flytekart.customer.ui.activity.MyPurchaseHistoryActivity;
import com.flytekart.customer.ui.activity.PDFViewActivity;
import com.flytekart.customer.ui.activity.SplashActivity;
import com.flytekart.customer.ui.activity.WebViewActivity;
import com.flytekart.customer.ui.adapter.AddressListAdapter;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Response;

public class MyAccountFragment extends Fragment implements View.OnClickListener {

    private View rlNotLoggedIn;
    private View svLoggedIn;
    private View tvLogin;
    private View tvMyAddresses;
    private View tvMyPurchaseHistory;
    private View tvCancellationPolicy;
    private View tvPrivacyPolicy;
    private View tvHelp;
    private View tvAboutUs;
    private TextView tvName;
    private TextView tvPhoneNumber;
    private TextView tvEmailId;
    private TextView tvLogout;
    private View llProfile;
    private View vDividerProfile;
    private View vDividerAddresses;
    private View vDividerPurchases;
    private View vDividerHelp;
    private SharedPreferences sharedPreferences;
    private String accessToken;
    private UserDetails userDetails;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rlNotLoggedIn = view.findViewById(R.id.rl_not_logged_in);
        svLoggedIn = view.findViewById(R.id.sv_logged_in);
        tvLogin = view.findViewById(R.id.tv_login);
        tvMyAddresses = view.findViewById(R.id.tv_my_addresses);
        tvMyPurchaseHistory = view.findViewById(R.id.tv_my_purchase_history);
        tvCancellationPolicy = view.findViewById(R.id.tv_cancellation_policy);
        tvPrivacyPolicy = view.findViewById(R.id.tv_privacy_policy);
        tvHelp = view.findViewById(R.id.tv_help);
        tvAboutUs = view.findViewById(R.id.tv_about_us);
        tvName = view.findViewById(R.id.tv_name);
        tvPhoneNumber = view.findViewById(R.id.tv_phone_number);
        tvEmailId = view.findViewById(R.id.tv_email_id);
        tvLogout = view.findViewById(R.id.tv_logout);
        llProfile = view.findViewById(R.id.ll_profile);
        vDividerProfile = view.findViewById(R.id.v_divider_profile);
        vDividerAddresses = view.findViewById(R.id.v_divider_addresses);
        vDividerPurchases = view.findViewById(R.id.v_divider_purchases);
        vDividerHelp = view.findViewById(R.id.v_divider_help);
        sharedPreferences = Utilities.getSharedPreferences();
        getLoginToken();
        enableUIBasedOnLogin();
        getUserDetails();
        setUserDetailsToUi();

        tvMyAddresses.setOnClickListener(this);
        tvMyPurchaseHistory.setOnClickListener(this);
        tvCancellationPolicy.setOnClickListener(this);
        tvPrivacyPolicy.setOnClickListener(this);
        tvAboutUs.setOnClickListener(this);
        tvLogout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_logout: {
                if (accessToken == null) {
                    if (getActivity() != null && isAdded()) {
                        Intent intent = new Intent(getActivity(), LoginActivity.class);
                        startActivity(intent);
                    }
                } else {
                    // Show a dialog asking for confirmation.
                    if (getActivity() != null && isAdded()) {
                        AlertDialog alertDialog = new AlertDialog.Builder(getActivity())
                                .setMessage("Do you want to logout?")
                                .setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        logout();
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // Do nothing
                                    }
                                })
                                .show();
                    }
                }
                break;
            }
            case R.id.tv_my_addresses: {
                if (getActivity() != null && isAdded()) {
                    Intent intent = new Intent(getActivity(), MyAddressesActivity.class);
                    intent.putExtra(AddressListAdapter.MODE, AddressListAdapter.MODE_EDIT_DELIVERY_ADDRESS);
                    startActivity(intent);
                    break;
                }
            }
            case R.id.tv_my_purchase_history: {
                if (getActivity() != null && isAdded()) {
                    Intent intent = new Intent(getActivity(), MyPurchaseHistoryActivity.class);
                    startActivity(intent);
                    break;
                }
            }
            case R.id.tv_cancellation_policy: {
                if (getActivity() != null && isAdded()) {
                    Intent intent = new Intent(getActivity(), PDFViewActivity.class);
                    intent.putExtra(Constants.TITLE, "Cancellation Policy");
                    intent.putExtra(Constants.PDF_FILE_NAME, "privacy_policy_template.pdf");
                    startActivity(intent);
                    break;
                }
            }
            case R.id.tv_privacy_policy: {
                if (getActivity() != null && isAdded()) {
                    Intent intent = new Intent(getActivity(), PDFViewActivity.class);
                    intent.putExtra(Constants.TITLE, "Privacy Policy");
                    intent.putExtra(Constants.PDF_FILE_NAME, "privacy_policy_template.pdf");
                    startActivity(intent);
                    break;
                }
            }
            case R.id.tv_about_us: {
                if (getActivity() != null && isAdded()) {
                    Intent intent = new Intent(getActivity(), WebViewActivity.class);
                    intent.putExtra(Constants.TITLE, "About Us");
                    intent.putExtra(Constants.URL, "https://www.google.co.in");
                    startActivity(intent);
                    break;
                }
            }
        }
    }

    public void enableUIBasedOnLogin() {
        // TODO Check if user logged in
        if (accessToken == null) {
            llProfile.setVisibility(View.GONE);
            vDividerProfile.setVisibility(View.GONE);
            tvMyAddresses.setVisibility(View.GONE);
            vDividerAddresses.setVisibility(View.GONE);
            tvMyPurchaseHistory.setVisibility(View.GONE);
            vDividerPurchases.setVisibility(View.GONE);
            tvHelp.setVisibility(View.GONE);
            vDividerHelp.setVisibility(View.GONE);
            tvLogout.setText(R.string.sign_in);
        } else {
            llProfile.setVisibility(View.VISIBLE);
            vDividerProfile.setVisibility(View.VISIBLE);
            tvMyAddresses.setVisibility(View.VISIBLE);
            vDividerAddresses.setVisibility(View.VISIBLE);
            tvMyPurchaseHistory.setVisibility(View.VISIBLE);
            vDividerPurchases.setVisibility(View.VISIBLE);
            tvHelp.setVisibility(View.VISIBLE);
            vDividerHelp.setVisibility(View.VISIBLE);
            tvLogout.setText(R.string.logout);
        }
    }

    public void getLoginToken() {
        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, null);
    }

    public void getUserDetails() {
        Gson gson = new Gson();
        String userDetailsString = sharedPreferences.getString(Constants.SHARED_PREF_KEY_USER_DETAILS, null);
        if (userDetailsString != null) {
            this.userDetails = gson.fromJson(userDetailsString, UserDetails.class);
        }
    }

    public void setUserDetailsToUi() {
        if (userDetails != null) {
            if (userDetails.getName() != null) {
                tvName.setText(userDetails.getName());
            } else {
                tvName.setText(Constants.EMPTY);
            }
            if (userDetails.getPhoneNumber() != null) {
                tvPhoneNumber.setText(userDetails.getPhoneNumber());
            } else {
                tvPhoneNumber.setText(Constants.EMPTY);
            }
            if (userDetails.getEmail() != null) {
                tvEmailId.setText(userDetails.getEmail());
            } else {
                tvEmailId.setText(Constants.EMPTY);
            }
        }
    }

    private void logout() {
        if (getActivity() != null && isAdded()) {
            SharedPreferences sharedPreferences = Utilities.getSharedPreferences();
            String pushTokenId = sharedPreferences.getString(Constants.SHARED_PREF_USER_PUSH_TOKEN_ID, null);
            deleteFCMToken(BuildConfig.CLIENT_ID, pushTokenId);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.remove(Constants.SHARED_PREF_KEY_ACCESS_TOKEN).apply();
            editor.remove(Constants.SHARED_PREF_KEY_USER_DETAILS).apply();
            editor.remove(Constants.SHARED_PREF_USER_PUSH_TOKEN_ID).apply();
            editor.remove(Constants.USED_ADDRESS).apply();
            Intent splashIntent = new Intent(getActivity(), SplashActivity.class);
            splashIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(splashIntent);
            getActivity().finish();
        }
    }

    private void deleteFCMToken(String clientId, String pushTokenId) {
        FirebaseMessaging.getInstance().deleteToken();
        DeleteUserPushTokenRequest request = new DeleteUserPushTokenRequest();
        request.setId(pushTokenId);
        Call<BaseResponse<UserPushToken>> deleteFCMTokenCall = Flytekart.getApiService().deleteFCMToken(
                accessToken, clientId, request);
        deleteFCMTokenCall.enqueue(new CustomCallback<BaseResponse<UserPushToken>>() {
            @Override
            public void onFlytekartSuccessResponse(@NotNull Call<BaseResponse<UserPushToken>> call, @NotNull Response<BaseResponse<UserPushToken>> response) {
                Logger.i("User push token delete API call response received.");
                // No need to do anything
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<UserPushToken>> call, APIError responseBody) {
                Logger.e("User push token delete API response failed");
                // No need to do anything
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<UserPushToken>> call) {
                Logger.i("User push token save API call failure.");
                // No need to do anything
            }
        });
    }
}
