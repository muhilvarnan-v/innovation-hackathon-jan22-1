package com.flytekart.customer.models;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class StoreProductDTO implements Parcelable {
    public String productId;
    public String productName;
    public List<StoreVariantDTO> variants;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<StoreVariantDTO> getVariants() {
        return variants;
    }

    public void setVariants(List<StoreVariantDTO> variants) {
        this.variants = variants;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.productId);
        dest.writeString(this.productName);
        dest.writeTypedList(this.variants);
    }

    public void readFromParcel(Parcel source) {
        this.productId = source.readString();
        this.productName = source.readString();
        this.variants = source.createTypedArrayList(StoreVariantDTO.CREATOR);
    }

    public StoreProductDTO() {
    }

    protected StoreProductDTO(Parcel in) {
        this.productId = in.readString();
        this.productName = in.readString();
        this.variants = in.createTypedArrayList(StoreVariantDTO.CREATOR);
    }

    public static final Parcelable.Creator<StoreProductDTO> CREATOR = new Parcelable.Creator<StoreProductDTO>() {
        @Override
        public StoreProductDTO createFromParcel(Parcel source) {
            return new StoreProductDTO(source);
        }

        @Override
        public StoreProductDTO[] newArray(int size) {
            return new StoreProductDTO[size];
        }
    };
}
