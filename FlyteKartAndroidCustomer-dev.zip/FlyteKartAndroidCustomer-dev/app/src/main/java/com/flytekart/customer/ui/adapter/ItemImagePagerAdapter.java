package com.flytekart.customer.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.viewpager.widget.PagerAdapter;

import com.flytekart.customer.R;
import com.flytekart.customer.models.ItemDetails;

public class ItemImagePagerAdapter extends PagerAdapter implements
        View.OnClickListener {
    private ItemDetails itemDetails;
    private int width;
    private int height;
    private OnPagerClickListener listener;

    public ItemImagePagerAdapter(OnPagerClickListener listener,
                                 ItemDetails itemDetails, int width, int height) {
        this.listener = listener;
        this.itemDetails = itemDetails;
        this.width = width;
        this.height = height;
    }

    @Override
    public int getCount() {
        if (itemDetails != null && itemDetails.colorCodes != null) {
            //return (blogPostSummaryList.size() * 100);
            return itemDetails.colorCodes.size();
        } else {
            return 0;
        }
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.pager_item_latest, container, false);
        int pos = position % itemDetails.colorCodes.size();

        ImageView imageView = view.findViewById(R.id.iv_hero_post_summary);
        if(itemDetails.colorCodes.get(position) != 0) {
            int colorCode = itemDetails.colorCodes.get(position);
            imageView.setBackgroundResource(colorCode);
            /*Picasso.get().load(heroImageUrl)
                    .resize(width, height)
                    .centerCrop()
                    .into(imageView);*/
        }

        View tvContent = view.findViewById(R.id.tv_content_post_summary);
        tvContent.setVisibility(View.INVISIBLE);

        view.setTag(R.layout.pager_item_latest, pos);
        view.setTag(itemDetails.colorCodes.get(pos));
        view.setOnClickListener(this);
        container.addView(view);
        try {
            container.removeViewAt(position - itemDetails.colorCodes.size());
        } catch (Exception e) {
            // Ignore
        }
        try {
            container.removeViewAt(position + itemDetails.colorCodes.size());
        } catch (Exception e) {
            // Ignore
        }
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        View view = (View) object;
        container.removeView(view);
    }

    @Override
    public void onClick(View v) {
        Integer colorCode = (Integer) v.getTag();
        int position = (int) v.getTag(R.layout.pager_item_latest);
        listener.onPagerClick(colorCode, position);
    }

    public interface OnPagerClickListener {
        void onPagerClick(int colorCode, int position);
    }
}
