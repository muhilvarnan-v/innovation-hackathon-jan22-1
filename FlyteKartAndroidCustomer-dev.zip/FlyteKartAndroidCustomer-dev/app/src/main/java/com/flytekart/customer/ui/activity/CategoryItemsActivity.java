package com.flytekart.customer.ui.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.DialogCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.Cart;
import com.flytekart.customer.models.FoodCode;
import com.flytekart.customer.models.Item;
import com.flytekart.customer.models.OrderItemDTO;
import com.flytekart.customer.models.StoreProductDTO;
import com.flytekart.customer.models.StoreVariantDTO;
import com.flytekart.customer.models.dto.StoreCategoryDTO;
import com.flytekart.customer.models.response.ApiCallResponse;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.models.response.OrderResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.ui.adapter.CategoryItemsAdapter;
import com.flytekart.customer.ui.custom.EndlessRecyclerOnScrollListener;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CategoryItemsActivity extends BaseActivity implements CategoryItemsAdapter.CategoryItemListener {

    private RecyclerView rvItems;
    private LinearLayoutManager layoutManager;
    private CategoryItemsAdapter categoryItemsAdapter;
    private List<StoreProductDTO> storeProducts;
    private String accessToken;
    private StoreCategoryDTO storeCategoryDTO;
    private int nextPageNumber = 0;
    private boolean isLoadingStoreProducts = false;
    private LayoutInflater layoutInflater;
    private ProgressDialog progressDialog;
    public static final int REQUEST_CODE_CATEGORY_ITEMS_ACTIVITY = 101;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_items);

        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        StoreCategoryDTO category = getIntent().getParcelableExtra(Constants.CATEGORY);
        setTitle(category.getName());

        rvItems = findViewById(R.id.rv_items);
        rvItems.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvItems.setLayoutManager(layoutManager);
        rvItems.addOnScrollListener(new EndlessRecyclerOnScrollListener(layoutManager) {
            @Override
            public void onLoadMore() {
                loadMoreData();
            }
        });
        //setListeners();

        SharedPreferences sharedPreferences = Utilities.getSharedPreferences();
        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, Constants.EMPTY);
        storeCategoryDTO = getIntent().getParcelableExtra(Constants.CATEGORY);
        layoutInflater = LayoutInflater.from(this);

        getStore();
        cart = getCart();
        getStoreProductsWithVariants();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ItemDetailsActivity.REQUEST_CODE_ITEM_DETAILS_ACTIVITY && data != null) {
            int position = data.getIntExtra(Constants.SELECTED_POSITION, -1);
            if (position != -1) {
                cart = getCart();
                categoryItemsAdapter.setCart(cart);
                categoryItemsAdapter.notifyItemChanged(position);
            }
        }
    }

    private void getStoreProductsWithVariants() {
        showProgress(true);
        Call<BaseResponse<List<StoreProductDTO>>> getStoreProductsCall = Flytekart.getApiService().getStoreProductsWithVariantsByStoreId(accessToken,
                store.getId(), BuildConfig.CLIENT_ID, storeCategoryDTO.getId(), Constants.DEFAULT_PAGE_SIZE, nextPageNumber);
        getStoreProductsCall.enqueue(new CustomCallback<BaseResponse<List<StoreProductDTO>>>() {
            @Override
            public void onFlytekartGenericErrorResponse(Call<BaseResponse<List<StoreProductDTO>>> call) {
                Logger.e("Store products list API call failure.");
                showProgress(false);
                isLoadingStoreProducts = false;
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<List<StoreProductDTO>>> call, Response<BaseResponse<List<StoreProductDTO>>> response) {
                Logger.e("Store products list response received.");
                showProgress(false);
                isLoadingStoreProducts = false;
                if (response.isSuccessful() && response.body() != null) {
                    storeProducts = response.body().getBody();
                    setStoreProductsToUI();
                }
                Logger.e("Store products list API call response status code : " + response.code());
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<List<StoreProductDTO>>> call, APIError responseBody) {
                Logger.e("Store products list API call failed");
                showProgress(false);
                isLoadingStoreProducts = false;
            }
        });
    }

    private void loadMoreData() {
        if (nextPageNumber > 0
                && (nextPageNumber * Constants.DEFAULT_PAGE_SIZE) == storeProducts.size()) {
            if (!isLoadingStoreProducts) {
                isLoadingStoreProducts = true;
                getStoreProductsWithVariants();
            }
        }
    }

    private void setStoreProductsToUI() {
        categoryItemsAdapter = new CategoryItemsAdapter(storeProducts, cart, this);
        rvItems.setAdapter(categoryItemsAdapter);
    }

    /*private void setListeners() {
        final GestureDetector gestureDetector = new GestureDetector(getApplicationContext(), new GestureDetector.SimpleOnGestureListener() {

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                return true;
            }

        });

        rvItems.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
                View child = rv.findChildViewUnder(e.getX(), e.getY());
                if (child != null && gestureDetector.onTouchEvent(e)) {
                    int pos = rv.getChildAdapterPosition(child);
                    onTagClicked(items.get(pos));
                }
                return false;
            }

            @Override
            public void onTouchEvent(RecyclerView rv, MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
    }

    private void onTagClicked(Item item) {
        Intent itemIntent = new Intent(this, ItemDetailsActivity.class);
        itemIntent.putExtra(Constants.ITEM, item);
        startActivity(itemIntent);
    }*/

    @Override
    public void onItemClicked(int position, StoreProductDTO storeProduct) {
        // TODO Not available for v0.5
        /*Intent itemIntent = new Intent(this, ItemDetailsActivity.class);
        itemIntent.putExtra(Constants.ITEM, storeProduct);
        itemIntent.putExtra(Constants.SELECTED_POSITION, position);
        startActivityForResult(itemIntent, ItemDetailsActivity.REQUEST_CODE_ITEM_DETAILS_ACTIVITY);*/
    }

    @Override
    public void onAddClick(int position, StoreProductDTO storeProduct) {
        if (storeProduct.getVariants().size() == 1) {
            addFirstItemToCart(storeProduct.getVariants().get(0));

            categoryItemsAdapter.setCart(cart);
            categoryItemsAdapter.notifyItemChanged(position);
            setupBadge();
        } else {
            showStoreVariantsOfAProduct(storeProduct);
        }
    }

    private void showStoreVariantsOfAProduct(StoreProductDTO storeProduct) {
        View dialogView = layoutInflater.inflate(R.layout.dialog_variants, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        builder.setTitle(storeProduct.productName);
        LinearLayout llVariants = dialogView.findViewById(R.id.ll_variants);
        for (StoreVariantDTO storeVariantDTO : storeProduct.variants) {
            View variantView = layoutInflater.inflate(R.layout.dialog_variant_item, null);
            TextView tvItemName = variantView.findViewById(R.id.tv_item_name);
            TextView tvItemOldPrice = variantView.findViewById(R.id.tv_item_old_price);
            TextView tvItemPrice = variantView.findViewById(R.id.tv_item_price);

            tvItemName.setText(storeVariantDTO.variantName);
            if (storeVariantDTO.originalPrice != null && storeVariantDTO.originalPrice != -1) {
                tvItemOldPrice.setText(Utilities.getFormattedMoney(storeVariantDTO.originalPrice));
                tvItemOldPrice.setVisibility(View.VISIBLE);
                tvItemOldPrice.setPaintFlags(tvItemOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            } else {
                tvItemOldPrice.setVisibility(View.GONE);
            }
            tvItemPrice.setText(Utilities.getFormattedMoney(storeVariantDTO.price));
            checkCartPresence(storeVariantDTO, variantView);
            llVariants.addView(variantView);
        }
        builder.setNeutralButton("Done", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do nothing
            }
        });
        builder.show();
    }

    private void checkCartPresence(StoreVariantDTO storeVariantDTO, View variantView) {
        TextView tvAdd = variantView.findViewById(R.id.tv_add);
        LinearLayout llItemCounter = variantView.findViewById(R.id.ll_item_counter);
        TextView tvDecrement = variantView.findViewById(R.id.tv_decrement);
        TextView tvCounter = variantView.findViewById(R.id.tv_counter);
        TextView tvIncrement = variantView.findViewById(R.id.tv_increment);
        int count = 0;
        if (cart != null && cart.getOrderItems() != null) {
            for (OrderItemDTO orderItem : cart.getOrderItems()) {
                if (orderItem.getStoreVariantId().equals(storeVariantDTO.storeVariantId)) {
                    count = count + orderItem.getQuantity();
                }
            }
        }
        if (count == 0) {
            tvAdd.setVisibility(View.VISIBLE);
            llItemCounter.setVisibility(View.GONE);
        } else {
            tvAdd.setVisibility(View.GONE);
            llItemCounter.setVisibility(View.VISIBLE);
            tvCounter.setText(String.valueOf(count));
        }
        tvAdd.setTag(storeVariantDTO);
        tvAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFirstItemToCart(storeVariantDTO);
                setupBadge();
                checkCartPresence(storeVariantDTO, variantView);
            }
        });
        tvIncrement.setTag(storeVariantDTO);
        tvIncrement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementItemInCart(storeVariantDTO);
                setupBadge();
                checkCartPresence(storeVariantDTO, variantView);
            }
        });
        tvDecrement.setTag(storeVariantDTO);
        tvDecrement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementItemInCart(storeVariantDTO);
                setupBadge();
                checkCartPresence(storeVariantDTO, variantView);
            }
        });
    }

    @Override
    public void onItemIncrement(int position, StoreProductDTO storeProduct) {
        if (storeProduct.getVariants().size() == 1) {
            incrementItemInCart(storeProduct.getVariants().get(0));

            categoryItemsAdapter.setCart(cart);
            categoryItemsAdapter.notifyItemChanged(position);
            setupBadge();
        } else {
            showStoreVariantsOfAProduct(storeProduct);
        }
    }

    @Override
    public void onItemDecrement(int position, StoreProductDTO storeProduct) {
        if (storeProduct.getVariants().size() == 1) {
            decrementItemInCart(storeProduct.getVariants().get(0));

            categoryItemsAdapter.setCart(cart);
            categoryItemsAdapter.notifyItemChanged(position);
            setupBadge();
        } else {
            showStoreVariantsOfAProduct(storeProduct);
        }
    }

    @Override
    protected void refreshCartItems() {
        super.refreshCartItems();
        cart = getCart();
        if (categoryItemsAdapter != null) {
            categoryItemsAdapter.setCart(cart);
            categoryItemsAdapter.notifyDataSetChanged();
        }
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}
