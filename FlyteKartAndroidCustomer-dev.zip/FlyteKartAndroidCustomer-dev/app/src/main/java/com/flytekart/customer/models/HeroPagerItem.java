package com.flytekart.customer.models;

public class HeroPagerItem {
    public int colorCode;
    public String title;
}
