package com.flytekart.customer.ui.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.appcompat.widget.Toolbar;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.Address;
import com.flytekart.customer.models.OrderItemDTO;
import com.flytekart.customer.models.request.CreateRazorpayOrderRequest;
import com.flytekart.customer.models.request.VerifyRazorpayPaymentRequest;
import com.flytekart.customer.models.response.ApiCallResponse;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.models.response.CreateRazorpayOrderResponse;
import com.flytekart.customer.models.response.OrderResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.ui.adapter.AddressListAdapter;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;
import com.google.gson.Gson;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Response;

public class CartActivity extends BaseActivity implements View.OnClickListener, PaymentResultListener {

    private TextView tvSubTotal;
    private TextView tvTax;
    private TextView tvTotal;
    private LinearLayout llCart;
    private TextView tvDiscountCopy;
    private TextView tvCartTotal;
    private TextView tvDeliveryAddress;
    private View tvPlaceOrder;
    private View rlEmptyCart;
    private View llTotals;
    private View llCartTotal;
    private View vDivider;
    private String accessToken;
    private Address deliveryAddress;
    private ProgressDialog progressDialog;
    private AppCompatSpinner spCartTotal;
    private OrderResponse orderResponse;
    private CreateRazorpayOrderResponse razorpayOrderResponse;

    public static final int REQUEST_CODE_CART_ACTIVITY = 200;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setTitle("Cart");
        getStore();
        cart = getCart();

        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, null);

        tvSubTotal = findViewById(R.id.tv_sub_total);
        tvTax = findViewById(R.id.tv_tax);
        tvTotal = findViewById(R.id.tv_total);
        llCart = findViewById(R.id.ll_cart);
        tvDiscountCopy = findViewById(R.id.tv_discount_copy);
        tvCartTotal = findViewById(R.id.tv_cart_total);
        tvPlaceOrder = findViewById(R.id.tv_place_order);
        rlEmptyCart = findViewById(R.id.rl_empty_cart);
        llTotals = findViewById(R.id.ll_totals);
        llCartTotal = findViewById(R.id.ll_cart_total);
        vDivider = findViewById(R.id.v_item_divider_2);
        tvDeliveryAddress = findViewById(R.id.tv_delivery_address);
        spCartTotal = findViewById(R.id.sp_cart_total);
        getDeliveryAddress();
        calculateTotalsAndDiscounts();
        displayPaymentOptions();
        displayCartItems();
        tvPlaceOrder.setOnClickListener(this);
        tvDeliveryAddress.setOnClickListener(this);
    }

    protected void getDeliveryAddress() {
        Gson gson = new Gson();
        String addressString = sharedPreferences.getString(Constants.USED_ADDRESS, null);
        if (addressString != null) {
            Address deliveryAddress = gson.fromJson(addressString, Address.class);
            if (deliveryAddress.getId() != null) {
                this.deliveryAddress = deliveryAddress;
                setDeliveryAddressToUI();
            }
        }
    }

    private void setDeliveryAddressToUI() {
        StringBuilder builder = new StringBuilder();
        builder.append(deliveryAddress.getLine1()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getLine2()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getCity()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getState()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getCountry()).append(Constants.COMMA_SPACE);
        builder.append(deliveryAddress.getZip());
        tvDeliveryAddress.setText(builder.toString());
    }

    private void calculateTotalsAndDiscounts() {
        if (cart.getOrderItems() != null && cart.getOrderItems().size() > 0) {
            double initialDiscount = 0;
            double cartTotal = 0;
            double cartPrice = 0;
            double cartTax = 0;
            if (cart.getOrderItems() != null) {
                for (OrderItemDTO cartItem : cart.getOrderItems()) {
                    /*if (cartItem.storeVariant.originalPrice != -1) {
                        initialDiscount = initialDiscount + (cartItem.quantity *
                                (cartItem.storeVariant.originalPrice - cartItem.storeVariant.price));
                    }*/

                    cartItem.setTotalPrice(cartItem.getQuantity() * cartItem.getUnitPrice());
                    cartItem.setTotalTax(cartItem.getQuantity() * cartItem.getUnitTax());
                    //cartItem.total = cartItem.itemTotal + cartItem.taxTotal;
                    cartTotal = cartTotal + cartItem.getTotalPrice() + cartItem.getTotalTax();
                    cartPrice = cartPrice + cartItem.getTotalPrice();
                    cartTax = cartTax + cartItem.getTotalTax();
                }
            }

            if (initialDiscount > 0) {
                String currencyCode = "Rs."; //cart.cartItems.get(0).storeVariant.currencyCode;
                tvDiscountCopy.setText(String.format(getString(R.string.discount_copy), currencyCode, initialDiscount));
                tvDiscountCopy.setVisibility(View.VISIBLE);
            } else {
                tvDiscountCopy.setVisibility(View.GONE);
            }
            tvCartTotal.setText(Utilities.getFormattedMoney(cartTotal));

            llCart.setVisibility(View.VISIBLE);
            llCartTotal.setVisibility(View.VISIBLE);
            vDivider.setVisibility(View.VISIBLE);
            rlEmptyCart.setVisibility(View.GONE);
            llTotals.setVisibility(View.VISIBLE);

            //tvSubTotal.setText(String.format(getString(R.string.price), currencyCode, cartPrice));
            tvSubTotal.setText(Utilities.getFormattedMoney(cartPrice));
            tvTax.setText(Utilities.getFormattedMoney(cartTax));
            tvTotal.setText(Utilities.getFormattedMoney(cartTotal));
        } else {
            llCart.setVisibility(View.GONE);
            llCartTotal.setVisibility(View.INVISIBLE);
            vDivider.setVisibility(View.INVISIBLE);
            rlEmptyCart.setVisibility(View.VISIBLE);
            llTotals.setVisibility(View.GONE);
            tvDiscountCopy.setVisibility(View.GONE);
        }
    }

    private void displayPaymentOptions() {
        // attributeNameAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, attributesStrings);
        String[] paymentModes = new String[2];
        paymentModes[0] = "Cash on delivery";
        paymentModes[1] = "Razorpay";
        ArrayAdapter arrayAdapter = new ArrayAdapter<>(this, R.layout.simple_list_item_1, paymentModes);
        spCartTotal.setAdapter(arrayAdapter);
    }

    private void displayCartItems() {
        if (cart.getOrderItems() != null && cart.getOrderItems().size() > 0) {
            LayoutInflater inflater = LayoutInflater.from(this);
            for (int i = 0; i < cart.getOrderItems().size(); i++) {
                OrderItemDTO cartItem = cart.getOrderItems().get(i);
                View rlCartItem = inflater.inflate(R.layout.list_item_cart_item, null, false);
                displayCartItem(rlCartItem, cartItem);

                llCart.addView(rlCartItem);
            }
        }
    }

    private void displayCartItem(View rlCartItem, OrderItemDTO cartItem) {
        CartItemViewHolder holder = new CartItemViewHolder(rlCartItem);
        //holder.ivItem.setImageResource(cartItem.storeVariant.colorCode);
        holder.tvItemName.setText(cartItem.getProductName());
        holder.tvQuantity.setText(cartItem.getVariantName());
        holder.tvOldPrice.setVisibility(View.INVISIBLE);
        holder.tvCategoryName.setText(cartItem.getCategoryName());
        /*if (cartItem.storeVariant.originalPrice == -1) {
            holder.tvOldPrice.setVisibility(View.INVISIBLE);
        } else {
            holder.tvOldPrice.setVisibility(View.VISIBLE);
            double oldPrice = cartItem.quantity * cartItem.storeVariant.originalPrice; // TODO This should be BigDecimal?
            holder.tvOldPrice.setText(String.format(getString(R.string.price), "Rs.", oldPrice));
            holder.tvOldPrice.setPaintFlags(holder.tvOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }*/
        double price = cartItem.getQuantity() * cartItem.getUnitPrice();
        holder.tvPrice.setText(Utilities.getFormattedMoney(price));
        holder.tvCounter.setText(String.valueOf(cartItem.getQuantity()));

        holder.ivVegSymbol.setVisibility(View.GONE);
        /*if (cartItem.storeVariant.foodCode == FoodCode.NONE) {
            holder.ivVegSymbol.setVisibility(View.GONE);
        } else if (cartItem.storeVariant.foodCode == FoodCode.VEG) {
            holder.ivVegSymbol.setVisibility(View.VISIBLE);
            holder.ivVegSymbol.setImageResource(R.drawable.ic_veg);
        } else if (cartItem.storeVariant.foodCode == FoodCode.NONVEG) {
            holder.ivVegSymbol.setVisibility(View.VISIBLE);
            holder.ivVegSymbol.setImageResource(R.drawable.ic_non_veg);
        }*/

        holder.tvIncrement.setTag(cartItem);
        holder.tvDecrement.setTag(cartItem);
        holder.tvIncrement.setOnClickListener(this);
        holder.tvDecrement.setOnClickListener(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_increment: {
                OrderItemDTO orderItemDTO = (OrderItemDTO) v.getTag();
                int oldPosition = -1;
                for (int i=0; i < cart.getOrderItems().size(); i++) {
                    OrderItemDTO cartItem = cart.getOrderItems().get(i);
                    if (cartItem.getStoreVariantId().equals(orderItemDTO.getStoreVariantId())) {
                        oldPosition = i;
                        break;
                    }
                }
                incrementItemInCart(orderItemDTO);
                setupBadge();
                cart = getCart();
                OrderItemDTO selectedCartItem = null;
                View itemView = llCart.getChildAt(oldPosition);
                for (int i=0; i < cart.getOrderItems().size(); i++) {
                    OrderItemDTO cartItem = cart.getOrderItems().get(i);
                    if (cartItem.getStoreVariantId().equals(orderItemDTO.getStoreVariantId())) {
                        selectedCartItem = cartItem;
                        break;
                    }
                }
                if (selectedCartItem != null) {
                    displayCartItem(itemView, selectedCartItem);
                } else {
                    llCart.removeView(itemView);
                }
                calculateTotalsAndDiscounts();
                break;
            }
            case R.id.tv_decrement: {
                OrderItemDTO orderItemDTO = (OrderItemDTO) v.getTag();
                int oldPosition = -1;
                for (int i=0; i < cart.getOrderItems().size(); i++) {
                    OrderItemDTO cartItem = cart.getOrderItems().get(i);
                    if (cartItem.getStoreVariantId().equals(orderItemDTO.getStoreVariantId())) {
                        oldPosition = i;
                        break;
                    }
                }
                decrementItemInCart(orderItemDTO);
                setupBadge();
                cart = getCart();
                OrderItemDTO selectedCartItem = null;
                View itemView = llCart.getChildAt(oldPosition);
                for (int i=0; i < cart.getOrderItems().size(); i++) {
                    OrderItemDTO cartItem = cart.getOrderItems().get(i);
                    if (cartItem.getStoreVariantId().equals(orderItemDTO.getStoreVariantId())) {
                        selectedCartItem = cartItem;
                        break;
                    }
                }
                if (selectedCartItem != null) {
                    displayCartItem(itemView, selectedCartItem);
                } else {
                    llCart.removeView(itemView);
                }
                calculateTotalsAndDiscounts();
                break;
            }
            case R.id.tv_delivery_address: {
                if (accessToken == null) {
                    showLoginAlert();
                } else {
                    openAddress();
                }
                break;
            }
            case R.id.tv_place_order: {
                if (accessToken == null) {
                    showLoginAlert();
                } else if (deliveryAddress == null) {
                    showAddressAlert();
                } else {
                    placeOrder();
                }
                break;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            deliveryAddress = data.getParcelableExtra(Constants.ADDRESS);
            saveDeliveryAddress(deliveryAddress);
            setDeliveryAddressToUI();
        }
    }

    private void saveDeliveryAddress(Address deliveryAddress) {
        Gson gson = new Gson();
        String json = gson.toJson(deliveryAddress);
        sharedPreferences.edit().putString(Constants.USED_ADDRESS, json).apply();
    }

    private void openAddress() {
        // Open MyAddressesActivity. MyAddresses should have a way to go to MapsActivity?
        /*Intent addressIntent = new Intent(this, MapsActivity.class);
        addressIntent.putExtra(Constants.MAPS_MODE, MapsActivity.MODE_SAVE_DELIVERY_ADDRESS);
        addressIntent.putExtra(Constants.ADDRESS, deliveryAddress);
        startActivityForResult(addressIntent, 1001);*/

        Intent addressIntent = new Intent(this, MyAddressesActivity.class);
        addressIntent.putExtra(AddressListAdapter.MODE, AddressListAdapter.MODE_SELECT_DELIVERY_ADDRESS);
        addressIntent.putExtra(Constants.ADDRESS, deliveryAddress);
        startActivityForResult(addressIntent, 1001);
    }

    private void showLoginAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Please login to place the order.");
        builder.setPositiveButton("Login", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent loginIntent = new Intent(CartActivity.this, LoginActivity.class);
                startActivity(loginIntent);
            }
        });
        builder.show();
    }

    private void showAddressAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Please add delivery address.");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                openAddress();
            }
        });
        builder.show();
    }

    private void placeOrder() {
        cart.getOrder().setStoreId(store.getId());
        cart.getOrder().setOrderSource(Constants.SALES_CHANNEL_ANDROID);

        String paymentType;
        if (spCartTotal.getSelectedItemPosition() == 0) {
            paymentType = Constants.PaymentType.COD;
            cart.getOrder().setPaymentType(Constants.PaymentType.COD);
            Logger.e("paymentType: " + spCartTotal.getSelectedItemPosition() + " COD");
        } else {
            paymentType = Constants.PaymentType.RAZORPAY;
            cart.getOrder().setPaymentType(Constants.PaymentType.RAZORPAY);
            Logger.e("paymentType: " + spCartTotal.getSelectedItemPosition() + " RAZORPAY");
        }

        //cart.getOrder().setOrderStatus(Constants.OrderStatus.PLACED);
        cart.getOrder().setDeliveryAddressId(deliveryAddress.getId());
        showProgress(true);
        Call<BaseResponse<OrderResponse>> saveOrderCall = Flytekart.getApiService().createOrder(
                accessToken, BuildConfig.CLIENT_ID, cart);
        saveOrderCall.enqueue(new CustomCallback<BaseResponse<OrderResponse>>() {
            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<OrderResponse>> call, Response<BaseResponse<OrderResponse>> response) {
                Logger.i("Create order API call response received.");
                showProgress(false);
                if (response.isSuccessful() && response.body() != null) {
                    orderResponse = response.body().getBody();
                    if (orderResponse.getOrder().getOrderStatus().getName().equals(Constants.OrderStatus.PLACED)) {
                        onOrderPlaced(orderResponse);
                        // Get dropdown data and go to next screen.
                        Toast.makeText(getApplicationContext(), "Order placed successfully.", Toast.LENGTH_SHORT).show();
                    } else {
                        // Check notes
                        double cartTotal = 0;
                        if (cart.getOrderItems() != null) {
                            for (OrderItemDTO cartItem : cart.getOrderItems()) {
                                cartItem.setTotalPrice(cartItem.getQuantity() * cartItem.getUnitPrice());
                                cartItem.setTotalTax(cartItem.getQuantity() * cartItem.getUnitTax());
                                //cartItem.total = cartItem.itemTotal + cartItem.taxTotal;
                                cartTotal = cartTotal + cartItem.getTotalPrice() + cartItem.getTotalTax();
                            }
                        }
                        createRazorpayOrder(orderResponse.getOrder().getId(), cartTotal);
                    }

                } else if (response.errorBody() != null) {
                    try {
                        ApiCallResponse apiCallResponse = new Gson().fromJson(
                                response.errorBody().string(), ApiCallResponse.class);
                        Toast.makeText(getApplicationContext(), apiCallResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Logger.e("Create order API response status code : " + response.code());
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<OrderResponse>> call, APIError responseBody) {
                Logger.i("Create order API call response failed.");
                showProgress(false);
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<OrderResponse>> call) {
                Logger.i("Order API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void createRazorpayOrder(String orderId, double cartTotal) {
        CreateRazorpayOrderRequest request = new CreateRazorpayOrderRequest();
        request.setOrderId(orderId);
        request.setPaymentMode(Constants.PaymentType.RAZORPAY);
        request.setAmount(cartTotal);

        showProgress(true);
        Call<BaseResponse<CreateRazorpayOrderResponse>> saveOrderCall = Flytekart.getApiService().createRazorpayOrder(
                accessToken, BuildConfig.CLIENT_ID, request);
        saveOrderCall.enqueue(new CustomCallback<BaseResponse<CreateRazorpayOrderResponse>>() {
            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<CreateRazorpayOrderResponse>> call, Response<BaseResponse<CreateRazorpayOrderResponse>> response) {
                Logger.i("Create order API call response received.");
                showProgress(false);
                if (response.isSuccessful() && response.body() != null) {
                    razorpayOrderResponse = response.body().getBody();
                    doRazorpayPayment(razorpayOrderResponse.getRazorpayOrderId(), razorpayOrderResponse.getAmount());//
                } else if (response.errorBody() != null) {
                    try {
                        ApiCallResponse apiCallResponse = new Gson().fromJson(
                                response.errorBody().string(), ApiCallResponse.class);
                        Toast.makeText(getApplicationContext(), apiCallResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Logger.e("Create order API response status code : " + response.code());
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<CreateRazorpayOrderResponse>> call, APIError responseBody) {
                Logger.i("Create order API call response failed.");
                showProgress(false);
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<CreateRazorpayOrderResponse>> call) {
                Logger.i("Order API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void verifyPayment(String razorpayPaymentId) {
        VerifyRazorpayPaymentRequest request = new VerifyRazorpayPaymentRequest();
        request.setOrderId(orderResponse.getOrder().getId());
        request.setRazorpayPaymentId(razorpayPaymentId);
        request.setPaymentId(razorpayOrderResponse.getPaymentId());
        request.setAmount(razorpayOrderResponse.getAmount());
        request.setPaymentMode(razorpayOrderResponse.getPaymentMode());
        showProgress(true);
        Call<BaseResponse<OrderResponse>> validatePaymentCall = Flytekart.getApiService().validateRazorpayPayment(
                accessToken, BuildConfig.CLIENT_ID, request);
        validatePaymentCall.enqueue(new CustomCallback<BaseResponse<OrderResponse>>() {
            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<OrderResponse>> call, Response<BaseResponse<OrderResponse>> response) {
                Logger.i("verifyPayment API call response received.");
                showProgress(false);
                if (response.isSuccessful() && response.body() != null) {
                    OrderResponse orderResponse = response.body().getBody();
                    if (orderResponse.getOrder().getOrderStatus().getName().equals(Constants.OrderStatus.PLACED)) {
                        onOrderPlaced(orderResponse);
                        // Get dropdown data and go to next screen.
                        Toast.makeText(getApplicationContext(), "Order placed successfully.", Toast.LENGTH_SHORT).show();
                    } else {
                        // Handle error
                        Toast.makeText(getApplicationContext(), "Something went wrong. Please try again. If any amount is debited, it will be refunded in 5-7 working days.", Toast.LENGTH_SHORT).show();
                    }

                } else if (response.errorBody() != null) {
                    try {
                        ApiCallResponse apiCallResponse = new Gson().fromJson(
                                response.errorBody().string(), ApiCallResponse.class);
                        Toast.makeText(getApplicationContext(), apiCallResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Logger.e("verifyPayment API response status code : " + response.code());
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<OrderResponse>> call, APIError responseBody) {
                Logger.i("verifyPayment API call response failed.");
                showProgress(false);
            }

            @Override
            public void onFlytekartGenericErrorResponse(@NotNull Call<BaseResponse<OrderResponse>> call) {
                Logger.i("verifyPayment API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Take user to order details screen
     * @param orderResponse
     */
    private void onOrderPlaced(OrderResponse orderResponse) {
        // Clear cart
        sharedPreferences.edit().remove(Constants.CART).apply();
        setupBadge();
        cart = getCart();
        Intent itemIntent = new Intent(this, OrderDetailsActivity.class);
        itemIntent.putExtra(Constants.ORDER, orderResponse);
        startActivity(itemIntent);
        finish();
    }

    private void doRazorpayPayment(String razorpayOrderId, double amount) {
        Activity activity = this;

        Checkout co = new Checkout();
        co.setKeyID("rzp_test_fZpy6ZIbWm8oCi");

        try {
            JSONObject options = new JSONObject();
            options.put("name", "Flytekart customer app");
            options.put("description", "Test payment");
            options.put("send_sms_hash",true);
            options.put("allow_rotation", false);
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png");
            options.put("currency", "INR");
            options.put("amount", amount * 100); // Only paise is accepted
            options.put("order_id", razorpayOrderId);

            // TODO Prefill
            /*JSONObject preFill = new JSONObject();
            preFill.put("email", "test@razorpay.com");
            preFill.put("contact", "9876543210");

            options.put("prefill", preFill);*/

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }

    // Ref: https://github.com/razorpay/razorpay-android-sample-app/blob/master/app/src/main/java/com/razorpay/sampleapp/java/PaymentActivity.java
    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        if (razorpayPaymentID != null) {
            verifyPayment(razorpayPaymentID);
        } else {
            // TODO Show error message
        }
    }

    @Override
    public void onPaymentError(int code, String response) {
        try {
            Toast.makeText(this, "Payment failed: " + code + " " + response, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Logger.e("Exception in onPaymentError: " + e);
        }
    }

    private static class CartItemViewHolder {
        ImageView ivItem;
        TextView tvItemName;
        TextView tvOldPrice;
        TextView tvCategoryName;
        TextView tvPrice;
        TextView tvQuantity;
        TextView tvCounter;
        ImageView ivVegSymbol;
        TextView tvIncrement;
        TextView tvDecrement;

        CartItemViewHolder(View rlCartView) {
            ivItem = rlCartView.findViewById(R.id.iv_item);
            tvItemName = rlCartView.findViewById(R.id.tv_item_name);
            tvOldPrice = rlCartView.findViewById(R.id.tv_item_old_price);
            tvCategoryName = rlCartView.findViewById(R.id.tv_item_category);
            tvPrice = rlCartView.findViewById(R.id.tv_item_price);
            tvQuantity = rlCartView.findViewById(R.id.tv_item_quantity);
            tvCounter = rlCartView.findViewById(R.id.tv_counter);
            ivVegSymbol = rlCartView.findViewById(R.id.iv_veg_symbol);
            tvIncrement = rlCartView.findViewById(R.id.tv_increment);
            tvDecrement = rlCartView.findViewById(R.id.tv_decrement);
        }
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}
