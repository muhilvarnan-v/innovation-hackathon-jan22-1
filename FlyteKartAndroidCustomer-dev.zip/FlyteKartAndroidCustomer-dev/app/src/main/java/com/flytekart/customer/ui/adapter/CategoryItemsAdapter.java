package com.flytekart.customer.ui.adapter;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.flytekart.customer.R;
import com.flytekart.customer.models.Cart;
import com.flytekart.customer.models.Cart_;
import com.flytekart.customer.models.OrderItemDTO;
import com.flytekart.customer.models.StoreProductDTO;
import com.flytekart.customer.models.StoreVariantDTO;
import com.flytekart.customer.utils.Utilities;

import java.util.List;

public class CategoryItemsAdapter extends RecyclerView.Adapter<CategoryItemsAdapter.CategoryItemViewHolder> implements View.OnClickListener {

    private List<StoreProductDTO> storeProducts;
    private Cart cart;
    private CategoryItemListener categoryItemListener;

    public CategoryItemsAdapter(List<StoreProductDTO> storeProducts, Cart cart, CategoryItemListener categoryItemListener) {
        this.storeProducts = storeProducts;
        this.cart = cart;
        this.categoryItemListener = categoryItemListener;
    }

    @NonNull
    @Override
    public CategoryItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_item, parent, false);
        return new CategoryItemViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryItemViewHolder holder, int position) {
        StoreProductDTO storeProduct = storeProducts.get(position);
        StoreVariantDTO storeVariant = storeProduct.variants.get(0);

        //holder.ivItem.setImageResource(storeProduct.colorCode);
        holder.tvItemName.setText(storeProduct.productName);
        holder.tvPrice.setText(Utilities.getFormattedMoney(storeVariant.price));
        if (storeVariant.originalPrice == null) {
            holder.tvOldPrice.setVisibility(View.INVISIBLE);
        } else {
            holder.tvOldPrice.setVisibility(View.VISIBLE);
            holder.tvOldPrice.setText(Utilities.getFormattedMoney(storeVariant.originalPrice));
            holder.tvOldPrice.setPaintFlags(holder.tvOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
        holder.tvQuantity.setText(storeVariant.variantName);
        holder.ivVegSymbol.setVisibility(View.GONE);
        /*if (storeProduct.foodCode == FoodCode.NONE) {
            holder.ivVegSymbol.setVisibility(View.GONE);
        } else if (storeProduct.foodCode == FoodCode.VEG) {
            holder.ivVegSymbol.setVisibility(View.VISIBLE);
            holder.ivVegSymbol.setImageResource(R.drawable.ic_veg);
        } else if (storeProduct.foodCode == FoodCode.NONVEG) {
            holder.ivVegSymbol.setVisibility(View.VISIBLE);
            holder.ivVegSymbol.setImageResource(R.drawable.ic_non_veg);
        }*/
        holder.itemView.setTag(storeProduct);
        holder.itemView.setTag(R.id.rl_item, position);
        holder.tvAdd.setTag(storeProduct);
        holder.tvAdd.setTag(R.id.rl_item, position);
        holder.tvIncrement.setTag(storeProduct);
        holder.tvIncrement.setTag(R.id.rl_item, position);
        holder.tvDecrement.setTag(storeProduct);
        holder.tvDecrement.setTag(R.id.rl_item, position);
        holder.itemView.setOnClickListener(this);
        holder.tvAdd.setOnClickListener(this);
        holder.tvIncrement.setOnClickListener(this);
        holder.tvDecrement.setOnClickListener(this);

        // Check cart presence
        checkCartPresence(storeProduct, holder);
    }

    @Override
    public int getItemCount() {
        return storeProducts.size();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_item: {
                StoreProductDTO storeProduct = (StoreProductDTO) v.getTag();
                int position = (int) v.getTag(R.id.rl_item);
                categoryItemListener.onItemClicked(position, storeProduct);
                break;
            }case R.id.tv_add: {
                StoreProductDTO storeProduct = (StoreProductDTO) v.getTag();
                int position = (int) v.getTag(R.id.rl_item);
                categoryItemListener.onAddClick(position, storeProduct);
                break;
            }
            case R.id.tv_increment: {
                StoreProductDTO storeProduct = (StoreProductDTO) v.getTag();
                int position = (int) v.getTag(R.id.rl_item);
                categoryItemListener.onItemIncrement(position, storeProduct);
                break;
            }
            case R.id.tv_decrement: {
                StoreProductDTO storeProduct = (StoreProductDTO) v.getTag();
                int position = (int) v.getTag(R.id.rl_item);
                categoryItemListener.onItemDecrement(position, storeProduct);
                break;
            }
        }
    }

    public static class CategoryItemViewHolder extends RecyclerView.ViewHolder {
        ImageView ivItem;
        TextView tvItemName;
        TextView tvPrice;
        TextView tvOldPrice;
        TextView tvQuantity;
        TextView tvCategory;
        ImageView ivVegSymbol;
        TextView tvAdd;
        TextView tvCounter;
        TextView tvIncrement;
        TextView tvDecrement;
        View llItemCounter;

        public CategoryItemViewHolder(@NonNull View itemView) {
            super(itemView);

            ivItem = itemView.findViewById(R.id.iv_item);
            tvItemName = itemView.findViewById(R.id.tv_item_name);
            tvPrice = itemView.findViewById(R.id.tv_item_price);
            tvOldPrice = itemView.findViewById(R.id.tv_item_old_price);
            tvQuantity = itemView.findViewById(R.id.tv_item_quantity);
            tvCategory = itemView.findViewById(R.id.tv_category_name);
            ivVegSymbol = itemView.findViewById(R.id.iv_veg_symbol);
            tvAdd = itemView.findViewById(R.id.tv_add);
            tvCounter = itemView.findViewById(R.id.tv_counter);
            tvIncrement = itemView.findViewById(R.id.tv_increment);
            tvDecrement = itemView.findViewById(R.id.tv_decrement);
            llItemCounter = itemView.findViewById(R.id.ll_item_counter);
        }
    }

    private void checkCartPresence(StoreProductDTO storeProduct, CategoryItemViewHolder holder) {
        int count = 0;
        if (cart != null && cart.getOrderItems() != null) {
            for (OrderItemDTO orderItem : cart.getOrderItems()) {
                if (orderItem.getProductId().equals(storeProduct.productId)) {
                    count = count + orderItem.getQuantity();
                }
            }
        }
        if (count == 0) {
            holder.tvAdd.setVisibility(View.VISIBLE);
            holder.llItemCounter.setVisibility(View.GONE);
        } else {
            holder.tvAdd.setVisibility(View.GONE);
            holder.llItemCounter.setVisibility(View.VISIBLE);
            holder.tvCounter.setText(String.valueOf(count));
        }
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public interface CategoryItemListener {
        void onItemClicked(int position, StoreProductDTO storeProduct);
        void onAddClick(int position, StoreProductDTO storeProduct);
        void onItemIncrement(int position, StoreProductDTO storeProduct);
        void onItemDecrement(int position, StoreProductDTO storeProduct);
    }
}
