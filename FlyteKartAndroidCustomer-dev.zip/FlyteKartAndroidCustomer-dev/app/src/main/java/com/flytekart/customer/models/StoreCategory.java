package com.flytekart.customer.models;

import android.os.Parcel;
import android.os.Parcelable;

public class StoreCategory implements Parcelable {
    public int colorCode;
    public String categoryName;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.colorCode);
        dest.writeString(this.categoryName);
    }

    public StoreCategory() {
    }

    protected StoreCategory(Parcel in) {
        this.colorCode = in.readInt();
        this.categoryName = in.readString();
    }

    public static final Creator<StoreCategory> CREATOR = new Creator<StoreCategory>() {
        @Override
        public StoreCategory createFromParcel(Parcel source) {
            return new StoreCategory(source);
        }

        @Override
        public StoreCategory[] newArray(int size) {
            return new StoreCategory[size];
        }
    };
}
