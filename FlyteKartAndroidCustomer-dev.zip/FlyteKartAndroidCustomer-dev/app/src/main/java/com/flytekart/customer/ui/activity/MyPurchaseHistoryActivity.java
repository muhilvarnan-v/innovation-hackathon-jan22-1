package com.flytekart.customer.ui.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.flytekart.customer.BuildConfig;
import com.flytekart.customer.Flytekart;
import com.flytekart.customer.R;
import com.flytekart.customer.models.UserDetails;
import com.flytekart.customer.models.response.APIError;
import com.flytekart.customer.models.response.BaseResponse;
import com.flytekart.customer.models.response.OrderResponse;
import com.flytekart.customer.network.CustomCallback;
import com.flytekart.customer.ui.adapter.OrdersAdapter;
import com.flytekart.customer.ui.custom.EndlessRecyclerOnScrollListener;
import com.flytekart.customer.utils.Constants;
import com.flytekart.customer.utils.Logger;
import com.flytekart.customer.utils.Utilities;
import com.google.gson.Gson;

import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

public class MyPurchaseHistoryActivity extends BaseActivity implements View.OnClickListener {

    private LinearLayout llNoRecordsFound;
    private View vNotLoggedIn;
    private LinearLayoutManager ordersLayoutManager;
    private RecyclerView rvOrdersList;
    private OrdersAdapter adapter;
    private List<OrderResponse> orderResponses;
    private ProgressDialog progressDialog;
    private boolean isLoadingOrders = false;
    private String accessToken;
    private int nextPageNumber = 0;
    private UserDetails userDetails;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_purchase_history);

        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setTitle("My Purchase History");

        llNoRecordsFound = findViewById(R.id.ll_no_records_found);
        vNotLoggedIn = findViewById(R.id.rl_not_logged_in);
        rvOrdersList = findViewById(R.id.rv_orders_list);
        rvOrdersList.setHasFixedSize(true);
        ordersLayoutManager = new LinearLayoutManager(this);
        rvOrdersList.setLayoutManager(ordersLayoutManager);
        //rvOrdersList.addItemDecoration(new DividerItemDecoration(ContextCompat.getDrawable(this, R.drawable.divider_rv)));
        rvOrdersList.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        rvOrdersList.addOnScrollListener(new EndlessRecyclerOnScrollListener(ordersLayoutManager) {
            @Override
            public void onLoadMore() {
                loadMoreData();
            }
        });

        SharedPreferences sharedPreferences = Utilities.getSharedPreferences();
        accessToken = sharedPreferences.getString(Constants.SHARED_PREF_KEY_ACCESS_TOKEN, Constants.EMPTY);
        getUserDetails();

        if (accessToken == null) {
            vNotLoggedIn.setVisibility(View.VISIBLE);
        } else {
            vNotLoggedIn.setVisibility(View.GONE);
        }
        vNotLoggedIn.setOnClickListener(this);

        getData();
        setListeners();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadMoreData() {
        if (nextPageNumber > 0
                && (nextPageNumber * Constants.DEFAULT_PAGE_SIZE) == orderResponses.size()) {
            if (!isLoadingOrders) {
                isLoadingOrders = true;
                getData();
            }
        }
    }

    private void getUserDetails() {
        Gson gson = new Gson();
        String userDetailsString = sharedPreferences.getString(Constants.SHARED_PREF_KEY_USER_DETAILS, null);
        if (userDetailsString != null) {
            this.userDetails = gson.fromJson(userDetailsString, UserDetails.class);
        }
    }

    private void getData() {
        Logger.e("Loading data - page = " + nextPageNumber);
        showProgress(true);
        Call<BaseResponse<List<OrderResponse>>> getOrdersByStoreCall = Flytekart.getApiService().getOrdersByUserId(accessToken,
                userDetails.getId(), BuildConfig.CLIENT_ID, nextPageNumber, Constants.DEFAULT_PAGE_SIZE);
        getOrdersByStoreCall.enqueue(new CustomCallback<BaseResponse<List<OrderResponse>>>() {
            @Override
            public void onFlytekartGenericErrorResponse(Call<BaseResponse<List<OrderResponse>>> call) {
                isLoadingOrders = false;
                Logger.e("Store List API call failure.");
                showProgress(false);
                Toast.makeText(getApplicationContext(), "Something went wrong. Please try again.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFlytekartSuccessResponse(Call<BaseResponse<List<OrderResponse>>> call, Response<BaseResponse<List<OrderResponse>>> response) {
                isLoadingOrders = false;
                Logger.e("Order list API success");
                showProgress(false);
                List<OrderResponse> orderResponses = response.body().getBody();
                setOrdersData(orderResponses);
            }

            @Override
            public void onFlytekartErrorResponse(Call<BaseResponse<List<OrderResponse>>> call, APIError responseBody) {
                isLoadingOrders = false;
                Logger.e("Order List API call  response status code : " + responseBody.getStatus());
                showProgress(false);
                Toast.makeText(getApplicationContext(), responseBody.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setOrdersData(List<OrderResponse> orderResponses) {
        if ((this.orderResponses == null || this.orderResponses.isEmpty()) &&
                (orderResponses == null || orderResponses.isEmpty())) {
            rvOrdersList.setVisibility(View.GONE);
            llNoRecordsFound.setVisibility(View.VISIBLE);
        } else {
            if (adapter == null) {
                llNoRecordsFound.setVisibility(View.GONE);
                rvOrdersList.setVisibility(View.VISIBLE);

                this.orderResponses = orderResponses;
                adapter = new OrdersAdapter(orderResponses);
                rvOrdersList.setAdapter(adapter);
            } else {
                int initialSize = this.orderResponses.size();
                this.orderResponses.addAll(orderResponses);
                adapter.notifyItemRangeInserted(initialSize, this.orderResponses.size() - 1);
            }
            nextPageNumber++;
        }
    }

    private void setListeners() {
        final GestureDetector gestureDetector = new GestureDetector(getApplicationContext(), new GestureDetector.SimpleOnGestureListener() {

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                return true;
            }

        });

        rvOrdersList.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
                View child = rv.findChildViewUnder(e.getX(), e.getY());
                if (child != null && gestureDetector.onTouchEvent(e)) {
                    int pos = rv.getChildAdapterPosition(child);
                    onOrderClicked(orderResponses.get(pos));
                }
                return false;
            }

            @Override
            public void onTouchEvent(RecyclerView rv, MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
    }

    /**
     * Take user to order details screen
     * @param orderResponse
     */
    private void onOrderClicked(OrderResponse orderResponse) {
        Intent itemIntent = new Intent(this, OrderDetailsActivity.class);
        itemIntent.putExtra(Constants.ORDER, orderResponse);
        startActivity(itemIntent);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_not_logged_in: {
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;
            }
        }
    }

    public void showProgress(boolean show) {
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(this);
            }
            progressDialog.setMessage(getResources().getString(R.string.progress_please_wait));
            progressDialog.setCancelable(false);
            progressDialog.show();
        } else if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }
}
