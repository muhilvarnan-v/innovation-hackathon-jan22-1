package com.flytekart.customer.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.flytekart.customer.Flytekart;
import com.flytekart.customer.models.Address;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Utilities {
    public static SharedPreferences getSharedPreferences() {
        return Flytekart.getInstance().getApplicationContext()
                .getSharedPreferences(Flytekart.class.getSimpleName(), Context.MODE_PRIVATE);
    }

    public static String getFormattedCalendarString(String timeString) {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sourceSdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSz", Locale.ENGLISH);
        SimpleDateFormat resultSdf = new SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.ENGLISH);
        try {
            cal.setTime(sourceSdf.parse(timeString));
            return resultSdf.format(cal.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return Constants.EMPTY;
    }

    public static String getFormattedOrderStatus(String orderStatus) {
        switch (orderStatus) {
            case "IN_PROGRESS":
                return "In progress";
            case "PLACED":
                return "Placed";
            case "CANCELED":
                return "Canceled";
            case "ACCEPTED":
                return "Accepted";
            case "PROCESSING":
                return "Processing";
            case "PROCESSED":
                return "Processed";
            case "OUT_FOR_DELIVERY":
                return "Out for delivery";
            case "DELIVERED":
                return "Delivered";
            default:
                return Constants.EMPTY;
        }
    }

    public static String getFormattedMoney(double moneyDouble) {
        BigDecimal bigDecimal = new BigDecimal(moneyDouble)
                .setScale(2, RoundingMode.HALF_UP);
        StringBuilder builder = new StringBuilder();
        builder.append(Constants.CURRENCY_RUPEE_PREFIX).append(Constants.SPACE).append(bigDecimal.toString());
        return builder.toString();
    }

    public static String getAddressString(Address address) {
        StringBuilder builder = new StringBuilder();
        if (address.getLine1() != null && !address.getLine1().isEmpty()) {
            builder.append(address.getLine1());
        }
        if (address.getLine2() != null && !address.getLine2().isEmpty()) {
            if (!builder.toString().isEmpty()) builder.append(Constants.COMMA_SPACE);
            builder.append(address.getLine2());
        }
        if (address.getCity() != null) {
            if (!builder.toString().isEmpty()) builder.append(Constants.COMMA_SPACE);
            builder.append(address.getCity());
        }
        if (address.getCity() != null) {
            if (!builder.toString().isEmpty()) builder.append(Constants.COMMA_SPACE);
            builder.append(address.getState());
        }
        if (address.getCountry() != null) {
            if (!builder.toString().isEmpty()) builder.append(Constants.COMMA_SPACE);
            builder.append(address.getCountry());
        }
        if (address.getZip() != null) {
            if (!builder.toString().isEmpty()) builder.append(Constants.COMMA_SPACE);
            builder.append(address.getZip());
        }
        return builder.toString();
    }
}
