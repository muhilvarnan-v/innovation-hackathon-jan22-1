package com.flytekart.customer.ui.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import com.flytekart.customer.R;

import java.util.ArrayList;
import java.util.List;

public class ViewPagerIndicator extends LinearLayout {
    private int pageCount = 0;
    private int selectedIndex = 0;
    private int count = 0;
    private int itemSize = 0;
    private int itemMargin = 0;
    private static final float SCALE = 1.3f;
    private static final int NO_SCALE = 1;

    private List<ImageView> indicatorImages;

    public ViewPagerIndicator(Context context) {
        this(context, null);
    }

    public ViewPagerIndicator(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ViewPagerIndicator(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setOrientation(HORIZONTAL);
        final TypedArray attributes = context.getTheme().obtainStyledAttributes(attrs, R.styleable.ViewPagerIndicator, 0, 0);
        try {
            count = attributes.getInteger(R.styleable.ViewPagerIndicator_itemCount, 5);
            itemSize = attributes.getDimensionPixelSize(R.styleable.ViewPagerIndicator_itemSize, 20);
            itemMargin = attributes.getDimensionPixelSize(R.styleable.ViewPagerIndicator_itemMargin, 20);
        } finally {
            attributes.recycle();
        }
        if (isInEditMode()) {
            createEditModeLayout();
        }
    }

    private void createEditModeLayout() {
        for (int i = 0; i < count; i++) {
            addView(createView());
        }
    }

    private void setPageCount(int pageCount) {
        this.pageCount = pageCount;
        selectedIndex = 0;

        removeAllViews();

        indicatorImages = new ArrayList<>(pageCount);
        for (int i = 0; i < pageCount; i++) {
            ImageView imageView = createView();
            indicatorImages.add(imageView);
            addView(imageView);
        }
        setSelectedIndex(selectedIndex);
    }

    private ImageView createView() {
        ImageView imageView = new ImageView(getContext());
        LayoutParams layoutParams = new LayoutParams(itemSize, itemSize);
        layoutParams.setMargins(itemMargin, itemMargin, itemMargin, itemMargin);
        imageView.setLayoutParams(layoutParams);
        //imageView.setImageResource(R.drawable.selected_pager_indicator);
        imageView.setBackgroundResource(R.drawable.selected_pager_indicator);
        return imageView;
    }

    private void setSelectedIndex(int selectedIndex) {
        if (selectedIndex < 0 || selectedIndex > pageCount - 1) {
            return;
        }

        final ImageView unselectedView = indicatorImages.get(this.selectedIndex);
        unselectedView.animate().scaleX(NO_SCALE).scaleY(NO_SCALE).setDuration(300).start();

        final ImageView selectedView = indicatorImages.get(selectedIndex);
        selectedView.animate().scaleX(SCALE).scaleY(SCALE).setDuration(300).start();

        this.selectedIndex = selectedIndex;
    }

    public void setViewPager(ViewPager viewPager) {
        setPageCount(viewPager.getAdapter().getCount());
        viewPager.addOnPageChangeListener(new IndicatorOnPageChangeListener());
    }

    private class IndicatorOnPageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            setSelectedIndex(position);
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    }
}
